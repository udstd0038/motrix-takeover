//#region src/shared/notifications.ts
var NOTIFICATIONS_DEFAULT = {
	master: true,
	confirm: false,
	error: true,
	reminder: true
};
function isSeverityEnabled(cfg, severity) {
	return cfg.master && cfg[severity];
}
//#endregion
//#region src/shared/logLevel.ts
var LOG_LEVEL_KEY = "motrix.logLevel";
var DEFAULT_LOG_LEVEL = "info";
var LOG_LEVEL_RANK = {
	silent: 0,
	error: 1,
	warn: 2,
	info: 3,
	debug: 4
};
function parseLogLevel(v) {
	return v === "silent" || v === "error" || v === "warn" || v === "info" || v === "debug" ? v : null;
}
async function getLogLevel() {
	return parseLogLevel((await browser.storage.local.get("motrix.logLevel"))["motrix.logLevel"]) ?? "info";
}
async function setLogLevel(v) {
	await browser.storage.local.set({ [LOG_LEVEL_KEY]: v });
}
//#endregion
export { parseLogLevel as a, isSeverityEnabled as c, getLogLevel as i, LOG_LEVEL_KEY as n, setLogLevel as o, LOG_LEVEL_RANK as r, NOTIFICATIONS_DEFAULT as s, DEFAULT_LOG_LEVEL as t };

//# sourceMappingURL=logLevel-DcvbLdwE.js.map