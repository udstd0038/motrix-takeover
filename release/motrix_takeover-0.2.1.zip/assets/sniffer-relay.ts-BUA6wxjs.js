import { l as shouldExcludeHost, u as isWebStoreBuild } from "./media-oiN-I4sB.js";
import { t as installSniffer } from "./mediaSniffer-lZsBbi9G.js";
//#region src/content/imageThumbnail.ts
var DEFAULT_MAX_EDGE = 72;
var MIN_MAX_EDGE = 48;
var MAX_MAX_EDGE = 96;
var MAX_URL_LENGTH$1 = 32768;
var MAX_DATA_URL_BYTES = 49152;
var MAX_IMAGES_SCANNED = 4096;
var MAX_CACHE_ENTRIES = 16;
var SUCCESS_CACHE_MS = 15e3;
var MISS_CACHE_MS = 1e3;
var ENCODE_QUALITY = .78;
function normalizeUrl(value, baseUrl) {
	if (typeof value !== "string" || value.length === 0 || value.length > MAX_URL_LENGTH$1) return null;
	try {
		const normalized = baseUrl ? new URL(value, baseUrl) : new URL(value);
		if (normalized.protocol !== "http:" && normalized.protocol !== "https:" && normalized.protocol !== "blob:" && normalized.protocol !== "data:") return null;
		normalized.hash = "";
		return normalized.href;
	} catch {
		return null;
	}
}
function readBaseUrl(doc) {
	try {
		const value = doc.baseURI;
		return typeof value === "string" && value.length <= MAX_URL_LENGTH$1 ? value : void 0;
	} catch {
		return;
	}
}
function maxEdgeFrom(value) {
	if (typeof value !== "number" || !Number.isFinite(value)) return DEFAULT_MAX_EDGE;
	return Math.min(MAX_MAX_EDGE, Math.max(MIN_MAX_EDGE, Math.round(value)));
}
function readImageUrl(image, key, baseUrl) {
	try {
		return normalizeUrl(image[key], baseUrl);
	} catch {
		return null;
	}
}
function positiveImageDimension(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 && value <= 65535 ? value : null;
}
function readRenderableDimensions(image) {
	try {
		if (!image.isConnected || image.complete !== true) return null;
		const width = positiveImageDimension(image.naturalWidth);
		const height = positiveImageDimension(image.naturalHeight);
		return width !== null && height !== null ? {
			width,
			height
		} : null;
	} catch {
		return null;
	}
}
function imageAt(images, index) {
	try {
		return images.item(index);
	} catch {
		return null;
	}
}
function findRenderedImage(doc, normalizedUrl, baseUrl) {
	let images;
	let count;
	try {
		images = doc.images;
		count = Math.min(images.length, MAX_IMAGES_SCANNED);
	} catch {
		return null;
	}
	for (let index = 0; index < count; index += 1) {
		const image = imageAt(images, index);
		if (!image) continue;
		const currentSrc = readImageUrl(image, "currentSrc", baseUrl);
		const src = readImageUrl(image, "src", baseUrl);
		if (currentSrc !== normalizedUrl && src !== normalizedUrl) continue;
		const dimensions = readRenderableDimensions(image);
		if (dimensions) return {
			image,
			...dimensions
		};
	}
	return null;
}
function encodeSquareThumbnail(doc, image, width, height, maxEdge) {
	let canvas;
	try {
		canvas = doc.createElement("canvas");
		canvas.width = maxEdge;
		canvas.height = maxEdge;
		const context = canvas.getContext("2d", { alpha: false });
		if (!context) return null;
		const sourceEdge = Math.min(width, height);
		const sourceX = (width - sourceEdge) / 2;
		const sourceY = (height - sourceEdge) / 2;
		context.drawImage(image, sourceX, sourceY, sourceEdge, sourceEdge, 0, 0, maxEdge, maxEdge);
		const dataUrl = canvas.toDataURL("image/webp", ENCODE_QUALITY);
		if (typeof dataUrl !== "string" || dataUrl.length > MAX_DATA_URL_BYTES || !/^data:image\/(?:webp|png);base64,[a-z\d+/]*={0,2}$/i.test(dataUrl)) return null;
		return dataUrl;
	} catch {
		return null;
	} finally {
		if (canvas) {
			canvas.width = 0;
			canvas.height = 0;
		}
	}
}
/**
* Produces small pixels only from an image the page has already loaded into
* an <img>. It never creates an Image or performs a fetch, so a thumbnail
* request cannot cause new network traffic or inherit page credentials.
*/
var RenderedImageThumbnailSampler = class {
	doc;
	now;
	cache = /* @__PURE__ */ new Map();
	constructor(doc = document, now = Date.now) {
		this.doc = doc;
		this.now = now;
	}
	capture(request) {
		try {
			if (typeof request !== "object" || request === null) return { dataUrl: null };
			const raw = request;
			const baseUrl = readBaseUrl(this.doc);
			const normalizedUrl = normalizeUrl(raw.url, baseUrl);
			if (!normalizedUrl) return { dataUrl: null };
			const maxEdge = maxEdgeFrom(raw.maxEdge);
			const cacheKey = `${normalizedUrl}\u0000${maxEdge}`;
			const now = this.now();
			const cached = this.cache.get(cacheKey);
			if (cached && cached.expiresAt > now) {
				this.cache.delete(cacheKey);
				this.cache.set(cacheKey, cached);
				return { dataUrl: cached.dataUrl };
			}
			if (cached) this.cache.delete(cacheKey);
			const match = findRenderedImage(this.doc, normalizedUrl, baseUrl);
			const dataUrl = match ? encodeSquareThumbnail(this.doc, match.image, match.width, match.height, maxEdge) : null;
			this.remember(cacheKey, dataUrl, now);
			return { dataUrl };
		} catch {
			return { dataUrl: null };
		}
	}
	remember(key, dataUrl, now) {
		while (this.cache.size >= MAX_CACHE_ENTRIES) {
			const oldest = this.cache.keys().next().value;
			if (typeof oldest !== "string") break;
			this.cache.delete(oldest);
		}
		this.cache.set(key, {
			dataUrl,
			expiresAt: now + (dataUrl ? SUCCESS_CACHE_MS : MISS_CACHE_MS)
		});
	}
};
var imageThumbnailSampler = new RenderedImageThumbnailSampler();
//#endregion
//#region src/content/sniffer-relay.ts
var ENTRY_SOURCE = "motrix-sniffer";
var RELAY_SOURCE = "motrix-sniffer-relay";
var MAX_ITEMS_PER_PACKET = 100;
var MAX_PACKET_BYTES = 262144;
var PACKET_OVERHEAD_BYTES = 8192;
var MAX_URL_LENGTH = 32768;
var MAX_TITLE_LENGTH = 512;
var MAX_TEXT_LENGTH = 512;
var MAX_EVIDENCE = 8;
var MAX_QUEUE_ITEMS = 400;
var MAX_QUEUE_BYTES = 786432;
var WINDOW_MS = 1e3;
var MAX_WINDOW_ITEMS = 300;
var MAX_WINDOW_BYTES = 524288;
var FIREFOX_MAIN_FALLBACK_MS = 500;
var encoder = new TextEncoder();
function boundedString(value, maxLength) {
	return typeof value === "string" && value.length > 0 ? value.slice(0, maxLength) : void 0;
}
function boundedNumber(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 ? value : void 0;
}
function stringBytes(value) {
	return encoder.encode(value).byteLength;
}
function boundedItems(value) {
	if (!Array.isArray(value)) return null;
	const items = [];
	let packetBytes = PACKET_OVERHEAD_BYTES;
	for (const raw of value.slice(0, MAX_ITEMS_PER_PACKET)) {
		if (typeof raw !== "object" || raw === null || Array.isArray(raw)) continue;
		const item = raw;
		const kind = boundedString(item.kind, 16);
		const url = boundedString(item.url, MAX_URL_LENGTH);
		const pageUrl = boundedString(item.pageUrl, MAX_URL_LENGTH);
		const pageTitle = boundedString(item.pageTitle, MAX_TITLE_LENGTH);
		if (!kind || !url || !pageUrl || !pageTitle) continue;
		const normalized = {
			kind,
			url,
			pageUrl,
			pageTitle,
			detectedAt: boundedNumber(item.detectedAt) ?? Date.now()
		};
		let itemBytes = 256 + stringBytes(kind) + stringBytes(url) + stringBytes(pageUrl) + stringBytes(pageTitle);
		const addOptionalString = (key, rawValue, maxLength) => {
			const text = boundedString(rawValue, maxLength);
			if (!text) return false;
			const bytes = stringBytes(text) + key.length + 8;
			if (packetBytes + itemBytes + bytes > MAX_PACKET_BYTES) return false;
			normalized[key] = text;
			itemBytes += bytes;
			return true;
		};
		const audioUrlAdded = addOptionalString("audioUrl", item.audioUrl, MAX_URL_LENGTH);
		if (kind === "mux" && !audioUrlAdded) continue;
		addOptionalString("mimeType", item.mimeType, 256);
		addOptionalString("category", item.category, 16);
		addOptionalString("alt", item.alt, MAX_TEXT_LENGTH);
		addOptionalString("suggestedFilename", item.suggestedFilename, MAX_TEXT_LENGTH);
		for (const [key, rawValue] of [
			["width", item.width],
			["height", item.height],
			["sizeBytes", item.sizeBytes]
		]) {
			const number = boundedNumber(rawValue);
			if (number !== void 0) normalized[key] = number;
		}
		if (typeof item.previewable === "boolean") normalized.previewable = item.previewable;
		if (Array.isArray(item.evidence)) {
			const evidence = [];
			for (const rawEvidence of item.evidence.slice(0, MAX_EVIDENCE)) {
				const entry = boundedString(rawEvidence, 32);
				if (!entry) continue;
				const bytes = stringBytes(entry) + 4;
				if (packetBytes + itemBytes + bytes > MAX_PACKET_BYTES) break;
				itemBytes += bytes;
				evidence.push(entry);
			}
			if (evidence.length > 0) normalized.evidence = evidence;
		}
		const serializedBytes = stringBytes(JSON.stringify(normalized)) + 1;
		if (packetBytes + serializedBytes > MAX_PACKET_BYTES) break;
		packetBytes += serializedBytes;
		items.push({
			value: normalized,
			bytes: serializedBytes
		});
	}
	return items;
}
var relayWindow = window;
var currentPage = () => ({
	pageUrl: location.href,
	pageTitle: document.title
});
var firefoxFallbackAllowed = () => !(isWebStoreBuild() && shouldExcludeHost(location.hostname, true));
var announce = () => {
	window.postMessage({
		source: RELAY_SOURCE,
		type: "ready"
	}, "*");
};
if (!relayWindow.__motrixSnifferRelayInstalled) {
	relayWindow.__motrixSnifferRelayInstalled = true;
	relayWindow.__motrixSnifferRelayAnnounce = announce;
	const queue = [];
	let queuedBytes = 0;
	let flushScheduled = false;
	let windowStartedAt = Date.now();
	let windowItems = 0;
	let windowBytes = 0;
	let mainHandshakeSeen = false;
	let firefoxFallbackTimer;
	const resetWindowIfNeeded = () => {
		if (Date.now() - windowStartedAt < WINDOW_MS) return;
		windowStartedAt = Date.now();
		windowItems = 0;
		windowBytes = 0;
	};
	const safelySend = (items) => {
		try {
			const message = {
				kind: "bg.mediaDetected",
				payload: {
					tabUrl: location.href,
					items
				}
			};
			if (stringBytes(JSON.stringify(message)) > MAX_PACKET_BYTES) return;
			const result = typeof browser !== "undefined" ? browser.runtime.sendMessage(message) : chrome.runtime.sendMessage(message);
			if (result && typeof result.catch === "function") result.catch(() => void 0);
		} catch {}
	};
	const scheduleFlush = (delay = 0) => {
		if (flushScheduled) return;
		flushScheduled = true;
		if (delay > 0) window.setTimeout(() => {
			flushScheduled = false;
			flush();
		}, delay);
		else queueMicrotask(() => {
			flushScheduled = false;
			flush();
		});
	};
	const flush = () => {
		resetWindowIfNeeded();
		if (queue.length === 0) return;
		if (windowItems >= MAX_WINDOW_ITEMS || windowBytes >= MAX_WINDOW_BYTES) {
			scheduleFlush(Math.max(1, WINDOW_MS - (Date.now() - windowStartedAt)));
			return;
		}
		const batch = [];
		let batchBytes = PACKET_OVERHEAD_BYTES;
		while (queue.length > 0 && batch.length < MAX_ITEMS_PER_PACKET) {
			const next = queue[0];
			if (!next) break;
			if (batchBytes + next.bytes > MAX_PACKET_BYTES || windowItems + batch.length + 1 > MAX_WINDOW_ITEMS || windowBytes + batchBytes + next.bytes > MAX_WINDOW_BYTES) break;
			queue.shift();
			queuedBytes -= next.bytes;
			batch.push(next.value);
			batchBytes += next.bytes;
		}
		if (batch.length > 0) {
			windowItems += batch.length;
			windowBytes += batchBytes;
			safelySend(batch);
		}
		if (queue.length > 0) {
			const next = queue[0];
			const windowExhausted = windowItems >= MAX_WINDOW_ITEMS || windowBytes >= MAX_WINDOW_BYTES || batch.length === 0 && next !== void 0 && windowBytes + PACKET_OVERHEAD_BYTES + next.bytes > MAX_WINDOW_BYTES;
			scheduleFlush(windowExhausted ? Math.max(1, WINDOW_MS - (Date.now() - windowStartedAt)) : 0);
		}
	};
	const enqueue = (items) => {
		for (const item of items) {
			if (queue.length >= MAX_QUEUE_ITEMS || queuedBytes + item.bytes > MAX_QUEUE_BYTES) break;
			queue.push(item);
			queuedBytes += item.bytes;
		}
		if (queue.length > 0) scheduleFlush();
	};
	const stopFirefoxFallback = () => {
		mainHandshakeSeen = true;
		if (firefoxFallbackTimer !== void 0) {
			window.clearTimeout(firefoxFallbackTimer);
			firefoxFallbackTimer = void 0;
		}
		relayWindow.__motrixSnifferIsolatedFallback?.uninstall();
		delete relayWindow.__motrixSnifferIsolatedFallback;
	};
	const startFirefoxFallback = () => {
		if (mainHandshakeSeen || !firefoxFallbackAllowed() || relayWindow.__motrixSnifferIsolatedFallback) return;
		relayWindow.__motrixSnifferIsolatedFallback = installSniffer((items) => {
			const bounded = boundedItems(items);
			if (bounded && bounded.length > 0) enqueue(bounded);
		}, currentPage(), currentPage);
	};
	window.addEventListener("message", (event) => {
		if (event.source !== window) return;
		const data = event.data;
		if (data?.source !== ENTRY_SOURCE) return;
		if (data.type === "hello" || data.type === "ack") stopFirefoxFallback();
		if (data.type === "hello") {
			announce();
			return;
		}
		if (data.type === "ack") return;
		if (data.type !== void 0 && data.type !== "media") return;
		const items = boundedItems(data.items);
		if (!items || items.length === 0) return;
		enqueue(items);
	});
	const thumbnailListener = (rawMessage, _sender, sendResponse) => {
		let kind;
		let payload;
		try {
			const envelope = rawMessage;
			kind = envelope?.kind;
			payload = envelope?.payload;
		} catch {
			return false;
		}
		if (kind !== "content.imageThumbnail") return false;
		Promise.resolve().then(() => imageThumbnailSampler.capture(payload)).then((response) => {
			try {
				sendResponse(response);
			} catch {}
		}, () => {
			try {
				sendResponse({ dataUrl: null });
			} catch {}
		});
		return true;
	};
	if (typeof browser !== "undefined") browser.runtime.onMessage.addListener(thumbnailListener);
	else chrome.runtime.onMessage.addListener(thumbnailListener);
	if (firefoxFallbackAllowed()) firefoxFallbackTimer = window.setTimeout(startFirefoxFallback, FIREFOX_MAIN_FALLBACK_MS);
}
relayWindow.__motrixSnifferRelayAnnounce?.();
//#endregion

//# sourceMappingURL=sniffer-relay.ts-BUA6wxjs.js.map