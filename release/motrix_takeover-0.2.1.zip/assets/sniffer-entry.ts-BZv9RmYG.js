import { l as shouldExcludeHost, u as isWebStoreBuild } from "./media-oiN-I4sB.js";
import { t as installSniffer } from "./mediaSniffer-lZsBbi9G.js";
//#region src/content/sniffer-entry.ts
var ENTRY_SOURCE = "motrix-sniffer";
var RELAY_SOURCE = "motrix-sniffer-relay";
var MAX_PENDING_REPORTS = 10;
var snifferWindow = window;
var currentPage = () => ({
	pageUrl: location.href,
	pageTitle: document.title
});
function webStorePageExcluded() {
	return isWebStoreBuild() && shouldExcludeHost(location.hostname, true);
}
if (!webStorePageExcluded()) {
	if (snifferWindow.__motrixSniffer) snifferWindow.__motrixSniffer.scan(currentPage());
	else {
		let relayReady = false;
		const pending = [];
		const postItems = (items) => {
			window.postMessage({
				source: ENTRY_SOURCE,
				type: "media",
				items
			}, "*");
		};
		const flush = () => {
			relayReady = true;
			for (const items of pending.splice(0)) postItems(items);
			window.postMessage({
				source: ENTRY_SOURCE,
				type: "ack"
			}, "*");
		};
		const onRelayMessage = (event) => {
			if (event.source !== window) return;
			const message = event.data;
			if (message?.source === RELAY_SOURCE && message.type === "ready") flush();
		};
		window.addEventListener("message", onRelayMessage);
		const installed = installSniffer((items) => {
			if (relayReady) postItems(items);
			else {
				if (pending.length >= MAX_PENDING_REPORTS) pending.shift();
				pending.push(items);
			}
		}, currentPage(), currentPage);
		snifferWindow.__motrixSniffer = {
			scan: installed.scan,
			uninstall: () => {
				window.removeEventListener("message", onRelayMessage);
				pending.length = 0;
				installed.uninstall();
			}
		};
		window.postMessage({
			source: ENTRY_SOURCE,
			type: "hello"
		}, "*");
	}
}
//#endregion

//# sourceMappingURL=sniffer-entry.ts-BZv9RmYG.js.map