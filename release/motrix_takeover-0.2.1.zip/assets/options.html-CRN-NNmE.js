import { H as normalizeRemoteEndpoint, N as LOCAL_ENDPOINT_ID, S as string, U as parseRemoteEndpoint, a as resolveDefaultLocale, at as instance, c as setLocaleOverride, d as _enum, et as send, i as initI18n, j as supportsAutomaticTakeover, l as LOCALE_NAMES, p as boolean, s as getLocaleOverride, st as __toESM, t as hasNativeMessagingSupport, u as SUPPORTED_LOCALES, v as object } from "./platformCapabilities-BhYiGJPy.js";
import { $ as usePositioner, $t as fastComponent, A as SelectTrigger, Bn as triggerPress, C as AlertTitle, Cr as ChevronRight, D as SelectContent, Dr as require_client, Dt as usePopupRootStore, E as Select, En as createChangeEventDetails, Er as createLucideIcon, Et as usePopupInteractionProps, Fn as none, G as FieldContent, Gn as cn, Gt as POPUP_COLLISION_AVOIDANCE, H as Switch, Ht as useFloatingPortalNode, J as FieldGroup, Jt as useValueAsRef, K as FieldDescription, Kn as cva, Mn as imperativeAction, Mt as useDismiss, O as SelectGroup, Or as require_react_dom, Q as Label, Qt as useTimeout, S as AlertDescription, Sr as CircleAlert, T as setThemeOverride, Tr as Check, Tt as useOpenStateTransitions, U as Input, Un as Button, V as Textarea, W as Field, Wn as buttonVariants, X as Separator, Xt as getDelay, Y as FieldLabel, Yn as EMPTY_OBJECT, Yt as addEventListener, Zt as Timeout, _ as AlertDialogFooter, _n as isMouseLikePointerType, _r as Plus, _t as PopupTriggerMap, a as DialogClose, ar as useStableCallback, at as triggerOpenStateMapping, b as Alert, br as Laptop, bt as applyPopupOpenChange, c as DialogFooter, cn as useOpenChangeComplete, cr as getWindow, d as Spinner, dt as useHoverInteractionSharedState, en as fastComponentRef, et as getDisabledMountTransitionStyles, f as AlertDialog, fr as require_jsx_runtime, ft as useFocus, g as AlertDialogDescription, gr as RefreshCw, gt as popupStoreSelectors, h as AlertDialogContent, hr as Server, ht as createPopupFloatingRootContext, i as Dialog, in as TabsTrigger, ir as useIsoLayoutEffect, j as SelectValue, jt as ReactStore, k as SelectItem, kn as disabled, kr as require_react, kt as useTriggerDataForwarding, l as DialogHeader, lr as isElement, lt as useHoverReferenceInteraction, m as AlertDialogCancel, mr as Trash2, mt as createInitialPopupStoreState, n as connectionErrorKey, nn as TabsContent, nr as formatErrorMessage, nt as popupStateMapping, o as DialogContent, ot as safePolygon, p as AlertDialogAction, pr as useTranslation, pt as usePopupHandleStore, q as FieldError, qn as useRenderElement, r as PairingCodePanel, rn as TabsList, rr as mergeProps, rt as popupTransitionStateMapping, s as DialogDescription, t as initTheme, tn as Tabs, tt as useAnchorPositioning, u as DialogTitle, ut as useHoverFloatingInteraction, v as AlertDialogHeader, vn as contains, vt as FOCUSABLE_POPUP_PROPS, w as getThemeOverride, wn as useBaseUiId, wt as useImplicitActiveTrigger, x as AlertAction, xr as KeyRound, y as AlertDialogTitle, yn as getTarget, yt as PopupHandleAttachment, zn as triggerHover } from "./theme-DX7Zessj.js";
import { i as getLogLevel, o as setLogLevel, s as NOTIFICATIONS_DEFAULT } from "./logLevel-DcvbLdwE.js";
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var BookOpenText = createLucideIcon("book-open-text", [
	["path", {
		d: "M12 5v16",
		key: "1f6ucr"
	}],
	["path", {
		d: "M16 13h2",
		key: "weia3s"
	}],
	["path", {
		d: "M16 9h2",
		key: "1n7gjm"
	}],
	["path", {
		d: "M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z",
		key: "1fyvmf"
	}],
	["path", {
		d: "M6 13h2",
		key: "1cckiz"
	}],
	["path", {
		d: "M6 9h2",
		key: "1k7j9f"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Bug = createLucideIcon("bug", [
	["path", {
		d: "M12 20v-9",
		key: "1qisl0"
	}],
	["path", {
		d: "M14 7a4 4 0 0 1 4 4v3a6 6 0 0 1-12 0v-3a4 4 0 0 1 4-4z",
		key: "uouzyp"
	}],
	["path", {
		d: "M14.12 3.88 16 2",
		key: "qol33r"
	}],
	["path", {
		d: "M21 21a4 4 0 0 0-3.81-4",
		key: "1b0z45"
	}],
	["path", {
		d: "M21 5a4 4 0 0 1-3.55 3.97",
		key: "5cxbf6"
	}],
	["path", {
		d: "M22 13h-4",
		key: "1jl80f"
	}],
	["path", {
		d: "M3 21a4 4 0 0 1 3.81-4",
		key: "1fjd4g"
	}],
	["path", {
		d: "M3 5a4 4 0 0 0 3.55 3.97",
		key: "1d7oge"
	}],
	["path", {
		d: "M6 13H2",
		key: "82j7cp"
	}],
	["path", {
		d: "m8 2 1.88 1.88",
		key: "fmnt4t"
	}],
	["path", {
		d: "M9 7.13V6a3 3 0 1 1 6 0v1.13",
		key: "1vgav8"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Copy = createLucideIcon("copy", [["rect", {
	width: "14",
	height: "14",
	x: "8",
	y: "8",
	rx: "2",
	ry: "2",
	key: "17jyea"
}], ["path", {
	d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",
	key: "zix9uf"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Earth = createLucideIcon("earth", [
	["path", {
		d: "M21.54 15H17a2 2 0 0 0-2 2v4.54",
		key: "1djwo0"
	}],
	["path", {
		d: "M7 3.34V5a3 3 0 0 0 3 3a2 2 0 0 1 2 2c0 1.1.9 2 2 2a2 2 0 0 0 2-2c0-1.1.9-2 2-2h3.17",
		key: "1tzkfa"
	}],
	["path", {
		d: "M11 21.95V18a2 2 0 0 0-2-2a2 2 0 0 1-2-2v-1a2 2 0 0 0-2-2H2.05",
		key: "14pb5j"
	}],
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Pencil = createLucideIcon("pencil", [["path", {
	d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
	key: "1a8usu"
}], ["path", {
	d: "m15 5 4 4",
	key: "1mk7zo"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ShieldCheck = createLucideIcon("shield-check", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]);
//#endregion
//#region src/components/github-mark.tsx
var import_client = require_client();
var import_jsx_runtime = require_jsx_runtime();
function GitHubMark() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		fill: "currentColor",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 .7a11.5 11.5 0 0 0-3.64 22.4c.58.1.79-.25.79-.56v-2.23c-3.22.7-3.9-1.37-3.9-1.37-.53-1.34-1.29-1.7-1.29-1.7-1.05-.72.08-.7.08-.7 1.16.08 1.78 1.19 1.78 1.19 1.04 1.77 2.72 1.26 3.38.96.1-.75.4-1.26.74-1.55-2.57-.29-5.28-1.29-5.28-5.68 0-1.26.45-2.29 1.19-3.1-.12-.29-.52-1.47.11-3.06 0 0 .97-.31 3.16 1.18a10.9 10.9 0 0 1 5.75 0c2.2-1.49 3.16-1.18 3.16-1.18.63 1.59.23 2.77.11 3.06.74.81 1.19 1.84 1.19 3.1 0 4.4-2.71 5.38-5.29 5.67.42.36.79 1.06.79 2.14v3.17c0 .31.21.67.8.56A11.5 11.5 0 0 0 12 .7Z" })
	});
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/root/TooltipRootContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var TooltipRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useTooltipRootContext(optional) {
	const context = import_react.useContext(TooltipRootContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(72));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/floating-ui-react/components/FloatingDelayGroup.mjs
var FloatingDelayGroupContext = /*#__PURE__*/ import_react.createContext({
	hasProvider: false,
	timeoutMs: 0,
	delayRef: { current: 0 },
	initialDelayRef: { current: 0 },
	timeout: new Timeout(),
	currentIdRef: { current: null },
	currentContextRef: { current: null }
});
function resetDelayRef(delayRef, initialDelayRef) {
	delayRef.current = initialDelayRef.current;
}
/**
* Experimental next version of `FloatingDelayGroup` to become the default
* in the future. This component is not yet stable.
* Provides context for a group of floating elements that should share a
* `delay`. Unlike `FloatingDelayGroup`, `useDelayGroup` with this
* component does not cause a re-render of unrelated consumers of the
* context when the delay changes.
* @see https://floating-ui.com/docs/FloatingDelayGroup
* @internal
*/
function FloatingDelayGroup(props) {
	const { children, delay, timeoutMs = 0 } = props;
	const delayRef = import_react.useRef(delay);
	const initialDelayRef = import_react.useRef(delay);
	const currentIdRef = import_react.useRef(null);
	const currentContextRef = import_react.useRef(null);
	const timeout = useTimeout();
	useIsoLayoutEffect(() => {
		initialDelayRef.current = delay;
		if (!currentIdRef.current) {
			delayRef.current = delay;
			return;
		}
		delayRef.current = {
			open: getDelay(delayRef.current, "open"),
			close: getDelay(delay, "close")
		};
	}, [
		delay,
		currentIdRef,
		delayRef,
		initialDelayRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingDelayGroupContext.Provider, {
		value: import_react.useMemo(() => ({
			hasProvider: true,
			delayRef,
			initialDelayRef,
			currentIdRef,
			timeoutMs,
			currentContextRef,
			timeout
		}), [timeoutMs, timeout]),
		children
	});
}
/**
* Enables grouping when called inside a component that's a child of a
* `FloatingDelayGroup`.
* @see https://floating-ui.com/docs/FloatingDelayGroup
* @internal
*/
function useDelayGroup(context, options = { open: false }) {
	const { open } = options;
	const store = "rootStore" in context ? context.rootStore : context;
	const floatingId = store.useState("floatingId");
	const { currentIdRef, delayRef, timeoutMs, initialDelayRef, currentContextRef, hasProvider, timeout } = import_react.useContext(FloatingDelayGroupContext);
	const [isInstantPhase, setIsInstantPhase] = import_react.useState(false);
	const openRef = import_react.useRef(open);
	useIsoLayoutEffect(() => {
		openRef.current = open;
	}, [open]);
	useIsoLayoutEffect(() => {
		function unset() {
			currentContextRef.current?.setIsInstantPhase(false);
			currentIdRef.current = null;
			currentContextRef.current = null;
			delayRef.current = initialDelayRef.current;
			timeout.clear();
		}
		if (!currentIdRef.current) return;
		if (!open && currentIdRef.current === floatingId) {
			setIsInstantPhase(false);
			if (timeoutMs) {
				const closingId = floatingId;
				timeout.start(timeoutMs, () => {
					if (store.select("open") || currentIdRef.current && currentIdRef.current !== closingId) return;
					unset();
				});
				return () => {
					if (openRef.current || currentIdRef.current !== closingId) timeout.clear();
				};
			}
			unset();
		}
	}, [
		open,
		floatingId,
		currentIdRef,
		delayRef,
		timeoutMs,
		initialDelayRef,
		currentContextRef,
		timeout,
		store
	]);
	useIsoLayoutEffect(() => {
		if (!open) return;
		const prevContext = currentContextRef.current;
		const prevId = currentIdRef.current;
		timeout.clear();
		currentContextRef.current = {
			onOpenChange: store.setOpen,
			setIsInstantPhase
		};
		currentIdRef.current = floatingId;
		delayRef.current = {
			open: 0,
			close: getDelay(initialDelayRef.current, "close")
		};
		if (prevId !== null && prevId !== floatingId) {
			setIsInstantPhase(true);
			prevContext?.setIsInstantPhase(true);
			prevContext?.onOpenChange(false, createChangeEventDetails(none));
		} else {
			setIsInstantPhase(false);
			prevContext?.setIsInstantPhase(false);
		}
	}, [
		open,
		floatingId,
		store,
		currentIdRef,
		delayRef,
		initialDelayRef,
		currentContextRef,
		timeout
	]);
	useIsoLayoutEffect(() => {
		return () => {
			if (currentIdRef.current === floatingId) {
				currentContextRef.current = null;
				if (!openRef.current) return;
				currentIdRef.current = null;
				resetDelayRef(delayRef, initialDelayRef);
				timeout.clear();
			}
		};
	}, [
		currentContextRef,
		currentIdRef,
		delayRef,
		floatingId,
		initialDelayRef,
		timeout
	]);
	return import_react.useMemo(() => ({
		hasProvider,
		delayRef,
		isInstantPhase
	}), [
		hasProvider,
		delayRef,
		isInstantPhase
	]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/floating-ui-react/hooks/useClientPoint.mjs
function createVirtualElement(domElement, data) {
	let offsetX = null;
	let offsetY = null;
	let isAutoUpdateEvent = false;
	return {
		contextElement: domElement || void 0,
		getBoundingClientRect() {
			const domRect = domElement?.getBoundingClientRect() || {
				width: 0,
				height: 0,
				x: 0,
				y: 0
			};
			const isXAxis = data.axis === "x" || data.axis === "both";
			const isYAxis = data.axis === "y" || data.axis === "both";
			const canTrackCursorOnAutoUpdate = ["mouseenter", "mousemove"].includes(data.dataRef.current.openEvent?.type || "") && data.pointerType !== "touch";
			let width = domRect.width;
			let height = domRect.height;
			let x = domRect.x;
			let y = domRect.y;
			if (offsetX == null && data.x && isXAxis) offsetX = domRect.x - data.x;
			if (offsetY == null && data.y && isYAxis) offsetY = domRect.y - data.y;
			x -= offsetX || 0;
			y -= offsetY || 0;
			width = 0;
			height = 0;
			if (!isAutoUpdateEvent || canTrackCursorOnAutoUpdate) {
				width = data.axis === "y" ? domRect.width : 0;
				height = data.axis === "x" ? domRect.height : 0;
				x = isXAxis && data.x != null ? data.x : x;
				y = isYAxis && data.y != null ? data.y : y;
			} else if (isAutoUpdateEvent && !canTrackCursorOnAutoUpdate) {
				height = data.axis === "x" ? domRect.height : height;
				width = data.axis === "y" ? domRect.width : width;
			}
			isAutoUpdateEvent = true;
			return {
				width,
				height,
				x,
				y,
				top: y,
				right: x + width,
				bottom: y + height,
				left: x
			};
		}
	};
}
function isMouseBasedEvent(event) {
	return event != null && event.clientX != null;
}
/**
* Positions the floating element relative to a client point (in the viewport),
* such as the mouse position. By default, it follows the mouse cursor.
* @see https://floating-ui.com/docs/useClientPoint
*/
function useClientPoint(context, props = {}) {
	const { enabled = true, axis = "both" } = props;
	const store = "rootStore" in context ? context.rootStore : context;
	const open = store.useState("open");
	const floating = store.useState("floatingElement");
	const domReference = store.useState("domReferenceElement");
	const dataRef = store.context.dataRef;
	const initialRef = import_react.useRef(false);
	const cleanupListenerRef = import_react.useRef(null);
	const [pointerType, setPointerType] = import_react.useState();
	const [reactive, setReactive] = import_react.useState([]);
	const resetReference = useStableCallback((reference) => {
		store.set("positionReference", reference);
	});
	const setReference = useStableCallback((newX, newY, referenceElement) => {
		if (initialRef.current) return;
		if (dataRef.current.openEvent && !isMouseBasedEvent(dataRef.current.openEvent)) return;
		store.set("positionReference", createVirtualElement(referenceElement ?? domReference, {
			x: newX,
			y: newY,
			axis,
			dataRef,
			pointerType
		}));
	});
	const handleReferenceEnterOrMove = useStableCallback((event) => {
		if (!open) setReference(event.clientX, event.clientY, event.currentTarget);
		else if (!cleanupListenerRef.current) {
			setReference(event.clientX, event.clientY, event.currentTarget);
			setReactive([]);
		}
	});
	const openCheck = isMouseLikePointerType(pointerType) ? floating : open;
	import_react.useEffect(() => {
		if (!enabled) {
			resetReference(domReference);
			return;
		}
		if (!openCheck) return;
		function cleanupListener() {
			cleanupListenerRef.current?.();
			cleanupListenerRef.current = null;
		}
		const win = getWindow(floating);
		function handleMouseMove(event) {
			const target = getTarget(event);
			if (!contains(floating, target)) setReference(event.clientX, event.clientY);
			else cleanupListener();
		}
		if (!dataRef.current.openEvent || isMouseBasedEvent(dataRef.current.openEvent)) cleanupListenerRef.current = addEventListener(win, "mousemove", handleMouseMove);
		else resetReference(domReference);
		return cleanupListener;
	}, [
		openCheck,
		enabled,
		floating,
		dataRef,
		domReference,
		store,
		setReference,
		resetReference,
		reactive
	]);
	import_react.useEffect(() => () => {
		store.set("positionReference", null);
	}, [store]);
	import_react.useEffect(() => {
		if (enabled && !floating) initialRef.current = false;
	}, [enabled, floating]);
	import_react.useEffect(() => {
		if (!enabled && open) initialRef.current = true;
	}, [enabled, open]);
	const reference = import_react.useMemo(() => {
		function setPointerTypeRef(event) {
			setPointerType(event.pointerType);
		}
		return {
			onPointerDown: setPointerTypeRef,
			onPointerEnter: setPointerTypeRef,
			onMouseMove: handleReferenceEnterOrMove,
			onMouseEnter: handleReferenceEnterOrMove
		};
	}, [handleReferenceEnterOrMove]);
	return import_react.useMemo(() => enabled ? {
		reference,
		trigger: reference
	} : {}, [enabled, reference]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/store/TooltipStore.mjs
var selectors = {
	...popupStoreSelectors,
	disabled: (state) => state.disabled,
	instantType: (state) => state.instantType,
	isInstantPhase: (state) => state.isInstantPhase,
	trackCursorAxis: (state) => state.trackCursorAxis,
	disableHoverablePopup: (state) => state.disableHoverablePopup,
	lastOpenChangeReason: (state) => state.openChangeReason,
	closeOnClick: (state) => state.closeOnClick,
	closeDelay: (state) => state.closeDelay,
	adaptiveOrigin: (state) => state.adaptiveOrigin
};
/**
* The store view that detached handle-backed triggers read from. Both the real `TooltipStore` and
* the inert fallback store satisfy it, so a trigger can read from whichever store the handle
* currently exposes. Narrowed to the members a trigger actually uses — the trigger-data members plus
* `setOpen`/`cancelPendingOpen` (called directly by the trigger) and `useSyncedValue` — so the
* exposed surface can't bypass the open-change pipeline; on the detached fallback store every one of
* these mutations is a no-op.
*/
var TooltipStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		super(createInitialState(initialState, triggerElements, floatingId, nested), createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		applyPopupOpenChange(this, nextOpen, eventDetails, { extraState: { openChangeReason: eventDetails.reason } });
	};
	cancelPendingOpen(event) {
		this.state.floatingRootContext.dispatchOpenChange(false, createChangeEventDetails(triggerPress, event));
	}
};
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	const state = {
		...createInitialPopupStoreState(),
		disabled: false,
		instantType: void 0,
		isInstantPhase: false,
		trackCursorAxis: "none",
		disableHoverablePopup: false,
		openChangeReason: null,
		closeOnClick: true,
		closeDelay: 0,
		adaptiveOrigin: void 0,
		...initialState
	};
	state.floatingRootContext = createPopupFloatingRootContext(triggerElements, floatingId, nested);
	return state;
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChange: void 0,
		onOpenChangeComplete: void 0,
		triggerElements
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/root/TooltipRoot.mjs
/**
* Groups all parts of the tooltip.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipRoot = fastComponent(function TooltipRoot(props) {
	const { disabled: disabled$1 = false, defaultOpen = false, open: openProp, disableHoverablePopup = false, trackCursorAxis = "none", actionsRef, onOpenChange, onOpenChangeComplete, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, children } = props;
	const store = usePopupRootStore((floatingId, nested) => new TooltipStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp
	}, floatingId, nested));
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const openState = store.useState("open");
	const open = !disabled$1 && openState;
	const activeTriggerId = store.useState("activeTriggerId");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	store.useSyncedValues({
		trackCursorAxis,
		disableHoverablePopup,
		disabled: disabled$1
	});
	useImplicitActiveTrigger(store, { closeOnActiveTriggerUnmount: true });
	const { forceUnmount, transitionStatus } = useOpenStateTransitions(open, store);
	const isInstantPhase = store.useState("isInstantPhase");
	const instantType = store.useState("instantType");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const previousInstantTypeRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (openState && disabled$1) store.setOpen(false, createChangeEventDetails(disabled));
	}, [
		openState,
		disabled$1,
		store
	]);
	useIsoLayoutEffect(() => {
		if (transitionStatus === "ending" && lastOpenChangeReason === "none" || transitionStatus !== "ending" && isInstantPhase) {
			if (instantType !== "delay") previousInstantTypeRef.current = instantType;
			store.set("instantType", "delay");
		} else if (previousInstantTypeRef.current !== null) {
			store.set("instantType", previousInstantTypeRef.current);
			previousInstantTypeRef.current = null;
		}
	}, [
		transitionStatus,
		isInstantPhase,
		lastOpenChangeReason,
		instantType,
		store
	]);
	useIsoLayoutEffect(() => {
		if (open) {
			if (activeTriggerId == null) store.set("payload", void 0);
		}
	}, [
		store,
		activeTriggerId,
		open
	]);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted || !disabled$1 && trackCursorAxis !== "none";
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(TooltipRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipInteractions, {
				store,
				disabled: disabled$1,
				trackCursorAxis
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
});
function TooltipInteractions({ store, disabled, trackCursorAxis }) {
	const floatingRootContext = store.useState("floatingRootContext");
	const dismiss = useDismiss(floatingRootContext, {
		enabled: !disabled,
		referencePress: () => store.select("closeOnClick")
	});
	const clientPoint = useClientPoint(floatingRootContext, {
		enabled: !disabled && trackCursorAxis !== "none",
		axis: trackCursorAxis === "none" ? void 0 : trackCursorAxis
	});
	const triggerProps = import_react.useMemo(() => mergeProps(clientPoint.reference, dismiss.reference), [clientPoint.reference, dismiss.reference]);
	usePopupInteractionProps(store, {
		activeTriggerProps: triggerProps,
		inactiveTriggerProps: triggerProps,
		popupProps: dismiss.floating ?? EMPTY_OBJECT
	});
	return null;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/provider/TooltipProviderContext.mjs
/**
* Holds the provider's `delay` value. `closeDelay` is handled by the delay group.
*/
var TooltipProviderContext = /*#__PURE__*/ import_react.createContext(void 0);
function useTooltipProviderContext() {
	return import_react.useContext(TooltipProviderContext);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/trigger/TooltipTrigger.mjs
var TOOLTIP_TRIGGER_IDENTIFIER = "data-base-ui-tooltip-trigger";
function getTargetElement(event) {
	if ("composedPath" in event) {
		const path = event.composedPath();
		for (let i = 0; i < path.length; i += 1) {
			const element = path[i];
			if (isElement(element)) return element;
		}
	}
	const target = event.target;
	if (isElement(target)) return target;
	return null;
}
function closestEnabledTooltipTrigger(element) {
	let current = element;
	while (current) {
		const trigger = current.closest(`[${TOOLTIP_TRIGGER_IDENTIFIER}]`);
		if (trigger) return trigger;
		const root = current.getRootNode();
		current = "host" in root && isElement(root.host) ? root.host : null;
	}
	return null;
}
/**
* An element to attach the tooltip to.
* Renders a `<button>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipTrigger$1 = fastComponentRef(function TooltipTrigger(componentProps, forwardedRef) {
	const { render, className, style, handle, payload, disabled: disabledProp, delay, closeOnClick = true, closeDelay, id: idProp, ...elementProps } = componentProps;
	const rootContext = useTooltipRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootContext;
	if (!store) throw new Error(formatErrorMessage(82));
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const floatingRootContext = store.useState("floatingRootContext");
	const triggerElementRef = import_react.useRef(null);
	const delayWithDefault = delay ?? 600;
	const closeDelayWithDefault = closeDelay ?? 0;
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		closeOnClick,
		closeDelay: closeDelayWithDefault
	});
	const providerDelay = useTooltipProviderContext();
	const { delayRef, isInstantPhase, hasProvider } = useDelayGroup(floatingRootContext, { open: isOpenedByThisTrigger });
	const hoverInteraction = useHoverInteractionSharedState(floatingRootContext);
	store.useSyncedValue("isInstantPhase", isInstantPhase);
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp ?? rootDisabled;
	const disabledRef = useValueAsRef(disabled);
	const trackCursorAxis = store.useState("trackCursorAxis");
	const disableHoverablePopup = store.useState("disableHoverablePopup");
	const isNestedTriggerHoveredRef = import_react.useRef(false);
	const nestedTriggerOpenTimeout = useTimeout();
	const pointerTypeRef = import_react.useRef(void 0);
	function getOpenDelay() {
		if (!hasProvider) return delayWithDefault;
		return getDelay(delayRef.current, "open") === 0 ? 0 : delay ?? providerDelay ?? 600;
	}
	function isEnabledNestedTriggerTarget(target) {
		const triggerEl = triggerElementRef.current;
		if (!triggerEl || !target) return false;
		const nearestTrigger = closestEnabledTooltipTrigger(target);
		return nearestTrigger !== null && nearestTrigger !== triggerEl && contains(triggerEl, nearestTrigger);
	}
	function detectNestedTriggerHover(target) {
		const nestedTriggerHovered = isEnabledNestedTriggerTarget(target);
		isNestedTriggerHoveredRef.current = nestedTriggerHovered;
		if (nestedTriggerHovered) {
			hoverInteraction.openChangeTimeout.clear();
			hoverInteraction.restTimeout.clear();
			hoverInteraction.restTimeoutPending = false;
			nestedTriggerOpenTimeout.clear();
		}
		return nestedTriggerHovered;
	}
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		enabled: !disabled,
		mouseOnly: true,
		move: false,
		handleClose: !disableHoverablePopup && trackCursorAxis !== "both" ? safePolygon() : null,
		restMs: getOpenDelay,
		delay() {
			if (closeDelay == null && hasProvider) return { close: getDelay(delayRef.current, "close") };
			return { close: closeDelayWithDefault };
		},
		triggerElementRef,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending",
		shouldOpen() {
			return !isNestedTriggerHoveredRef.current;
		}
	});
	const focusProps = useFocus(floatingRootContext, { enabled: !disabled }).reference;
	const handleNestedTriggerHover = (event) => {
		const wasNestedTriggerHovered = isNestedTriggerHoveredRef.current;
		const target = getTargetElement(event);
		const nestedTriggerHovered = detectNestedTriggerHover(target);
		const triggerEl = triggerElementRef.current;
		const targetInsideTrigger = triggerEl && target && contains(triggerEl, target);
		if (nestedTriggerHovered && store.select("open") && store.select("lastOpenChangeReason") === "trigger-hover") {
			store.setOpen(false, createChangeEventDetails(triggerHover, event));
			return;
		}
		if (wasNestedTriggerHovered && !nestedTriggerHovered && targetInsideTrigger && !disabledRef.current && !store.select("open") && triggerEl && isMouseLikePointerType(pointerTypeRef.current)) {
			const open = () => {
				if (!isNestedTriggerHoveredRef.current && !disabledRef.current && !store.select("open")) store.setOpen(true, createChangeEventDetails(triggerHover, event, triggerEl));
			};
			const openDelay = getOpenDelay();
			if (openDelay === 0) {
				nestedTriggerOpenTimeout.clear();
				open();
			} else nestedTriggerOpenTimeout.start(openDelay, open);
		}
	};
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	return useRenderElement("button", componentProps, {
		state: { open: isOpenedByThisTrigger },
		ref: [
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			hoverProps,
			focusProps,
			isMountedByThisTrigger || trackCursorAxis !== "none" ? rootTriggerProps : void 0,
			{
				onMouseOver(event) {
					handleNestedTriggerHover(event.nativeEvent);
				},
				onFocus(event) {
					if (isEnabledNestedTriggerTarget(getTargetElement(event.nativeEvent))) event.preventBaseUIHandler();
				},
				onMouseLeave() {
					isNestedTriggerHoveredRef.current = false;
					nestedTriggerOpenTimeout.clear();
					pointerTypeRef.current = void 0;
				},
				onPointerEnter(event) {
					pointerTypeRef.current = event.pointerType;
				},
				onPointerDown(event) {
					pointerTypeRef.current = event.pointerType;
					store.set("closeOnClick", closeOnClick);
					if (closeOnClick && !store.select("open")) store.cancelPendingOpen(event.nativeEvent);
				},
				onClick(event) {
					if (closeOnClick && !store.select("open")) store.cancelPendingOpen(event.nativeEvent);
				},
				id: thisTriggerId,
				"data-trigger-disabled": disabled ? "" : void 0,
				[TOOLTIP_TRIGGER_IDENTIFIER]: disabled ? void 0 : ""
			},
			elementProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/portal/TooltipPortalContext.mjs
var TooltipPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
function useTooltipPortalContext() {
	const value = import_react.useContext(TooltipPortalContext);
	if (value === void 0) throw new Error(formatErrorMessage(70));
	return value;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/FloatingPortalLite.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* `FloatingPortal` includes tabbable logic handling for focus management.
* For components that don't need tabbable logic, use `FloatingPortalLite`.
* @internal
*/
var FloatingPortalLite = /*#__PURE__*/ import_react.forwardRef(function FloatingPortalLite(componentProps, forwardedRef) {
	const { children, container, className, render, style, ...elementProps } = componentProps;
	const { node: portalNode, subtree: portalSubtree } = useFloatingPortalNode({
		container,
		ref: forwardedRef,
		componentProps,
		elementProps
	});
	if (!portalSubtree && !portalNode) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [portalSubtree, portalNode && /*#__PURE__*/ import_react_dom.createPortal(children, portalNode)] });
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/portal/TooltipPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPortal = /*#__PURE__*/ import_react.forwardRef(function TooltipPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	if (!(useTooltipRootContext().useState("mounted") || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortalLite, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/positioner/TooltipPositionerContext.mjs
var TooltipPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
function useTooltipPositionerContext() {
	const context = import_react.useContext(TooltipPositionerContext);
	if (context === void 0) throw new Error(formatErrorMessage(71));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/positioner/TooltipPositioner.mjs
/**
* Positions the tooltip against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPositioner = /*#__PURE__*/ import_react.forwardRef(function TooltipPositioner(componentProps, forwardedRef) {
	const { render, className, anchor, positionMethod = "absolute", side = "top", align = "center", sideOffset = 0, alignOffset = 0, collisionBoundary = "clipping-ancestors", collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance = POPUP_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const keepMounted = useTooltipPortalContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const trackCursorAxis = store.useState("trackCursorAxis");
	const disableHoverablePopup = store.useState("disableHoverablePopup");
	const floatingRootContext = store.useState("floatingRootContext");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const positioning = useAnchorPositioning({
		anchor,
		positionMethod,
		floatingRootContext,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		collisionBoundary,
		collisionPadding,
		sticky,
		arrowPadding,
		disableAnchorTracking,
		keepMounted,
		collisionAvoidance,
		adaptiveOrigin
	});
	const state = import_react.useMemo(() => ({
		open,
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden,
		instant: trackCursorAxis !== "none" ? "tracking-cursor" : instantType
	}), [
		open,
		positioning.side,
		positioning.align,
		positioning.anchorHidden,
		trackCursorAxis,
		instantType
	]);
	const element = usePositioner(componentProps, state, {
		styles: positioning.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, store.useStateSetter("positionerElement")],
		hidden: !mounted,
		inert: !open || trackCursorAxis === "both" || disableHoverablePopup
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipPositionerContext.Provider, {
		value: positioning,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/popup/TooltipPopup.mjs
/**
* A container for the tooltip contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPopup = /*#__PURE__*/ import_react.forwardRef(function TooltipPopup(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const { side, align } = useTooltipPositionerContext();
	const open = store.useState("open");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const floatingContext = store.useState("floatingRootContext");
	const disabled = store.useState("disabled");
	const closeDelay = store.useState("closeDelay");
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	useHoverFloatingInteraction(floatingContext, {
		enabled: !disabled,
		closeDelay
	});
	const setPopupElement = store.useStateSetter("popupElement");
	return useRenderElement("div", componentProps, {
		state: {
			open,
			side,
			align,
			instant: instantType,
			transitionStatus
		},
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		props: [
			FOCUSABLE_POPUP_PROPS,
			popupProps,
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		],
		stateAttributesMapping: popupTransitionStateMapping
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/arrow/TooltipArrow.mjs
/**
* Displays an element positioned against the tooltip anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipArrow = /*#__PURE__*/ import_react.forwardRef(function TooltipArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = useTooltipPositionerContext();
	const state = {
		open: store.useState("open"),
		side,
		align,
		uncentered: arrowUncentered,
		instant: store.useState("instantType")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: [forwardedRef, arrowRef],
		props: [{
			style: arrowStyles,
			"aria-hidden": true
		}, elementProps],
		stateAttributesMapping: popupStateMapping
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/tooltip/provider/TooltipProvider.mjs
/**
* Provides a shared delay for multiple tooltips. The grouping logic ensures that
* once a tooltip becomes visible, the adjacent tooltips will be shown instantly.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipProvider$1 = function TooltipProvider(props) {
	const { delay, closeDelay, timeout = 400 } = props;
	const delayValue = import_react.useMemo(() => ({
		open: delay,
		close: closeDelay
	}), [delay, closeDelay]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipProviderContext.Provider, {
		value: delay,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingDelayGroup, {
			delay: delayValue,
			timeoutMs: timeout,
			children: props.children
		})
	});
};
//#endregion
//#region src/components/ui/tooltip.tsx
function TooltipProvider({ delay = 0, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider$1, {
		"data-slot": "tooltip-provider",
		delay,
		...props
	});
}
function Tooltip({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipRoot, {
		"data-slot": "tooltip",
		...props
	});
}
function TooltipTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger$1, {
		"data-slot": "tooltip-trigger",
		...props
	});
}
function TooltipContent({ className, side = "top", sideOffset = 4, align = "center", alignOffset = 0, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipPositioner, {
		align,
		alignOffset,
		side,
		sideOffset,
		className: "isolate z-50",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipPopup, {
			"data-slot": "tooltip-content",
			className: cn("z-50 inline-flex w-fit max-w-xs origin-(--transform-origin) items-center gap-1.5 rounded-md bg-foreground px-3 py-1.5 text-xs text-background has-data-[slot=kbd]:pr-1.5 data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 **:data-[slot=kbd]:relative **:data-[slot=kbd]:isolate **:data-[slot=kbd]:z-50 **:data-[slot=kbd]:rounded-sm data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
			...props,
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipArrow, { className: "z-50 size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground data-[side=bottom]:top-1 data-[side=inline-end]:top-1/2! data-[side=inline-end]:-left-1 data-[side=inline-end]:-translate-y-1/2 data-[side=inline-start]:top-1/2! data-[side=inline-start]:-right-1 data-[side=inline-start]:-translate-y-1/2 data-[side=left]:top-1/2! data-[side=left]:-right-1 data-[side=left]:-translate-y-1/2 data-[side=right]:top-1/2! data-[side=right]:-left-1 data-[side=right]:-translate-y-1/2 data-[side=top]:-bottom-2.5" })]
		})
	}) });
}
//#endregion
//#region node_modules/.pnpm/react-hook-form@7.87.0_react@19.2.8/node_modules/react-hook-form/dist/index.esm.mjs
var isCheckBoxInput = (element) => element.type === "checkbox";
var isFileInput = (element) => element.type === "file";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : isFileInput(event.target) ? event.target.files : event.target.value : event;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
function getNullAncestorValue(control, name) {
	const segments = stringToPath(name);
	let formValues = control._formValues;
	let defaultValues = control._defaultValues;
	for (let i = 0; i < segments.length - 1; i++) {
		const key = segments[i];
		formValues = formValues == null ? formValues : formValues[key];
		defaultValues = defaultValues == null ? defaultValues : defaultValues[key];
		if (formValues === null || defaultValues === null) return null;
	}
}
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data === null || typeof data !== "object") return data;
	if (data instanceof Date) return new Date(data);
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (data instanceof Blob || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	if (!isArray && data.constructor !== Object) return data;
	const copy = isArray ? [] : Object.create(Object.getPrototypeOf(data));
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = isWeb ? import_react.useLayoutEffect : import_react.useEffect;
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && !isPlainObject(object);
function deepEqual(object1, object2, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!(key in object2)) return false;
		if (key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
function useResyncOnReconnect(getInitialValue) {
	const _connected = import_react.useRef(false);
	const _initialized = import_react.useRef(false);
	const _prevValue = import_react.useRef(void 0);
	const _renderCount = import_react.useRef(0);
	_renderCount.current++;
	if (!_initialized.current && getInitialValue) {
		_initialized.current = true;
		_prevValue.current = cloneObject(getInitialValue());
	}
	return {
		resyncIfNeeded: import_react.useCallback((enabled, getCurrentValue, setValue) => {
			if (enabled && (_connected.current || _initialized.current && _renderCount.current > 1)) {
				const currentValue = getCurrentValue();
				if (!deepEqual(_prevValue.current, currentValue)) setValue(currentValue);
			}
			_connected.current = true;
		}, []),
		snapshot: import_react.useCallback((enabled, getCurrentValue) => {
			if (enabled) _prevValue.current = cloneObject(getCurrentValue());
		}, [])
	};
}
/**
* Subscribes to each form state and isolates re-renders at the custom hook level. It has its own scope for form state subscriptions, so it will not affect other useFormState or useForm instances. Using this hook can reduce the re-render impact on large and complex form applications.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformstate) • [Demo](https://codesandbox.io/s/useformstate-75xly)
*
* @param props - Include options to specify fields to subscribe to. {@link UseFormStateReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, control } = useForm({
*     defaultValues: {
*     firstName: "firstName"
*   }});
*   const { dirtyFields } = useFormState({
*     control
*   });
*   const onSubmit = (data) => console.log(data);
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input {...register("firstName")} placeholder="First Name" />
*       {dirtyFields.firstName && <p>Field is dirty.</p>}
*       <input type="submit" />
*     </form>
*   );
* }
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const [formState, updateFormState] = import_react.useState(getCurrentFormState);
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(!disabled, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			name,
			formState: _localProxyFormState.current,
			exact,
			callback: (formState) => {
				!disabled && updateFormState({
					...control._formState,
					...formState,
					defaultValues: control._defaultValues
				});
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, getCurrentFormState);
		};
	}, [
		name,
		disabled,
		exact,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName, get(defaultValue, fieldName))));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
/**
* Custom hook to subscribe to field changes and isolate re-rendering at the component level.
*
* @remarks
*
* [API](https://react-hook-form.com/docs/usewatch) • [Demo](https://codesandbox.io/s/react-hook-form-v7-ts-usewatch-h9i5e)
*
* @example
* ```tsx
* const { control } = useForm();
* const values = useWatch({
*   name: "fieldName",
*   control,
* })
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _computeFormValues = import_react.useRef(void 0);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const getInitialOutput = () => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	};
	const [value, updateValue] = import_react.useState(getInitialOutput);
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else updateValue(formValues);
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getInitialOutput);
	const _refreshValue = import_react.useRef(refreshValue);
	_refreshValue.current = refreshValue;
	const _getCurrentOutput = import_react.useRef(getCurrentOutput);
	_getCurrentOutput.current = getCurrentOutput;
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			_refreshValue.current();
		} else resyncIfNeeded(!disabled, () => _getCurrentOutput.current(), (currentValue) => {
			updateValue(currentValue);
			_computeFormValues.current = currentValue;
		});
		const unsubscribe = control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				_refreshValue.current(formState.values);
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, () => _getCurrentOutput.current());
		};
	}, [
		control,
		exact,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	return import_react.useMemo(() => {
		if (disabled) return false;
		const nameChanged = !controlChanged && !deepEqual(prevName, name);
		return controlChanged || nameChanged;
	}, [
		disabled,
		controlChanged,
		name,
		prevName
	]) ? getCurrentOutput() : value;
}
/**
* Custom hook to work with controlled component, this function provide you with both form and field level state. Re-render is isolated at the hook level.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller) • [Demo](https://codesandbox.io/s/usecontroller-0o8px)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns field properties, field and form state. {@link UseControllerReturn}
*
* @example
* ```tsx
* function Input(props) {
*   const { field, fieldState, formState } = useController(props);
*   return (
*     <div>
*       <input {...field} placeholder={props.name} />
*       <p>{fieldState.isTouched && "Touched"}</p>
*       <p>{formState.isSubmitted ? "submitted" : ""}</p>
*     </div>
*   );
* }
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => {
			const resolved = get(control._formValues, name, get(control._defaultValues, name, defaultValue));
			return isUndefined(resolved) ? getNullAncestorValue(control, name) : resolved;
		}, [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _proxyRef = import_react.useRef(null);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => _registerProps.current.onBlur({
		target: {
			value: get(control._formValues, name),
			name
		},
		type: EVENTS.BLUR
	}), [name, control._formValues]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) field._f.ref = _proxyRef.current;
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
		_registerProps.current = control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) field._f.mount = value;
		};
		updateMounted(name, true);
		if (_shouldUnregisterField) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		}
		!isArrayField && control.register(name);
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			(isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component based on `useController` hook to work with controlled component.
*
* @remarks
* [API](https://react-hook-form.com/docs/usecontroller/controller) • [Demo](https://codesandbox.io/s/react-hook-form-v6-controller-ts-jwyzw) • [Video](https://www.youtube.com/watch?v=N2UNk_UCVyA)
*
* @param props - the path name to the form field value, and validation rules.
*
* @returns provide field handler functions, field and form state.
*
* @example
* ```tsx
* function App() {
*   const { control } = useForm<FormValues>({
*     defaultValues: {
*       test: ""
*     }
*   });
*
*   return (
*     <form>
*       <Controller
*         control={control}
*         name="test"
*         render={({ field: { onChange, onBlur, value, ref }, formState, fieldState }) => (
*           <>
*             <input
*               onChange={onChange} // send value to hook form
*               onBlur={onBlur} // notify when input is touched
*               value={value} // return updated value
*               ref={ref} // set ref for focus management
*             />
*             <p>{formState.isSubmitted ? "submitted" : ""}</p>
*             <p>{fieldState.isTouched ? "touched" : ""}</p>
*           </>
*         )}
*       />
*     </form>
*   );
* }
* ```
*/
var Controller = (props) => props.render(useController(props));
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames, abortEarly) => {
	for (const key of fieldsNames || Object.keys(fields)) {
		if (key === "_f") continue;
		const field = fieldsNames ? get(fields, key) : fields[key];
		if (field) {
			const { _f } = field;
			if (_f) {
				if (_f.refs && _f.refs[0] && action(_f.refs[0], key) && !abortEarly) return true;
				else if (_f.ref && action(_f.ref, _f.name) && !abortEarly) return true;
				else if (iterateFieldsByAction(field, action)) break;
			} else if (isObject(field) || Array.isArray(field)) {
				if (iterateFieldsByAction(field, action)) break;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, error[name]);
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (!Array.isArray(options)) return defaultResult;
	if (options.length > 1) {
		const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
		return {
			value: values,
			isValid: !!values.length
		};
	}
	const option = options[0];
	if (!option || !option.checked || option.disabled) return defaultResult;
	if (!option.attributes || !("value" in option.attributes)) return validResult;
	return isUndefined(option.value) || option.value === "" ? validResult : {
		value: option.value,
		isValid: true
	};
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = isRadioInput(ref);
	const isCheckBox = isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isDateObject(inputValue) && !isNaN(inputValue)) {
			const valueNumber = ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((maxLength || minLength) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	const fieldError = error[name];
	setCustomValidity(fieldError ? fieldError.message : true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function baseGet(object, updatePath) {
	const length = updatePath.length - 1;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* A provider component that propagates the `useForm` methods to all children components via [React Context](https://react.dev/reference/react/useContext) API. To be used with {@link useFormContext}.
*
* @remarks
* [API](https://react-hook-form.com/docs/useformcontext) • [Demo](https://codesandbox.io/s/react-hook-form-v7-form-context-ytudi)
*
* @param props - all useForm methods
*
* @example
* ```tsx
* function App() {
*   const methods = useForm();
*   const onSubmit = data => console.log(data);
*
*   return (
*     <FormProvider {...methods} >
*       <form onSubmit={methods.handleSubmit(onSubmit)}>
*         <NestedInput />
*         <input type="submit" />
*       </form>
*     </FormProvider>
*   );
* }
*
*  function NestedInput() {
*   const { register } = useFormContext(); // retrieve all hook methods
*   return <input {...register("test")} />;
* }
* ```
*/
var FormProvider = ({ children, watch, getValues, getErrors, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getErrors,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getErrors,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
var createSubject = () => {
	let _observers = [];
	const next = (value) => {
		for (const observer of _observers) observer.next && observer.next(value);
	};
	const subscribe = (observer) => {
		_observers.push(observer);
		return { unsubscribe: () => {
			_observers = _observers.filter((o) => o !== observer);
		} };
	};
	const unsubscribe = () => {
		_observers = [];
	};
	return {
		get observers() {
			return _observers;
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = {};
	for (const key in fieldsState) if (fieldsState.hasOwnProperty(key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && isObject(fieldState) && fieldValue) {
			const nestedFieldsState = extractFormValues(fieldState, fieldValue);
			if (isObject(nestedFieldsState)) values[key] = nestedFieldsState;
		} else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var hasOwn = (value, key) => value !== null && isObjectType(value) && Object.prototype.hasOwnProperty.call(value, key);
var has = (object, path) => {
	if (!path) return false;
	let result = object;
	for (const key of isKey(path) ? [path] : stringToPath(path)) {
		if (!hasOwn(result, key)) return hasOwn(object, path);
		result = result[key];
	}
	return true;
};
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
function isDirtyContainer(value) {
	return Array.isArray(value) || isObject(value);
}
function collectDirtyFieldNames(dirtyTree, cachedDirtyFields, prefix = "", names = []) {
	for (const key in dirtyTree) {
		const path = prefix ? `${prefix}.${key}` : key;
		const value = dirtyTree[key];
		if (isDirtyContainer(value) && isDirtyContainer(get(cachedDirtyFields, path))) collectDirtyFieldNames(value, cachedDirtyFields, path, names);
		else names.push(path);
	}
	return names;
}
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldArrayItemNames = (names, name) => {
	const segments = name.split(".");
	const matches = [];
	let prefix = segments[0];
	for (let i = 1; i < segments.length; prefix += "." + segments[i++]) if (!isNaN(+segments[i]) && names.has(prefix)) matches.push(`${prefix}.${segments[i]}`);
	return matches;
};
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, field._f);
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || !isUndefined(options.required) && options.required !== false || !isUndefined(options.min) || !isUndefined(options.max) || !isUndefined(options.maxLength) || !isUndefined(options.minLength) || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error || isKey(name)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, updateFormState, isRoot) => {
	updateFormState(formStateData);
	const keys = Object.keys(formStateData).filter((key) => key !== "name");
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var shouldSubscribeByName = (name, signalName, exact) => !name || !signalName || name === signalName || convertToArrayPayload(name).some((currentName) => currentName && (exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName)));
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => {
	const array = get(ref, name);
	!compact(array).length && !(array !== null && array !== void 0 && array.root) && unset(ref, name);
};
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var FORM_ERROR_TYPE = "form";
var updateDirtyFields = (dirtyFields, nextDirtyFields) => {
	for (const key in dirtyFields) if (!(key in nextDirtyFields)) delete dirtyFields[key];
	Object.assign(dirtyFields, nextDirtyFields);
};
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: _options.errors || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		actionArrayLengths: /* @__PURE__ */ new Map(),
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	let _valuesSubscriberCount = 0;
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	let _proxySubscribeFormState = { ..._proxyFormState };
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	const shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_proxyFormState.isValid || _proxySubscribeFormState.isValid || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId === _setValidCallId && isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && (_proxyFormState.isValidating || _proxyFormState.validatingFields || _proxySubscribeFormState.isValidating || _proxySubscribeFormState.validatingFields)) {
			(names || _names.mount).forEach((name) => {
				if (name) isValidating ? set(_formState.validatingFields, name, isValidating) : unset(_formState.validatingFields, name);
			});
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			const fields = get(_fields, name);
			if (!_state.actionArrayLengths.has(name)) _state.actionArrayLengths.set(name, Array.isArray(fields) ? fields.length : 0);
			if (shouldUpdateFieldsAndState && Array.isArray(fields)) {
				const fieldValues = method(fields, args.argA, args.argB);
				shouldSetValues && set(_fields, name, fieldValues);
			}
			const fieldArrayErrors = get(_formState.errors, name);
			if (shouldUpdateFieldsAndState && Array.isArray(fieldArrayErrors)) {
				const rootError = fieldArrayErrors.root;
				const errors = method(fieldArrayErrors, args.argA, args.argB) || fieldArrayErrors;
				if (rootError) errors.root = rootError;
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
			}
			const touchedFieldsArray = get(_formState.touchedFields, name);
			if ((_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && shouldUpdateFieldsAndState && Array.isArray(touchedFieldsArray)) {
				const touchedFields = method(touchedFieldsArray, args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			if (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) _updateDirtyFields();
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		_formState.errors = errors;
		_subjects.state.next({
			errors: _formState.errors,
			isValid: false
		});
	};
	const hasExplicitNullIntermediate = (name) => {
		const segments = isKey(name) ? [name] : stringToPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const isStaleArrayIndex = (name) => {
		if (!_state.actionArrayLengths.size) return false;
		const segments = isKey(name) ? [name] : stringToPath(name);
		let node = _formValues;
		let path = "";
		let ownerDepth = -1;
		let ownerPreActionLength = 0;
		for (let i = 0; i < segments.length; i++) {
			if (isNullOrUndefined(node)) return false;
			const key = segments[i];
			path = path ? `${path}.${key}` : key;
			if (Array.isArray(node) && +key >= node.length) return ownerDepth === -1 ? false : i === ownerDepth ? +key < ownerPreActionLength : true;
			if (_state.actionArrayLengths.has(path)) {
				ownerDepth = i + 1;
				ownerPreActionLength = _state.actionArrayLengths.get(path);
			}
			node = node[key];
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name) || isStaleArrayIndex(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			isUndefined(defaultValue) || ref && ref.defaultChecked || shouldSkipSetValueAs ? set(_formValues, name, shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f)) : setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				_setValid();
				if (wasUnsetInFormValues && _formState.isDirty && (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty)) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (props.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_proxyFormState.isDirty || _proxySubscribeFormState.isDirty) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine !== _formState.isDirty) updateDirtyFields(_formState.dirtyFields, getDirtyFields(_defaultValues, _formValues, void 0, _fields));
				else isCurrentFieldPristine ? unset(_formState.dirtyFields, name) : set(_formState.dirtyFields, name, true);
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || (_proxyFormState.dirtyFields || _proxySubscribeFormState.dirtyFields) && isPreviousDirty !== !isCurrentFieldPristine;
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = get(_formState.touchedFields, name);
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || (_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			clearTimeout(timers[name]);
			delete delayErrorCallbacks[name];
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const { errors } = await _runSchema(names);
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				const error = get(errors, name);
				error ? _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key))) ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else _formState.errors = errors;
		return errors;
	};
	const validateForm = async ({ name, eventType }) => {
		if (props.validate) {
			const result = await props.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (isObject(result)) for (const key in result) {
				const error = result[key];
				if (error) setError(`${FORM_ERROR_TYPE}.${key}`, {
					message: isString(error.message) ? error.message : "",
					type: error.type || INPUT_VALIDATION_RULES.validate
				});
			}
			else if (isString(result) || !result) setError(FORM_ERROR_TYPE, {
				message: result || "",
				type: INPUT_VALIDATION_RULES.validate
			});
			else clearErrors(FORM_ERROR_TYPE);
			return result;
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		if (props.validate) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _proxyFormState.validatingFields || _proxyFormState.isValidating || _proxySubscribeFormState.validatingFields || _proxySubscribeFormState.isValidating;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					!onlyCheckValid && (get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name));
					if (props.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && data && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => generateWatchOutput(names, _names, { ..._state.mount ? _formValues : isUndefined(defaultValue) || isString(names) ? _defaultValues : defaultValue }, isGlobal, defaultValue);
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false, skipValueRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) {
					if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
						if (!checkboxRef.defaultChecked || !checkboxRef.disabled) {
							if (Array.isArray(fieldValue)) checkboxRef.checked = !!fieldValue.find((data) => data === checkboxRef.value);
							else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
						}
					});
					else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				} else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender && !skipValueRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : cloneObject(_formValues)
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false, skipValueRender = false) => {
		if (_names.array.has(name)) _subjects.array.next({
			name,
			values: skipClone ? _formValues : cloneObject(_formValues)
		});
		for (const fieldKey in value) {
			if (!value.hasOwnProperty(fieldKey)) continue;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if ((_proxyFormState.isDirty || _proxyFormState.dirtyFields || _proxySubscribeFormState.isDirty || _proxySubscribeFormState.dirtyFields) && options.shouldDirty) {
				_updateDirtyFields();
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _getDirty(name, cloneValue)
				});
			}
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			const skipValueRender = !isValueUnchanged && !skipStateEmit;
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const values = skipClone ? _formValues : cloneObject(_formValues);
			_subjects.state.next({
				...watched && _formState,
				name: _state.mount || watched ? name : void 0,
				values
			});
			if (!isFieldArray) for (const itemName of getFieldArrayItemNames(_names.array, name)) _subjects.state.next({
				name: itemName,
				values
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues)) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			for (const fieldName of _names.mount) if (has(updatedFormValues, fieldName)) _setValue(fieldName, get(updatedFormValues, fieldName), options, true, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscriberCount ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = Number.isNaN(fieldValue) || isDateObject(fieldValue) && isNaN(fieldValue.getTime()) || deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			let error;
			let isValid;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !props.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, cloneObject(fieldValue));
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					const pendingDelayError = delayErrorCallbacks[name];
					pendingDelayError && pendingDelayError(0);
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._valuesSubscriberCount ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && (_proxyFormState.isValid || _proxySubscribeFormState.isValid)) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && props.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const { errors } = await _runSchema([name]);
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_proxyFormState.isValid || _proxySubscribeFormState.isValid) isValid = await executeBuiltInValidation({
						fields: _fields,
						onlyCheckValid: true,
						name,
						eventType: event.type
					});
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		if (_options.resolver) {
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			!(!validationResult && !_formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else {
				clearTimeout(timers[name]);
				delete delayErrorCallbacks[name];
			}
		}
		if (options.shouldTouch) for (const fieldName of name ? fieldNames : _names.mount) !_names.array.has(fieldName) && set(_formState.touchedFields, fieldName, true);
		_subjects.state.next({
			...!isString(name) || (_proxyFormState.isValid || _proxySubscribeFormState.isValid) && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			...options.shouldTouch && (_proxyFormState.touchedFields || _proxySubscribeFormState.touchedFields) ? { touchedFields: _formState.touchedFields } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = (fieldNames, config) => {
		let values = { ..._state.mount ? _formValues : _defaultValues };
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	};
	const getErrors = (fieldNames) => isUndefined(fieldNames) ? { ..._formState.errors } : isString(fieldNames) ? get(_formState.errors, fieldNames) : fieldNames.map((name) => get(_formState.errors, name));
	const getFieldState = (name, formState) => {
		const targetFormState = formState || _formState;
		const error = get(targetFormState.errors, name);
		return {
			invalid: !!error,
			isDirty: !!get(targetFormState.dirtyFields, name),
			error,
			isValidating: !!get(_formState.validatingFields, name),
			isTouched: !!get(targetFormState.touchedFields, name)
		};
	};
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		names === null || names === void 0 || names.forEach((inputName) => unset(_formState.errors, inputName));
		if (names) names.forEach((inputName) => {
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else {
			_formState.errors = {};
			_subjects.state.next({ errors: _formState.errors });
		}
	};
	const setError = (name, error, options) => {
		const ref = (get(_fields, name, { _f: {} })._f || {}).ref;
		const { ref: currentRef, message, type, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		options && options.shouldFocus && ref && ref.focus && ref.focus();
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			_valuesSubscriberCount++;
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			let called = false;
			return { unsubscribe: () => {
				if (called) return;
				called = true;
				_valuesSubscriberCount--;
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		var _a;
		const needsValues = !!((_a = props.formState) === null || _a === void 0 ? void 0 : _a.values);
		if (needsValues) _valuesSubscriberCount++;
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, _setFormState, props.reRenderRoot)) {
				const snapshot = { ..._formValues };
				props.callback({
					values: snapshot,
					..._formState,
					...formState,
					defaultValues: _defaultValues
				});
			}
		} });
		if (!needsValues) return unsubscribe;
		let called = false;
		return () => {
			if (called) return;
			called = true;
			_valuesSubscriberCount--;
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		_proxySubscribeFormState = {
			..._proxySubscribeFormState,
			...props.formState
		};
		return _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
	};
	const unregister = (name, options = {}) => {
		for (const fieldName of name ? convertToArrayPayload(name) : _names.mount) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			if (!options.keepValue) {
				unset(_fields, fieldName);
				unset(_formValues, fieldName);
			}
			!options.keepError && unset(_formState.errors, fieldName);
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!options.keepIsValidating && unset(_formState.validatingFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		_valuesSubscriberCount && _subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...options.keepDirty ? {} : { isDirty: _getDirty() }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!options.required,
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					const newField = { ...field._f };
					if (radioOrCheckbox) {
						newField.refs = [
							...refs.filter(live),
							fieldRef,
							...Array.isArray(get(_defaultValues, name)) ? [{}] : []
						];
						newField.ref = {
							type: fieldRef.type,
							name
						};
					} else {
						newField.ref = fieldRef;
						delete newField.refs;
					}
					set(_fields, name, { _f: newField });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0, false);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let result = void 0;
		let onValidError = void 0;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		if (_options.resolver) {
			const { errors, values } = await _runSchema();
			_updateIsValidating();
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else await executeBuiltInValidation({
			fields: _fields,
			eventType: EVENTS.SUBMIT
		});
		if (_names.disabled.size) for (const name of _names.disabled) unset(fieldValues, name);
		unset(_formState.errors, ROOT_ERROR_TYPE);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				result = await onValid(fieldValues, e);
			} catch (error) {
				onValidError = error;
			}
		} else {
			if (onInvalid) await onInvalid({ ..._formState.errors }, e);
			_focusError();
			setTimeout(_focusError);
		}
		_subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidError,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidError) throw onValidError;
		return result;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = options.defaultValue ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				unset(_formState.errors, name);
				_setValid();
			}
			_subjects.state.next({ ..._formState });
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...collectDirtyFieldNames(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs), _formState.dirtyFields)]);
				for (const fieldName of fieldsToCheck) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		_state.actionArrayLengths.clear();
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		_formState = {
			..._formState,
			...formState
		};
	};
	_subjects.state.subscribe({ next: _setFormState });
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		getErrors,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
/**
* Custom hook to manage the entire form.
*
* @remarks
* [API](https://react-hook-form.com/docs/useform) • [Demo](https://codesandbox.io/s/react-hook-form-get-started-ts-5ksmm) • [Video](https://www.youtube.com/watch?v=RkXv4AXXC_4)
*
* @param props - form configuration and validation parameters.
*
* @returns methods - individual functions to manage the form state. {@link UseFormReturn}
*
* @example
* ```tsx
* function App() {
*   const { register, handleSubmit, watch, formState: { errors } } = useForm();
*   const onSubmit = data => console.log(data);
*
*   console.log(watch("example"));
*
*   return (
*     <form onSubmit={handleSubmit(onSubmit)}>
*       <input defaultValue="test" {...register("example")} />
*       <input {...register("exampleRequired", { required: true })} />
*       {errors.exampleRequired && <span>This field is required</span>}
*       <button>Submit</button>
*     </form>
*   );
* }
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	control._options = props;
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect();
	useIsomorphicLayoutEffect(() => {
		const getCurrentFormState = () => ({
			...control._formState,
			defaultValues: control._defaultValues
		});
		resyncIfNeeded(true, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFormState);
		};
	}, [
		control,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._disableForm(props.disabled), [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		}
	}, [control, props.errors]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		var _a;
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!((_a = control._options.resetOptions) === null || _a === void 0 ? void 0 : _a.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount) {
			control._setValid();
			control._state.mount = true;
		}
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/use-render/useRender.mjs
/**
* Renders a Base UI element.
*
* @public
*/
function useRender(params) {
	return useRenderElement(params.defaultTagName ?? "div", params, params);
}
//#endregion
//#region src/components/ui/form.tsx
var Form = FormProvider;
var FormFieldContext = import_react.createContext({});
var FormField = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormFieldContext.Provider, {
		value: { name: props.name },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Controller, { ...props })
	});
};
import_react.createContext({});
//#endregion
//#region src/options/components/SettingsTabForm.tsx
function SettingsTabForm({ form, onSubmit, children }) {
	const { t } = useTranslation();
	const [saved, setSaved] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const { isDirty, isSubmitting } = form.formState;
	const submit = async (values) => {
		setError(null);
		setSaved(false);
		try {
			await onSubmit(values);
			form.reset(values);
			setSaved(true);
		} catch (e) {
			setError(e.message);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Form, {
		...form,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: form.handleSubmit(submit),
			className: "space-y-5",
			children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2 pt-1",
				children: [
					saved && !isDirty && error === null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-green-600 dark:text-green-400",
						children: t("options.common.saved")
					}),
					error !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-destructive",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "secondary",
							disabled: !isDirty || isSubmitting,
							onClick: () => {
								form.reset();
								setError(null);
								setSaved(false);
							},
							children: t("options.common.cancel")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "sm",
							disabled: !isDirty || isSubmitting,
							children: isSubmitting ? t("options.common.saving") : t("options.common.apply")
						})]
					})
				]
			})]
		})
	});
}
//#endregion
//#region src/options/SettingPanel.tsx
/** Shared surface for tab content; headings belong to its setting groups. */
function SettingPanel({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-2xl border border-border/60 bg-card px-5 py-4 shadow-inset-panel",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children
		})
	});
}
//#endregion
//#region src/options/components/SettingSection.tsx
function SettingSection({ title, description, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex flex-col gap-3",
		children: [(title != null || action != null) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-1",
				children: [title != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold tracking-tight text-foreground",
					children: title
				}), description != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: description
				})]
			}), action != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			})]
		}), children]
	});
}
//#endregion
//#region src/options/useTakeoverAvailability.ts
/** Refresh selection without resetting unsaved settings in the form. */
function useTakeoverAvailability() {
	const [availability, setAvailability] = (0, import_react.useState)("unknown");
	(0, import_react.useEffect)(() => {
		let generation = 0;
		let disposed = false;
		const refresh = async () => {
			const current = ++generation;
			setAvailability("unknown");
			try {
				const config = await send("bg.getEndpointConfig", void 0);
				if (!disposed && current === generation) setAvailability(supportsAutomaticTakeover(config) ? "local" : "remote");
			} catch {}
		};
		const onChanged = (changes, area) => {
			if (area === "local" && "motrix.endpointConfig" in changes) refresh();
		};
		browser.storage.onChanged.addListener(onChanged);
		refresh();
		return () => {
			disposed = true;
			browser.storage.onChanged.removeListener(onChanged);
		};
	}, []);
	return availability;
}
//#endregion
//#region src/options/sections/TakeoverSection.tsx
function TakeoverSection({ form, consentAck, setConsentAck }) {
	const { t } = useTranslation();
	const availability = useTakeoverAvailability();
	const [showConsent, setShowConsent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (availability !== "local") setShowConsent(false);
	}, [availability]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingSection, {
		title: t("options.takeover.title"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				control: form.control,
				name: "enabled",
				render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					orientation: "horizontal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "download-enabled",
						children: t("options.takeover.enableLabel")
					}), availability !== "local" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, {
						id: "download-takeover-unavailable",
						children: t(availability === "remote" ? "options.takeover.remoteUnavailable" : "options.takeover.availabilityUnknown")
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "download-enabled",
						checked: availability === "local" && field.value,
						disabled: availability !== "local",
						"aria-describedby": availability !== "local" ? "download-takeover-unavailable" : void 0,
						"aria-label": t("options.takeover.enableAria"),
						onCheckedChange: (checked) => {
							if (availability !== "local") return;
							if (checked && consentAck < 1) {
								setShowConsent(true);
								return;
							}
							field.onChange(checked);
						}
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				control: form.control,
				name: "thresholdMB",
				render: ({ field, fieldState }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					orientation: "responsive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "download-threshold",
							children: t("options.takeover.minSizeLabel")
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "download-threshold",
							type: "number",
							className: "bg-background @md/field-group:w-40",
							placeholder: t("options.takeover.minSizePlaceholder"),
							"aria-invalid": fieldState.invalid,
							...field
						}),
						fieldState.invalid && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { errors: [{ message: t(fieldState.error?.message ?? "") }] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
				control: form.control,
				name: "denylist",
				render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
					orientation: "vertical",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "download-denylist",
						children: t("options.takeover.denylistLabel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						id: "download-denylist",
						className: "min-h-20",
						...field
					})]
				})
			})
		] })
	}), showConsent && availability === "local" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 rounded-xl border border-amber-400/70 bg-amber-50 p-3.5 text-xs text-amber-950 dark:border-amber-500/30 dark:bg-amber-950/30 dark:text-amber-100",
		role: "dialog",
		"aria-label": t("options.takeover.consentDialogLabel"),
		onKeyDown: (e) => {
			if (e.key === "Escape") setShowConsent(false);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-2.5 leading-relaxed",
			children: t("options.takeover.consentBody")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "sm",
				onClick: () => {
					if (availability !== "local") return;
					setConsentAck(1);
					form.setValue("enabled", true, { shouldDirty: true });
					setShowConsent(false);
				},
				children: t("options.takeover.consentConfirm")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				size: "sm",
				variant: "secondary",
				onClick: () => setShowConsent(false),
				children: t("options.takeover.consentCancel")
			})]
		})]
	})] });
}
//#endregion
//#region src/options/tabs/schemas.ts
var takeoverFormSchema = object({
	enabled: boolean(),
	thresholdMB: string().refine((s) => s.trim() === "" || Number(s) >= 0, { message: "options.takeover.thresholdInvalid" }),
	denylist: string()
});
var generalFormSchema = object({
	theme: _enum([
		"system",
		"light",
		"dark"
	]),
	language: _enum(["system", ...SUPPORTED_LOCALES]),
	notifyMaster: boolean(),
	notifyConfirm: boolean(),
	notifyError: boolean(),
	notifyReminder: boolean()
});
var serverFormSchema = object({
	name: string().trim().min(1, { message: "options.servers.nameRequired" }),
	url: string().min(1, { message: "options.servers.urlRequired" }).refine((value) => {
		try {
			parseRemoteEndpoint(value);
			return true;
		} catch {
			return false;
		}
	}, { message: "options.servers.urlInvalid" })
});
var helpFormSchema = object({ logLevel: _enum([
	"silent",
	"error",
	"warn",
	"info",
	"debug"
]) });
//#endregion
//#region src/options/takeoverForm.ts
var THRESHOLD_RULE_ID = "mvp.threshold";
function configToForm(config) {
	const threshold = config.rules.find((r) => r.id === THRESHOLD_RULE_ID)?.match.minSizeMB;
	const denylist = config.rules.filter((r) => r.id !== THRESHOLD_RULE_ID && r.action === "chrome" && r.match.domains).flatMap((r) => r.match.domains ?? []);
	return {
		enabled: config.enabled,
		thresholdMB: typeof threshold === "number" ? String(threshold) : "",
		denylist: denylist.join("\n")
	};
}
function formToConfig(form, consentAckVersion) {
	const rules = [];
	const domains = form.denylist.split("\n").map((s) => s.trim()).filter((s) => s.length > 0);
	for (const [i, domain] of domains.entries()) rules.push({
		id: `mvp.deny.${i}`,
		match: { domains: [domain] },
		action: "chrome"
	});
	const mb = Number(form.thresholdMB);
	if (Number.isFinite(mb) && mb > 0) rules.push({
		id: THRESHOLD_RULE_ID,
		match: { minSizeMB: mb },
		action: "chrome"
	});
	return {
		enabled: form.enabled,
		consentAckVersion,
		defaultAction: "motrix",
		rules
	};
}
//#endregion
//#region node_modules/.pnpm/@hookform+resolvers@5.9.1_@_ffcc2465188a2fb213f2783a127b8413/node_modules/@hookform/resolvers/dist/resolvers.mjs
var t$1 = (r, t, s) => {
	if (r && "reportValidity" in r) {
		const o = get(s, t);
		r.setCustomValidity(o && o.message || ""), r.reportValidity();
	}
};
var s$1 = (e, r) => {
	for (const s in r.fields) {
		const o = r.fields[s];
		o && o.ref && "reportValidity" in o.ref ? t$1(o.ref, s, e) : o && o.refs && o.refs.forEach((r) => t$1(r, s, e));
	}
};
var o$1 = (t, o) => {
	o.shouldUseNativeValidation && s$1(t, o);
	const n = {};
	for (const s in t) {
		const f = get(o.fields, s), c = Object.assign(t[s] || {}, { ref: f && f.refs ? f.refs[0] : f && f.ref });
		if (i$1(o.names || Object.keys(t), s)) {
			const t = Object.assign({}, get(n, s));
			set(t, "root", c), set(n, s, t);
		} else set(n, s, c);
	}
	return n;
};
var i$1 = (e, r) => {
	const t = n(r).replace(/[.*+?^${}()|\\]/g, "\\$&");
	return e.some((e) => n(e).match(`^${t}\\.\\d+`));
};
function n(e) {
	return e.replace(/\[(\d+)]/g, ".$1").replace(/[[\]]/g, "");
}
//#endregion
//#region node_modules/.pnpm/@hookform+resolvers@5.9.1_@_ffcc2465188a2fb213f2783a127b8413/node_modules/@hookform/resolvers/zod/dist/zod.mjs
function o() {
	return o = Object.assign ? Object.assign.bind() : function(r) {
		for (var e = 1; e < arguments.length; e++) {
			var n = arguments[e];
			for (var o in n) ({}).hasOwnProperty.call(n, o) && (r[o] = n[o]);
		}
		return r;
	}, o.apply(null, arguments);
}
function t(r, e) {
	try {
		var n = r();
	} catch (r) {
		return e(r);
	}
	return n && n.then ? n.then(void 0, e) : n;
}
function s(r, e) {
	for (var o = Object.create(null); r.length;) {
		var t = r[0], s = t.code, i = t.message, u = t.path.join(".");
		if (!o[u]) if ("unionErrors" in t) {
			var a, c, l = t.unionErrors.reduce(function(r, e) {
				return e.errors.length < r.errors.length ? e : r;
			}).errors[0];
			o[u] = {
				message: null != (a = null == l ? void 0 : l.message) ? a : i,
				type: null != (c = null == l ? void 0 : l.code) ? c : s
			};
		} else o[u] = {
			message: i,
			type: s
		};
		if ("unionErrors" in t && t.unionErrors.forEach(function(e) {
			return e.errors.forEach(function(e) {
				return r.push(e);
			});
		}), e) {
			var f = o[u].types, d = f && f[t.code];
			o[u] = appendErrors(u, e, o, s, d ? [].concat(d, t.message) : t.message);
		}
		r.shift();
	}
	return o;
}
function i(r, e) {
	for (var t = Object.create(null), s = function() {
		var s = r[0], i = s.code, u = s.message, a = s.path.join(".");
		if (!t[a]) if ("invalid_union" === s.code && s.errors.length > 0) {
			var c, l, f = s.errors.reduce(function(r, e) {
				return e.length < r.length ? e : r;
			})[0];
			t[a] = {
				message: null != (c = null == f ? void 0 : f.message) ? c : u,
				type: null != (l = null == f ? void 0 : f.code) ? l : i
			};
		} else t[a] = {
			message: u,
			type: i
		};
		if ("invalid_union" === s.code && s.errors.forEach(function(e) {
			return e.forEach(function(e) {
				return r.push(o({}, e, { path: [].concat(s.path, e.path) }));
			});
		}), e) {
			var d = t[a].types, h = d && d[s.code];
			t[a] = appendErrors(a, e, t, i, h ? [].concat(h, s.message) : s.message);
		}
		r.shift();
	}; r.length;) s();
	return t;
}
function u(n, o, u) {
	if (void 0 === u && (u = {}), function(r) {
		return "_zod" in r && "object" == typeof r._zod;
	}(n)) return function(s, a, c) {
		try {
			return Promise.resolve(t(function() {
				function e(e) {
					return c.shouldUseNativeValidation && s$1({}, c), {
						errors: {},
						values: u.raw ? Object.assign({}, s) : e
					};
				}
				var t = n;
				return "sync" === u.mode ? e(t.parse(s, o)) : Promise.resolve(t.parseAsync(s, o)).then(e);
			}, function(r) {
				if (function(r) {
					var e;
					return !(null == r || null == (e = r._zod) || null == (e = e.traits) || !e.has("$ZodError"));
				}(r)) return {
					values: {},
					errors: o$1(i(r.issues, !c.shouldUseNativeValidation && "all" === c.criteriaMode), c)
				};
				throw r;
			}));
		} catch (r) {
			return Promise.reject(r);
		}
	};
	if (function(r) {
		return "_def" in r && "object" == typeof r._def;
	}(n)) return function(i, a, c) {
		try {
			return Promise.resolve(t(function() {
				return Promise.resolve(n["sync" === u.mode ? "parse" : "parseAsync"](i, o)).then(function(e) {
					return c.shouldUseNativeValidation && s$1({}, c), {
						errors: {},
						values: u.raw ? Object.assign({}, i) : e
					};
				});
			}, function(r) {
				if (function(r) {
					return Array.isArray(null == r ? void 0 : r.issues);
				}(r)) return {
					values: {},
					errors: o$1(s(r.errors, !c.shouldUseNativeValidation && "all" === c.criteriaMode), c)
				};
				throw r;
			}));
		} catch (r) {
			return Promise.reject(r);
		}
	};
	throw new Error("Invalid input: not a Zod schema");
}
//#endregion
//#region src/options/zodFormResolver.ts
/**
* @hookform/resolvers resolves its Zod v4 declarations through pnpm's hoisted
* Zod 3 compatibility package, while this application uses Zod 4.4. Runtime
* support is compatible, so keep the type adaptation in one boundary.
*/
var compatibleZodResolver = u;
function zodFormResolver(schema) {
	return compatibleZodResolver(schema);
}
//#endregion
//#region src/options/tabs/DownloadTab.tsx
function DownloadTab() {
	const { t } = useTranslation();
	const [consentAck, setConsentAck] = (0, import_react.useState)(0);
	const [loadFailed, setLoadFailed] = (0, import_react.useState)(false);
	const form = useForm({
		resolver: zodFormResolver(takeoverFormSchema),
		defaultValues: {
			enabled: false,
			thresholdMB: "",
			denylist: ""
		}
	});
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const takeover = await send("bg.getTakeoverConfig", void 0);
				if (cancelled) return;
				form.reset(configToForm(takeover));
				setConsentAck(takeover.consentAckVersion);
				setLoadFailed(false);
			} catch {
				if (!cancelled) setLoadFailed(true);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [form]);
	const onSubmit = async (values) => {
		await send("bg.setTakeoverConfig", formToConfig(values, consentAck));
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingPanel, { children: [loadFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive",
		role: "alert",
		children: t("options.common.loadError")
	}), !loadFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsTabForm, {
		form,
		onSubmit,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TakeoverSection, {
			form,
			consentAck,
			setConsentAck
		})
	})] });
}
//#endregion
//#region src/options/sections/AppearanceSection.tsx
function AppearanceSection({ form }) {
	const { t } = useTranslation();
	const themeItems = {
		system: t("options.appearance.theme.system"),
		light: t("options.appearance.theme.light"),
		dark: t("options.appearance.theme.dark")
	};
	const languageItems = {
		system: t("options.language.system"),
		...LOCALE_NAMES
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingSection, {
		title: t("options.appearance.title"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
			control: form.control,
			name: "theme",
			render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				orientation: "responsive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "appearance-theme",
					children: t("options.appearance.theme.label")
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					items: themeItems,
					value: field.value,
					onValueChange: (value) => {
						if (value !== null) field.onChange(value);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						id: "appearance-theme",
						className: "min-w-48",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "system",
							children: themeItems.system
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "light",
							children: themeItems.light
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: "dark",
							children: themeItems.dark
						})
					] }) })]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
			control: form.control,
			name: "language",
			render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				orientation: "responsive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "appearance-language",
					children: t("options.language.label")
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					items: languageItems,
					value: field.value,
					onValueChange: (value) => {
						if (value !== null) field.onChange(value);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						id: "appearance-language",
						className: "min-w-48",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: "system",
						children: languageItems.system
					}), SUPPORTED_LOCALES.map((locale) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: locale,
						children: languageItems[locale]
					}, locale))] }) })]
				})]
			})
		})] })
	});
}
//#endregion
//#region src/options/sections/NotificationsSection.tsx
function NotificationsSection({ form }) {
	const { t } = useTranslation();
	const master = form.watch("notifyMaster");
	const detailRow = (name, labelKey, descKey) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
		control: form.control,
		name,
		render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
			orientation: "horizontal",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: name,
				children: t(labelKey)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: t(descKey)
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				id: name,
				checked: field.value,
				"aria-label": t(labelKey),
				onCheckedChange: field.onChange
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingSection, {
		title: t("options.notifications.title"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
			control: form.control,
			name: "notifyMaster",
			render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
				orientation: "horizontal",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "notify-master",
					children: t("options.notifications.masterLabel")
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					id: "notify-master",
					checked: field.value,
					"aria-label": t("options.notifications.masterAria"),
					onCheckedChange: field.onChange
				})]
			})
		}), master && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			detailRow("notifyConfirm", "options.notifications.confirmLabel", "options.notifications.confirmDesc"),
			detailRow("notifyError", "options.notifications.errorLabel", "options.notifications.errorDesc"),
			detailRow("notifyReminder", "options.notifications.reminderLabel", "options.notifications.reminderDesc")
		] })] })
	});
}
//#endregion
//#region src/options/tabs/GeneralTab.tsx
function GeneralTab() {
	const { t } = useTranslation();
	const [loadFailed, setLoadFailed] = (0, import_react.useState)(false);
	const form = useForm({
		resolver: zodFormResolver(generalFormSchema),
		defaultValues: {
			theme: "system",
			language: "system",
			notifyMaster: NOTIFICATIONS_DEFAULT.master,
			notifyConfirm: NOTIFICATIONS_DEFAULT.confirm,
			notifyError: NOTIFICATIONS_DEFAULT.error,
			notifyReminder: NOTIFICATIONS_DEFAULT.reminder
		}
	});
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const [theme, locale, notif] = await Promise.all([
					getThemeOverride(),
					getLocaleOverride(),
					send("bg.getNotificationsConfig", void 0)
				]);
				if (cancelled) return;
				const n = notif ?? NOTIFICATIONS_DEFAULT;
				form.reset({
					theme: theme ?? "system",
					language: locale ?? "system",
					notifyMaster: n.master,
					notifyConfirm: n.confirm,
					notifyError: n.error,
					notifyReminder: n.reminder
				});
				setLoadFailed(false);
			} catch {
				if (!cancelled) setLoadFailed(true);
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [form]);
	const onSubmit = async (values) => {
		await send("bg.setNotificationsConfig", {
			master: values.notifyMaster,
			confirm: values.notifyConfirm,
			error: values.notifyError,
			reminder: values.notifyReminder
		});
		await setThemeOverride(values.theme === "system" ? null : values.theme);
		await setLocaleOverride(values.language === "system" ? null : values.language);
		await instance.changeLanguage(values.language === "system" ? resolveDefaultLocale() : values.language);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingPanel, { children: [loadFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "rounded-md border border-destructive/40 bg-destructive/5 px-3 py-2 text-xs text-destructive",
		role: "alert",
		children: t("options.common.loadError")
	}), !loadFailed && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingsTabForm, {
		form,
		onSubmit,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppearanceSection, { form }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationsSection, { form })
		]
	})] });
}
//#endregion
//#region src/components/ui/item.tsx
function ItemGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "list",
		"data-slot": "item-group",
		className: cn("group/item-group flex w-full flex-col gap-4 has-data-[size=sm]:gap-2.5 has-data-[size=xs]:gap-2", className),
		...props
	});
}
function ItemSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		"data-slot": "item-separator",
		orientation: "horizontal",
		className: cn("my-2", className),
		...props
	});
}
var itemVariants = cva("group/item flex w-full flex-wrap items-center rounded-md border text-sm transition-colors duration-100 outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 [a]:transition-colors [a]:hover:bg-muted", {
	variants: {
		variant: {
			default: "border-transparent",
			outline: "border-border",
			muted: "border-transparent bg-muted/50"
		},
		size: {
			default: "gap-3.5 px-4 py-3.5",
			sm: "gap-2.5 px-3 py-2.5",
			xs: "gap-2 px-2.5 py-2 in-data-[slot=dropdown-menu-content]:p-0"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Item({ className, variant = "default", size = "default", render, ...props }) {
	return useRender({
		defaultTagName: "div",
		props: mergeProps({ className: cn(itemVariants({
			variant,
			size,
			className
		})) }, props),
		render,
		state: {
			slot: "item",
			variant,
			size
		}
	});
}
var itemMediaVariants = cva("flex shrink-0 items-center justify-center gap-2 group-has-data-[slot=item-description]/item:translate-y-0.5 group-has-data-[slot=item-description]/item:self-start [&_svg]:pointer-events-none", {
	variants: { variant: {
		default: "bg-transparent",
		icon: "[&_svg:not([class*='size-'])]:size-4",
		image: "size-10 overflow-hidden rounded-sm group-data-[size=sm]/item:size-8 group-data-[size=xs]/item:size-6 [&_img]:size-full [&_img]:object-cover"
	} },
	defaultVariants: { variant: "default" }
});
function ItemMedia({ className, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "item-media",
		"data-variant": variant,
		className: cn(itemMediaVariants({
			variant,
			className
		})),
		...props
	});
}
function ItemContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "item-content",
		className: cn("flex flex-1 flex-col gap-1 group-data-[size=xs]/item:gap-0 [&+[data-slot=item-content]]:flex-none", className),
		...props
	});
}
function ItemTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "item-title",
		className: cn("line-clamp-1 flex w-fit items-center gap-2 text-sm leading-snug font-medium underline-offset-4", className),
		...props
	});
}
function ItemDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		"data-slot": "item-description",
		className: cn("line-clamp-2 text-left text-sm leading-normal font-normal text-muted-foreground group-data-[size=xs]/item:text-xs [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary", className),
		...props
	});
}
function ItemActions({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "item-actions",
		className: cn("flex items-center gap-2", className),
		...props
	});
}
//#endregion
//#region src/options/components/SettingRow.tsx
function SettingRow({ label, htmlFor, description, children, stack = false }) {
	if (stack) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor,
				className: "text-muted-foreground",
				children: label
			}),
			description != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: description
			}),
			children
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
				htmlFor,
				children: label
			}), description != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-muted-foreground",
				children: description
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "shrink-0",
			children
		})]
	});
}
//#endregion
//#region src/shared/links.ts
/** Centralised outbound links used across extension surfaces. */
var LINKS = {
	website: "https://motrix.app",
	repo: "https://github.com/udstd0038/motrix-takeover",
	issues: "https://github.com/agalwood/Motrix/issues",
	docs: "https://motrix.app/manual/",
	license: "https://github.com/agalwood/Motrix/blob/master/LICENSE"
};
//#endregion
//#region src/options/tabs/HelpTab.tsx
function HelpTab() {
	const { t } = useTranslation();
	const logLevelItems = {
		silent: t("options.diagnostics.logLevels.silent"),
		error: t("options.diagnostics.logLevels.error"),
		warn: t("options.diagnostics.logLevels.warn"),
		info: t("options.diagnostics.logLevels.info"),
		debug: t("options.diagnostics.logLevels.debug")
	};
	const form = useForm({
		resolver: zodFormResolver(helpFormSchema),
		defaultValues: { logLevel: "info" }
	});
	const [adapters, setAdapters] = (0, import_react.useState)([]);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const extId = browser.runtime.id;
	const version = browser.runtime.getManifest().version;
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			const level = await getLogLevel();
			if (!cancelled) form.reset({ logLevel: level });
		})();
		return () => {
			cancelled = true;
		};
	}, [form]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const r = await send("bg.listAdapters", void 0);
				if (!cancelled) setAdapters(r.adapters.map((a) => a.id));
			} catch {}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	const onSubmit = async (values) => {
		await setLogLevel(values.logLevel);
	};
	const copyDiagnostics = async () => {
		const text = [
			`Extension ID: ${extId}`,
			`Version: ${version}`,
			`Adapters: ${adapters.length ? adapters.join(", ") : "none"}`
		].join("\n");
		try {
			await navigator.clipboard.writeText(text);
			setCopied(true);
		} catch {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingPanel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingSection, {
			title: t("options.help.title"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemGroup, {
				className: "gap-0 overflow-hidden rounded-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						variant: "muted",
						className: "rounded-none transition-[color,background-color,border-color,transform] duration-100 ease-out active:scale-[0.995] motion-reduce:transform-none",
						render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: LINKS.docs,
							target: "_blank",
							rel: "noreferrer"
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMedia, {
								variant: "icon",
								className: "size-9 border rounded-lg bg-background text-foreground shadow-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpenText, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemTitle, { children: t("options.help.docs") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDescription, { children: t("options.help.docsDescription") })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemActions, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
								"aria-hidden": "true",
								className: "text-muted-foreground"
							}) })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemSeparator, { className: "my-0 ml-16" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
						variant: "muted",
						className: "rounded-none transition-[color,background-color,border-color,transform] duration-100 ease-out active:scale-[0.995] motion-reduce:transform-none",
						render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: LINKS.issues,
							target: "_blank",
							rel: "noreferrer"
						}),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMedia, {
								variant: "icon",
								className: "size-9 border rounded-lg bg-background text-foreground shadow-xs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bug, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemTitle, { children: t("options.help.reportBug") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDescription, { children: t("options.help.reportBugDescription") })] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemActions, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
								"aria-hidden": "true",
								className: "text-muted-foreground"
							}) })
						]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-5" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingSection, {
			title: t("options.help.diagnostics"),
			description: t("options.help.diagnosticsDescription"),
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "ghost",
				onClick: () => void copyDiagnostics(),
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { "data-icon": "inline-start" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "data-icon": "inline-start" }), copied ? t("options.help.copied") : t("options.help.copyDiagnostics")]
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingsTabForm, {
				form,
				onSubmit,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormField, {
					control: form.control,
					name: "logLevel",
					render: ({ field }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						orientation: "responsive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: "help-log-level",
							children: t("options.diagnostics.logLevel")
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							items: logLevelItems,
							value: field.value,
							onValueChange: (value) => {
								if (value !== null) field.onChange(value);
							},
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
								id: "help-log-level",
								className: "min-w-48",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectGroup, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "silent",
									children: logLevelItems.silent
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "error",
									children: logLevelItems.error
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "warn",
									children: logLevelItems.warn
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "info",
									children: logLevelItems.info
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "debug",
									children: logLevelItems.debug
								})
							] }) })]
						})]
					})
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
							label: t("options.diagnostics.extensionId"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-72 truncate font-mono text-xs",
								children: extId
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
							label: t("options.diagnostics.version"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: version
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingRow, {
							label: t("options.diagnostics.adapters"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "max-w-72 text-right text-xs",
								children: adapters.length ? adapters.join(", ") : t("options.diagnostics.noneRegistered")
							})
						})
					]
				})]
			})
		})
	] });
}
//#endregion
//#region src/components/ui/badge.tsx
var badgeVariants = cva("group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-4xl border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3!", {
	variants: { variant: {
		default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
		secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
		destructive: "bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",
		outline: "border-border text-foreground [a]:hover:bg-muted [a]:hover:text-muted-foreground",
		ghost: "hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",
		link: "text-primary underline-offset-4 hover:underline"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant = "default", render, ...props }) {
	return useRender({
		defaultTagName: "span",
		props: mergeProps({ className: cn(badgeVariants({ variant }), className) }, props),
		render,
		state: {
			slot: "badge",
			variant
		}
	});
}
//#endregion
//#region src/options/integration/BackendListSection.tsx
function BackendListSection({ config, localBackendAvailable, connectionState, paired, pairingLoading, busy, onAdd, onEdit, onDelete, onActivate }) {
	const { t } = useTranslation();
	const activeEndpointId = config?.activeEndpointId ?? "local";
	const backendRows = [...localBackendAvailable ? [{
		id: LOCAL_ENDPOINT_ID,
		name: t("options.endpoint.localName"),
		description: t("options.endpoint.localDescription"),
		server: null
	}] : [], ...(config?.servers ?? []).map((server) => ({
		id: server.id,
		name: server.name,
		description: server.url,
		server
	}))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingSection, {
		title: t("options.endpoint.currentTitle"),
		description: t("options.endpoint.currentDescription"),
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			size: "sm",
			disabled: config === null || busy,
			onClick: onAdd,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), t("options.servers.add")]
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemGroup, {
			"aria-label": t("options.endpoint.listLabel"),
			children: backendRows.map((backend) => {
				const current = backend.id === activeEndpointId;
				const server = backend.server;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
					role: "listitem",
					variant: current ? "muted" : "outline",
					size: "sm",
					"aria-current": current ? "true" : void 0,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMedia, {
							variant: "icon",
							children: backend.server === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemContent, {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemTitle, { children: backend.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDescription, {
								title: backend.description,
								children: backend.description
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemActions, {
							className: "ml-auto max-w-full flex-wrap justify-end",
							children: [current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: "secondary",
									children: t("options.servers.current")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: connectionState === "connected" ? "default" : "outline",
									children: t(`options.endpoint.connection.${connectionState}`)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: paired ? "secondary" : "outline",
									children: pairingLoading ? t("options.pairing.loading") : paired ? t("options.pairing.paired") : t("options.pairing.notPaired")
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								disabled: config === null || busy,
								"aria-label": t("options.endpoint.activateAria", { name: backend.name }),
								onClick: () => void onActivate(backend.id),
								children: t("options.endpoint.activate")
							}), server !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon-sm",
								disabled: busy,
								"aria-label": t("options.servers.editAria", { name: server.name }),
								onClick: () => onEdit(server),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "ghost",
								size: "icon-sm",
								disabled: busy,
								"aria-label": t("options.servers.deleteAria", { name: server.name }),
								onClick: () => onDelete(server),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})] })]
						})
					]
				}, backend.id);
			})
		}), config !== null && config.servers.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			className: "gap-y-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("options.servers.emptyTitle") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("options.servers.emptyDescription") })
			]
		})]
	});
}
//#endregion
//#region src/options/integration/BackendPairingSection.tsx
function BackendPairingSection({ selectedEndpointName, localBackendUnavailable, isRemote, pairingLoading, paired, ready, busy, onPair, onReconnect, onForget, children }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingSection, {
		title: t("options.pairing.backendTitle", { name: selectedEndpointName }),
		description: t("options.pairing.scopedHelp"),
		children: [
			localBackendUnavailable ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				className: "gap-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("options.pairing.serverRequiredTitle") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("options.pairing.serverRequiredHelp") })
				]
			}) : pairingLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				className: "gap-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("options.pairing.loading") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("options.pairing.scopedHelp") })
				]
			}) : isRemote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				className: "gap-y-1",
				children: [
					paired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: paired ? t("options.pairing.pairedTitle") : t("options.pairing.remoteTitle") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: paired ? t("options.pairing.pairedHelp") : t("options.pairing.remoteHelp") })
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				className: "gap-y-1",
				children: [
					paired ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: paired ? t("options.pairing.pairedTitle") : t("options.pairing.localTitle") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: paired ? t("options.pairing.pairedHelp") : t("options.pairing.localHelp") })
				]
			}),
			children,
			!localBackendUnavailable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					!paired && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						disabled: !ready || busy,
						onClick: onPair,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { "data-icon": "inline-start" }), t("options.pairing.pair")]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "outline",
						disabled: !ready || busy || !paired,
						onClick: () => void onReconnect(),
						children: [
							busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }),
							!busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "data-icon": "inline-start" }),
							t("options.pairing.reconnect")
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "destructive",
						disabled: !paired || busy,
						onClick: () => void onForget(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { "data-icon": "inline-start" }), t("options.pairing.forget")]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/options/integration/messages.ts
function assertMessageSucceeded(value) {
	if (typeof value === "object" && value !== null && "error" in value && typeof value.error === "string") throw new Error(value.error);
}
//#endregion
//#region src/popup/InstancePicker.tsx
/** A candidate's §4.1 `instanceId` is at most 128 ASCII chars (per
*  discovery-service.ts's own bound) — this is purely a display trim so one
*  long value can't push the port/version columns off a narrow popup. */
function shortInstanceId(instanceId) {
	if (instanceId === null) return "—";
	return instanceId.length > 12 ? `${instanceId.slice(0, 12)}…` : instanceId;
}
function InstancePicker({ candidates, onChoose, onRescan, disabled, rescanning }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [candidates.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: t("popup.pairing.pickerHelp")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "sm",
				variant: "outline",
				className: "ml-auto",
				disabled: disabled || rescanning,
				onClick: onRescan,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
					"data-icon": "inline-start",
					className: rescanning ? "animate-spin" : void 0
				}), t("popup.pairing.rescan")]
			})]
		}), candidates.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: t("popup.pairing.noCandidates")
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemGroup, {
			"aria-label": t("popup.pairing.candidatesLabel"),
			children: candidates.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Item, {
				role: "listitem",
				variant: "outline",
				size: "sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemMedia, {
						variant: "icon",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ItemContent, {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemTitle, { children: t("popup.pairing.candidatePort", { port: candidate.port }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemDescription, { children: t("popup.pairing.candidateDetail", {
							instanceId: shortInstanceId(candidate.instanceId),
							appVersion: candidate.appVersion ?? t("popup.pairing.unknownVersion")
						}) })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemActions, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "sm",
						disabled,
						onClick: () => onChoose(candidate.port),
						children: t("popup.pairing.choose")
					}) })
				]
			}, candidate.port))
		})]
	});
}
//#endregion
//#region src/options/integration/PairingDialog.tsx
/**
* Discover → (auto-proceed on one candidate, or let the user choose) →
* chooseCandidate → poll for the pairingCode prompt bg.getState surfaces →
* submitPairingCode, repeating for each retry run until success or failure.
*
* Never renders "paired"/"connected" before `onPaired()` fires, and
* `onPaired()` only fires once bg.getState reports `state === 'connected'`
* — which is only true after a verified `confirmB`, never merely on
* `pairAccept`.
*/
function PairingDialog({ open, remote, onOpenChange, onPaired }) {
	const { t } = useTranslation();
	const [candidates, setCandidates] = (0, import_react.useState)(null);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [chosen, setChosen] = (0, import_react.useState)(false);
	const [pairingCode, setPairingCode] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [dialogError, setDialogError] = (0, import_react.useState)(null);
	const remoteAttemptStarted = (0, import_react.useRef)(false);
	const rescan = (0, import_react.useCallback)(async () => {
		setScanning(true);
		setDialogError(null);
		try {
			const response = await send("bg.listPairCandidates", void 0);
			assertMessageSucceeded(response);
			setCandidates(response.candidates);
		} catch {
			setDialogError(t("errors.connection.generic"));
		} finally {
			setScanning(false);
		}
	}, [t]);
	(0, import_react.useEffect)(() => {
		if (!open) {
			remoteAttemptStarted.current = false;
			setCandidates(null);
			setChosen(false);
			setPairingCode(null);
			setDialogError(null);
			return;
		}
		if (remote) {
			if (remoteAttemptStarted.current) return;
			remoteAttemptStarted.current = true;
			setChosen(true);
			send("bg.reconnect", void 0).then((response) => {
				try {
					assertMessageSucceeded(response);
				} catch {
					setDialogError(t("errors.connection.generic"));
				}
			});
			return;
		}
		rescan();
	}, [
		open,
		remote,
		rescan,
		t
	]);
	const choose = (0, import_react.useCallback)(async (port) => {
		setChosen(true);
		setDialogError(null);
		try {
			const response = await send("bg.chooseCandidate", { port });
			assertMessageSucceeded(response);
			if (!response.ok) setDialogError(t("errors.connection.generic"));
		} catch {
			setDialogError(t("errors.connection.generic"));
		}
	}, [t]);
	(0, import_react.useEffect)(() => {
		if (!open || chosen || candidates === null || candidates.length !== 1) return;
		const only = candidates[0];
		if (only !== void 0) choose(only.port);
	}, [
		open,
		chosen,
		candidates,
		choose
	]);
	(0, import_react.useEffect)(() => {
		if (!chosen) return;
		let cancelled = false;
		const tick = async () => {
			try {
				const response = await send("bg.getState", void 0);
				assertMessageSucceeded(response);
				if (cancelled) return;
				if (response.state === "connected") {
					onPaired();
					onOpenChange(false);
					return;
				}
				if (response.pairingCode) setDialogError(null);
				else if (response.state === "disconnected" && response.lastError) setDialogError(t(connectionErrorKey(response.lastErrorReason ?? null)));
				setPairingCode(response.pairingCode ?? null);
			} catch {}
		};
		tick();
		const timer = setInterval(() => void tick(), 1e3);
		return () => {
			cancelled = true;
			clearInterval(timer);
		};
	}, [
		chosen,
		onOpenChange,
		onPaired,
		t
	]);
	(0, import_react.useEffect)(() => {
		if (pairingCode === null) return;
		const timer = setInterval(() => {
			send("bg.pairHeartbeat", void 0);
		}, 2e4);
		return () => clearInterval(timer);
	}, [pairingCode]);
	const submitCode = (0, import_react.useCallback)(async (code) => {
		setSubmitting(true);
		setDialogError(null);
		try {
			const response = await send("bg.submitPairingCode", { code });
			if (response.ok === false) {
				setDialogError(t("errors.connection.deadlineExceeded"));
				return;
			}
			assertMessageSucceeded(response);
		} catch {
			setDialogError(t("errors.connection.generic"));
		} finally {
			setSubmitting(false);
		}
	}, [t]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("options.pairing.pairDialogTitle") }) }),
			dialogError !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				variant: "destructive",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: dialogError })]
			}),
			!remote && !chosen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InstancePicker, {
				candidates: candidates ?? [],
				onChoose: (port) => void choose(port),
				onRescan: () => void rescan(),
				disabled: scanning,
				rescanning: scanning
			}),
			chosen && pairingCode === null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}), t("options.pairing.loading")]
			}),
			chosen && pairingCode !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairingCodePanel, {
				onSubmit: (code) => void submitCode(code),
				size: "lg",
				run: pairingCode.run,
				maxRuns: pairingCode.maxRuns,
				attemptsRemaining: pairingCode.attemptsRemaining,
				disabled: submitting
			})
		] })
	});
}
//#endregion
//#region src/options/integration/RemoteServerCard.tsx
function ServerSecurityTooltip({ secure }) {
	const { t } = useTranslation();
	const description = t(secure ? "options.servers.statusTransportSecure" : "options.servers.statusTransportPlain");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		type: "button",
		"aria-label": description,
		className: cn("inline-flex size-5 shrink-0 items-center justify-center rounded-sm outline-none transition-colors hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 [&>svg]:size-4", secure ? "text-muted-foreground" : "text-destructive"),
		children: secure ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { "aria-hidden": "true" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { "aria-hidden": "true" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		className: "max-w-80",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: description })
	})] });
}
function RemoteServerCard({ server, serverIdentity, connectionState, paired, policy, busy, onPolicyChange }) {
	const { t } = useTranslation();
	const remoteDownloadSwitchId = (0, import_react.useId)();
	const policyReplacement = (changes) => ({
		remoteDataBoundaryAcceptedAt: policy?.remoteDataBoundaryAcceptedAt ?? null,
		allowRequestCredentials: policy?.allowRequestCredentials ?? false,
		allowCustomHeaders: policy?.allowCustomHeaders ?? false,
		allowPageContent: false,
		allowServerUrlProbe: false,
		allowServerUrlResolve: false,
		allowAutomaticTakeover: false,
		...changes
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		"aria-label": t("options.servers.statusTitle"),
		className: "gap-y-1 pr-4 has-data-[slot=alert-action]:pr-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, {
				className: cn("truncate", paired && "pr-40"),
				children: server.name
			}),
			paired && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertAction, {
				className: "top-4 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: remoteDownloadSwitchId,
					className: "whitespace-nowrap",
					children: t("options.pairing.remoteConsentTitle")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					id: remoteDownloadSwitchId,
					"aria-label": t("options.pairing.remoteConsentTitle"),
					checked: policy?.remoteDataBoundaryAcceptedAt != null,
					disabled: connectionState !== "connected" || policy === null || busy,
					onCheckedChange: (checked) => void onPolicyChange(policyReplacement({
						remoteDataBoundaryAcceptedAt: checked ? Date.now() : null,
						...!checked ? {
							allowCustomHeaders: false,
							allowRequestCredentials: false
						} : {}
					}))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, {
				className: "flex flex-col gap-2 [&_p:not(:last-child)]:mb-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 break-all",
							children: t("options.servers.statusAuthority", { value: server.url })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServerSecurityTooltip, { secure: server.url.startsWith("wss://") })]
					}),
					serverIdentity !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "opacity-70",
						children: t("options.servers.statusRuntime", {
							runtime: serverIdentity.runtime,
							name: serverIdentity.name,
							version: serverIdentity.version
						})
					}),
					paired && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("options.pairing.remoteConsentBody") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("options.takeover.remoteUnavailable") }),
					paired && connectionState !== "connected" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("options.pairing.remoteConsentOffline") }),
					policy?.remoteDataBoundaryAcceptedAt != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 pt-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium text-card-foreground",
									children: t("options.pairing.remoteHeadersLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("options.pairing.remoteHeadersHelp") })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								"aria-label": t("options.pairing.remoteHeadersLabel"),
								checked: policy.allowCustomHeaders,
								disabled: connectionState !== "connected" || busy,
								onCheckedChange: (checked) => void onPolicyChange(policyReplacement({
									allowCustomHeaders: checked,
									...!checked ? { allowRequestCredentials: false } : {}
								}))
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium text-card-foreground",
									children: t("options.pairing.remoteCredentialsLabel")
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("options.pairing.remoteCredentialsHelp") })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
								"aria-label": t("options.pairing.remoteCredentialsLabel"),
								checked: policy.allowRequestCredentials,
								disabled: connectionState !== "connected" || busy || !policy.allowCustomHeaders,
								onCheckedChange: (checked) => void onPolicyChange(policyReplacement({ allowRequestCredentials: checked }))
							})]
						})]
					})
				]
			})
		]
	});
}
//#endregion
//#region src/options/integration/ServerEditorDialog.tsx
function ServerEditorDialog({ open, server, onOpenChange, onSave }) {
	const { t } = useTranslation();
	const form = useForm({
		resolver: zodFormResolver(serverFormSchema),
		defaultValues: {
			name: "",
			url: ""
		}
	});
	const usesPlainWebSocket = form.watch("url").toLowerCase().startsWith("ws://");
	(0, import_react.useEffect)(() => {
		if (!open) return;
		form.reset({
			name: server?.name ?? "",
			url: server?.url ?? ""
		});
	}, [
		form,
		open,
		server
	]);
	const handleSubmit = async (values) => {
		try {
			await onSave(values);
			onOpenChange(false);
		} catch {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: server === null ? t("options.servers.addTitle") : t("options.servers.editTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: t("options.servers.dialogDescription") })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
				id: "motrix-server-form",
				onSubmit: form.handleSubmit(handleSubmit),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldGroup, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						"data-invalid": form.formState.errors.name !== void 0,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "motrix-server-name",
								children: t("options.servers.nameLabel")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "motrix-server-name",
								autoComplete: "off",
								placeholder: t("options.servers.namePlaceholder"),
								"aria-invalid": form.formState.errors.name !== void 0,
								...form.register("name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: form.formState.errors.name?.message === void 0 ? null : t(form.formState.errors.name.message) })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						"data-invalid": form.formState.errors.url !== void 0,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "motrix-server-url",
								children: t("options.servers.urlLabel")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "motrix-server-url",
								autoComplete: "url",
								inputMode: "url",
								placeholder: t("options.servers.urlPlaceholder"),
								"aria-invalid": form.formState.errors.url !== void 0,
								...form.register("url")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: t("options.servers.urlDescription") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: form.formState.errors.url?.message === void 0 ? null : t(form.formState.errors.url.message) })
						]
					}),
					usesPlainWebSocket && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
						"aria-label": t("options.servers.transportWarningTitle"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("options.servers.transportWarningTitle") }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("options.servers.transportWarningBody") })
						]
					})
				] })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline"
				}),
				children: t("options.common.cancel")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				form: "motrix-server-form",
				disabled: form.formState.isSubmitting,
				children: [form.formState.isSubmitting && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }), t("options.servers.save")]
			})] })
		] })
	});
}
//#endregion
//#region src/options/integration/useIntegrationSettings.ts
/** Keeps catalog mutations, connection refreshes and recovery in one place. */
function useIntegrationSettings() {
	const { t } = useTranslation();
	const [config, setConfig] = (0, import_react.useState)(null);
	const [connectionState, setConnectionState] = (0, import_react.useState)("disconnected");
	const [serverIdentity, setServerIdentity] = (0, import_react.useState)(null);
	const [pairing, setPairing] = (0, import_react.useState)(null);
	const [pairingLoading, setPairingLoading] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [remotePolicyBusy, setRemotePolicyBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [editorOpen, setEditorOpen] = (0, import_react.useState)(false);
	const [editingServer, setEditingServer] = (0, import_react.useState)(null);
	const [serverToDelete, setServerToDelete] = (0, import_react.useState)(null);
	const [remotePolicy, setRemotePolicy] = (0, import_react.useState)(null);
	const refreshConnection = (0, import_react.useCallback)(async () => {
		const response = await send("bg.getState", void 0);
		assertMessageSucceeded(response);
		setConnectionState(response.state);
		setServerIdentity(response.server ?? null);
	}, []);
	const refreshPairing = (0, import_react.useCallback)(async (endpointId) => {
		setPairingLoading(true);
		try {
			const response = await send("bg.getPairingStatus", { endpointId });
			assertMessageSucceeded(response);
			setPairing({
				endpointId,
				paired: response.paired
			});
		} finally {
			setPairingLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const [endpointConfig, stateResponse] = await Promise.all([send("bg.getEndpointConfig", void 0), send("bg.getState", void 0)]);
				if (cancelled) return;
				assertMessageSucceeded(endpointConfig);
				assertMessageSucceeded(stateResponse);
				setConfig(endpointConfig);
				setConnectionState(stateResponse.state);
				setServerIdentity(stateResponse.server ?? null);
				const pairingResponse = await send("bg.getPairingStatus", { endpointId: endpointConfig.activeEndpointId });
				if (cancelled) return;
				assertMessageSucceeded(pairingResponse);
				setPairing({
					endpointId: endpointConfig.activeEndpointId,
					paired: pairingResponse.paired
				});
				setPairingLoading(false);
			} catch (cause) {
				if (!cancelled) {
					setError(cause.message);
					setPairingLoading(false);
				}
			}
		})();
		return () => {
			cancelled = true;
		};
	}, []);
	const activeEndpointId = config?.activeEndpointId ?? "local";
	const activeEndpointIdRef = (0, import_react.useRef)(activeEndpointId);
	activeEndpointIdRef.current = activeEndpointId;
	const activeServer = config?.servers.find((server) => server.id === activeEndpointId) ?? null;
	const paired = pairing?.endpointId === activeEndpointId ? pairing.paired : false;
	const isRemote = activeEndpointId !== LOCAL_ENDPOINT_ID;
	(0, import_react.useEffect)(() => {
		if (connectionState === "connected" || connectionState === "disconnected" || connectionState === "denied") return;
		let cancelled = false;
		let inFlight = false;
		const syncingEndpointId = activeEndpointId;
		const syncConnection = async () => {
			if (inFlight) return;
			inFlight = true;
			try {
				const response = await send("bg.getState", void 0);
				assertMessageSucceeded(response);
				if (cancelled || activeEndpointIdRef.current !== syncingEndpointId) return;
				setConnectionState(response.state);
				setServerIdentity(response.server ?? null);
			} catch {} finally {
				inFlight = false;
			}
		};
		syncConnection();
		const timer = window.setInterval(() => void syncConnection(), 1e3);
		return () => {
			cancelled = true;
			window.clearInterval(timer);
		};
	}, [activeEndpointId, connectionState]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		if (!isRemote || !paired) {
			setRemotePolicy(null);
			return () => {
				cancelled = true;
			};
		}
		if (connectionState !== "connected") return () => {
			cancelled = true;
		};
		send("bg.getRemoteBackendPolicy", void 0).then((response) => {
			if (cancelled) return;
			assertMessageSucceeded(response);
			setRemotePolicy(response.policy);
		}).catch(() => {
			if (!cancelled) setRemotePolicy(null);
		});
		return () => {
			cancelled = true;
		};
	}, [
		connectionState,
		isRemote,
		paired
	]);
	const runAction = async (action, rethrow = false, setPending = setBusy) => {
		setPending(true);
		setError(null);
		try {
			await action();
		} catch (cause) {
			setError(cause.message);
			try {
				const latest = await send("bg.getEndpointConfig", void 0);
				assertMessageSucceeded(latest);
				setConfig(latest);
				setPairing(null);
				await Promise.all([refreshPairing(latest.activeEndpointId), refreshConnection()]);
			} catch {}
			if (rethrow) throw cause;
		} finally {
			setPending(false);
		}
	};
	const handleEndpointChange = async (endpointId) => {
		if (config === null || endpointId === config.activeEndpointId) return;
		await runAction(async () => {
			const activated = await send("bg.activateEndpoint", { endpointId });
			assertMessageSucceeded(activated);
			setConfig(activated.config);
			setPairing(null);
			setRemotePolicy(null);
			setConnectionState("bootstrapping");
			setServerIdentity(null);
			await Promise.all([refreshPairing(activated.config.activeEndpointId), refreshConnection()]);
		});
	};
	const handleReconnect = async () => {
		await runAction(async () => {
			assertMessageSucceeded(await send("bg.reconnect", void 0));
			await Promise.all([refreshPairing(activeEndpointId), refreshConnection()]);
		});
	};
	const handleForget = async () => {
		await runAction(async () => {
			assertMessageSucceeded(await send("bg.unpair", { endpointId: activeEndpointId }));
			await Promise.all([refreshPairing(activeEndpointId), refreshConnection()]);
		});
	};
	const replaceRemotePolicy = async (replacement) => {
		await runAction(async () => {
			const response = await send("bg.replaceRemoteBackendPolicy", replacement);
			assertMessageSucceeded(response);
			setRemotePolicy(response.policy);
			await refreshConnection();
		}, false, setRemotePolicyBusy);
	};
	const openAddServer = () => {
		setEditingServer(null);
		setEditorOpen(true);
	};
	const openEditServer = (server) => {
		setEditingServer(server);
		setEditorOpen(true);
	};
	const handleSaveServer = async (values) => {
		if (config === null) return;
		await runAction(async () => {
			const normalizedUrl = normalizeRemoteEndpoint(values.url);
			if (config.servers.some((server) => server.id !== editingServer?.id && server.url === normalizedUrl)) throw new Error(t("options.servers.urlDuplicate"));
			const name = values.name.trim();
			const result = editingServer === null ? await send("bg.addServer", {
				name,
				url: normalizedUrl
			}) : await send("bg.updateServer", {
				endpointId: editingServer.id,
				expected: {
					name: editingServer.name,
					url: editingServer.url,
					revision: editingServer.revision
				},
				changes: {
					name,
					url: normalizedUrl
				}
			});
			assertMessageSucceeded(result);
			setConfig(result.config);
			setPairing(null);
			await Promise.all([refreshPairing(result.config.activeEndpointId), refreshConnection()]);
		}, true);
	};
	const handleDeleteServer = async () => {
		if (config === null || serverToDelete === null) return;
		const deleting = serverToDelete;
		await runAction(async () => {
			const removed = await send("bg.removeServer", {
				endpointId: deleting.id,
				expected: {
					name: deleting.name,
					url: deleting.url,
					revision: deleting.revision
				}
			});
			assertMessageSucceeded(removed);
			setConfig(removed.config);
			setServerToDelete(null);
			if (removed.wasActive) {
				setPairing(null);
				setConnectionState("disconnected");
				await Promise.all([refreshPairing(removed.config.activeEndpointId), refreshConnection()]);
			}
		});
	};
	const refreshAfterPairing = () => {
		Promise.all([refreshPairing(activeEndpointId), refreshConnection()]);
	};
	return {
		config,
		connectionState,
		serverIdentity,
		activeEndpointId,
		activeServer,
		isRemote,
		paired,
		pairingLoading,
		busy,
		remotePolicyBusy,
		remotePolicy,
		error,
		editorOpen,
		setEditorOpen,
		editingServer,
		serverToDelete,
		setServerToDelete,
		openAddServer,
		openEditServer,
		handleEndpointChange,
		handleReconnect,
		handleForget,
		replaceRemotePolicy,
		handleSaveServer,
		handleDeleteServer,
		refreshAfterPairing
	};
}
//#endregion
//#region src/options/tabs/IntegrationTab.tsx
function IntegrationTab() {
	const { t } = useTranslation();
	const localBackendAvailable = hasNativeMessagingSupport();
	const [pairDialogOpen, setPairDialogOpen] = (0, import_react.useState)(false);
	const { config, connectionState, serverIdentity, activeEndpointId, activeServer, isRemote, paired, pairingLoading, busy, remotePolicyBusy, remotePolicy, error, editorOpen, setEditorOpen, editingServer, serverToDelete, setServerToDelete, openAddServer, openEditServer, handleEndpointChange, handleReconnect, handleForget, replaceRemotePolicy, handleSaveServer, handleDeleteServer, refreshAfterPairing } = useIntegrationSettings();
	const localBackendUnavailable = !localBackendAvailable && activeEndpointId === "local";
	const selectedEndpointName = activeServer?.name ?? t(localBackendAvailable ? "options.endpoint.localName" : "popup.backend.server");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SettingPanel, { children: [
			error !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				variant: "destructive",
				className: "gap-y-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("options.common.saveError") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: error })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackendListSection, {
				config,
				localBackendAvailable,
				connectionState,
				paired,
				pairingLoading,
				busy,
				onAdd: openAddServer,
				onEdit: openEditServer,
				onDelete: setServerToDelete,
				onActivate: handleEndpointChange
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-5" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackendPairingSection, {
				selectedEndpointName,
				localBackendUnavailable,
				isRemote,
				pairingLoading,
				paired,
				ready: config !== null,
				busy,
				onPair: () => setPairDialogOpen(true),
				onReconnect: handleReconnect,
				onForget: handleForget,
				children: isRemote && activeServer !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RemoteServerCard, {
					server: activeServer,
					serverIdentity,
					connectionState,
					paired,
					policy: remotePolicy,
					busy: busy || remotePolicyBusy,
					onPolicyChange: replaceRemotePolicy
				})
			})
		] }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServerEditorDialog, {
			open: editorOpen,
			server: editingServer,
			onOpenChange: setEditorOpen,
			onSave: handleSaveServer
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairingDialog, {
			open: pairDialogOpen,
			remote: isRemote,
			onOpenChange: setPairDialogOpen,
			onPaired: refreshAfterPairing
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: serverToDelete !== null,
			onOpenChange: (open) => {
				if (!open) setServerToDelete(null);
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("options.servers.deleteTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t(serverToDelete?.id === activeEndpointId ? localBackendAvailable ? "options.servers.deleteActiveDescription" : "options.servers.deleteActiveServerOnlyDescription" : "options.servers.deleteDescription", { name: serverToDelete?.name ?? "" }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: t("options.common.cancel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogAction, {
				variant: "destructive",
				disabled: busy,
				onClick: () => void handleDeleteServer(),
				children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }), t("options.servers.delete")]
			})] })] })
		})
	] });
}
//#endregion
//#region src/options/App.tsx
function App() {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen w-full px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-4xl space-y-7",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 rounded-[1.625rem] border border-border/70 bg-accent pt-5 p-2.5 shadow-card",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex flex-wrap items-center gap-4 px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/app-icon.png",
							alt: "Motrix App Icon",
							className: "size-14 shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-semibold tracking-tight text-foreground",
								children: t("options.title")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 max-w-xl text-sm text-muted-foreground",
								children: t("options.about.subtitle")
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						"aria-label": "Motrix",
						className: "ml-auto flex shrink-0 items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: LINKS.website,
							target: "_blank",
							rel: "noreferrer",
							"aria-label": t("options.about.website"),
							title: t("options.about.website"),
							className: buttonVariants({
								size: "icon-sm",
								variant: "ghost"
							}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Earth, { "aria-hidden": "true" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: LINKS.repo,
							target: "_blank",
							rel: "noreferrer",
							"aria-label": "GitHub",
							title: "GitHub",
							className: buttonVariants({
								size: "icon-sm",
								variant: "ghost"
							}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitHubMark, {})
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
					defaultValue: "general",
					className: "",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
							className: "w-full bg-tab-background",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "general",
									children: t("options.tabs.general")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "download",
									children: t("options.tabs.download")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "integration",
									children: t("options.tabs.integration")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
									value: "help",
									children: t("options.tabs.help")
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "general",
							className: "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GeneralTab, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "download",
							className: "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DownloadTab, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "integration",
							className: "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IntegrationTab, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: "help",
							className: "",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpTab, {})
						})
					]
				})]
			})
		})
	}) });
}
//#endregion
//#region src/options/index.tsx
initTheme();
var root = document.getElementById("root");
initI18n().then(() => {
	if (root) (0, import_client.createRoot)(root).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}));
});
//#endregion

//# sourceMappingURL=options.html-CRN-NNmE.js.map