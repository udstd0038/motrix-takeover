//#region \0rolldown/runtime.js
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJSMin = (cb, mod) => () => (mod || (cb((mod = { exports: {} }).exports, mod), cb = null), mod.exports);
var __copyProps = (to, from, except, desc) => {
	if (from && typeof from === "object" || typeof from === "function") for (var keys = __getOwnPropNames(from), i = 0, n = keys.length, key; i < n; i++) {
		key = keys[i];
		if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
			get: ((k) => from[k]).bind(null, key),
			enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
		});
	}
	return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(isNodeMode || !mod || !mod.__esModule || !__hasOwnProp.call(mod, "default") ? __defProp(target, "default", {
	value: mod,
	enumerable: true
}) : target, mod));
//#endregion
//#region node_modules/.pnpm/i18next@26.4.0_typescript@7.0.2/node_modules/i18next/dist/esm/i18next.js
var isString = (obj) => typeof obj === "string";
var defer = () => {
	let res;
	let rej;
	const promise = new Promise((resolve, reject) => {
		res = resolve;
		rej = reject;
	});
	promise.resolve = res;
	promise.reject = rej;
	return promise;
};
var makeString = (object) => {
	if (object == null) return "";
	return String(object);
};
var copy = (a, s, t) => {
	a.forEach((m) => {
		if (s[m]) t[m] = s[m];
	});
};
var lastOfPathSeparatorRegExp = /###/g;
var cleanKey = (key) => key && key.includes("###") ? key.replace(lastOfPathSeparatorRegExp, ".") : key;
var canNotTraverseDeeper = (object) => !object || isString(object);
var getLastOfPath = (object, path, Empty) => {
	const stack = !isString(path) ? path : path.split(".");
	let stackIndex = 0;
	while (stackIndex < stack.length - 1) {
		if (canNotTraverseDeeper(object)) return {};
		const key = cleanKey(stack[stackIndex]);
		if (!object[key] && Empty) object[key] = new Empty();
		if (Object.prototype.hasOwnProperty.call(object, key)) object = object[key];
		else object = {};
		++stackIndex;
	}
	if (canNotTraverseDeeper(object)) return {};
	return {
		obj: object,
		k: cleanKey(stack[stackIndex])
	};
};
var setPath = (object, path, newValue) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	if (obj !== void 0 || path.length === 1) {
		obj[k] = newValue;
		return;
	}
	let e = path[path.length - 1];
	let p = path.slice(0, path.length - 1);
	let last = getLastOfPath(object, p, Object);
	while (last.obj === void 0 && p.length) {
		e = `${p[p.length - 1]}.${e}`;
		p = p.slice(0, p.length - 1);
		last = getLastOfPath(object, p, Object);
		if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== "undefined") last.obj = void 0;
	}
	last.obj[`${last.k}.${e}`] = newValue;
};
var pushPath = (object, path, newValue, concat) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	obj[k] = obj[k] || [];
	obj[k].push(newValue);
};
var getPath = (object, path) => {
	const { obj, k } = getLastOfPath(object, path);
	if (!obj) return void 0;
	if (!Object.prototype.hasOwnProperty.call(obj, k)) return void 0;
	return obj[k];
};
var getPathWithDefaults = (data, defaultData, key) => {
	const value = getPath(data, key);
	if (value !== void 0) return value;
	return getPath(defaultData, key);
};
var deepExtend = (target, source, overwrite) => {
	for (const prop in source) if (prop !== "__proto__" && prop !== "constructor") {
		if (Object.prototype.hasOwnProperty.call(target, prop)) {
			if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
				if (overwrite) target[prop] = source[prop];
			} else deepExtend(target[prop], source[prop], overwrite);
		} else target[prop] = source[prop];
	}
	return target;
};
var regexEscape = (str) => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
var _entityMap = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;"
};
var escape = (data) => {
	if (isString(data)) return data.replace(/[&<>"'\/]/g, (s) => _entityMap[s]);
	return data;
};
var RegExpCache = class {
	constructor(capacity) {
		this.capacity = capacity;
		this.regExpMap = /* @__PURE__ */ new Map();
		this.regExpQueue = [];
	}
	getRegExp(pattern) {
		const regExpFromCache = this.regExpMap.get(pattern);
		if (regExpFromCache !== void 0) return regExpFromCache;
		const regExpNew = new RegExp(pattern);
		if (this.regExpQueue.length === this.capacity) this.regExpMap.delete(this.regExpQueue.shift());
		this.regExpMap.set(pattern, regExpNew);
		this.regExpQueue.push(pattern);
		return regExpNew;
	}
};
var chars = [
	" ",
	",",
	"?",
	"!",
	";"
];
var looksLikeObjectPathRegExpCache = new RegExpCache(20);
var looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
	nsSeparator = nsSeparator || "";
	keySeparator = keySeparator || "";
	const possibleChars = chars.filter((c) => !nsSeparator.includes(c) && !keySeparator.includes(c));
	if (possibleChars.length === 0) return true;
	const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map((c) => c === "?" ? "\\?" : c).join("|")})`);
	let matched = !r.test(key);
	if (!matched) {
		const ki = key.indexOf(keySeparator);
		if (ki > 0 && !r.test(key.substring(0, ki))) matched = true;
	}
	return matched;
};
var deepFind = (obj, path, keySeparator = ".") => {
	if (!obj) return void 0;
	if (obj[path]) {
		if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
		return obj[path];
	}
	const tokens = path.split(keySeparator);
	let current = obj;
	for (let i = 0; i < tokens.length;) {
		if (!current || typeof current !== "object") return;
		let next;
		let nextPath = "";
		for (let j = i; j < tokens.length; ++j) {
			if (j !== i) nextPath += keySeparator;
			nextPath += tokens[j];
			next = current[nextPath];
			if (next !== void 0) {
				if ([
					"string",
					"number",
					"boolean"
				].includes(typeof next) && j < tokens.length - 1) continue;
				i += j - i + 1;
				break;
			}
		}
		current = next;
	}
	return current;
};
var getCleanedCode = (code) => code?.replace(/_/g, "-");
var consoleLogger = {
	type: "logger",
	log(args) {
		this.output("log", args);
	},
	warn(args) {
		this.output("warn", args);
	},
	error(args) {
		this.output("error", args);
	},
	output(type, args) {
		console?.[type]?.apply?.(console, args);
	}
};
var baseLogger = new class Logger {
	constructor(concreteLogger, options = {}) {
		this.init(concreteLogger, options);
	}
	init(concreteLogger, options = {}) {
		this.prefix = options.prefix || "i18next:";
		this.logger = concreteLogger || consoleLogger;
		this.options = options;
		this.debug = options.debug;
	}
	log(...args) {
		return this.forward(args, "log", "", true);
	}
	warn(...args) {
		return this.forward(args, "warn", "", true);
	}
	error(...args) {
		return this.forward(args, "error", "");
	}
	deprecate(...args) {
		return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
	}
	forward(args, lvl, prefix, debugOnly) {
		if (debugOnly && !this.debug) return null;
		args = args.map((a) => isString(a) ? a.replace(/[\r\n\x00-\x1F\x7F]/g, " ") : a);
		if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
		return this.logger[lvl](args);
	}
	create(moduleName) {
		return new Logger(this.logger, {
			prefix: `${this.prefix}:${moduleName}:`,
			...this.options
		});
	}
	clone(options) {
		options = options || this.options;
		options.prefix = options.prefix || this.prefix;
		return new Logger(this.logger, options);
	}
}();
var EventEmitter = class {
	constructor() {
		this.observers = {};
	}
	on(events, listener) {
		events.split(" ").forEach((event) => {
			if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
			const numListeners = this.observers[event].get(listener) || 0;
			this.observers[event].set(listener, numListeners + 1);
		});
		return this;
	}
	off(event, listener) {
		if (!this.observers[event]) return;
		if (!listener) {
			delete this.observers[event];
			return;
		}
		this.observers[event].delete(listener);
	}
	once(event, listener) {
		const wrapper = (...args) => {
			listener(...args);
			this.off(event, wrapper);
		};
		this.on(event, wrapper);
		return this;
	}
	emit(event, ...args) {
		if (this.observers[event]) Array.from(this.observers[event].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(...args);
		});
		if (this.observers["*"]) Array.from(this.observers["*"].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(event, ...args);
		});
	}
};
var ResourceStore = class extends EventEmitter {
	constructor(data, options = {
		ns: ["translation"],
		defaultNS: "translation"
	}) {
		super();
		this.data = data || {};
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		if (this.options.ignoreJSONStructure === void 0) this.options.ignoreJSONStructure = true;
	}
	addNamespaces(ns) {
		if (!this.options.ns.includes(ns)) this.options.ns.push(ns);
	}
	removeNamespaces(ns) {
		const index = this.options.ns.indexOf(ns);
		if (index > -1) this.options.ns.splice(index, 1);
	}
	getResource(lng, ns, key, options = {}) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		const ignoreJSONStructure = options.ignoreJSONStructure !== void 0 ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
		let path;
		if (lng.includes(".")) path = lng.split(".");
		else {
			path = [lng, ns];
			if (key) {
				if (Array.isArray(key)) path.push(...key);
				else if (isString(key) && keySeparator) path.push(...key.split(keySeparator));
				else path.push(key);
			}
		}
		const result = getPath(this.data, path);
		if (!result && !ns && !key && lng.includes(".")) {
			lng = path[0];
			ns = path[1];
			key = path.slice(2).join(".");
		}
		if (result || !ignoreJSONStructure || !isString(key)) return result;
		return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
	}
	addResource(lng, ns, key, value, options = { silent: false }) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		let path = [lng, ns];
		if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
		if (lng.includes(".")) {
			path = lng.split(".");
			value = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		setPath(this.data, path, value);
		if (!options.silent) this.emit("added", lng, ns, key, value);
	}
	addResources(lng, ns, resources, options = { silent: false }) {
		for (const m in resources) if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], { silent: true });
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	addResourceBundle(lng, ns, resources, deep, overwrite, options = {
		silent: false,
		skipCopy: false
	}) {
		let path = [lng, ns];
		if (lng.includes(".")) {
			path = lng.split(".");
			deep = resources;
			resources = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		let pack = getPath(this.data, path) || {};
		if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
		if (deep) deepExtend(pack, resources, overwrite);
		else pack = {
			...pack,
			...resources
		};
		setPath(this.data, path, pack);
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	removeResourceBundle(lng, ns) {
		if (this.hasResourceBundle(lng, ns)) delete this.data[lng][ns];
		this.removeNamespaces(ns);
		this.emit("removed", lng, ns);
	}
	hasResourceBundle(lng, ns) {
		return this.getResource(lng, ns) !== void 0;
	}
	getResourceBundle(lng, ns) {
		if (!ns) ns = this.options.defaultNS;
		return this.getResource(lng, ns);
	}
	getDataByLanguage(lng) {
		return this.data[lng];
	}
	hasLanguageSomeTranslations(lng) {
		const data = this.getDataByLanguage(lng);
		return !!(data && Object.keys(data) || []).find((v) => data[v] && Object.keys(data[v]).length > 0);
	}
	toJSON() {
		return this.data;
	}
};
var postProcessor = {
	processors: {},
	addPostProcessor(module) {
		this.processors[module.name] = module;
	},
	handle(processors, value, key, options, translator) {
		processors.forEach((processor) => {
			value = this.processors[processor]?.process(value, key, options, translator) ?? value;
		});
		return value;
	}
};
var PATH_KEY = Symbol("i18next/PATH_KEY");
function createProxy() {
	const state = [];
	const handler = Object.create(null);
	let proxy;
	handler.get = (target, key) => {
		proxy?.revoke?.();
		if (key === PATH_KEY) return state;
		state.push(key);
		proxy = Proxy.revocable(target, handler);
		return proxy.proxy;
	};
	return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
	const { [PATH_KEY]: path } = selector(createProxy());
	const keySeparator = opts?.keySeparator ?? ".";
	const nsSeparator = opts?.nsSeparator ?? ":";
	const strict = opts?.enableSelector === "strict";
	if (path.length > 1 && nsSeparator) {
		const ns = opts?.ns;
		const nsList = strict ? Array.isArray(ns) ? ns : ns ? [ns] : null : Array.isArray(ns) ? ns : null;
		if (nsList) {
			if ((strict ? nsList : nsList.length > 1 ? nsList.slice(1) : []).includes(path[0])) return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
		}
	}
	return path.join(keySeparator);
}
var shouldHandleAsObject = (res) => !isString(res) && typeof res !== "boolean" && typeof res !== "number";
var Translator = class Translator extends EventEmitter {
	constructor(services, options = {}) {
		super();
		copy([
			"resourceStore",
			"languageUtils",
			"pluralResolver",
			"interpolator",
			"backendConnector",
			"i18nFormat",
			"utils"
		], services, this);
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		this.logger = baseLogger.create("translator");
		this.checkedLoadedFor = {};
	}
	changeLanguage(lng) {
		if (lng) this.language = lng;
	}
	exists(key, o = { interpolation: {} }) {
		const opt = { ...o };
		if (key == null) return false;
		const resolved = this.resolve(key, opt);
		if (resolved?.res === void 0) return false;
		const isObject = shouldHandleAsObject(resolved.res);
		if (opt.returnObjects === false && isObject) return false;
		return true;
	}
	extractFromKey(key, opt) {
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		let namespaces = opt.ns || this.options.defaultNS || [];
		const wouldCheckForNsInKey = nsSeparator && key.includes(nsSeparator);
		const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
		if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
			const m = key.match(this.interpolator.nestingRegexp);
			if (m && m.length > 0) return {
				key,
				namespaces: isString(namespaces) ? [namespaces] : namespaces
			};
			const parts = key.split(nsSeparator);
			if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.includes(parts[0])) namespaces = parts.shift();
			key = parts.join(keySeparator);
		}
		return {
			key,
			namespaces: isString(namespaces) ? [namespaces] : namespaces
		};
	}
	translate(keys, o, lastKey) {
		let opt = typeof o === "object" ? { ...o } : o;
		if (typeof opt !== "object" && this.options.overloadTranslationOptionHandler) opt = this.options.overloadTranslationOptionHandler(arguments);
		if (typeof opt === "object") opt = { ...opt };
		if (!opt) opt = {};
		if (keys == null) return "";
		if (typeof keys === "function") keys = keysFromSelector(keys, {
			...this.options,
			...opt
		});
		if (!Array.isArray(keys)) keys = [String(keys)];
		keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : String(k));
		const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		const { key, namespaces } = this.extractFromKey(keys[keys.length - 1], opt);
		const namespace = namespaces[namespaces.length - 1];
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const lng = opt.lng || this.language;
		const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
		if (lng?.toLowerCase() === "cimode") {
			if (appendNamespaceToCIMode) {
				if (returnDetails) return {
					res: `${namespace}${nsSeparator}${key}`,
					usedKey: key,
					exactUsedKey: key,
					usedLng: lng,
					usedNS: namespace,
					usedParams: this.getUsedParamsDetails(opt)
				};
				return `${namespace}${nsSeparator}${key}`;
			}
			if (returnDetails) return {
				res: key,
				usedKey: key,
				exactUsedKey: key,
				usedLng: lng,
				usedNS: namespace,
				usedParams: this.getUsedParamsDetails(opt)
			};
			return key;
		}
		const resolved = this.resolve(keys, opt);
		let res = resolved?.res;
		const resUsedKey = resolved?.usedKey || key;
		const resExactUsedKey = resolved?.exactUsedKey || key;
		const noObject = [
			"[object Number]",
			"[object Function]",
			"[object RegExp]"
		];
		const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
		const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
		const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
		const hasDefaultValue = Translator.hasDefaultValue(opt);
		const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : "";
		const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, { ordinal: false }) : "";
		const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
		const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
		let resForObjHndl = res;
		if (handleAsObjectInI18nFormat && !res && hasDefaultValue) resForObjHndl = defaultValue;
		const handleAsObject = shouldHandleAsObject(resForObjHndl);
		const resType = Object.prototype.toString.apply(resForObjHndl);
		if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && !noObject.includes(resType) && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
			if (!opt.returnObjects && !this.options.returnObjects) {
				if (!this.options.returnedObjectHandler) this.logger.warn("accessing an object - but returnObjects options is not enabled!");
				const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
					...opt,
					ns: namespaces
				}) : `key '${key} (${this.language})' returned an object instead of string.`;
				if (returnDetails) {
					resolved.res = r;
					resolved.usedParams = this.getUsedParamsDetails(opt);
					return resolved;
				}
				return r;
			}
			if (keySeparator) {
				const resTypeIsArray = Array.isArray(resForObjHndl);
				const copy = resTypeIsArray ? [] : {};
				const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
				for (const m in resForObjHndl) if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
					const deepKey = `${newKeyToUse}${keySeparator}${m}`;
					if (hasDefaultValue && !res) copy[m] = this.translate(deepKey, {
						...opt,
						defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
						joinArrays: false,
						ns: namespaces
					});
					else copy[m] = this.translate(deepKey, {
						...opt,
						joinArrays: false,
						ns: namespaces
					});
					if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
				}
				res = copy;
			}
		} else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
			res = res.join(joinArrays);
			if (res) res = this.extendTranslation(res, keys, opt, lastKey);
		} else {
			let usedDefault = false;
			let usedKey = false;
			if (!this.isValidLookup(res) && hasDefaultValue) {
				usedDefault = true;
				res = defaultValue;
			}
			if (!this.isValidLookup(res)) {
				usedKey = true;
				res = key;
			}
			const resForMissing = (opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey) && usedKey ? void 0 : res;
			const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
			if (usedKey || usedDefault || updateMissing) {
				this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace, needsPluralHandling && !updateMissing ? `${key}${this.pluralResolver.getSuffix(lng, opt.count, opt)}` : key, updateMissing ? defaultValue : res);
				if (keySeparator) {
					const fk = this.resolve(key, {
						...opt,
						keySeparator: false
					});
					if (fk && fk.res) this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
				}
				let lngs = [];
				const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
				if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) for (let i = 0; i < fallbackLngs.length; i++) lngs.push(fallbackLngs[i]);
				else if (this.options.saveMissingTo === "all") lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
				else lngs.push(opt.lng || this.language);
				const send = (l, k, specificDefaultValue) => {
					const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
					if (this.options.missingKeyHandler) this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
					else if (this.backendConnector?.saveMissing) this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
					this.emit("missingKey", l, namespace, k, res);
				};
				if (this.options.saveMissing) {
					if (this.options.saveMissingPlurals && needsPluralHandling) lngs.forEach((language) => {
						const suffixes = this.pluralResolver.getSuffixes(language, opt);
						if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && !suffixes.includes(`${this.options.pluralSeparator}zero`)) suffixes.push(`${this.options.pluralSeparator}zero`);
						suffixes.forEach((suffix) => {
							send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
						});
					});
					else send(lngs, key, defaultValue);
				}
			}
			res = this.extendTranslation(res, keys, opt, resolved, lastKey);
			if (usedKey && res === key && this.options.appendNamespaceToMissingKey) res = `${namespace}${nsSeparator}${key}`;
			if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : void 0, opt);
		}
		if (returnDetails) {
			resolved.res = res;
			resolved.usedParams = this.getUsedParamsDetails(opt);
			return resolved;
		}
		return res;
	}
	extendTranslation(res, key, opt, resolved, lastKey) {
		if (this.i18nFormat?.parse) res = this.i18nFormat.parse(res, {
			...this.options.interpolation.defaultVariables,
			...opt
		}, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, { resolved });
		else if (!opt.skipInterpolation) {
			if (opt.interpolation) this.interpolator.init({
				...opt,
				interpolation: {
					...this.options.interpolation,
					...opt.interpolation
				}
			});
			const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== void 0 ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
			let nestBef;
			if (skipOnVariables) {
				const nb = res.match(this.interpolator.nestingRegexp);
				nestBef = nb && nb.length;
			}
			let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
			if (this.options.interpolation.defaultVariables) data = {
				...this.options.interpolation.defaultVariables,
				...data
			};
			res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
			if (skipOnVariables) {
				const na = res.match(this.interpolator.nestingRegexp);
				const nestAft = na && na.length;
				if (nestBef < nestAft) opt.nest = false;
			}
			if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
			if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
				if (lastKey?.[0] === args[0] && !opt.context) {
					this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
					return null;
				}
				return this.translate(...args, key);
			}, opt);
			if (opt.interpolation) this.interpolator.reset();
		}
		const postProcess = opt.postProcess || this.options.postProcess;
		const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
		if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
			i18nResolved: {
				...resolved,
				usedParams: this.getUsedParamsDetails(opt)
			},
			...opt
		} : opt, this);
		return res;
	}
	resolve(keys, opt = {}) {
		let found;
		let usedKey;
		let exactUsedKey;
		let usedLng;
		let usedNS;
		if (isString(keys)) keys = [keys];
		if (Array.isArray(keys)) keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : k);
		keys.forEach((k) => {
			if (this.isValidLookup(found)) return;
			const extracted = this.extractFromKey(k, opt);
			const key = extracted.key;
			usedKey = key;
			let namespaces = extracted.namespaces;
			if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
			const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
			const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
			const needsContextHandling = opt.context !== void 0 && (isString(opt.context) || typeof opt.context === "number") && opt.context !== "";
			const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
			namespaces.forEach((ns) => {
				if (this.isValidLookup(found)) return;
				usedNS = ns;
				if (!this.checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
					this.checkedLoadedFor[`${codes[0]}-${ns}`] = true;
					this.logger.warn(`key "${usedKey}" for languages "${codes.join(", ")}" won't get resolved as namespace "${usedNS}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
				}
				codes.forEach((code) => {
					if (this.isValidLookup(found)) return;
					usedLng = code;
					const finalKeys = [key];
					if (this.i18nFormat?.addLookupKeys) this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
					else {
						let pluralSuffix;
						if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
						const zeroSuffix = `${this.options.pluralSeparator}zero`;
						const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
						if (needsPluralHandling) {
							if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
							finalKeys.push(key + pluralSuffix);
							if (needsZeroSuffixLookup) finalKeys.push(key + zeroSuffix);
						}
						if (needsContextHandling) {
							const contextKey = `${key}${this.options.contextSeparator || "_"}${opt.context}`;
							finalKeys.push(contextKey);
							if (needsPluralHandling) {
								if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
								finalKeys.push(contextKey + pluralSuffix);
								if (needsZeroSuffixLookup) finalKeys.push(contextKey + zeroSuffix);
							}
						}
					}
					let possibleKey;
					while (possibleKey = finalKeys.pop()) if (!this.isValidLookup(found)) {
						exactUsedKey = possibleKey;
						found = this.getResource(code, ns, possibleKey, opt);
					}
				});
			});
		});
		return {
			res: found,
			usedKey,
			exactUsedKey,
			usedLng,
			usedNS
		};
	}
	isValidLookup(res) {
		return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
	}
	getResource(code, ns, key, options = {}) {
		if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
		return this.resourceStore.getResource(code, ns, key, options);
	}
	getUsedParamsDetails(options = {}) {
		const optionsKeys = [
			"defaultValue",
			"ordinal",
			"context",
			"replace",
			"lng",
			"lngs",
			"fallbackLng",
			"ns",
			"keySeparator",
			"nsSeparator",
			"returnObjects",
			"returnDetails",
			"joinArrays",
			"postProcess",
			"interpolation"
		];
		const useOptionsReplaceForData = options.replace && !isString(options.replace);
		let data = useOptionsReplaceForData ? options.replace : options;
		if (useOptionsReplaceForData && typeof options.count !== "undefined") data = {
			...data,
			count: options.count
		};
		if (this.options.interpolation.defaultVariables) data = {
			...this.options.interpolation.defaultVariables,
			...data
		};
		if (!useOptionsReplaceForData) {
			data = { ...data };
			for (const key of optionsKeys) delete data[key];
		}
		return data;
	}
	static hasDefaultValue(options) {
		const prefix = "defaultValue";
		for (const option in options) if (Object.prototype.hasOwnProperty.call(options, option) && option.startsWith(prefix) && void 0 !== options[option]) return true;
		return false;
	}
};
var LanguageUtil = class {
	constructor(options) {
		this.options = options;
		this.supportedLngs = this.options.supportedLngs || false;
		this.logger = baseLogger.create("languageUtils");
		this.resolveHierarchyCache = {};
	}
	clearCache() {
		this.resolveHierarchyCache = {};
	}
	getScriptPartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return null;
		const p = code.split("-");
		if (p.length === 2) return null;
		p.pop();
		if (p[p.length - 1].toLowerCase() === "x") return null;
		return this.formatLanguageCode(p.join("-"));
	}
	getLanguagePartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return code;
		const p = code.split("-");
		return this.formatLanguageCode(p[0]);
	}
	formatLanguageCode(code) {
		if (isString(code) && code.includes("-")) {
			let formattedCode;
			try {
				formattedCode = Intl.getCanonicalLocales(code)[0];
			} catch (e) {}
			if (formattedCode && this.options.lowerCaseLng) formattedCode = formattedCode.toLowerCase();
			if (formattedCode) return formattedCode;
			if (this.options.lowerCaseLng) return code.toLowerCase();
			return code;
		}
		return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
	}
	isSupportedCode(code) {
		if (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) code = this.getLanguagePartFromCode(code);
		return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.includes(code);
	}
	getBestMatchFromCodes(codes) {
		if (!codes) return null;
		let found;
		codes.forEach((code) => {
			if (found) return;
			const cleanedLng = this.formatLanguageCode(code);
			if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
		});
		if (!found && this.options.supportedLngs) codes.forEach((code) => {
			if (found) return;
			const lngScOnly = this.getScriptPartFromCode(code);
			if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
			const lngOnly = this.getLanguagePartFromCode(code);
			if (this.isSupportedCode(lngOnly)) return found = lngOnly;
			found = this.options.supportedLngs.find((supportedLng) => {
				if (supportedLng === lngOnly) return true;
				if (!supportedLng.includes("-") && !lngOnly.includes("-")) return false;
				if (supportedLng.includes("-") && !lngOnly.includes("-") && supportedLng.slice(0, supportedLng.indexOf("-")) === lngOnly) return true;
				if (supportedLng.startsWith(lngOnly) && lngOnly.length > 1) return true;
				return false;
			});
		});
		if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
		return found;
	}
	getFallbackCodes(fallbacks, code) {
		if (!fallbacks) return [];
		if (typeof fallbacks === "function") fallbacks = fallbacks(code);
		if (isString(fallbacks)) fallbacks = [fallbacks];
		if (Array.isArray(fallbacks)) return fallbacks;
		if (!code) return fallbacks.default || [];
		let found = fallbacks[code];
		if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
		if (!found) found = fallbacks[this.formatLanguageCode(code)];
		if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
		if (!found) found = fallbacks.default;
		return found || [];
	}
	toResolveHierarchy(code, fallbackCode) {
		const fallbackLng = this.options.fallbackLng;
		const fallbackLngKey = Array.isArray(fallbackLng) ? fallbackLng.join("|") : fallbackLng;
		if (fallbackLngKey !== this._cachedFallbackLng) {
			this.resolveHierarchyCache = {};
			this._cachedFallbackLng = fallbackLngKey;
		}
		const hasCacheableFallback = fallbackCode === void 0 || fallbackCode === false || isString(fallbackCode);
		const usesUncacheableOptionsFallback = fallbackCode === void 0 && typeof this.options.fallbackLng === "function";
		const cacheable = isString(code) && hasCacheableFallback && !usesUncacheableOptionsFallback;
		let cacheKey = null;
		if (cacheable) {
			let fallbackCacheKey;
			if (fallbackCode === void 0) fallbackCacheKey = "undefined";
			else if (fallbackCode === false) fallbackCacheKey = "boolean:false";
			else fallbackCacheKey = `string:${fallbackCode}`;
			cacheKey = `${code.length}:${code}|${fallbackCacheKey}`;
		}
		if (cacheKey !== null) {
			const cached = this.resolveHierarchyCache[cacheKey];
			if (cached !== void 0) return cached.slice();
		}
		const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
		const codes = [];
		const addCode = (c) => {
			if (!c) return;
			if (this.isSupportedCode(c)) codes.push(c);
			else this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
		};
		if (isString(code) && (code.includes("-") || code.includes("_"))) {
			if (this.options.load !== "languageOnly") addCode(this.formatLanguageCode(code));
			if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly") addCode(this.getScriptPartFromCode(code));
			if (this.options.load !== "currentOnly") addCode(this.getLanguagePartFromCode(code));
		} else if (isString(code)) addCode(this.formatLanguageCode(code));
		fallbackCodes.forEach((fc) => {
			if (!codes.includes(fc)) addCode(this.formatLanguageCode(fc));
		});
		if (cacheKey !== null) {
			this.resolveHierarchyCache[cacheKey] = codes;
			return codes.slice();
		}
		return codes;
	}
};
var suffixesOrder = {
	zero: 0,
	one: 1,
	two: 2,
	few: 3,
	many: 4,
	other: 5
};
var dummyRule = {
	select: (count) => count === 1 ? "one" : "other",
	resolvedOptions: () => ({ pluralCategories: ["one", "other"] })
};
var PluralResolver = class {
	constructor(languageUtils, options = {}) {
		this.languageUtils = languageUtils;
		this.options = options;
		this.logger = baseLogger.create("pluralResolver");
		this.pluralRulesCache = {};
	}
	clearCache() {
		this.pluralRulesCache = {};
	}
	getRule(code, options = {}) {
		const cleanedCode = getCleanedCode(code === "dev" ? "en" : code);
		const type = options.ordinal ? "ordinal" : "cardinal";
		const cacheKey = JSON.stringify({
			cleanedCode,
			type
		});
		if (cacheKey in this.pluralRulesCache) return this.pluralRulesCache[cacheKey];
		let rule;
		try {
			rule = new Intl.PluralRules(cleanedCode, { type });
		} catch (err) {
			if (typeof Intl === "undefined") {
				this.logger.error("No Intl support, please use an Intl polyfill!");
				return dummyRule;
			}
			if (!code.match(/-|_/)) return dummyRule;
			const lngPart = this.languageUtils.getLanguagePartFromCode(code);
			rule = this.getRule(lngPart, options);
		}
		this.pluralRulesCache[cacheKey] = rule;
		return rule;
	}
	needsPlural(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		return rule?.resolvedOptions().pluralCategories.length > 1;
	}
	getPluralFormsOfKey(code, key, options = {}) {
		return this.getSuffixes(code, options).map((suffix) => `${key}${suffix}`);
	}
	getSuffixes(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		if (!rule) return [];
		return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map((pluralCategory) => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${pluralCategory}`);
	}
	getSuffix(code, count, options = {}) {
		const rule = this.getRule(code, options);
		if (rule) return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${rule.select(count)}`;
		this.logger.warn(`no plural rule found for: ${code}`);
		return this.getSuffix("dev", count, options);
	}
};
var deepFindWithDefaults = (data, defaultData, key, keySeparator = ".", ignoreJSONStructure = true) => {
	let path = getPathWithDefaults(data, defaultData, key);
	if (!path && ignoreJSONStructure && isString(key)) {
		path = deepFind(data, key, keySeparator);
		if (path === void 0) path = deepFind(defaultData, key, keySeparator);
	}
	return path;
};
var regexSafe = (val) => val.replace(/\$/g, "$$$$");
var Interpolator = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("interpolator");
		this.options = options;
		this.format = options?.interpolation?.format || ((value) => value);
		this.init(options);
	}
	init(options = {}) {
		if (!options.interpolation) options.interpolation = { escapeValue: true };
		const { escape: escape$1, escapeValue, useRawValueToEscape, prefix, prefixEscaped, suffix, suffixEscaped, formatSeparator, unescapeSuffix, unescapePrefix, nestingPrefix, nestingPrefixEscaped, nestingSuffix, nestingSuffixEscaped, nestingOptionsSeparator, maxReplaces, alwaysFormat } = options.interpolation;
		this.escape = escape$1 !== void 0 ? escape$1 : escape;
		this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
		this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
		this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || "{{";
		this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || "}}";
		this.formatSeparator = formatSeparator || ",";
		this.unescapePrefix = unescapeSuffix ? "" : unescapePrefix ? regexEscape(unescapePrefix) : "-";
		this.unescapeSuffix = this.unescapePrefix ? "" : unescapeSuffix ? regexEscape(unescapeSuffix) : "";
		this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape("$t(");
		this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(")");
		this.nestingOptionsSeparator = nestingOptionsSeparator || ",";
		this.maxReplaces = maxReplaces || 1e3;
		this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
		this.resetRegExp();
	}
	reset() {
		if (this.options) this.init(this.options);
	}
	resetRegExp() {
		const getOrResetRegExp = (existingRegExp, pattern) => {
			if (existingRegExp?.source === pattern) {
				existingRegExp.lastIndex = 0;
				return existingRegExp;
			}
			return new RegExp(pattern, "g");
		};
		this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
		this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
		this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']+|"[^"]*"|'[^']*'|\\((?:[^()]|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
	}
	interpolate(str, data, lng, options) {
		let match;
		let value;
		let replaces;
		const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
		const handleFormat = (key) => {
			if (!key.includes(this.formatSeparator)) {
				const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
				return this.alwaysFormat ? this.format(path, void 0, lng, {
					...options,
					...data,
					interpolationkey: key
				}) : path;
			}
			const p = key.split(this.formatSeparator);
			const k = p.shift().trim();
			const f = p.join(this.formatSeparator).trim();
			return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
				...options,
				...data,
				interpolationkey: k
			});
		};
		this.resetRegExp();
		if (!this.escapeValue && typeof str === "string" && /\$t\([^)]*\{[^}]*\{\{/.test(str)) this.logger.warn("nesting options string contains interpolated variables with escapeValue: false — if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.");
		const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
		const skipOnVariables = options?.interpolation?.skipOnVariables !== void 0 ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
		[{
			regex: this.regexpUnescape,
			safeValue: (val) => val
		}, {
			regex: this.regexp,
			safeValue: (val) => this.escapeValue ? this.escape(val) : val
		}].forEach((todo) => {
			replaces = 0;
			while (match = todo.regex.exec(str)) {
				const matchedVar = match[1].trim();
				value = handleFormat(matchedVar);
				if (value === void 0) {
					if (typeof missingInterpolationHandler === "function") {
						const temp = missingInterpolationHandler(str, match, options);
						value = isString(temp) ? temp : "";
					} else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) value = "";
					else if (skipOnVariables) {
						value = match[0];
						continue;
					} else {
						this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
						value = "";
					}
				} else if (!isString(value) && !this.useRawValueToEscape) value = makeString(value);
				const safeValue = todo.safeValue(value);
				str = str.replace(match[0], regexSafe(safeValue));
				if (skipOnVariables) {
					todo.regex.lastIndex += safeValue.length;
					todo.regex.lastIndex -= match[0].length;
				} else todo.regex.lastIndex = 0;
				replaces++;
				if (replaces >= this.maxReplaces) break;
			}
		});
		return str;
	}
	nest(str, fc, options = {}) {
		let match;
		let value;
		let clonedOptions;
		const handleHasOptions = (key, inheritedOptions) => {
			const sep = this.nestingOptionsSeparator;
			if (!key.includes(sep)) return key;
			const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
			let optionsString = `{${c[1]}`;
			key = c[0];
			optionsString = this.interpolate(optionsString, clonedOptions);
			const matchedSingleQuotes = optionsString.match(/'/g);
			const matchedDoubleQuotes = optionsString.match(/"/g);
			if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) optionsString = optionsString.replace(/'/g, "\"");
			try {
				clonedOptions = JSON.parse(optionsString);
				if (inheritedOptions) clonedOptions = {
					...inheritedOptions,
					...clonedOptions
				};
			} catch (e) {
				this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
				return `${key}${sep}${optionsString}`;
			}
			if (clonedOptions.defaultValue && clonedOptions.defaultValue.includes(this.prefix)) delete clonedOptions.defaultValue;
			return key;
		};
		while (match = this.nestingRegexp.exec(str)) {
			let formatters = [];
			clonedOptions = { ...options };
			clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
			clonedOptions.applyPostProcessor = false;
			delete clonedOptions.defaultValue;
			const keyEndIndex = /{.*}/s.test(match[1]) ? match[1].lastIndexOf("}") + 1 : match[1].indexOf(this.formatSeparator);
			if (keyEndIndex !== -1) {
				formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map((elem) => elem.trim()).filter(Boolean);
				match[1] = match[1].slice(0, keyEndIndex);
			}
			value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
			if (value && match[0] === str && !isString(value)) return value;
			if (!isString(value)) value = makeString(value);
			if (!value) {
				this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
				value = "";
			}
			if (formatters.length) value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
				...options,
				interpolationkey: match[1].trim()
			}), value.trim());
			str = str.replace(match[0], value);
			this.regexp.lastIndex = 0;
		}
		return str;
	}
};
var parseFormatStr = (formatStr) => {
	let formatName = formatStr.toLowerCase().trim();
	const formatOptions = {};
	if (formatStr.includes("(")) {
		const p = formatStr.split("(");
		formatName = p[0].toLowerCase().trim();
		const optStr = p[1].slice(0, -1);
		if (formatName === "currency" && !optStr.includes(":")) {
			if (!formatOptions.currency) formatOptions.currency = optStr.trim();
		} else if (formatName === "relativetime" && !optStr.includes(":")) {
			if (!formatOptions.range) formatOptions.range = optStr.trim();
		} else optStr.split(";").forEach((opt) => {
			if (opt) {
				const [key, ...rest] = opt.split(":");
				const val = rest.join(":").trim().replace(/^'+|'+$/g, "");
				const trimmedKey = key.trim();
				if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
				if (val === "false") formatOptions[trimmedKey] = false;
				if (val === "true") formatOptions[trimmedKey] = true;
				if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
			}
		});
	}
	return {
		formatName,
		formatOptions
	};
};
var createCachedFormatter = (fn) => {
	const cache = {};
	return (v, l, o) => {
		let optForCache = o;
		if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) optForCache = {
			...optForCache,
			[o.interpolationkey]: void 0
		};
		const key = l + JSON.stringify(optForCache);
		let frm = cache[key];
		if (!frm) {
			frm = fn(getCleanedCode(l), o);
			cache[key] = frm;
		}
		return frm(v);
	};
};
var createNonCachedFormatter = (fn) => (v, l, o) => fn(getCleanedCode(l), o)(v);
var Formatter = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("formatter");
		this.options = options;
		this.init(options);
	}
	init(services, options = { interpolation: {} }) {
		this.formatSeparator = options.interpolation.formatSeparator || ",";
		const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
		this.formats = {
			number: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			currency: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, {
					...opt,
					style: "currency"
				});
				return (val) => formatter.format(val);
			}),
			datetime: cf((lng, opt) => {
				const formatter = new Intl.DateTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			relativetime: cf((lng, opt) => {
				const formatter = new Intl.RelativeTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val, opt.range || "day");
			}),
			list: cf((lng, opt) => {
				const formatter = new Intl.ListFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			})
		};
	}
	add(name, fc) {
		this.formats[name.toLowerCase().trim()] = fc;
	}
	addCached(name, fc) {
		this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
	}
	format(value, format, lng, options = {}) {
		if (!format) return value;
		if (value == null) return value;
		const rawFormats = format.split(this.formatSeparator);
		const formats = [];
		for (let i = 0; i < rawFormats.length; i++) {
			let f = rawFormats[i];
			while (f.indexOf("(") > -1 && !f.includes(")") && i + 1 < rawFormats.length) f = `${f}${this.formatSeparator}${rawFormats[++i]}`;
			formats.push(f);
		}
		return formats.reduce((mem, f) => {
			const { formatName, formatOptions } = parseFormatStr(f);
			if (this.formats[formatName]) {
				let formatted = mem;
				try {
					const valOptions = options?.formatParams?.[options.interpolationkey] || {};
					const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
					formatted = this.formats[formatName](mem, l, {
						...formatOptions,
						...options,
						...valOptions
					});
				} catch (error) {
					this.logger.warn(error);
				}
				return formatted;
			} else this.logger.warn(`there was no format function for ${formatName}`);
			return mem;
		}, value);
	}
};
var removePending = (q, name) => {
	if (q.pending[name] !== void 0) {
		delete q.pending[name];
		q.pendingCount--;
	}
};
var Connector = class extends EventEmitter {
	constructor(backend, store, services, options = {}) {
		super();
		this.backend = backend;
		this.store = store;
		this.services = services;
		this.languageUtils = services.languageUtils;
		this.options = options;
		this.logger = baseLogger.create("backendConnector");
		this.waitingReads = [];
		this.maxParallelReads = options.maxParallelReads || 10;
		this.readingCalls = 0;
		this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
		this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
		this.state = {};
		this.queue = [];
		this.backend?.init?.(services, options.backend, options);
	}
	queueLoad(languages, namespaces, options, callback) {
		const toLoad = {};
		const pending = {};
		const toLoadLanguages = {};
		const toLoadNamespaces = {};
		languages.forEach((lng) => {
			let hasAllNamespaces = true;
			namespaces.forEach((ns) => {
				const name = `${lng}|${ns}`;
				if (!options.reload && this.store.hasResourceBundle(lng, ns)) this.state[name] = 2;
				else if (this.state[name] < 0);
				else if (this.state[name] === 1) {
					if (pending[name] === void 0) pending[name] = true;
				} else {
					this.state[name] = 1;
					hasAllNamespaces = false;
					if (pending[name] === void 0) pending[name] = true;
					if (toLoad[name] === void 0) toLoad[name] = true;
					if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
				}
			});
			if (!hasAllNamespaces) toLoadLanguages[lng] = true;
		});
		if (Object.keys(toLoad).length || Object.keys(pending).length) this.queue.push({
			pending,
			pendingCount: Object.keys(pending).length,
			loaded: {},
			errors: [],
			callback
		});
		return {
			toLoad: Object.keys(toLoad),
			pending: Object.keys(pending),
			toLoadLanguages: Object.keys(toLoadLanguages),
			toLoadNamespaces: Object.keys(toLoadNamespaces)
		};
	}
	loaded(name, err, data) {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		if (err) this.emit("failedLoading", lng, ns, err);
		if (!err && data) this.store.addResourceBundle(lng, ns, data, void 0, void 0, { skipCopy: true });
		this.state[name] = err ? -1 : 2;
		if (err && data) this.state[name] = 0;
		const loaded = {};
		this.queue.forEach((q) => {
			pushPath(q.loaded, [lng], ns);
			removePending(q, name);
			if (err) q.errors.push(err);
			if (q.pendingCount === 0 && !q.done) {
				Object.keys(q.loaded).forEach((l) => {
					if (!loaded[l]) loaded[l] = {};
					const loadedKeys = q.loaded[l];
					if (loadedKeys.length) loadedKeys.forEach((n) => {
						if (loaded[l][n] === void 0) loaded[l][n] = true;
					});
				});
				q.done = true;
				if (q.errors.length) q.callback(q.errors);
				else q.callback();
			}
		});
		this.emit("loaded", loaded);
		this.queue = this.queue.filter((q) => !q.done);
	}
	read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
		if (!lng.length) return callback(null, {});
		if (this.readingCalls >= this.maxParallelReads) {
			this.waitingReads.push({
				lng,
				ns,
				fcName,
				tried,
				wait,
				callback
			});
			return;
		}
		this.readingCalls++;
		const resolver = (err, data) => {
			this.readingCalls--;
			if (this.waitingReads.length > 0) {
				const next = this.waitingReads.shift();
				this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
			}
			if (err && data && tried < this.maxRetries) {
				setTimeout(() => {
					this.read(lng, ns, fcName, tried + 1, wait * 2, callback);
				}, wait);
				return;
			}
			callback(err, data);
		};
		const fc = this.backend[fcName].bind(this.backend);
		if (fc.length === 2) {
			try {
				const r = fc(lng, ns);
				if (r && typeof r.then === "function") r.then((data) => resolver(null, data)).catch(resolver);
				else resolver(null, r);
			} catch (err) {
				resolver(err);
			}
			return;
		}
		return fc(lng, ns, resolver);
	}
	prepareLoading(languages, namespaces, options = {}, callback) {
		if (!this.backend) {
			this.logger.warn("No backend was added via i18next.use. Will not load resources.");
			return callback && callback();
		}
		if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
		if (isString(namespaces)) namespaces = [namespaces];
		const toLoad = this.queueLoad(languages, namespaces, options, callback);
		if (!toLoad.toLoad.length) {
			if (!toLoad.pending.length) callback();
			return null;
		}
		toLoad.toLoad.forEach((name) => {
			this.loadOne(name);
		});
	}
	load(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, {}, callback);
	}
	reload(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, { reload: true }, callback);
	}
	loadOne(name, prefix = "") {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		this.read(lng, ns, "read", void 0, void 0, (err, data) => {
			if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
			if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
			this.loaded(name, err, data);
		});
	}
	saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
		if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
			this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
			return;
		}
		if (key === void 0 || key === null || key === "") return;
		if (this.backend?.create) {
			const opts = {
				...options,
				isUpdate
			};
			const fc = this.backend.create.bind(this.backend);
			if (fc.length < 6) try {
				let r;
				if (fc.length === 5) r = fc(languages, namespace, key, fallbackValue, opts);
				else r = fc(languages, namespace, key, fallbackValue);
				if (r && typeof r.then === "function") r.then((data) => clb(null, data)).catch(clb);
				else clb(null, r);
			} catch (err) {
				clb(err);
			}
			else fc(languages, namespace, key, fallbackValue, clb, opts);
		}
		if (!languages || !languages[0]) return;
		this.store.addResource(languages[0], namespace, key, fallbackValue);
	}
};
var get = () => ({
	debug: false,
	initAsync: true,
	ns: ["translation"],
	defaultNS: ["translation"],
	fallbackLng: ["dev"],
	fallbackNS: false,
	supportedLngs: false,
	nonExplicitSupportedLngs: false,
	load: "all",
	preload: false,
	keySeparator: ".",
	nsSeparator: ":",
	pluralSeparator: "_",
	contextSeparator: "_",
	enableSelector: false,
	partialBundledLanguages: false,
	saveMissing: false,
	updateMissing: false,
	saveMissingTo: "fallback",
	saveMissingPlurals: true,
	missingKeyHandler: false,
	missingInterpolationHandler: false,
	postProcess: false,
	postProcessPassResolved: false,
	returnNull: false,
	returnEmptyString: true,
	returnObjects: false,
	joinArrays: false,
	returnedObjectHandler: false,
	parseMissingKeyHandler: false,
	appendNamespaceToMissingKey: false,
	appendNamespaceToCIMode: false,
	overloadTranslationOptionHandler: (args) => {
		let ret = {};
		if (typeof args[1] === "object") ret = args[1];
		if (isString(args[1])) ret.defaultValue = args[1];
		if (isString(args[2])) ret.tDescription = args[2];
		if (typeof args[2] === "object" || typeof args[3] === "object") {
			const options = args[3] || args[2];
			Object.keys(options).forEach((key) => {
				ret[key] = options[key];
			});
		}
		return ret;
	},
	interpolation: {
		escapeValue: true,
		prefix: "{{",
		suffix: "}}",
		formatSeparator: ",",
		unescapePrefix: "-",
		nestingPrefix: "$t(",
		nestingSuffix: ")",
		nestingOptionsSeparator: ",",
		maxReplaces: 1e3,
		skipOnVariables: true
	},
	cacheInBuiltFormats: true
});
var transformOptions = (options) => {
	if (isString(options.ns)) options.ns = [options.ns];
	if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
	if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
	if (options.supportedLngs && !options.supportedLngs.includes("cimode")) options.supportedLngs = options.supportedLngs.concat(["cimode"]);
	return options;
};
var noop = () => {};
var bindMemberFunctions = (inst) => {
	Object.getOwnPropertyNames(Object.getPrototypeOf(inst)).forEach((mem) => {
		if (typeof inst[mem] === "function") inst[mem] = inst[mem].bind(inst);
	});
};
var instance = class I18n extends EventEmitter {
	constructor(options = {}, callback) {
		super();
		this.options = transformOptions(options);
		this.services = {};
		this.logger = baseLogger;
		this.modules = { external: [] };
		bindMemberFunctions(this);
		if (callback && !this.isInitialized && !options.isClone) {
			if (!this.options.initAsync) {
				this.init(options, callback);
				return this;
			}
			setTimeout(() => {
				this.init(options, callback);
			}, 0);
		}
	}
	init(options = {}, callback) {
		this.isInitializing = true;
		if (typeof options === "function") {
			callback = options;
			options = {};
		}
		if (options.defaultNS == null && options.ns) {
			if (isString(options.ns)) options.defaultNS = options.ns;
			else if (!options.ns.includes("translation")) options.defaultNS = options.ns[0];
		}
		const defOpts = get();
		this.options = {
			...defOpts,
			...this.options,
			...transformOptions(options)
		};
		this.options.interpolation = {
			...defOpts.interpolation,
			...this.options.interpolation
		};
		if (options.keySeparator !== void 0) this.options.userDefinedKeySeparator = options.keySeparator;
		if (options.nsSeparator !== void 0) this.options.userDefinedNsSeparator = options.nsSeparator;
		if (typeof this.options.overloadTranslationOptionHandler !== "function") this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
		const createClassOnDemand = (ClassOrObject) => {
			if (!ClassOrObject) return null;
			if (typeof ClassOrObject === "function") return new ClassOrObject();
			return ClassOrObject;
		};
		if (!this.options.isClone) {
			if (this.modules.logger) baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
			else baseLogger.init(null, this.options);
			let formatter;
			if (this.modules.formatter) formatter = this.modules.formatter;
			else formatter = Formatter;
			const lu = new LanguageUtil(this.options);
			this.store = new ResourceStore(this.options.resources, this.options);
			const s = this.services;
			s.logger = baseLogger;
			s.resourceStore = this.store;
			s.languageUtils = lu;
			s.pluralResolver = new PluralResolver(lu, { prepend: this.options.pluralSeparator });
			if (formatter) {
				s.formatter = createClassOnDemand(formatter);
				if (s.formatter.init) s.formatter.init(s, this.options);
				this.options.interpolation.format = s.formatter.format.bind(s.formatter);
			}
			s.interpolator = new Interpolator(this.options);
			s.utils = { hasLoadedNamespace: this.hasLoadedNamespace.bind(this) };
			s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
			s.backendConnector.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			if (this.modules.languageDetector) {
				s.languageDetector = createClassOnDemand(this.modules.languageDetector);
				if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
			}
			if (this.modules.i18nFormat) {
				s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
				if (s.i18nFormat.init) s.i18nFormat.init(this);
			}
			this.translator = new Translator(this.services, this.options);
			this.translator.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			this.modules.external.forEach((m) => {
				if (m.init) m.init(this);
			});
		}
		this.format = this.options.interpolation.format;
		if (!callback) callback = noop;
		if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
			const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
			if (codes.length > 0 && codes[0] !== "dev") this.options.lng = codes[0];
		}
		if (!this.services.languageDetector && !this.options.lng) this.logger.warn("init: no languageDetector is used and no lng is defined");
		[
			"getResource",
			"hasResourceBundle",
			"getResourceBundle",
			"getDataByLanguage"
		].forEach((fcName) => {
			this[fcName] = (...args) => this.store[fcName](...args);
		});
		[
			"addResource",
			"addResources",
			"addResourceBundle",
			"removeResourceBundle"
		].forEach((fcName) => {
			this[fcName] = (...args) => {
				this.store[fcName](...args);
				return this;
			};
		});
		const deferred = defer();
		const load = () => {
			const finish = (err, t) => {
				this.isInitializing = false;
				if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn("init: i18next is already initialized. You should call init just once!");
				this.isInitialized = true;
				if (!this.options.isClone) this.logger.log("initialized", this.options);
				this.emit("initialized", this.options);
				deferred.resolve(t);
				callback(err, t);
			};
			if ((this.languages || this.isLanguageChangingTo) && !this.isInitialized) return finish(null, this.t.bind(this));
			this.changeLanguage(this.options.lng, finish);
		};
		if (this.options.resources || !this.options.initAsync) load();
		else setTimeout(load, 0);
		return deferred;
	}
	loadResources(language, callback = noop) {
		let usedCallback = callback;
		const usedLng = isString(language) ? language : this.language;
		if (typeof language === "function") usedCallback = language;
		if (!this.options.resources || this.options.partialBundledLanguages) {
			if (usedLng?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
			const toLoad = [];
			const append = (lng) => {
				if (!lng) return;
				if (lng === "cimode") return;
				this.services.languageUtils.toResolveHierarchy(lng).forEach((l) => {
					if (l === "cimode") return;
					if (!toLoad.includes(l)) toLoad.push(l);
				});
			};
			if (!usedLng) this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach((l) => append(l));
			else append(usedLng);
			this.options.preload?.forEach?.((l) => append(l));
			this.services.backendConnector.load(toLoad, this.options.ns, (e) => {
				if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
				usedCallback(e);
			});
		} else usedCallback(null);
	}
	reloadResources(lngs, ns, callback) {
		const deferred = defer();
		if (typeof lngs === "function") {
			callback = lngs;
			lngs = void 0;
		}
		if (typeof ns === "function") {
			callback = ns;
			ns = void 0;
		}
		if (!lngs) lngs = this.languages;
		if (!ns) ns = this.options.ns;
		if (!callback) callback = noop;
		this.services.backendConnector.reload(lngs, ns, (err) => {
			deferred.resolve();
			callback(err);
		});
		return deferred;
	}
	use(module) {
		if (!module) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
		if (!module.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
		if (module.type === "backend") this.modules.backend = module;
		if (module.type === "logger" || module.log && module.warn && module.error) this.modules.logger = module;
		if (module.type === "languageDetector") this.modules.languageDetector = module;
		if (module.type === "i18nFormat") this.modules.i18nFormat = module;
		if (module.type === "postProcessor") postProcessor.addPostProcessor(module);
		if (module.type === "formatter") this.modules.formatter = module;
		if (module.type === "3rdParty") this.modules.external.push(module);
		return this;
	}
	setResolvedLanguage(l) {
		if (!l || !this.languages) return;
		if (["cimode", "dev"].includes(l)) return;
		for (let li = 0; li < this.languages.length; li++) {
			const lngInLngs = this.languages[li];
			if (["cimode", "dev"].includes(lngInLngs)) continue;
			if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
				this.resolvedLanguage = lngInLngs;
				break;
			}
		}
		if (!this.resolvedLanguage && !this.languages.includes(l) && this.store.hasLanguageSomeTranslations(l)) {
			this.resolvedLanguage = l;
			this.languages.unshift(l);
		}
	}
	changeLanguage(lng, callback) {
		this.isLanguageChangingTo = lng;
		const deferred = defer();
		this.emit("languageChanging", lng);
		const setLngProps = (l) => {
			this.language = l;
			this.languages = this.services.languageUtils.toResolveHierarchy(l);
			this.resolvedLanguage = void 0;
			this.setResolvedLanguage(l);
		};
		const done = (err, l) => {
			if (l) {
				if (this.isLanguageChangingTo === lng) {
					setLngProps(l);
					this.translator.changeLanguage(l);
					this.isLanguageChangingTo = void 0;
					this.emit("languageChanged", l);
					this.logger.log("languageChanged", l);
				}
			} else this.isLanguageChangingTo = void 0;
			deferred.resolve((...args) => this.t(...args));
			if (callback) callback(err, (...args) => this.t(...args));
		};
		const setLng = (lngs) => {
			if (!lng && !lngs && this.services.languageDetector) lngs = [];
			const fl = isString(lngs) ? lngs : lngs && lngs[0];
			const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
			if (l) {
				if (!this.language) setLngProps(l);
				if (!this.translator.language) this.translator.changeLanguage(l);
				this.services.languageDetector?.cacheUserLanguage?.(l);
			}
			this.loadResources(l, (err) => {
				done(err, l);
			});
		};
		if (!lng && this.services.languageDetector && !this.services.languageDetector.async) setLng(this.services.languageDetector.detect());
		else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
			if (this.services.languageDetector.detect.length === 0) this.services.languageDetector.detect().then(setLng);
			else this.services.languageDetector.detect(setLng);
		} else setLng(lng);
		return deferred;
	}
	getFixedT(lng, ns, keyPrefix, fixedOpts) {
		const scopeNs = fixedOpts?.scopeNs;
		const fixedT = (key, opts, ...rest) => {
			let o;
			if (typeof opts !== "object") o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
			else o = { ...opts };
			o.lng = o.lng || fixedT.lng;
			o.lngs = o.lngs || fixedT.lngs;
			const explicitCallNs = o.ns !== void 0 && o.ns !== null;
			o.ns = o.ns || fixedT.ns;
			if (o.keyPrefix !== "") o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
			const selectorOpts = {
				...this.options,
				...o
			};
			if (Array.isArray(scopeNs) && !explicitCallNs) selectorOpts.ns = scopeNs;
			if (typeof o.keyPrefix === "function") o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
			const keySeparator = this.options.keySeparator || ".";
			let resultKey;
			if (o.keyPrefix && Array.isArray(key)) resultKey = key.map((k) => {
				if (typeof k === "function") k = keysFromSelector(k, selectorOpts);
				return `${o.keyPrefix}${keySeparator}${k}`;
			});
			else {
				if (typeof key === "function") key = keysFromSelector(key, selectorOpts);
				resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
			}
			return this.t(resultKey, o);
		};
		if (isString(lng)) fixedT.lng = lng;
		else fixedT.lngs = lng;
		fixedT.ns = ns;
		fixedT.keyPrefix = keyPrefix;
		return fixedT;
	}
	t(...args) {
		return this.translator?.translate(...args);
	}
	exists(...args) {
		return this.translator?.exists(...args);
	}
	setDefaultNamespace(ns) {
		this.options.defaultNS = ns;
	}
	hasLoadedNamespace(ns, options = {}) {
		if (!this.isInitialized) {
			this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages);
			return false;
		}
		if (!this.languages || !this.languages.length) {
			this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages);
			return false;
		}
		const lng = options.lng || this.resolvedLanguage || this.languages[0];
		const fallbackLng = this.options ? this.options.fallbackLng : false;
		const lastLng = this.languages[this.languages.length - 1];
		if (lng.toLowerCase() === "cimode") return true;
		const loadNotPending = (l, n) => {
			const loadState = this.services.backendConnector.state[`${l}|${n}`];
			return loadState === -1 || loadState === 0 || loadState === 2;
		};
		if (options.precheck) {
			const preResult = options.precheck(this, loadNotPending);
			if (preResult !== void 0) return preResult;
		}
		if (this.hasResourceBundle(lng, ns)) return true;
		if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
		if (loadNotPending(lng, ns) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
		return false;
	}
	loadNamespaces(ns, callback) {
		const deferred = defer();
		if (!this.options.ns) {
			if (callback) callback();
			return Promise.resolve();
		}
		if (isString(ns)) ns = [ns];
		ns.forEach((n) => {
			if (!this.options.ns.includes(n)) this.options.ns.push(n);
		});
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	loadLanguages(lngs, callback) {
		const deferred = defer();
		if (isString(lngs)) lngs = [lngs];
		const preloaded = this.options.preload || [];
		const newLngs = lngs.filter((lng) => !preloaded.includes(lng) && this.services.languageUtils.isSupportedCode(lng));
		if (!newLngs.length) {
			if (callback) callback();
			return Promise.resolve();
		}
		this.options.preload = preloaded.concat(newLngs);
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	dir(lng) {
		if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
		if (!lng) return "rtl";
		try {
			const l = new Intl.Locale(lng);
			if (l && l.getTextInfo) {
				const ti = l.getTextInfo();
				if (ti && ti.direction) return ti.direction;
			}
		} catch (e) {}
		const rtlLngs = [
			"ar",
			"shu",
			"sqr",
			"ssh",
			"xaa",
			"yhd",
			"yud",
			"aao",
			"abh",
			"abv",
			"acm",
			"acq",
			"acw",
			"acx",
			"acy",
			"adf",
			"ads",
			"aeb",
			"aec",
			"afb",
			"ajp",
			"apc",
			"apd",
			"arb",
			"arq",
			"ars",
			"ary",
			"arz",
			"auz",
			"avl",
			"ayh",
			"ayl",
			"ayn",
			"ayp",
			"bbz",
			"pga",
			"he",
			"iw",
			"ps",
			"pbt",
			"pbu",
			"pst",
			"prp",
			"prd",
			"ug",
			"ur",
			"ydd",
			"yds",
			"yih",
			"ji",
			"yi",
			"hbo",
			"men",
			"xmn",
			"fa",
			"jpr",
			"peo",
			"pes",
			"prs",
			"dv",
			"sam",
			"ckb"
		];
		const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
		if (lng.toLowerCase().indexOf("-latn") > 1) return "ltr";
		return rtlLngs.includes(languageUtils.getLanguagePartFromCode(lng)) || lng.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
	}
	static createInstance(options = {}, callback) {
		const instance = new I18n(options, callback);
		instance.createInstance = I18n.createInstance;
		return instance;
	}
	cloneInstance(options = {}, callback = noop) {
		const forkResourceStore = options.forkResourceStore;
		if (forkResourceStore) delete options.forkResourceStore;
		const mergedOptions = {
			...this.options,
			...options,
			isClone: true
		};
		const clone = new I18n(mergedOptions);
		if (options.debug !== void 0 || options.prefix !== void 0) clone.logger = clone.logger.clone(options);
		[
			"store",
			"services",
			"language"
		].forEach((m) => {
			clone[m] = this[m];
		});
		clone.services = { ...this.services };
		clone.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		if (forkResourceStore) {
			clone.store = new ResourceStore(Object.keys(this.store.data).reduce((prev, l) => {
				prev[l] = { ...this.store.data[l] };
				prev[l] = Object.keys(prev[l]).reduce((acc, n) => {
					acc[n] = { ...prev[l][n] };
					return acc;
				}, prev[l]);
				return prev;
			}, {}), mergedOptions);
			clone.services.resourceStore = clone.store;
		}
		if (options.interpolation) {
			const mergedInterpolation = {
				...get().interpolation,
				...this.options.interpolation,
				...options.interpolation
			};
			const mergedForInterpolator = {
				...mergedOptions,
				interpolation: mergedInterpolation
			};
			clone.services.interpolator = new Interpolator(mergedForInterpolator);
		}
		clone.translator = new Translator(clone.services, mergedOptions);
		clone.translator.on("*", (event, ...args) => {
			clone.emit(event, ...args);
		});
		clone.init(mergedOptions, callback);
		clone.translator.options = mergedOptions;
		clone.translator.backendConnector.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		return clone;
	}
	toJSON() {
		return {
			options: this.options,
			store: this.store,
			language: this.language,
			languages: this.languages,
			resolvedLanguage: this.resolvedLanguage
		};
	}
}.createInstance();
instance.createInstance;
instance.dir;
instance.init;
instance.loadResources;
instance.reloadResources;
instance.use;
instance.changeLanguage;
instance.getFixedT;
instance.t;
instance.exists;
instance.setDefaultNamespace;
instance.hasLoadedNamespace;
instance.loadNamespaces;
instance.loadLanguages;
//#endregion
//#region node_modules/.pnpm/react-i18next@17.0.12_i18ne_75a90816b2e69342b4989a4a95b04d67/node_modules/react-i18next/dist/es/unescape.js
var matchHtmlEntity = /&(?:amp|#38|lt|#60|gt|#62|apos|#39|quot|#34|nbsp|#160|copy|#169|reg|#174|hellip|#8230|#x2F|#47);/g;
var htmlEntities = {
	"&amp;": "&",
	"&#38;": "&",
	"&lt;": "<",
	"&#60;": "<",
	"&gt;": ">",
	"&#62;": ">",
	"&apos;": "'",
	"&#39;": "'",
	"&quot;": "\"",
	"&#34;": "\"",
	"&nbsp;": " ",
	"&#160;": " ",
	"&copy;": "©",
	"&#169;": "©",
	"&reg;": "®",
	"&#174;": "®",
	"&hellip;": "…",
	"&#8230;": "…",
	"&#x2F;": "/",
	"&#47;": "/"
};
var unescapeHtmlEntity = (m) => htmlEntities[m];
var unescape = (text) => text.replace(matchHtmlEntity, unescapeHtmlEntity);
//#endregion
//#region node_modules/.pnpm/react-i18next@17.0.12_i18ne_75a90816b2e69342b4989a4a95b04d67/node_modules/react-i18next/dist/es/defaults.js
var defaultOptions = {
	bindI18n: "languageChanged",
	bindI18nStore: "",
	transEmptyNodeValue: "",
	transSupportBasicHtmlNodes: true,
	transWrapTextNodes: "",
	transKeepBasicHtmlNodesFor: [
		"br",
		"strong",
		"i",
		"p"
	],
	useSuspense: true,
	unescape,
	transDefaultProps: void 0
};
var setDefaults = (options = {}) => {
	defaultOptions = {
		...defaultOptions,
		...options
	};
};
var getDefaults = () => defaultOptions;
//#endregion
//#region node_modules/.pnpm/react-i18next@17.0.12_i18ne_75a90816b2e69342b4989a4a95b04d67/node_modules/react-i18next/dist/es/i18nInstance.js
var i18nInstance;
var setI18n = (instance) => {
	i18nInstance = instance;
};
var getI18n = () => i18nInstance;
//#endregion
//#region node_modules/.pnpm/react-i18next@17.0.12_i18ne_75a90816b2e69342b4989a4a95b04d67/node_modules/react-i18next/dist/es/initReactI18next.js
var initReactI18next = {
	type: "3rdParty",
	init(instance) {
		setDefaults(instance.options.react);
		setI18n(instance);
	}
};
//#endregion
//#region src/shared/messages.ts
var MEDIA_SUBMIT_ERROR = {
	invalidRequest: "media-submit.invalid-request",
	submitFailed: "media-submit.submit-failed"
};
function isErrorResponse(v) {
	return typeof v === "object" && v !== null && typeof v.error === "string";
}
//#endregion
//#region src/background/MessageBus.ts
/**
* Routes typed Envelope messages from popup/options/content scripts to
* handlers registered in the background SW. Handlers may be async; the
* bus enforces an "async response" sentinel by always returning true
* from the chrome.runtime.onMessage callback.
*/
var MessageBus = class {
	handlers = /* @__PURE__ */ new Map();
	beforeDispatch;
	constructor(options = {}) {
		this.beforeDispatch = options.beforeDispatch ?? (() => Promise.resolve());
	}
	on(kind, handler) {
		this.handlers.set(kind, handler);
	}
	/** Call once at background startup. */
	attach() {
		browser.runtime.onMessage.addListener((rawMsg, sender, sendResponse) => {
			const env = rawMsg;
			if (!env || typeof env.kind !== "string") {
				sendResponse({ error: "invalid envelope" });
				return true;
			}
			const handler = this.handlers.get(env.kind);
			if (!handler) {
				sendResponse({ error: `no handler for ${env.kind}` });
				return true;
			}
			Promise.resolve().then(() => this.beforeDispatch()).then(() => handler(env.payload, sender)).then((res) => sendResponse(res)).catch((e) => sendResponse({ error: e instanceof Error ? e.message : "handler failed" }));
			return true;
		});
	}
};
/**
* Client-side helper. popup/options use this to call into background;
* the response type is statically inferred from the message kind.
*/
async function send(kind, payload) {
	const env = {
		kind,
		payload
	};
	const response = await browser.runtime.sendMessage(env);
	if (isErrorResponse(response)) throw new Error(response.error);
	return response;
}
//#endregion
//#region src/background/mbp1/canonical.ts
/**
* MBP1 canonical encoding primitives (bridge-pairing-protocol.md §2).
*
* `len64LE` / `enc` / `encU32BE` / `encU64BE` are the wire's length-prefixed
* and fixed-width integer encodings; every canonical structure in the
* protocol (identity strings in §6.4's `TT`, the §9.2 ticket MAC input, ...)
* composes from these.
*
* The integer encoders throw on out-of-range input rather than silently
* wrapping. `DataView.setUint32`/`setBigUint64` wrap modulo their width
* instead of throwing, which would let two distinct field values (e.g.
* `exp = 0` and `exp = 2**64`) collide on the wire and defeat §6.4's
* guarantee that flipping any ticket field changes the resulting digest.
*/
var textEncoder = new TextEncoder();
/** UTF-8 encode a string. Does not enforce ASCII-only (see `enc`). */
function utf8(s) {
	return textEncoder.encode(s);
}
function assertNonNegativeSafeInteger(n, label) {
	if (!Number.isSafeInteger(n) || n < 0) throw new RangeError(`${label}: expected a safe non-negative integer, got ${n}`);
}
/** The length of `n` as an 8-byte little-endian integer (RFC 9382 §3.2). */
function len64LE(n) {
	assertNonNegativeSafeInteger(n, "len64LE");
	const out = /* @__PURE__ */ new Uint8Array(8);
	new DataView(out.buffer).setBigUint64(0, BigInt(n), true);
	return out;
}
/**
* Rejects any non-ASCII byte in `s`, returning its UTF-8 bytes — which, for an
* ASCII string, are the ASCII bytes.
*
* Exported because §2's ASCII rule binds more than `enc`. The server asserts it
* separately in `deriveW` and it matters there for a reason beyond hygiene:
* that side encodes with `Buffer.from(s, 'ascii')`, which truncates each
* character to its low byte, while this side uses UTF-8. For any non-ASCII
* input the two would derive **different** `w` values, and the only symptom
* would be key confirmation failing against a real Motrix — so both sides
* refuse the input instead of encoding it differently.
*/
function assertAscii(s, field) {
	const bytes = utf8(s);
	for (const byte of bytes) if (byte >= 128) throw new Error(`${field} must be ASCII-only`);
	return bytes;
}
/**
* `len64LE(len) ‖ bytes`. Strings are UTF-8 encoded; every string field in a
* canonical structure MUST be ASCII-only, so non-ASCII input is rejected.
* Raw byte strings (point/scalar encodings) pass through unchecked.
*/
function enc(s) {
	if (typeof s === "string") {
		const bytes = assertAscii(s, "enc: string field");
		return concatBytes(len64LE(bytes.length), bytes);
	}
	return concatBytes(len64LE(s.length), s);
}
/** `n` as a 4-byte big-endian unsigned integer. */
function encU32BE(n) {
	assertNonNegativeSafeInteger(n, "encU32BE");
	if (n > 4294967295) throw new RangeError(`encU32BE: ${n} exceeds the 32-bit unsigned range`);
	const out = /* @__PURE__ */ new Uint8Array(4);
	new DataView(out.buffer).setUint32(0, n, false);
	return out;
}
/** `n` as an 8-byte big-endian unsigned integer. */
function encU64BE(n) {
	assertNonNegativeSafeInteger(n, "encU64BE");
	const out = /* @__PURE__ */ new Uint8Array(8);
	new DataView(out.buffer).setBigUint64(0, BigInt(n), false);
	return out;
}
/** Concatenate byte strings in order, without mutating any input. */
function concatBytes(...parts) {
	const total = parts.reduce((sum, part) => sum + part.length, 0);
	const out = new Uint8Array(total);
	let offset = 0;
	for (const part of parts) {
		out.set(part, offset);
		offset += part.length;
	}
	return out;
}
var B64U_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
var B64U_REVERSE = new Map([...B64U_ALPHABET].map((char, index) => [char, index]));
function alphabetChar(index) {
	const char = B64U_ALPHABET[index];
	if (char === void 0) throw new RangeError(`b64u: alphabet index ${index} out of range`);
	return char;
}
/** base64url, no padding (RFC 4648 §5). */
function b64uEncode(bytes) {
	let out = "";
	let buffer = 0;
	let bits = 0;
	for (const byte of bytes) {
		buffer = buffer << 8 | byte;
		bits += 8;
		while (bits >= 6) {
			bits -= 6;
			out += alphabetChar(buffer >> bits & 63);
		}
		buffer &= (1 << bits) - 1;
	}
	if (bits > 0) out += alphabetChar(buffer << 6 - bits & 63);
	return out;
}
/**
* Decode base64url, no padding. Rejects padding characters, characters
* outside the alphabet, an impossible length (`len % 4 === 1`), and
* non-canonical input whose unused trailing bits are nonzero.
*/
function b64uDecode(s) {
	if (s.length % 4 === 1) throw new Error(`b64uDecode: invalid base64url length ${s.length}`);
	const bytes = [];
	let buffer = 0;
	let bits = 0;
	for (const char of s) {
		const value = B64U_REVERSE.get(char);
		if (value === void 0) throw new Error(`b64uDecode: invalid base64url character ${JSON.stringify(char)}`);
		buffer = buffer << 6 | value;
		bits += 6;
		if (bits >= 8) {
			bits -= 8;
			bytes.push(buffer >> bits & 255);
			buffer &= (1 << bits) - 1;
		}
	}
	if (buffer !== 0) throw new Error("b64uDecode: non-canonical encoding (nonzero padding bits)");
	return Uint8Array.from(bytes);
}
/**
* Constant-time byte-string comparison: the running time depends only on
* `max(a.length, b.length)`, never on the position of the first differing
* byte or on whether the lengths match.
*/
function timingSafeEqualBytes(a, b) {
	const length = Math.max(a.length, b.length);
	let diff = a.length === b.length ? 0 : 1;
	for (let i = 0; i < length; i++) diff |= (a[i] ?? 0) ^ (b[i] ?? 0);
	return diff === 0;
}
var ENCODED_PATH_SEPARATOR = /%(?:2f|5c)/iu;
var PERCENT_TRIPLET = /%([0-9a-f]{2})/giu;
var INVALID_PERCENT_ENCODING = /%(?![0-9a-f]{2})/iu;
function hasAsciiControl$1(value) {
	for (let index = 0; index < value.length; index += 1) {
		const code = value.charCodeAt(index);
		if (code <= 31 || code === 127) return true;
	}
	return false;
}
function hasUserInfoSyntax(value) {
	const schemeEnd = value.indexOf("://");
	if (schemeEnd === -1) return false;
	const suffix = value.slice(schemeEnd + 3);
	const delimiterOffset = suffix.search(/[/?#]/u);
	return (delimiterOffset === -1 ? suffix : suffix.slice(0, delimiterOffset)).includes("@");
}
function hasLayeredEncodedPathSeparator(value) {
	let candidate = value;
	while (true) {
		if (ENCODED_PATH_SEPARATOR.test(candidate)) return true;
		const decoded = candidate.replace(PERCENT_TRIPLET, (_triplet, hex) => String.fromCharCode(Number.parseInt(hex, 16)));
		if (decoded === candidate) return false;
		candidate = decoded;
	}
}
function canonicalBaseUrl(url) {
	const basePath = url.pathname === "/" ? "" : url.pathname.replace(/\/+$/u, "");
	return `${url.origin}${basePath}`;
}
/**
* Parse the user-configured remote endpoint.
*
* `remoteUrl` is a WS/WSS *base URL*. A non-root path is preserved as
* a reverse-proxy prefix. Query strings, fragments, credentials, whitespace,
* controls, backslashes and encoded path separators are rejected because
* different parsers/proxies could otherwise route one spelling differently.
*
* URL serialization gives us one canonical routing authority: host casing and
* explicit default ports are normalized, and trailing slashes do not create a
* second logical endpoint. This function never trims, upgrades, or downgrades
* the configured transport. MBP1 protects application content on both schemes;
* callers surface the additional transport risk of `ws://` to the user.
*/
function parseRemoteEndpoint(input) {
	if (input.length === 0 || input.length > 4096 || hasAsciiControl$1(input) || /\p{White_Space}/u.test(input) || input.includes("\\") || hasLayeredEncodedPathSeparator(input) || INVALID_PERCENT_ENCODING.test(input) || hasUserInfoSyntax(input) || input.includes("?") || input.includes("#")) throw new Error("remoteUrl is ambiguous or outside the accepted bound");
	let url;
	try {
		url = new URL(input);
	} catch {
		throw new Error("remoteUrl must be a valid ws:// or wss:// URL");
	}
	if (url.protocol !== "ws:" && url.protocol !== "wss:") throw new Error("remoteUrl must use ws:// or wss://");
	if (url.username !== "" || url.password !== "") throw new Error("remoteUrl must not include credentials");
	if (url.search !== "" || url.hash !== "") throw new Error("remoteUrl must not include a query string or fragment");
	const baseUrl = canonicalBaseUrl(url);
	if (baseUrl.length > 4096) throw new Error("remoteUrl canonical form is too long");
	let reparsed;
	try {
		reparsed = new URL(baseUrl);
	} catch {
		throw new Error("remoteUrl canonical form is invalid");
	}
	if (canonicalBaseUrl(reparsed) !== baseUrl) throw new Error("remoteUrl canonical form is unstable");
	return {
		baseUrl,
		port: url.port === "" ? url.protocol === "wss:" ? 443 : 80 : Number(url.port)
	};
}
function normalizeRemoteEndpoint(input) {
	return parseRemoteEndpoint(input).baseUrl;
}
//#endregion
//#region src/background/mbp1/backend-authority.ts
/**
* Backend trust/routing authority for MBP1 client state.
*
* This is a client-local namespace only. It is deliberately separate from
* MBP1's `Principal` and MUST NOT be added to A_id, B_id, RT, or another wire
* transcript. A browser profile remains the same principal when it connects
* to two backends; the authority prevents those backends from sharing the
* principal's credentials, pins, or recovery state locally.
*/
var BACKEND_AUTHORITY_BRAND = Symbol("motrix.mbp1.backend-authority");
var issuedAuthorities = /* @__PURE__ */ new WeakSet();
function issueAuthority(authority) {
	const frozen = Object.freeze(authority);
	issuedAuthorities.add(frozen);
	return frozen;
}
var LOCAL_BACKEND_AUTHORITY = issueAuthority({
	[BACKEND_AUTHORITY_BRAND]: true,
	kind: "local"
});
var AUTHORITY_KEY_DOMAIN = "MBP1/backend-authority/v1";
var MAX_ENDPOINT_ID_LENGTH = 128;
var MAX_REMOTE_URL_LENGTH = 4096;
var ENCODED_PATH_SEPARATOR_RE = /%(?:2f|5c)/i;
function hasAsciiControl(value) {
	for (let index = 0; index < value.length; index += 1) {
		const code = value.charCodeAt(index);
		if (code <= 31 || code === 127) return true;
	}
	return false;
}
function validateEndpointId(endpointId) {
	if (endpointId.length === 0 || endpointId.trim() !== endpointId) throw new Error("endpointId must be non-empty and already trimmed");
	if (endpointId.length > MAX_ENDPOINT_ID_LENGTH || hasAsciiControl(endpointId)) throw new Error("endpointId is outside the accepted ASCII identifier form");
	enc(endpointId);
}
function normalizeRemoteAuthorityFields(input) {
	validateEndpointId(input.endpointId);
	if (input.wsBase.length > MAX_REMOTE_URL_LENGTH || input.wsBase.length === 0 || input.wsBase.includes("\\") || hasAsciiControl(input.wsBase) || /\p{White_Space}/u.test(input.wsBase) || ENCODED_PATH_SEPARATOR_RE.test(input.wsBase)) throw new Error("remote MBP1 authority URL is ambiguous or too long");
	const canonicalWsBase = normalizeRemoteEndpoint(input.wsBase);
	if (canonicalWsBase.length > MAX_REMOTE_URL_LENGTH || normalizeRemoteEndpoint(canonicalWsBase) !== canonicalWsBase) throw new Error("remote MBP1 authority URL is not canonical");
	enc(canonicalWsBase);
	return {
		endpointId: input.endpointId,
		canonicalWsBase
	};
}
/**
* Assert that an authority is an ephemeral value issued by this module.
*
* Authorities MUST NOT be persisted or reconstructed from messages/JSON.
* Persist endpoint configuration, then call the appropriate authority factory
* after reading it. Copies are rejected even if they carry the private symbol.
*/
function assertBackendAuthority(value) {
	if (typeof value !== "object" || value === null || !issuedAuthorities.has(value) || value[BACKEND_AUTHORITY_BRAND] !== true) throw new Error("BackendAuthority must be created by its module factory");
}
/**
* Construct the only supported remote authority: an explicitly configured,
* explicitly configured websocket base. The scheme is part of the authority,
* so switching between WS and WSS cannot reuse credentials accidentally.
* Display names are intentionally absent from this type and therefore cannot
* affect credential scope.
*/
function createRemoteBackendAuthority(input) {
	const normalized = normalizeRemoteAuthorityFields(input);
	return issueAuthority({
		[BACKEND_AUTHORITY_BRAND]: true,
		kind: "remote",
		...normalized
	});
}
/**
* Stable, injective client-storage key for one backend authority.
*
* Every field is independently length-prefixed. A delimiter join would let
* an endpoint id containing the delimiter move the apparent field boundary
* and collide with another `{endpointId, canonicalWsBase}` pair.
*/
function backendAuthorityKey(authority) {
	assertBackendAuthority(authority);
	if (authority.kind === "local") return b64uEncode(concatBytes(enc(AUTHORITY_KEY_DOMAIN), enc("local")));
	const remote = normalizeRemoteAuthorityFields({
		endpointId: authority.endpointId,
		wsBase: authority.canonicalWsBase
	});
	return b64uEncode(concatBytes(enc(AUTHORITY_KEY_DOMAIN), enc("remote"), enc(remote.endpointId), enc(remote.canonicalWsBase)));
}
//#endregion
//#region src/background/mbp1/operation-queue.ts
function createOperationQueue() {
	let tail = Promise.resolve();
	return (operation) => {
		const result = tail.then(operation);
		tail = result.then(() => void 0, () => void 0);
		return result;
	};
}
//#endregion
//#region src/background/EndpointConfigStore.ts
/**
* Persists the Motrix backend catalogue in browser.storage.local.
*
* The local App has a stable, reserved id (`local`). Every Server entry has
* its own id for selection and a canonical WS/WSS URL for authority construction.
* The Extension is unreleased, so only the final schema is accepted; obsolete
* development data is never migrated into a routing or credential authority.
*/
var STORAGE_KEY = "motrix.endpointConfig";
var LOCAL_ENDPOINT_ID = "local";
var DEFAULT = {
	version: 3,
	activeEndpointId: LOCAL_ENDPOINT_ID,
	servers: [],
	cleanupTombstones: []
};
var DEFAULT_SERVER_NAME = "Motrix Server";
function cloneDefault() {
	return {
		...DEFAULT,
		servers: [],
		cleanupTombstones: []
	};
}
function cloneServer(server) {
	return { ...server };
}
function cloneTombstone(tombstone) {
	return { ...tombstone };
}
function cloneConfig(config) {
	return {
		version: 3,
		activeEndpointId: config.activeEndpointId,
		servers: config.servers.map(cloneServer),
		cleanupTombstones: config.cleanupTombstones.map(cloneTombstone)
	};
}
function isSafeRevision(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
var CONFIG_KEYS = /* @__PURE__ */ new Set([
	"version",
	"activeEndpointId",
	"servers",
	"cleanupTombstones"
]);
var SERVER_KEYS = /* @__PURE__ */ new Set([
	"id",
	"name",
	"url",
	"revision",
	"state"
]);
var TOMBSTONE_KEYS = /* @__PURE__ */ new Set([
	"endpointId",
	"canonicalWsBase",
	"invalidatedRevision"
]);
function isPlainRecord(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function hasExactOwnKeys(value, expected) {
	const keys = Object.keys(value);
	return keys.length === expected.size && keys.every((key) => expected.has(key));
}
function normalizeServer(value, strict) {
	if (!isPlainRecord(value)) {
		if (strict) throw new Error("server must be an object");
		return null;
	}
	if (!hasExactOwnKeys(value, SERVER_KEYS)) {
		if (strict) throw new Error("server fields are invalid");
		return null;
	}
	const raw = value;
	const id = typeof raw.id === "string" ? raw.id : "";
	if (id === "" || id === "local") {
		if (strict) throw new Error("server id must be non-empty and not \"local\"");
		return null;
	}
	if (typeof raw.url !== "string") {
		if (strict) throw new Error("server url must be a string");
		return null;
	}
	let url;
	try {
		url = createRemoteBackendAuthority({
			endpointId: id,
			wsBase: raw.url
		}).canonicalWsBase;
	} catch (error) {
		if (strict) throw error;
		return null;
	}
	if (typeof raw.name !== "string") {
		if (strict) throw new Error("server name must be a string");
		return null;
	}
	const name = raw.name.trim() === "" ? DEFAULT_SERVER_NAME : raw.name.trim();
	if (!isSafeRevision(raw.revision)) {
		if (strict) throw new Error("server revision must be a safe integer");
		return null;
	}
	if (raw.state !== "ready" && raw.state !== "cleanup-pending") {
		if (strict) throw new Error("server state is invalid");
		return null;
	}
	return {
		id,
		name,
		url,
		revision: raw.revision,
		state: raw.state
	};
}
function normalizeTombstone(value, strict) {
	if (!isPlainRecord(value)) {
		if (strict) throw new Error("cleanup tombstone must be an object");
		return null;
	}
	if (!hasExactOwnKeys(value, TOMBSTONE_KEYS)) {
		if (strict) throw new Error("cleanup tombstone fields are invalid");
		return null;
	}
	const raw = value;
	const endpointId = typeof raw.endpointId === "string" ? raw.endpointId : "";
	if (endpointId === "" || endpointId === "local") {
		if (strict) throw new Error("cleanup tombstone endpoint id is invalid");
		return null;
	}
	if (!isSafeRevision(raw.invalidatedRevision)) {
		if (strict) throw new Error("cleanup tombstone invalidated revision must be a safe integer");
		return null;
	}
	if (typeof raw.canonicalWsBase !== "string") {
		if (strict) throw new Error("cleanup tombstone URL must be a string");
		return null;
	}
	let canonicalWsBase;
	try {
		canonicalWsBase = createRemoteBackendAuthority({
			endpointId,
			wsBase: raw.canonicalWsBase
		}).canonicalWsBase;
	} catch (error) {
		if (strict) throw error;
		return null;
	}
	return {
		endpointId,
		canonicalWsBase,
		invalidatedRevision: raw.invalidatedRevision
	};
}
function readStoredConfig(value) {
	if (value === void 0) return {
		kind: "known",
		config: cloneDefault()
	};
	if (!value || typeof value !== "object") return { kind: "corrupt" };
	if (!Object.hasOwn(value, "version")) return { kind: "obsolete" };
	const version = value.version;
	if (typeof version === "number" && Number.isSafeInteger(version) && version >= 0 && version < 3) return { kind: "obsolete" };
	if (version !== 3) return { kind: "future" };
	try {
		return {
			kind: "known",
			config: normalizeCurrent(value, true)
		};
	} catch {
		return { kind: "corrupt" };
	}
}
function normalizeCurrent(value, strict) {
	if (!isPlainRecord(value)) {
		if (strict) throw new Error("endpoint config must be an object");
		return cloneDefault();
	}
	if (!hasExactOwnKeys(value, CONFIG_KEYS)) {
		if (strict) throw new Error("endpoint config fields are invalid");
		return cloneDefault();
	}
	const raw = value;
	if (!Array.isArray(raw.servers)) {
		if (strict) throw new Error("endpoint config servers must be an array");
		return cloneDefault();
	}
	if (!Array.isArray(raw.cleanupTombstones)) {
		if (strict) throw new Error("endpoint config cleanup tombstones must be an array");
		return cloneDefault();
	}
	const servers = [];
	const ids = /* @__PURE__ */ new Set();
	const urls = /* @__PURE__ */ new Set();
	for (const value of raw.servers) {
		const server = normalizeServer(value, strict);
		if (server === null) continue;
		if (ids.has(server.id)) {
			if (strict) throw new Error("server id is duplicated");
			continue;
		}
		if (urls.has(server.url)) {
			if (strict) throw new Error("server URL is duplicated");
			continue;
		}
		ids.add(server.id);
		urls.add(server.url);
		servers.push(server);
	}
	const cleanupTombstones = [];
	const tombstoneIds = /* @__PURE__ */ new Set();
	const tombstoneUrls = /* @__PURE__ */ new Set();
	for (const value of raw.cleanupTombstones) {
		const tombstone = normalizeTombstone(value, strict);
		if (tombstone === null) continue;
		if (tombstoneIds.has(tombstone.endpointId)) {
			if (strict) throw new Error("cleanup tombstone endpoint id is duplicated");
			continue;
		}
		if (tombstoneUrls.has(tombstone.canonicalWsBase) || urls.has(tombstone.canonicalWsBase)) {
			if (strict) throw new Error("cleanup tombstone URL conflicts with a configured authority");
			continue;
		}
		tombstoneIds.add(tombstone.endpointId);
		tombstoneUrls.add(tombstone.canonicalWsBase);
		cleanupTombstones.push(tombstone);
	}
	for (const server of servers) {
		const tombstone = cleanupTombstones.find((candidate) => candidate.endpointId === server.id);
		if (server.state === "ready") {
			if (tombstone !== void 0) {
				if (strict) throw new Error("ready server cannot retain a cleanup tombstone");
			}
		} else if (tombstone === void 0 || tombstone.invalidatedRevision + 1 !== server.revision) {
			if (strict) throw new Error("cleanup-pending server must match a tombstone for the prior revision");
		}
	}
	for (const tombstone of cleanupTombstones) {
		const server = servers.find(({ id }) => id === tombstone.endpointId);
		if (server !== void 0 && (server.state !== "cleanup-pending" || tombstone.invalidatedRevision + 1 !== server.revision)) {
			if (strict) throw new Error("cleanup tombstone conflicts with the current endpoint profile");
		}
	}
	if (typeof raw.activeEndpointId !== "string") {
		if (strict) throw new Error("active endpoint id must be a string");
		return cloneDefault();
	}
	const requestedActiveId = raw.activeEndpointId;
	if (strict && requestedActiveId !== "local" && !ids.has(requestedActiveId)) throw new Error("active endpoint id is unknown");
	return {
		version: 3,
		activeEndpointId: requestedActiveId === "local" ? LOCAL_ENDPOINT_ID : ids.has(requestedActiveId) ? requestedActiveId : LOCAL_ENDPOINT_ID,
		servers,
		cleanupTombstones
	};
}
/** Resolve the currently selected backend, falling back safely to the App. */
function resolveActiveEndpoint(config) {
	return resolveEndpointById(config, config.activeEndpointId) ?? { mode: "local" };
}
/** Resolve an explicit endpoint id. Unknown ids return null (fail closed). */
function resolveEndpointById(config, endpointId) {
	if (endpointId === "local") return { mode: "local" };
	const server = config.servers.find(({ id }) => id === endpointId);
	if (!server || (server.state ?? "ready") !== "ready") return null;
	let remoteUrl;
	try {
		remoteUrl = createRemoteBackendAuthority({
			endpointId: server.id,
			wsBase: server.url
		}).canonicalWsBase;
	} catch {
		return null;
	}
	return {
		mode: "remote",
		remoteUrl,
		endpointId: server.id,
		revision: isSafeRevision(server.revision) ? server.revision : 0
	};
}
/** Validate and canonicalize a caller-supplied catalogue without writing. */
function normalizeEndpointConfig(config) {
	if (config.version !== 3) throw new Error(`endpoint config version must be 3`);
	return normalizeCurrent(config, true);
}
/** Fixed fail-closed error that never includes persisted endpoint data. */
var UnsupportedEndpointConfigVersionError = class extends Error {
	constructor() {
		super("endpoint config version is unsupported");
	}
};
var CorruptEndpointConfigStoreError = class extends Error {
	constructor() {
		super("endpoint config store is corrupt");
	}
};
var enqueueEndpointConfigOperation = createOperationQueue();
var endpointConfigLifecycleWriterBrand = Symbol("EndpointConfigLifecycleWriter");
var issuedEndpointConfigLifecycleWriters = /* @__PURE__ */ new WeakSet();
var IssuedEndpointConfigLifecycleWriter = class {
	owner;
	[endpointConfigLifecycleWriterBrand] = true;
	constructor(owner) {
		this.owner = owner;
		issuedEndpointConfigLifecycleWriters.add(this);
	}
	set(config) {
		if (!issuedEndpointConfigLifecycleWriters.has(this)) throw new TypeError("endpoint lifecycle writer was not issued");
		return this.owner.setForIssuedLifecycleWriter(config, this);
	}
};
var EndpointConfigStore = class {
	async get() {
		return this.read(false);
	}
	/** Lifecycle writers and the startup recovery barrier use this stricter
	* read so an opaque future/corrupt document cannot masquerade as an empty
	* local catalogue and then be overwritten or skipped. */
	async getForLifecycleMutation() {
		return this.read(true);
	}
	async read(requireKnown) {
		return enqueueEndpointConfigOperation(async () => {
			const value = (await browser.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
			const stored = readStoredConfig(value);
			if (stored.kind === "future") {
				if (requireKnown) throw new UnsupportedEndpointConfigVersionError();
				return cloneDefault();
			}
			if (stored.kind === "corrupt") {
				if (requireKnown) throw new CorruptEndpointConfigStoreError();
				return cloneDefault();
			}
			if (stored.kind === "obsolete") {
				await browser.storage.local.remove(STORAGE_KEY);
				return cloneDefault();
			}
			return cloneConfig(stored.config);
		});
	}
	/** Issue the sole nominal production write view. Import/use outside
	* EndpointCatalogService is rejected by scripts/check-imports.mjs. */
	issueLifecycleWriter() {
		return new IssuedEndpointConfigLifecycleWriter(this);
	}
	/** Test/fixture primitive. Production source is forbidden from calling it. */
	async setForTest(config) {
		return this.persist(config);
	}
	async setForIssuedLifecycleWriter(config, writer) {
		if (!issuedEndpointConfigLifecycleWriters.has(writer)) throw new TypeError("endpoint lifecycle writer was not issued");
		return this.persist(config);
	}
	async persist(config) {
		return enqueueEndpointConfigOperation(async () => {
			const current = readStoredConfig((await browser.storage.local.get(STORAGE_KEY))[STORAGE_KEY]);
			if (current.kind === "future") throw new UnsupportedEndpointConfigVersionError();
			if (current.kind === "corrupt") throw new CorruptEndpointConfigStoreError();
			const normalized = normalizeEndpointConfig(config);
			await browser.storage.local.set({ [STORAGE_KEY]: normalized });
		});
	}
};
//#endregion
//#region src/shared/takeoverAvailability.ts
/** Use the selected id, never a resolver's fallback for an unavailable Server. */
function supportsAutomaticTakeover(config) {
	return config?.activeEndpointId === LOCAL_ENDPOINT_ID;
}
//#endregion
//#region src/shared/takeover.ts
var TAKEOVER_DEFAULT = {
	enabled: false,
	consentAckVersion: 0,
	defaultAction: "motrix",
	rules: []
};
var MIB = 1048576;
var QUALITY_SENTINEL = "file";
function hostOf(url) {
	try {
		return new URL(url).hostname.toLowerCase();
	} catch {
		return "";
	}
}
/** Suffix match: host === entry or host ends with `.entry` (leading dots on entry ignored). */
function hostSuffixMatch(host, entry) {
	const h = host.toLowerCase();
	const e = entry.replace(/^\.+/, "").toLowerCase();
	if (e.length === 0) return false;
	return h === e || h.endsWith(`.${e}`);
}
/** True iff `url` is a BitTorrent magnet link (`magnet:?…`). */
function isMagnetUrl(url) {
	return typeof url === "string" && url.startsWith("magnet:?");
}
/** Decode a magnet link's `dn=` display-name hint, or undefined if absent. */
function magnetDisplayName(uri) {
	const q = uri.indexOf("?");
	if (q < 0) return void 0;
	const dn = new URLSearchParams(uri.slice(q + 1)).get("dn");
	return dn !== null && dn.length > 0 ? dn : void 0;
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
	const numericValues = Object.values(entries).filter((v) => typeof v === "number");
	return Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
}
function joinValues(array, separator = "|") {
	return array.map((val) => stringifyPrimitive(val)).join(separator);
}
function jsonStringifyReplacer(_, value) {
	if (typeof value === "bigint") return value.toString();
	return value;
}
function cached(getter) {
	return { get value() {
		{
			const value = getter();
			Object.defineProperty(this, "value", { value });
			return value;
		}
	} };
}
function nullish(input) {
	return input === null || input === void 0;
}
function cleanRegex(source) {
	const start = source.startsWith("^") ? 1 : 0;
	const end = source.endsWith("$") ? source.length - 1 : source.length;
	return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
	const ratio = val / step;
	const roundedRatio = Math.round(ratio);
	const tolerance = 4 * Number.EPSILON * Math.max(Math.abs(ratio), 1);
	if (Math.abs(ratio - roundedRatio) < tolerance) return 0;
	return ratio - roundedRatio;
}
function assignProp(target, prop, value) {
	Object.defineProperty(target, prop, {
		value,
		writable: true,
		enumerable: true,
		configurable: true
	});
}
function mergeDefs(...defs) {
	const mergedDescriptors = {};
	for (const def of defs) {
		const descriptors = Object.getOwnPropertyDescriptors(def);
		Object.assign(mergedDescriptors, descriptors);
	}
	return Object.defineProperties({}, mergedDescriptors);
}
function esc(str) {
	return JSON.stringify(str);
}
function slugify(input) {
	return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
function isObject(data) {
	return typeof data === "object" && data !== null && !Array.isArray(data);
}
var allowsEval = { value: false };
function isPlainObject(o) {
	if (isObject(o) === false) return false;
	const ctor = o.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return true;
	const prot = ctor.prototype;
	if (isObject(prot) === false) return false;
	if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) return false;
	return true;
}
function shallowClone(o) {
	if (isPlainObject(o)) return { ...o };
	if (Array.isArray(o)) return [...o];
	if (o instanceof Map) return new Map(o);
	if (o instanceof Set) return new Set(o);
	return o;
}
var propertyKeyTypes = /* @__PURE__*/ new Set([
	"string",
	"number",
	"symbol"
]);
function escapeRegex(str) {
	return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
	const cl = new inst._zod.constr(def ?? inst._zod.def);
	if (!def || params?.parent) cl._zod.parent = inst;
	return cl;
}
function normalizeParams(_params) {
	const params = _params;
	if (!params) return {};
	if (typeof params === "string") return { error: () => params };
	if (params?.message !== void 0) {
		if (params?.error !== void 0) throw new Error("Cannot specify both `message` and `error` params");
		params.error = params.message;
	}
	delete params.message;
	if (typeof params.error === "string") return {
		...params,
		error: () => params.error
	};
	return params;
}
function stringifyPrimitive(value) {
	if (typeof value === "bigint") return value.toString() + "n";
	if (typeof value === "string") return `"${value}"`;
	return `${value}`;
}
function optionalKeys(shape) {
	return Object.keys(shape).filter((k) => {
		return shape[k]._zod.optin !== void 0 && shape[k]._zod.optout === "optional";
	});
}
var NUMBER_FORMAT_RANGES = /*@__PURE__*/ (() => ({
	safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
	int32: [-2147483648, 2147483647],
	uint32: [0, 4294967295],
	float32: [-34028234663852886e22, 34028234663852886e22],
	float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
}))();
function pick(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".pick() cannot be used on object schemas containing refinements");
	return clone(schema, mergeDefs(schema._zod.def, {
		get shape() {
			const newShape = {};
			for (const key of Reflect.ownKeys(mask)) {
				if (!Object.prototype.hasOwnProperty.call(currDef.shape, key)) throw new Error(`Unrecognized key: "${String(key)}"`);
				if (!mask[key]) continue;
				assignProp(newShape, key, currDef.shape[key]);
			}
			assignProp(this, "shape", newShape);
			return newShape;
		},
		checks: []
	}));
}
function omit(schema, mask) {
	const currDef = schema._zod.def;
	const checks = currDef.checks;
	if (checks && checks.length > 0) throw new Error(".omit() cannot be used on object schemas containing refinements");
	return clone(schema, mergeDefs(schema._zod.def, {
		get shape() {
			const newShape = { ...schema._zod.def.shape };
			for (const key of Reflect.ownKeys(mask)) {
				if (!Object.prototype.hasOwnProperty.call(currDef.shape, key)) throw new Error(`Unrecognized key: "${String(key)}"`);
				if (!mask[key]) continue;
				delete newShape[key];
			}
			assignProp(this, "shape", newShape);
			return newShape;
		},
		checks: []
	}));
}
function extend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to extend: expected a plain object");
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) {
		const existingShape = schema._zod.def.shape;
		for (const key of Reflect.ownKeys(shape)) if (Object.getOwnPropertyDescriptor(existingShape, key) !== void 0) throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
	}
	return clone(schema, mergeDefs(schema._zod.def, { get shape() {
		const _shape = {
			...schema._zod.def.shape,
			...shape
		};
		assignProp(this, "shape", _shape);
		return _shape;
	} }));
}
function safeExtend(schema, shape) {
	if (!isPlainObject(shape)) throw new Error("Invalid input to safeExtend: expected a plain object");
	return clone(schema, mergeDefs(schema._zod.def, { get shape() {
		const _shape = {
			...schema._zod.def.shape,
			...shape
		};
		assignProp(this, "shape", _shape);
		return _shape;
	} }));
}
function merge(a, b) {
	if (!b?._zod?.def) throw new Error("Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`.");
	if (a._zod.def.checks?.length) throw new Error(".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead.");
	return clone(a, mergeDefs(a._zod.def, {
		get shape() {
			const _shape = {
				...a._zod.def.shape,
				...b._zod.def.shape
			};
			assignProp(this, "shape", _shape);
			return _shape;
		},
		get catchall() {
			return b._zod.def.catchall;
		},
		checks: b._zod.def.checks ?? []
	}));
}
function partial(Class, schema, mask, name = "partial") {
	const checks = schema._zod.def.checks;
	if (checks && checks.length > 0) throw new Error(`.${name}() cannot be used on object schemas containing refinements`);
	return clone(schema, mergeDefs(schema._zod.def, {
		get shape() {
			const oldShape = schema._zod.def.shape;
			const shape = { ...oldShape };
			if (mask) for (const key of Reflect.ownKeys(mask)) {
				if (!Object.prototype.hasOwnProperty.call(oldShape, key)) throw new Error(`Unrecognized key: "${String(key)}"`);
				if (!mask[key]) continue;
				shape[key] = Class ? new Class({
					type: "optional",
					innerType: oldShape[key]
				}) : oldShape[key];
			}
			else for (const key of Reflect.ownKeys(oldShape)) shape[key] = Class ? new Class({
				type: "optional",
				innerType: oldShape[key]
			}) : oldShape[key];
			assignProp(this, "shape", shape);
			return shape;
		},
		checks: []
	}));
}
function required(Class, schema, mask) {
	return clone(schema, mergeDefs(schema._zod.def, { get shape() {
		const oldShape = schema._zod.def.shape;
		const shape = { ...oldShape };
		if (mask) for (const key of Reflect.ownKeys(mask)) {
			if (!Object.prototype.hasOwnProperty.call(shape, key)) throw new Error(`Unrecognized key: "${String(key)}"`);
			if (!mask[key]) continue;
			shape[key] = new Class({
				type: "nonoptional",
				innerType: oldShape[key]
			});
		}
		else for (const key of Reflect.ownKeys(oldShape)) shape[key] = new Class({
			type: "nonoptional",
			innerType: oldShape[key]
		});
		assignProp(this, "shape", shape);
		return shape;
	} }));
}
function aborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue !== true) return true;
	return false;
}
function explicitlyAborted(x, startIndex = 0) {
	if (x.aborted === true) return true;
	for (let i = startIndex; i < x.issues.length; i++) if (x.issues[i]?.continue === false) return true;
	return false;
}
function prefixIssues(path, issues) {
	return issues.map((iss) => {
		var _a;
		(_a = iss).path ?? (_a.path = []);
		iss.path.unshift(path);
		return iss;
	});
}
function unwrapMessage(message) {
	return typeof message === "string" ? message : message?.message;
}
function attachSchema(issues, start, inst) {
	var _a;
	for (let i = start; i < issues.length; i++) (_a = issues[i]).schema ?? (_a.schema = inst);
}
function finalizeIssue(iss, ctx, config) {
	var _a;
	const traits = iss.inst?._zod?.traits;
	if (traits?.has("$ZodType")) {
		if (traits.has("$ZodCheck")) (_a = iss).schema ?? (_a.schema = iss.inst);
		else iss.schema = iss.inst;
	}
	const schemaError = iss.schema !== iss.inst ? iss.schema?._zod.def?.error : void 0;
	const message = iss.message ? iss.message : unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(schemaError?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
	const { inst: _inst, schema: _schema, continue: _continue, input: _input, ...rest } = iss;
	rest.path ?? (rest.path = []);
	rest.message = message;
	if (ctx?.reportInput) rest.input = _input;
	return rest;
}
var highSurrogate = /[\uD800-\uDBFF]/;
function codePointLength(str) {
	const units = str.length;
	if (!highSurrogate.test(str)) return units;
	let count = units;
	for (let i = 0; i < units - 1; i++) if ((str.charCodeAt(i) & 64512) === 55296 && (str.charCodeAt(i + 1) & 64512) === 56320) {
		count--;
		i++;
	}
	return count;
}
function getLengthableOrigin(input) {
	if (Array.isArray(input)) return "array";
	if (typeof input === "string") return "string";
	return "unknown";
}
function parsedType(data) {
	const t = typeof data;
	switch (t) {
		case "number": return Number.isNaN(data) ? "nan" : "number";
		case "object": {
			if (data === null) return "null";
			if (Array.isArray(data)) return "array";
			const obj = data;
			if (obj && Object.getPrototypeOf(obj) !== Object.prototype && "constructor" in obj && obj.constructor) return obj.constructor.name;
		}
	}
	return t;
}
function issue(...args) {
	const [iss, input, inst] = args;
	if (typeof iss === "string") return {
		message: iss,
		code: "custom",
		input,
		inst
	};
	return { ...iss };
}
/**
* Installs a trait's members on its prototype. Each value builds that member for the instance on first read; the built value shadows the accessor as an own property, so a detached `const { parse } = schema` keeps working.
*
* Call this from a `proto` initializer, which runs once per prototype — never per instance.
*/
function members(proto, table) {
	for (const key in table) {
		const desc = Object.getOwnPropertyDescriptor(table, key);
		if (desc.get) Object.defineProperty(proto, key, {
			...desc,
			enumerable: false
		});
		else defineBound(proto, key, desc.value);
	}
}
/** Shadows a prototype member with an own value, so a getter that builds from the instance runs once. */
function own(inst, key, value, enumerable = true) {
	Object.defineProperty(inst, key, {
		configurable: true,
		writable: true,
		enumerable,
		value
	});
	return value;
}
/** Like {@link own}, for a member that was never an own data property and has to stay out of `Object.keys`. */
function hide(inst, key, value) {
	return own(inst, key, value, false);
}
function defineBound(proto, key, fn) {
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			return this == null ? fn : own(this, key, fn.bind(this));
		},
		set(value) {
			own(this, key, value);
		}
	});
}
/** Returns the prototype to install on, or `undefined` if this group is already installed on it. */
function claim(inst, sentinel) {
	const proto = Object.getPrototypeOf(inst);
	return sentinel in proto ? void 0 : proto;
}
var installing;
var broke = false;
var breaker = {
	configurable: true,
	get() {
		broke = true;
	}
};
/**
* Installs a lazily-derived internal on the `_zod` prototype of `inst`'s
* constructor, computed from the internals object itself and cached there on
* first read. One accessor per constructor rather than one per instance.
*/
function defineLazyInternal(inst, key, compute) {
	const proto = Object.getPrototypeOf(inst._zod);
	if (key in proto && installing !== inst._zod) {
		installing = void 0;
		return;
	}
	installing = inst._zod;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			Object.defineProperty(this, key, breaker);
			const outer = broke;
			broke = false;
			try {
				const value = compute(this);
				if (broke) delete this[key];
				else Object.defineProperty(this, key, {
					configurable: true,
					writable: true,
					value
				});
				broke = broke || outer;
				return value;
			} catch (err) {
				delete this[key];
				broke = broke || outer;
				throw err;
			}
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				value
			});
		}
	});
}
/**
* Installs `key` on `inst`'s prototype, computed by `make` on first read and cached there as an own
* data property. One accessor per constructor rather than one per instance, because an own accessor
* puts every instance after the first into v8 dictionary mode. The key doubles as the sentinel.
*/
function installLazyProp(inst, key, make, enumerable) {
	const proto = claim(inst, key);
	if (!proto) return;
	Object.defineProperty(proto, key, {
		configurable: true,
		get() {
			const desc = {
				configurable: true,
				writable: true,
				enumerable,
				value: void 0
			};
			Object.defineProperty(this, key, desc);
			desc.value = make(this);
			Object.defineProperty(this, key, desc);
			return desc.value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				configurable: true,
				writable: true,
				enumerable,
				value
			});
		}
	});
}
/** Marks the thunk `_catch` synthesises for a constant catch value. `Function.length` cannot tell that thunk from a user callback — rest and defaulted parameters both report arity 0 — and a user callback reads `ctx.error`, whose issues only finalize correctly against the caller's per-parse error map. Provenance can say what arity cannot. A plain string key rather than `Symbol.for`, whose call at module scope no bundler can prove pure — the same shape that anchored `urlCanParse` into every build. */
var CONSTANT_CATCH = "~constantCatch";
/** Wraps a constant catch value in a thunk tagged with {@link CONSTANT_CATCH}. */
function constantCatch(value) {
	const fn = () => value;
	fn[CONSTANT_CATCH] = true;
	return fn;
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/core.js
var _a$1;
var _zodDesc$1 = {
	value: void 0,
	enumerable: false
};
var _E = "captureStackTrace" in Error ? Error : null;
function newError(Definition) {
	const E = _E;
	if (E) {
		const saved = E.stackTraceLimit;
		if (typeof saved === "number") {
			try {
				E.stackTraceLimit = 0;
			} catch {
				_E = null;
				return new Definition();
			}
			try {
				return new Definition();
			} finally {
				E.stackTraceLimit = saved;
			}
		}
	}
	return new Definition();
}
function $constructor(name, initializer, proto, params) {
	const zodProto = {};
	function Internals(def) {
		this.def = def;
		this.constr = _;
		this.traits = /* @__PURE__ */ new Set();
	}
	Internals.prototype = zodProto;
	const protoMembers = proto;
	const initialized = protoMembers && /* @__PURE__ */ new WeakSet();
	function init(inst, def) {
		if (!inst._zod) {
			_zodDesc$1.value = new Internals(def);
			try {
				Object.defineProperty(inst, "_zod", _zodDesc$1);
			} finally {
				_zodDesc$1.value = void 0;
			}
		}
		if (inst._zod.traits.has(name)) return;
		inst._zod.traits.add(name);
		initializer(inst, def);
		if (initialized) {
			const own = Object.getPrototypeOf(inst);
			const ctorProto = inst._zod.constr.prototype;
			let up = own;
			while (up && up !== ctorProto) up = Object.getPrototypeOf(up);
			const target = up ?? own;
			if (!initialized.has(target)) {
				initialized.add(target);
				members(target, protoMembers);
			}
		}
		const proto = _.prototype;
		for (const k in proto) {
			if (!Object.prototype.hasOwnProperty.call(proto, k)) continue;
			if (!(k in inst)) inst[k] = proto[k].bind(inst);
		}
	}
	const Parent = params?.Parent ?? Object;
	class Definition extends Parent {}
	Object.defineProperty(Definition, "name", { value: name });
	function _(def) {
		const inst = params?.Parent ? newError(Definition) : this;
		init(inst, def);
		const deferred = inst._zod.deferred;
		if (deferred) {
			for (const fn of deferred) fn();
			inst._zod.deferred = void 0;
		}
		const pp = globalThis.__zod_globalConfig?.postProcessor;
		if (pp) pp(inst);
		return inst;
	}
	Object.defineProperty(_, "init", { value: init });
	Object.defineProperty(_, Symbol.hasInstance, { value: (inst) => {
		if (params?.Parent && inst instanceof params.Parent) return true;
		return inst?._zod?.traits?.has(name);
	} });
	Object.defineProperty(_, "name", { value: name });
	return _;
}
var $ZodAsyncError = class extends Error {
	constructor() {
		super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
	}
};
var $ZodEncodeError = class extends Error {
	constructor(name) {
		super(`Encountered unidirectional transform during encode: ${name}`);
		this.name = "ZodEncodeError";
	}
};
(_a$1 = globalThis).__zod_globalConfig ?? (_a$1.__zod_globalConfig = {});
var globalConfig = globalThis.__zod_globalConfig;
function config(newConfig) {
	if (newConfig) Object.assign(globalConfig, newConfig);
	return globalConfig;
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/errors.js
function _getMessage() {
	const internals = this._zod;
	internals.message ?? (internals.message = JSON.stringify(internals.def, jsonStringifyReplacer, 2));
	return internals.message;
}
function _setMessage(value) {
	this._zod.message = value;
}
var _messageDesc = {
	get: _getMessage,
	set: _setMessage,
	enumerable: true,
	configurable: true
};
var _zodDesc = {
	value: void 0,
	enumerable: false
};
var _issuesDesc = {
	value: void 0,
	enumerable: false
};
var _installedToString = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
var initializer$1 = (inst, def) => {
	inst.name = "$ZodError";
	_zodDesc.value = inst._zod;
	Object.defineProperty(inst, "_zod", _zodDesc);
	_issuesDesc.value = def;
	Object.defineProperty(inst, "issues", _issuesDesc);
	_zodDesc.value = void 0;
	_issuesDesc.value = void 0;
	Object.defineProperty(inst, "message", _messageDesc);
	const proto = Object.getPrototypeOf(inst);
	if (!_installedToString.has(proto)) {
		_installedToString.add(proto);
		Object.defineProperty(proto, "toString", {
			configurable: true,
			enumerable: false,
			get() {
				const value = () => this.message;
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
				return value;
			},
			set(value) {
				Object.defineProperty(this, "toString", {
					value,
					configurable: true,
					writable: true
				});
			}
		});
	}
};
var $ZodError = $constructor("$ZodError", initializer$1);
var $ZodRealError = $constructor("$ZodError", initializer$1, void 0, { Parent: Error });
/** Get-or-create `obj[key]` as an own data property. A path segment naming an inherited member
* ("toString", "constructor") would otherwise read through to the prototype, and assigning
* "__proto__" would hit the setter instead of creating a key. */
function node(obj, key, make) {
	if (!Object.prototype.hasOwnProperty.call(obj, key)) {
		if (key === "__proto__") Object.defineProperty(obj, key, {
			value: make(),
			writable: true,
			enumerable: true,
			configurable: true
		});
		else obj[key] = make();
	}
	return obj[key];
}
function flattenError(error, mapper = (issue) => issue.message) {
	const fieldErrors = {};
	const formErrors = [];
	for (const sub of error.issues) if (sub.path.length > 0) node(fieldErrors, sub.path[0], () => []).push(mapper(sub));
	else formErrors.push(mapper(sub));
	return {
		formErrors,
		fieldErrors
	};
}
function formatError(error, mapper = (issue) => issue.message) {
	const fieldErrors = { _errors: [] };
	const processError = (error, path = []) => {
		for (const issue of error.issues) if (issue.code === "invalid_union" && issue.errors.length) issue.errors.map((issues) => processError({ issues }, [...path, ...issue.path]));
		else if (issue.code === "invalid_key") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else if (issue.code === "invalid_element") processError({ issues: issue.issues }, [...path, ...issue.path]);
		else {
			const fullpath = [...path, ...issue.path];
			if (fullpath.length === 0) fieldErrors._errors.push(mapper(issue));
			else {
				let curr = fieldErrors;
				let i = 0;
				while (i < fullpath.length) {
					const el = fullpath[i];
					const terminal = i === fullpath.length - 1;
					if (el === "_errors") {
						if (terminal) curr._errors.push(mapper(issue));
						i++;
						continue;
					}
					if (!Object.prototype.hasOwnProperty.call(curr, el)) Object.defineProperty(curr, el, {
						value: { _errors: [] },
						enumerable: true,
						writable: true,
						configurable: true
					});
					const node = curr[el];
					if (terminal) node._errors.push(mapper(issue));
					curr = node;
					i++;
				}
			}
		}
	};
	processError(error);
	return fieldErrors;
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/parse.js
function finalizeParams(callee, params) {
	return {
		callee: params?.callee ?? callee,
		Err: params?.Err
	};
}
var _parse = (_Err) => {
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: false
		} : { async: false };
		const result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) throw new $ZodAsyncError();
		if (result.issues.length) {
			const e = new ((_params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, _params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _parseAsync = (_Err) => {
	const fn = async (schema, value, _ctx, params) => {
		const ctx = _ctx ? {
			..._ctx,
			async: true
		} : { async: true };
		let result = schema._zod.run({
			value,
			issues: []
		}, ctx);
		if (result instanceof Promise) result = await result;
		if (result.issues.length) {
			const e = new ((params?.Err) ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
			captureStackTrace(e, params?.callee ?? fn);
			throw e;
		}
		return result.value;
	};
	return fn;
};
var _safeParse = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: false
	} : { async: false };
	const result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) throw new $ZodAsyncError();
	return result.issues.length ? {
		success: false,
		error: new (_Err ?? $ZodError)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
	} : {
		success: true,
		data: result.value
	};
};
var safeParse$1 = /* @__PURE__*/ _safeParse($ZodRealError);
var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		async: true
	} : { async: true };
	let result = schema._zod.run({
		value,
		issues: []
	}, ctx);
	if (result instanceof Promise) result = await result;
	return result.issues.length ? {
		success: false,
		error: new _Err(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
	} : {
		success: true,
		data: result.value
	};
};
var safeParseAsync$1 = /* @__PURE__*/ _safeParseAsync($ZodRealError);
var _encode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return parse(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decode = (_Err) => {
	const parse = _parse(_Err);
	const fn = (schema, value, _ctx, _params) => {
		return parse(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _encodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		const ctx = _ctx ? {
			..._ctx,
			direction: "backward"
		} : { direction: "backward" };
		return await parseAsync(schema, value, ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _decodeAsync = (_Err) => {
	const parseAsync = _parseAsync(_Err);
	const fn = async (schema, value, _ctx, _params) => {
		return await parseAsync(schema, value, _ctx, finalizeParams(fn, _params));
	};
	return fn;
};
var _safeEncode = (_Err) => (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParse(_Err)(schema, value, ctx);
};
var _safeDecode = (_Err) => (schema, value, _ctx) => {
	return _safeParse(_Err)(schema, value, _ctx);
};
var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
	const ctx = _ctx ? {
		..._ctx,
		direction: "backward"
	} : { direction: "backward" };
	return _safeParseAsync(_Err)(schema, value, ctx);
};
var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
	return _safeParseAsync(_Err)(schema, value, _ctx);
};
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/regexes.js
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var cuid = /^[cC][0-9a-z]{6,}$/;
var cuid2 = /^[0-9a-z]+$/;
var ulid = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/;
var xid = /^[0-9a-vA-V]{20}$/;
var ksuid = /^[A-Za-z0-9]{27}$/;
var nanoid = /^[a-zA-Z0-9_-]{21}$/;
function nanoidOfLength(length) {
	return new RegExp(`^[a-zA-Z0-9_-]{${length}}$`);
}
/** ISO 8601-1 duration regex. Does not support the 8601-2 extensions like negative durations or fractional/negative components. */
var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
/** A regex for any UUID-like identifier: 8-4-4-4-12 hex pattern */
var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
/** Returns a regex for validating an RFC 9562/4122 UUID.
*
* @param version Optionally specify a version 1-8. If no version is specified, all versions are supported. */
var uuid = (version) => {
	if (!version) return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
	return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
/** Practical email validation */
var email = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var _emoji$1 = `^[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$`;
function emoji() {
	return new RegExp(_emoji$1, "u");
}
var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
var base64url = /^[A-Za-z0-9_-]*$/;
var domain = /^(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$/;
var httpProtocol = /^https?$/;
var e164 = /^\+[1-9]\d{6,14}$/;
var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
/** Anchors a pattern source. The interpolation lives here rather than at the call site because
* esbuild will not drop a `@__PURE__` call whose own argument interpolates a variable, but it
* will drop `anchor(dateSource)`. Keeping it inline pinned `date` into every bundle. */
function anchor(source) {
	return new RegExp(`^${source}$`);
}
var date = /*@__PURE__*/ anchor(dateSource);
function timeSource(args) {
	const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
	return typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : args.seconds ? `${hhmm}:[0-5]\\d(?:\\.\\d+)?` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
}
function time(args) {
	return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
	const opts = ["Z"];
	if (args.offset) opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
	const qualified = `${timeSource({
		precision: args.precision,
		seconds: true
	})}(?:${opts.join("|")})`;
	const timeRegex = args.local ? `${qualified}|${timeSource({ precision: args.precision })}` : qualified;
	return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
}
var string$1 = (params) => {
	const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
	return new RegExp(`^${regex}$`);
};
var integer = /^-?\d+$/;
var number$1 = /^-?\d+(?:\.\d+)?$/;
var boolean$1 = /^(?:true|false)$/i;
var lowercase = /^[^A-Z]*$/;
var uppercase = /^[^a-z]*$/;
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/checks.js
var $ZodCheck = /*@__PURE__*/ $constructor("$ZodCheck", (inst, def) => {
	var _a;
	inst._zod ?? (inst._zod = {});
	inst._zod.def = def;
	(_a = inst._zod).onattach ?? (_a.onattach = []);
});
/** Default `when` for length-based checks: run only on non-nullish values with a `length`. */
var _whenHasLength = (payload) => {
	const val = payload.value;
	return !nullish(val) && val.length !== void 0;
};
var numericOriginMap = {
	number: "number",
	bigint: "bigint",
	object: "date"
};
var $ZodCheckLessThan = /*@__PURE__*/ $constructor("$ZodCheckLessThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		const curr = (def.inclusive ? bag.maximum : bag.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
		if (def.value < curr) {
			if (def.inclusive) bag.maximum = def.value;
			else bag.exclusiveMaximum = def.value;
		}
	});
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value <= def.value : payload.value < def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_big",
			maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckGreaterThan = /*@__PURE__*/ $constructor("$ZodCheckGreaterThan", (inst, def) => {
	$ZodCheck.init(inst, def);
	const origin = numericOriginMap[typeof def.value];
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		const curr = (def.inclusive ? bag.minimum : bag.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
		if (def.value > curr) {
			if (def.inclusive) bag.minimum = def.value;
			else bag.exclusiveMinimum = def.value;
		}
	});
	inst._zod.check = (payload) => {
		if (def.inclusive ? payload.value >= def.value : payload.value > def.value) return;
		payload.issues.push({
			origin: numericOriginMap[typeof payload.value] ?? origin,
			code: "too_small",
			minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
			input: payload.value,
			inclusive: def.inclusive,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMultipleOf = /*@__PURE__*/ $constructor("$ZodCheckMultipleOf", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.onattach.push((inst) => {
		var _a;
		(_a = inst._zod.bag).multipleOf ?? (_a.multipleOf = def.value);
	});
	inst._zod.check = (payload) => {
		if (typeof payload.value !== typeof def.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
		if (typeof payload.value === "bigint" ? def.value !== BigInt(0) && payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0) return;
		payload.issues.push({
			origin: typeof payload.value,
			code: "not_multiple_of",
			divisor: def.value,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckNumberFormat = /*@__PURE__*/ $constructor("$ZodCheckNumberFormat", (inst, def) => {
	$ZodCheck.init(inst, def);
	def.format = def.format || "float64";
	const isInt = def.format?.includes("int");
	const origin = isInt ? "int" : "number";
	const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.format = def.format;
		bag.minimum = minimum;
		bag.maximum = maximum;
		if (isInt) bag.pattern = integer;
	});
	inst._zod.check = (payload) => {
		const input = payload.value;
		if (isInt) {
			if (!Number.isInteger(input)) {
				payload.issues.push({
					expected: origin,
					format: def.format,
					code: "invalid_type",
					continue: false,
					input,
					inst
				});
				return;
			}
			if (!Number.isSafeInteger(input)) {
				if (input > 0) payload.issues.push({
					input,
					code: "too_big",
					maximum: Number.MAX_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				else payload.issues.push({
					input,
					code: "too_small",
					minimum: Number.MIN_SAFE_INTEGER,
					note: "Integers must be within the safe integer range.",
					inst,
					origin,
					inclusive: true,
					continue: !def.abort
				});
				return;
			}
		}
		if (input < minimum) payload.issues.push({
			origin: "number",
			input,
			code: "too_small",
			minimum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
		if (input > maximum) payload.issues.push({
			origin: "number",
			input,
			code: "too_big",
			maximum,
			inclusive: true,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMaxLength = /*@__PURE__*/ $constructor("$ZodCheckMaxLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.onattach.push((inst) => {
		const curr = inst._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
		if (def.maximum < curr) inst._zod.bag.maximum = def.maximum;
	});
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units > def.maximum ? codePointLength(input) : units) <= def.maximum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_big",
			maximum: def.maximum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckMinLength = /*@__PURE__*/ $constructor("$ZodCheckMinLength", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.onattach.push((inst) => {
		const curr = inst._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
		if (def.minimum > curr) inst._zod.bag.minimum = def.minimum;
	});
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		if ((typeof input === "string" && units >= def.minimum && units < def.minimum * 2 ? codePointLength(input) : units) >= def.minimum) return;
		const origin = getLengthableOrigin(input);
		payload.issues.push({
			origin,
			code: "too_small",
			minimum: def.minimum,
			inclusive: true,
			input,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLengthEquals = /*@__PURE__*/ $constructor("$ZodCheckLengthEquals", (inst, def) => {
	var _a;
	$ZodCheck.init(inst, def);
	(_a = inst._zod.def).when ?? (_a.when = _whenHasLength);
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.minimum = def.length;
		bag.maximum = def.length;
		bag.length = def.length;
	});
	inst._zod.check = (payload) => {
		const input = payload.value;
		const units = input.length;
		const length = typeof input === "string" && units >= def.length && units <= def.length * 2 ? codePointLength(input) : units;
		if (length === def.length) return;
		const origin = getLengthableOrigin(input);
		const tooBig = length > def.length;
		payload.issues.push({
			origin,
			...tooBig ? {
				code: "too_big",
				maximum: def.length
			} : {
				code: "too_small",
				minimum: def.length
			},
			inclusive: true,
			exact: true,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStringFormat = /*@__PURE__*/ $constructor("$ZodCheckStringFormat", (inst, def) => {
	var _a, _b;
	$ZodCheck.init(inst, def);
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.format = def.format;
		if (def.pattern) {
			bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
			bag.patterns.add(def.pattern);
		}
	});
	if (def.pattern) (_a = inst._zod).check ?? (_a.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: def.format,
			input: payload.value,
			...def.pattern ? { pattern: def.pattern.toString() } : {},
			inst,
			continue: !def.abort
		});
	});
	else (_b = inst._zod).check ?? (_b.check = () => {});
});
var $ZodCheckRegex = /*@__PURE__*/ $constructor("$ZodCheckRegex", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		def.pattern.lastIndex = 0;
		if (def.pattern.test(payload.value)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "regex",
			input: payload.value,
			pattern: def.pattern.toString(),
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckLowerCase = /*@__PURE__*/ $constructor("$ZodCheckLowerCase", (inst, def) => {
	def.pattern ?? (def.pattern = lowercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckUpperCase = /*@__PURE__*/ $constructor("$ZodCheckUpperCase", (inst, def) => {
	def.pattern ?? (def.pattern = uppercase);
	$ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckIncludes = /*@__PURE__*/ $constructor("$ZodCheckIncludes", (inst, def) => {
	$ZodCheck.init(inst, def);
	const escapedRegex = escapeRegex(def.includes);
	const pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position},}${escapedRegex}` : escapedRegex);
	def.pattern = pattern;
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
		bag.patterns.add(pattern);
	});
	inst._zod.check = (payload) => {
		if (payload.value.includes(def.includes, def.position)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "includes",
			includes: def.includes,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckStartsWith = /*@__PURE__*/ $constructor("$ZodCheckStartsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
		bag.patterns.add(pattern);
	});
	inst._zod.check = (payload) => {
		if (payload.value.startsWith(def.prefix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "starts_with",
			prefix: def.prefix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckEndsWith = /*@__PURE__*/ $constructor("$ZodCheckEndsWith", (inst, def) => {
	$ZodCheck.init(inst, def);
	const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
	def.pattern ?? (def.pattern = pattern);
	inst._zod.onattach.push((inst) => {
		const bag = inst._zod.bag;
		bag.patterns ?? (bag.patterns = /* @__PURE__ */ new Set());
		bag.patterns.add(pattern);
	});
	inst._zod.check = (payload) => {
		if (payload.value.endsWith(def.suffix)) return;
		payload.issues.push({
			origin: "string",
			code: "invalid_format",
			format: "ends_with",
			suffix: def.suffix,
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCheckOverwrite = /*@__PURE__*/ $constructor("$ZodCheckOverwrite", (inst, def) => {
	$ZodCheck.init(inst, def);
	inst._zod.check = (payload) => {
		payload.value = def.tx(payload.value);
	};
});
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/doc.js
var Doc = class {
	constructor(args = [], closed = {}) {
		this.content = [];
		this.indent = 0;
		this.args = args;
		this.closed = closed;
	}
	indented(fn) {
		this.indent += 1;
		fn(this);
		this.indent -= 1;
	}
	write(arg) {
		if (typeof arg === "function") {
			arg(this, { execution: "sync" });
			arg(this, { execution: "async" });
			return;
		}
		const lines = arg.split("\n").filter((x) => x);
		const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
		const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
		for (const line of dedented) this.content.push(line);
	}
	compile() {
		throw new Error("Zod JIT is disabled in extension builds.");
	}
};
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/versions.js
var version = {
	major: 4,
	minor: 5,
	patch: 4
};
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/schemas.js
var $ZodType = /*@__PURE__*/ $constructor("$ZodType", (inst, def) => {
	var _a;
	inst ?? (inst = {});
	inst._zod.def = def;
	inst._zod.bag = inst._zod.bag || {};
	inst._zod.version = version;
	const defChecks = inst._zod.def.checks;
	const checks = inst._zod.traits.has("$ZodCheck") ? [inst, ...defChecks ?? []] : defChecks?.length ? [...defChecks] : [];
	for (const ch of checks) for (const fn of ch._zod.onattach) fn(inst);
	if (checks.length === 0) {
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred?.push(() => {
			inst._zod.run = inst._zod.parse;
		});
	} else {
		const runChecks = (payload, checks, ctx) => {
			if (payload.memo) return payload;
			let isAborted = aborted(payload);
			let asyncResult;
			for (const ch of checks) {
				if (ch._zod.def.when) {
					if (explicitlyAborted(payload)) continue;
					if (!ch._zod.def.when(payload)) continue;
				} else if (isAborted) continue;
				const currLen = payload.issues.length;
				const _ = ch._zod.check(payload);
				if (_ instanceof Promise && ctx?.async === false) throw new $ZodAsyncError();
				if (asyncResult || _ instanceof Promise) asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
					await _;
					if (payload.issues.length === currLen) return;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				});
				else {
					if (payload.issues.length === currLen) continue;
					attachSchema(payload.issues, currLen, inst);
					if (!isAborted) isAborted = aborted(payload, currLen);
				}
			}
			if (asyncResult) return asyncResult.then(() => {
				return payload;
			});
			return payload;
		};
		const handleCanaryResult = (canary, payload, ctx) => {
			if (aborted(canary)) {
				canary.aborted = true;
				return canary;
			}
			const checkResult = runChecks(payload, checks, ctx);
			if (checkResult instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
			}
			return inst._zod.parse(checkResult, ctx);
		};
		inst._zod.run = (payload, ctx) => {
			if (ctx.skipChecks) return inst._zod.parse(payload, ctx);
			if (ctx.direction === "backward") {
				const canary = inst._zod.parse({
					value: payload.value,
					issues: []
				}, {
					...ctx,
					skipChecks: true
				});
				if (canary instanceof Promise) return canary.then((canary) => {
					return handleCanaryResult(canary, payload, ctx);
				});
				return handleCanaryResult(canary, payload, ctx);
			}
			const result = inst._zod.parse(payload, ctx);
			if (result instanceof Promise) {
				if (ctx.async === false) throw new $ZodAsyncError();
				return result.then((result) => runChecks(result, checks, ctx));
			}
			return runChecks(result, checks, ctx);
		};
	}
}, {
	get "~standard"() {
		return hide(this, "~standard", standardProps(this));
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	}
});
/** The Standard Schema surface for `inst`. Shared so wrappers can extend it without forcing it. */
var toStandardResult = (r) => r.success ? { value: r.data } : { issues: r.error?.issues };
function standardProps(inst) {
	return {
		validate: (value) => {
			try {
				return toStandardResult(safeParse$1(inst, value));
			} catch (_) {
				return safeParseAsync$1(inst, value).then(toStandardResult);
			}
		},
		vendor: "zod",
		version: 1
	};
}
var $ZodString = /*@__PURE__*/ $constructor("$ZodString", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = [...inst?._zod.bag?.patterns ?? []].pop() ?? string$1(inst._zod.bag);
	inst._zod.parse = (payload, _) => {
		if (def.coerce) try {
			payload.value = String(payload.value);
		} catch (_) {}
		if (typeof payload.value === "string") return payload;
		payload.issues.push({
			expected: "string",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
var $ZodStringFormat = /*@__PURE__*/ $constructor("$ZodStringFormat", (inst, def) => {
	$ZodCheckStringFormat.init(inst, def);
	$ZodString.init(inst, def);
});
var $ZodGUID = /*@__PURE__*/ $constructor("$ZodGUID", (inst, def) => {
	def.pattern ?? (def.pattern = guid);
	$ZodStringFormat.init(inst, def);
});
var $ZodUUID = /*@__PURE__*/ $constructor("$ZodUUID", (inst, def) => {
	if (def.version) {
		const v = {
			v1: 1,
			v2: 2,
			v3: 3,
			v4: 4,
			v5: 5,
			v6: 6,
			v7: 7,
			v8: 8
		}[def.version];
		if (v === void 0) throw new Error(`Invalid UUID version: "${def.version}"`);
		def.pattern ?? (def.pattern = uuid(v));
	} else def.pattern ?? (def.pattern = uuid());
	$ZodStringFormat.init(inst, def);
});
var $ZodEmail = /*@__PURE__*/ $constructor("$ZodEmail", (inst, def) => {
	def.pattern ?? (def.pattern = email);
	$ZodStringFormat.init(inst, def);
});
/** Parses a URL for `$ZodURL`, applying the one guard the URL constructor cannot express. Returns the parsed URL, or a code naming the stage that rejected it — the runtime needs that distinction to pick an issue note, and compiled code only needs to know it is not a URL. */
function parseURLObject(trimmed, def) {
	if (!def.normalize && def.protocol?.source === httpProtocol.source && !/^https?:\/\//i.test(trimmed)) return 1;
	try {
		return new URL(trimmed);
	} catch {
		return 2;
	}
}
var asciiTabOrNewline = /[\t\n\r]/g;
/** The URL parser deletes every ASCII tab, LF and CR from its input before it parses, so `new URL("https://exa\nmple.com")` reports on `example.com`. Applying the same deletion to the returned value closes the half of that divergence which can move the host; the parser's other rewrite, stripping C0 controls at the edges, cannot. */
function stripTabAndNewline(value) {
	return value.replace(asciiTabOrNewline, "");
}
function urlHostnameOk(url, hostname) {
	hostname.lastIndex = 0;
	return hostname.test(url.hostname);
}
function urlProtocolOk(url, protocol) {
	protocol.lastIndex = 0;
	return protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol);
}
var $ZodURL = /*@__PURE__*/ $constructor("$ZodURL", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		try {
			const trimmed = payload.value.trim();
			const url = parseURLObject(trimmed, def);
			if (url === 1) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					note: "Invalid URL format",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (url === 2) {
				payload.issues.push({
					code: "invalid_format",
					format: "url",
					input: payload.value,
					inst,
					continue: !def.abort
				});
				return;
			}
			if (def.hostname && !urlHostnameOk(url, def.hostname)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid hostname",
				pattern: def.hostname.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			if (def.protocol && !urlProtocolOk(url, def.protocol)) payload.issues.push({
				code: "invalid_format",
				format: "url",
				note: "Invalid protocol",
				pattern: def.protocol.source,
				input: payload.value,
				inst,
				continue: !def.abort
			});
			payload.value = def.normalize ? url.href : stripTabAndNewline(trimmed);
			return;
		} catch (_) {
			payload.issues.push({
				code: "invalid_format",
				format: "url",
				input: payload.value,
				inst,
				continue: !def.abort
			});
		}
	};
});
var $ZodEmoji = /*@__PURE__*/ $constructor("$ZodEmoji", (inst, def) => {
	def.pattern ?? (def.pattern = emoji());
	$ZodStringFormat.init(inst, def);
});
var $ZodNanoID = /*@__PURE__*/ $constructor("$ZodNanoID", (inst, def) => {
	if (def.length !== void 0 && (!Number.isInteger(def.length) || def.length < 1)) throw new Error(`Invalid nanoid length: ${def.length}`);
	def.pattern ?? (def.pattern = def.length === void 0 ? nanoid : nanoidOfLength(def.length));
	$ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link $ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var $ZodCUID = /*@__PURE__*/ $constructor("$ZodCUID", (inst, def) => {
	def.pattern ?? (def.pattern = cuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodCUID2 = /*@__PURE__*/ $constructor("$ZodCUID2", (inst, def) => {
	def.pattern ?? (def.pattern = cuid2);
	$ZodStringFormat.init(inst, def);
});
var $ZodULID = /*@__PURE__*/ $constructor("$ZodULID", (inst, def) => {
	def.pattern ?? (def.pattern = ulid);
	$ZodStringFormat.init(inst, def);
});
var $ZodXID = /*@__PURE__*/ $constructor("$ZodXID", (inst, def) => {
	def.pattern ?? (def.pattern = xid);
	$ZodStringFormat.init(inst, def);
});
var $ZodKSUID = /*@__PURE__*/ $constructor("$ZodKSUID", (inst, def) => {
	def.pattern ?? (def.pattern = ksuid);
	$ZodStringFormat.init(inst, def);
});
var $ZodISODateTime = /*@__PURE__*/ $constructor("$ZodISODateTime", (inst, def) => {
	def.pattern ?? (def.pattern = datetime(def));
	$ZodStringFormat.init(inst, def);
	if (def.local || def.precision === -1) {
		inst._zod.bag.laxFormat = true;
		inst._zod.onattach.push((s) => {
			s._zod.bag.laxFormat = true;
		});
	}
});
var $ZodISODate = /*@__PURE__*/ $constructor("$ZodISODate", (inst, def) => {
	def.pattern ?? (def.pattern = date);
	$ZodStringFormat.init(inst, def);
});
var $ZodISOTime = /*@__PURE__*/ $constructor("$ZodISOTime", (inst, def) => {
	def.pattern ?? (def.pattern = time(def));
	$ZodStringFormat.init(inst, def);
});
var $ZodISODuration = /*@__PURE__*/ $constructor("$ZodISODuration", (inst, def) => {
	def.pattern ?? (def.pattern = duration);
	$ZodStringFormat.init(inst, def);
});
var $ZodIPv4 = /*@__PURE__*/ $constructor("$ZodIPv4", (inst, def) => {
	def.pattern ?? (def.pattern = ipv4);
	$ZodStringFormat.init(inst, def);
	inst._zod.bag.format = `ipv4`;
});
/** An IPv6 address is written with hex digits, colons and dots, and nothing else. The guard is what makes the check below an IPv6 check: `new URL("http://[...]")` parses an authority, not an address, so `@` and `\` re-delimit it and `"::@1\\"` validates against the host `0.0.0.1`. The URL parser also deletes ASCII tab, LF and CR rather than failing, which is how `"::1\n"` validated as `::1`. */
var ipv6Alphabet = /^[0-9a-fA-F:.]+$/;
function isValidIPv6(value) {
	if (!ipv6Alphabet.test(value)) return false;
	try {
		new URL(`http://[${value}]`);
		return true;
	} catch {
		return false;
	}
}
var $ZodIPv6 = /*@__PURE__*/ $constructor("$ZodIPv6", (inst, def) => {
	def.pattern ?? (def.pattern = ipv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.bag.format = `ipv6`;
	inst._zod.check = (payload) => {
		if (!isValidIPv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "ipv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodCIDRv4 = /*@__PURE__*/ $constructor("$ZodCIDRv4", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv4);
	$ZodStringFormat.init(inst, def);
});
function isValidCIDRv6(value) {
	const parts = value.split("/");
	if (parts.length !== 2) return false;
	const [address, prefix] = parts;
	if (!prefix) return false;
	const prefixNum = Number(prefix);
	if (`${prefixNum}` !== prefix) return false;
	if (prefixNum < 0 || prefixNum > 128) return false;
	return isValidIPv6(address);
}
var $ZodCIDRv6 = /*@__PURE__*/ $constructor("$ZodCIDRv6", (inst, def) => {
	def.pattern ?? (def.pattern = cidrv6);
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (!isValidCIDRv6(payload.value)) payload.issues.push({
			code: "invalid_format",
			format: "cidrv6",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
function isValidBase64(data) {
	if (data === "") return true;
	if (/\s/.test(data)) return false;
	if (data.length % 4 !== 0) return false;
	try {
		atob(data);
		return true;
	} catch {
		return false;
	}
}
var $ZodBase64 = /*@__PURE__*/ $constructor("$ZodBase64", (inst, def) => {
	def.pattern ?? (def.pattern = base64);
	$ZodStringFormat.init(inst, def);
	inst._zod.bag.contentEncoding = "base64";
	inst._zod.check = (payload) => {
		if (isValidBase64(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
function isValidBase64URL(data) {
	if (!base64url.test(data)) return false;
	const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
	return isValidBase64(base64.padEnd(Math.ceil(base64.length / 4) * 4, "="));
}
var $ZodBase64URL = /*@__PURE__*/ $constructor("$ZodBase64URL", (inst, def) => {
	def.pattern ?? (def.pattern = base64url);
	$ZodStringFormat.init(inst, def);
	inst._zod.bag.contentEncoding = "base64url";
	inst._zod.check = (payload) => {
		if (isValidBase64URL(payload.value)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "base64url",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodE164 = /*@__PURE__*/ $constructor("$ZodE164", (inst, def) => {
	def.pattern ?? (def.pattern = e164);
	$ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
	try {
		const tokensParts = token.split(".");
		if (tokensParts.length !== 3) return false;
		const [header] = tokensParts;
		if (!header) return false;
		const parsedHeader = JSON.parse(atob(header));
		if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT") return false;
		if (!parsedHeader.alg) return false;
		if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm)) return false;
		return true;
	} catch {
		return false;
	}
}
var $ZodJWT = /*@__PURE__*/ $constructor("$ZodJWT", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	inst._zod.check = (payload) => {
		if (isValidJWT(payload.value, def.alg)) return;
		payload.issues.push({
			code: "invalid_format",
			format: "jwt",
			input: payload.value,
			inst,
			continue: !def.abort
		});
	};
});
var $ZodNumber = /*@__PURE__*/ $constructor("$ZodNumber", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = inst._zod.bag.pattern ?? number$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Number(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) return payload;
		const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? String(input) : void 0 : void 0;
		payload.issues.push({
			expected: "number",
			code: "invalid_type",
			input,
			inst,
			...received ? { received } : {}
		});
		return payload;
	};
});
var $ZodNumberFormat = /*@__PURE__*/ $constructor("$ZodNumberFormat", (inst, def) => {
	$ZodCheckNumberFormat.init(inst, def);
	$ZodNumber.init(inst, def);
});
var $ZodBoolean = /*@__PURE__*/ $constructor("$ZodBoolean", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.pattern = boolean$1;
	inst._zod.parse = (payload, _ctx) => {
		if (def.coerce) try {
			payload.value = Boolean(payload.value);
		} catch (_) {}
		const input = payload.value;
		if (typeof input === "boolean") return payload;
		payload.issues.push({
			expected: "boolean",
			code: "invalid_type",
			input,
			inst
		});
		return payload;
	};
});
var $ZodUnknown = /*@__PURE__*/ $constructor("$ZodUnknown", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload) => payload;
});
var $ZodNever = /*@__PURE__*/ $constructor("$ZodNever", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _ctx) => {
		payload.issues.push({
			expected: "never",
			code: "invalid_type",
			input: payload.value,
			inst
		});
		return payload;
	};
});
function handleArrayResult(result, final, index) {
	if (result.issues.length) final.issues.push(...prefixIssues(index, result.issues));
	final.value[index] = result.value;
}
var $ZodArray = /*@__PURE__*/ $constructor("$ZodArray", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!Array.isArray(input)) {
			payload.issues.push({
				expected: "array",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, Array(input.length), ctx) : Array(input.length);
		const proms = [];
		for (let i = 0; i < input.length; i++) {
			const item = input[i];
			const result = def.element._zod.run({
				value: item,
				issues: []
			}, ctx);
			if (result instanceof Promise) proms.push(result.then((result) => handleArrayResult(result, payload, i)));
			else handleArrayResult(result, payload, i);
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
});
function handlePropertyResult(result, final, key, input, optin, optout) {
	const isPresent = key in input;
	const isOptionalOut = optout === "optional";
	if (!isPresent && isOptionalOut && optin === "optional") return;
	if (result.issues.length) {
		if (optin !== void 0 && isOptionalOut && !isPresent) return;
		final.issues.push(...prefixIssues(key, result.issues));
	}
	if (!isPresent && optin === void 0) {
		if (!result.issues.length) final.issues.push({
			code: "invalid_type",
			expected: "nonoptional",
			input: void 0,
			path: [key]
		});
		return;
	}
	if (result.value === void 0) {
		if (isPresent) final.value[key] = void 0;
	} else final.value[key] = result.value;
}
var NO_SYMBOL_KEYS = [];
function normalizeDef(def) {
	const keys = Object.keys(def.shape);
	const ownSymbols = Object.getOwnPropertySymbols(def.shape);
	const symbolKeys = ownSymbols.length ? ownSymbols : NO_SYMBOL_KEYS;
	const allKeys = symbolKeys.length ? [...keys, ...symbolKeys] : keys;
	for (const k of allKeys) if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) throw new Error(`Invalid element at key "${String(k)}": expected a Zod schema`);
	const okeys = optionalKeys(def.shape);
	return {
		...def,
		allKeys,
		symbolKeys,
		keySet: new Set(keys),
		numKeys: keys.length,
		optionalKeys: new Set(okeys)
	};
}
function handleCatchall(proms, input, payload, ctx, def, inst) {
	const unrecognized = [];
	const keySet = def.keySet;
	const _catchall = def.catchall._zod;
	const t = _catchall.def.type;
	const optin = _catchall.optin;
	const optout = _catchall.optout;
	for (const key in input) {
		if (keySet.has(key)) continue;
		if (key === "__proto__") {
			if (t === "never") unrecognized.push(key);
			continue;
		}
		if (t === "never") {
			unrecognized.push(key);
			continue;
		}
		const r = _catchall.run({
			value: input[key],
			issues: []
		}, ctx);
		if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
		else handlePropertyResult(r, payload, key, input, optin, optout);
	}
	if (unrecognized.length) payload.issues.push({
		code: "unrecognized_keys",
		keys: unrecognized,
		input,
		inst,
		continue: true
	});
	if (!proms.length) return payload;
	return Promise.all(proms).then(() => {
		return payload;
	});
}
var propShapes = /* @__PURE__ */ new WeakMap();
var $ZodObject = /*@__PURE__*/ $constructor("$ZodObject", (inst, def) => {
	$ZodType.init(inst, def);
	if (!Object.getOwnPropertyDescriptor(def, "shape")?.get) {
		const sh = def.shape;
		propShapes.set(def, sh);
		Object.defineProperty(def, "shape", { get: () => {
			const newSh = { ...sh };
			Object.defineProperty(def, "shape", { value: newSh });
			propShapes.set(def, newSh);
			return newSh;
		} });
	}
	const _normalized = cached(() => normalizeDef(def));
	defineLazyInternal(inst, "propValues", (zod) => {
		const shape = zod.def.shape;
		const propValues = {};
		for (const key in shape) {
			const field = shape[key]._zod;
			if (field.values) {
				if (!Object.prototype.hasOwnProperty.call(propValues, key)) assignProp(propValues, key, /* @__PURE__ */ new Set());
				for (const v of field.values) propValues[key].add(v);
				if (field.optin !== void 0) propValues[key].add(void 0);
			}
		}
		return propValues;
	});
	const isObject$1 = isObject;
	const catchall = def.catchall;
	let value;
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$1(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
		const proms = [];
		const shape = value.shape;
		for (const key of value.allKeys) {
			if (key === "__proto__") continue;
			const el = shape[key];
			const optin = el._zod.optin;
			const optout = el._zod.optout;
			const r = el._zod.run({
				value: input[key],
				issues: []
			}, ctx);
			if (r instanceof Promise) proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, optin, optout)));
			else handlePropertyResult(r, payload, key, input, optin, optout);
		}
		if (!catchall) return proms.length ? Promise.all(proms).then(() => payload) : payload;
		return handleCatchall(proms, input, payload, ctx, _normalized.value, inst);
	};
});
var $ZodObjectJIT = /*@__PURE__*/ $constructor("$ZodObjectJIT", (inst, def) => {
	$ZodObject.init(inst, def);
	const superParse = inst._zod.parse;
	const _normalized = cached(() => normalizeDef(def));
	const memo = globalConfig.memoizer;
	const generateFastpass = (shape) => {
		const normalized = _normalized.value;
		const syms = normalized.symbolKeys;
		const doc = new Doc(["payload", "ctx"], {
			shape,
			inst,
			memo,
			syms
		});
		const parseStr = (k) => `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
		const prefixStr = (id, k) => `
          for (let i = 0; i < ${id}.issues.length; i++) {
            const iss = ${id}.issues[i];
            iss.path = iss.path ? [${k}, ...iss.path] : [${k}];
            payload.issues.push(iss);
          }`;
		doc.write(`const input = payload.value;`);
		const ids = Object.create(null);
		let counter = 0;
		for (const key of normalized.allKeys) ids[key] = `key_${counter++}`;
		doc.write(memo ? `const newResult = memo.alloc(inst, payload, {}, ctx);` : `const newResult = {};`);
		for (const key of normalized.allKeys) {
			if (key === "__proto__") continue;
			const id = ids[key];
			const k = typeof key === "symbol" ? `syms[${syms.indexOf(key)}]` : esc(key);
			const isPresent = `${k} in input`;
			const schema = shape[key];
			const optin = schema?._zod?.optin;
			const isOptionalIn = optin !== void 0;
			const isOptionalOut = schema?._zod?.optout === "optional";
			doc.write(`const ${id} = ${parseStr(k)};`);
			if (isOptionalIn && isOptionalOut) {
				const assign = optin === "optional" ? `${id}_present` : `${id}.value !== undefined || ${id}_present`;
				doc.write(`
        const ${id}_present = ${isPresent};
        if (!${id}.issues.length || ${id}_present) {
          if (${id}.issues.length) {${prefixStr(id, k)}
          }

          if (${assign}) {
            newResult[${k}] = ${id}.value;
          }
        }

      `);
			} else if (!isOptionalIn) doc.write(`
        const ${id}_present = ${isPresent};
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
        if (!${id}_present && !${id}.issues.length) {
          payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: undefined,
            path: [${k}]
          });
        }

        if (${id}_present) {
          newResult[${k}] = ${id}.value;
        }

      `);
			else doc.write(`
        if (${id}.issues.length) {${prefixStr(id, k)}
        }
        
        if (${id}.value === undefined) {
          if (${isPresent}) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${id}.value;
        }

      `);
		}
		doc.write(`payload.value = newResult;`);
		doc.write(`return payload;`);
		return doc.compile();
	};
	let fastpass;
	const isObject$2 = isObject;
	const jit = !globalConfig.jitless;
	const fastEnabled = jit && allowsEval.value;
	const catchall = def.catchall;
	let value;
	inst._zod.parse = (payload, ctx) => {
		value ?? (value = _normalized.value);
		const input = payload.value;
		if (!isObject$2(input)) {
			payload.issues.push({
				expected: "object",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
			if (!fastpass) fastpass = generateFastpass(def.shape);
			payload = fastpass(payload, ctx);
			if (!catchall) return payload;
			return handleCatchall([], input, payload, ctx, value, inst);
		}
		return superParse(payload, ctx);
	};
});
function handleUnionResults(results, final, inst, ctx) {
	for (const result of results) if (result.issues.length === 0) {
		final.value = result.value;
		return final;
	}
	const nonaborted = results.filter((r) => !aborted(r));
	if (nonaborted.length === 1) {
		final.value = nonaborted[0].value;
		return nonaborted[0];
	}
	final.issues.push({
		code: "invalid_union",
		input: final.value,
		inst,
		errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
	});
	return final;
}
var $ZodUnion = /*@__PURE__*/ $constructor("$ZodUnion", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.options.some((o) => o._zod.optin === "defaulted") ? "defaulted" : zod.def.options.some((o) => o._zod.optin !== void 0) ? "optional" : void 0);
	defineLazyInternal(inst, "optout", (zod) => zod.def.options.some((o) => o._zod.optout === "optional") ? "optional" : void 0);
	defineLazyInternal(inst, "values", (zod) => {
		if (zod.def.options.every((o) => o._zod.values)) return new Set(zod.def.options.flatMap((option) => Array.from(option._zod.values)));
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		if (zod.def.options.every((o) => o._zod.pattern)) {
			const patterns = zod.def.options.map((o) => o._zod.pattern);
			return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
		}
	});
	const first = def.options.length === 1 ? def.options[0]._zod.run : null;
	inst._zod.parse = (payload, ctx) => {
		if (first) return first(payload, ctx);
		let async = false;
		const results = [];
		for (const option of def.options) {
			const result = option._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) {
				results.push(result);
				async = true;
			} else {
				if (result.issues.length === 0) return result;
				results.push(result);
			}
		}
		if (!async) return handleUnionResults(results, payload, inst, ctx);
		return Promise.all(results).then((results) => {
			return handleUnionResults(results, payload, inst, ctx);
		});
	};
});
var $ZodDiscriminatedUnion = /*@__PURE__*/ $constructor("$ZodDiscriminatedUnion", (inst, def) => {
	def.inclusive = false;
	$ZodUnion.init(inst, def);
	const _super = inst._zod.parse;
	defineLazyInternal(inst, "propValues", (zod) => {
		const propValues = {};
		for (const option of zod.def.options) {
			const pv = option._zod.propValues;
			if (!pv || Object.keys(pv).length === 0) throw new Error(`Invalid discriminated union option at index "${zod.def.options.indexOf(option)}"`);
			for (const [k, v] of Object.entries(pv)) {
				if (!Object.prototype.hasOwnProperty.call(propValues, k)) assignProp(propValues, k, /* @__PURE__ */ new Set());
				for (const val of v) propValues[k].add(val);
			}
		}
		return propValues;
	});
	def.options.forEach((option, i) => {
		const propShape = propShapes.get(option._zod.def);
		if (propShape && !Object.prototype.hasOwnProperty.call(propShape, def.discriminator)) throw new Error(`Invalid discriminated union option at index "${i}"`);
	});
	const disc = cached(() => {
		const opts = def.options;
		const map = /* @__PURE__ */ new Map();
		for (const o of opts) {
			const values = o._zod.propValues?.[def.discriminator];
			if (!values || values.size === 0) throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(o)}"`);
			for (const v of values) {
				if (map.has(v)) throw new Error(`Duplicate discriminator value "${String(v)}"`);
				map.set(v, o);
			}
		}
		return map;
	});
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!isObject(input)) {
			payload.issues.push({
				code: "invalid_type",
				expected: "object",
				input,
				inst
			});
			return payload;
		}
		const opt = disc.value.get(input?.[def.discriminator]);
		if (opt) return opt._zod.run(payload, ctx);
		if (def.unionFallback || ctx.direction === "backward") return _super(payload, ctx);
		payload.issues.push({
			code: "invalid_union",
			errors: [],
			note: "No matching discriminator",
			discriminator: def.discriminator,
			options: Array.from(disc.value.keys()),
			input,
			path: [def.discriminator],
			inst
		});
		return payload;
	};
});
var $ZodIntersection = /*@__PURE__*/ $constructor("$ZodIntersection", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		const left = def.left._zod.run({
			value: input,
			issues: []
		}, ctx);
		const right = def.right._zod.run({
			value: input,
			issues: []
		}, ctx);
		if (left instanceof Promise || right instanceof Promise) return Promise.all([left, right]).then(([left, right]) => {
			return handleIntersectionResults(payload, left, right);
		});
		return handleIntersectionResults(payload, left, right);
	};
});
function mergeValues(a, b) {
	if (a === b) return {
		valid: true,
		data: a
	};
	if (a instanceof Date && b instanceof Date && +a === +b) return {
		valid: true,
		data: a
	};
	if (isPlainObject(a) && isPlainObject(b)) {
		const bKeys = Object.keys(b);
		const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
		const newObj = {
			...a,
			...b
		};
		if (Object.prototype.hasOwnProperty.call(newObj, "__proto__")) delete newObj.__proto__;
		for (const key of sharedKeys) {
			if (key === "__proto__") continue;
			const sharedValue = mergeValues(a[key], b[key]);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
			};
			newObj[key] = sharedValue.data;
		}
		return {
			valid: true,
			data: newObj
		};
	}
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return {
			valid: false,
			mergeErrorPath: []
		};
		const newArray = [];
		for (let index = 0; index < a.length; index++) {
			const itemA = a[index];
			const itemB = b[index];
			const sharedValue = mergeValues(itemA, itemB);
			if (!sharedValue.valid) return {
				valid: false,
				mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
			};
			newArray.push(sharedValue.data);
		}
		return {
			valid: true,
			data: newArray
		};
	}
	return {
		valid: false,
		mergeErrorPath: []
	};
}
function handleIntersectionResults(result, left, right) {
	const unrecKeys = /* @__PURE__ */ new Map();
	let unrecIssue;
	const keyIssues = /* @__PURE__ */ new Map();
	const collect = (iss, side) => {
		let keys;
		if (iss.code === "unrecognized_keys" && !iss.path?.length) {
			unrecIssue ?? (unrecIssue = iss);
			keys = iss.keys;
		} else if (iss.code === "invalid_key" && iss.origin === "record" && iss.path?.length === 1) {
			const k = String(iss.path[0]);
			if (!keyIssues.has(k)) keyIssues.set(k, iss);
			keys = [k];
		} else return false;
		for (const k of keys) {
			if (!unrecKeys.has(k)) unrecKeys.set(k, {});
			unrecKeys.get(k)[side] = true;
		}
		return true;
	};
	for (const iss of left.issues) if (!collect(iss, "l")) result.issues.push(iss);
	for (const iss of right.issues) if (!collect(iss, "r")) result.issues.push(iss);
	const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
	if (bothKeys.length) {
		const aggregated = unrecIssue ? bothKeys.filter((k) => unrecIssue.keys.includes(k)) : [];
		if (aggregated.length) result.issues.push({
			...unrecIssue,
			keys: aggregated
		});
		for (const k of bothKeys) if (!aggregated.includes(k) && keyIssues.has(k)) result.issues.push(keyIssues.get(k));
	}
	const merged = mergeValues(left.value, right.value);
	if (!merged.valid) {
		if (aborted(result)) return result;
		throw new Error(`Unmergable intersection. Error path: ${JSON.stringify(merged.mergeErrorPath)}`);
	}
	result.value = merged.data;
	return result;
}
var $ZodRecord = /*@__PURE__*/ $constructor("$ZodRecord", (inst, def) => {
	$ZodType.init(inst, def);
	const memo = globalConfig.memoizer;
	memo?.attach(inst);
	inst._zod.parse = (payload, ctx) => {
		const input = payload.value;
		if (!isPlainObject(input)) {
			payload.issues.push({
				expected: "record",
				code: "invalid_type",
				input,
				inst
			});
			return payload;
		}
		const proms = [];
		const values = def.keyType._zod.values;
		if (values && !def.partial) {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			const recordKeys = /* @__PURE__ */ new Set();
			for (const key of values) if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
				recordKeys.add(typeof key === "number" ? key.toString() : key);
				if (key === "__proto__") continue;
				const keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (keyResult.issues.length) {
					payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			let unrecognized;
			for (const key in input) if (!recordKeys.has(key)) {
				if (def.mode === "loose") {
					if (key === "__proto__") continue;
					payload.value[key] = input[key];
				} else {
					unrecognized = unrecognized ?? [];
					unrecognized.push(key);
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		} else {
			payload.value = memo ? memo.alloc(inst, payload, {}, ctx) : {};
			let unrecognized;
			for (const key of Reflect.ownKeys(input)) {
				if (key === "__proto__") continue;
				if (!Object.prototype.propertyIsEnumerable.call(input, key)) continue;
				let keyResult = def.keyType._zod.run({
					value: key,
					issues: []
				}, ctx);
				if (keyResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
				if (typeof key === "string" && number$1.test(key) && keyResult.issues.length) {
					const retryResult = def.keyType._zod.run({
						value: Number(key),
						issues: []
					}, ctx);
					if (retryResult instanceof Promise) throw new Error("Async schemas not supported in object keys currently");
					if (retryResult.issues.length === 0) keyResult = retryResult;
				}
				if (keyResult.issues.length) {
					if (def.mode === "loose") payload.value[key] = input[key];
					else if (values) {
						unrecognized = unrecognized ?? [];
						unrecognized.push(key);
					} else payload.issues.push({
						code: "invalid_key",
						origin: "record",
						issues: keyResult.issues.map((iss) => finalizeIssue(iss, ctx, config())),
						input: key,
						path: [key],
						inst
					});
					continue;
				}
				const outKey = keyResult.value;
				if (outKey === "__proto__") continue;
				const result = def.valueType._zod.run({
					value: input[key],
					issues: []
				}, ctx);
				if (result instanceof Promise) proms.push(result.then((result) => {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}));
				else {
					if (result.issues.length) payload.issues.push(...prefixIssues(key, result.issues));
					payload.value[outKey] = result.value;
				}
			}
			if (unrecognized && unrecognized.length > 0) payload.issues.push({
				code: "unrecognized_keys",
				input,
				inst,
				keys: unrecognized,
				continue: true
			});
		}
		if (proms.length) return Promise.all(proms).then(() => payload);
		return payload;
	};
});
var $ZodEnum = /*@__PURE__*/ $constructor("$ZodEnum", (inst, def) => {
	$ZodType.init(inst, def);
	const values = getEnumValues(def.entries);
	const valuesSet = new Set(values);
	inst._zod.values = valuesSet;
	const patternValues = values.filter((k) => propertyKeyTypes.has(typeof k));
	inst._zod.pattern = new RegExp(patternValues.length ? `^(${patternValues.map((o) => escapeRegex(o.toString())).join("|")})$` : "^[^\\s\\S]$");
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (valuesSet.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodLiteral = /*@__PURE__*/ $constructor("$ZodLiteral", (inst, def) => {
	$ZodType.init(inst, def);
	const values = new Set(def.values);
	inst._zod.values = values;
	inst._zod.pattern = new RegExp(def.values.length ? `^(${def.values.map((o) => typeof o === "string" ? escapeRegex(o) : o ? escapeRegex(o.toString()) : String(o)).join("|")})$` : "^[^\\s\\S]$");
	inst._zod.parse = (payload, _ctx) => {
		const input = payload.value;
		if (values.has(input)) return payload;
		payload.issues.push({
			code: "invalid_value",
			values: def.values,
			input,
			inst
		});
		return payload;
	};
});
var $ZodTransform = /*@__PURE__*/ $constructor("$ZodTransform", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "optional";
	globalConfig.memoizer?.guard(inst);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		const _out = def.transform(payload.value, payload);
		if (ctx.async) return (_out instanceof Promise ? _out : Promise.resolve(_out)).then((output) => {
			payload.value = output;
			return payload;
		});
		if (_out instanceof Promise) throw new $ZodAsyncError();
		payload.value = _out;
		return payload;
	};
});
function handleOptionalResult(payload, result) {
	payload.value = result.issues.length ? void 0 : result.value;
	return payload;
}
var $ZodOptional = /*@__PURE__*/ $constructor("$ZodOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	inst._zod.optout = "optional";
	defineLazyInternal(inst, "values", (zod) => {
		const values = zod.def.innerType._zod.values;
		return values ? /* @__PURE__ */ new Set([...values, void 0]) : void 0;
	});
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === void 0) {
			if (def.innerType._zod.optin !== "defaulted") return payload;
			const result = def.innerType._zod.run({
				value: payload.value,
				issues: []
			}, ctx);
			if (result instanceof Promise) return result.then((result) => handleOptionalResult(payload, result));
			return handleOptionalResult(payload, result);
		}
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodExactOptional = /*@__PURE__*/ $constructor("$ZodExactOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "pattern", (zod) => zod.def.innerType._zod.pattern);
	inst._zod.parse = (payload, ctx) => {
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNullable = /*@__PURE__*/ $constructor("$ZodNullable", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "pattern", (zod) => {
		const pattern = zod.def.innerType._zod.pattern;
		return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : void 0;
	});
	defineLazyInternal(inst, "values", (zod) => {
		return zod.def.innerType._zod.values ? /* @__PURE__ */ new Set([...zod.def.innerType._zod.values, null]) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		if (payload.value === null) return payload;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodDefault = /*@__PURE__*/ $constructor("$ZodDefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) {
			payload.value = def.defaultValue;
			/**
			* $ZodDefault returns the default value immediately in forward direction.
			* It doesn't pass the default value into the validator ("prefault"). There's no reason to pass the default value through validation. The validity of the default is enforced by TypeScript statically. Otherwise, it's the responsibility of the user to ensure the default is valid. In the case of pipes with divergent in/out types, you can specify the default on the `in` schema of your ZodPipe to set a "prefault" for the pipe.   */
			return payload;
		}
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleDefaultResult(result, def));
		return handleDefaultResult(result, def);
	};
});
function handleDefaultResult(payload, def) {
	if (payload.value === void 0) payload.value = def.defaultValue;
	return payload;
}
var $ZodPrefault = /*@__PURE__*/ $constructor("$ZodPrefault", (inst, def) => {
	$ZodType.init(inst, def);
	inst._zod.optin = "defaulted";
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		if (payload.value === void 0) payload.value = def.defaultValue;
		return def.innerType._zod.run(payload, ctx);
	};
});
var $ZodNonOptional = /*@__PURE__*/ $constructor("$ZodNonOptional", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => {
		const v = zod.def.innerType._zod.values;
		return v ? new Set([...v].filter((x) => x !== void 0)) : void 0;
	});
	inst._zod.parse = (payload, ctx) => {
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then((result) => handleNonOptionalResult(result, inst));
		return handleNonOptionalResult(result, inst);
	};
});
function handleNonOptionalResult(payload, inst) {
	if (!payload.issues.length && payload.value === void 0) payload.issues.push({
		code: "invalid_type",
		expected: "nonoptional",
		input: payload.value,
		inst
	});
	return payload;
}
function handleCatchResult(payload, result, def, ctx) {
	if (!result.issues.length) {
		payload.value = result.value;
		if (result.memo) payload.memo = true;
		return payload;
	}
	payload.value = def.catchValue({
		...result,
		value: payload.value,
		error: { issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config())) },
		input: payload.value
	});
	return payload;
}
var $ZodCatch = /*@__PURE__*/ $constructor("$ZodCatch", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType._zod.optin === "defaulted" ? "defaulted" : "optional");
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType._zod.optout);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run({
			value: payload.value,
			issues: []
		}, ctx);
		if (result instanceof Promise) return result.then((result) => handleCatchResult(payload, result, def, ctx));
		return handleCatchResult(payload, result, def, ctx);
	};
});
var $ZodPipe = /*@__PURE__*/ $constructor("$ZodPipe", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "values", (zod) => zod.def.in._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.in._zod.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.out._zod.optout);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.in._zod.propValues);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") {
			const right = def.out._zod.run(payload, ctx);
			if (right instanceof Promise) return right.then((right) => handlePipeResult(right, def.in, ctx));
			return handlePipeResult(right, def.in, ctx);
		}
		const left = def.in._zod.run(payload, ctx);
		if (left instanceof Promise) return left.then((left) => handlePipeResult(left, def.out, ctx));
		return handlePipeResult(left, def.out, ctx);
	};
});
function handlePipeResult(left, next, ctx) {
	if (left.issues.some((iss) => iss.code !== "unrecognized_keys")) {
		left.aborted = true;
		return left;
	}
	return next._zod.run({
		value: left.value,
		issues: left.issues
	}, ctx);
}
var $ZodPreprocess = /*@__PURE__*/ $constructor("$ZodPreprocess", (inst, def) => {
	$ZodPipe.init(inst, def);
});
var $ZodReadonly = /*@__PURE__*/ $constructor("$ZodReadonly", (inst, def) => {
	$ZodType.init(inst, def);
	defineLazyInternal(inst, "propValues", (zod) => zod.def.innerType._zod.propValues);
	defineLazyInternal(inst, "values", (zod) => zod.def.innerType._zod.values);
	defineLazyInternal(inst, "optin", (zod) => zod.def.innerType?._zod?.optin);
	defineLazyInternal(inst, "optout", (zod) => zod.def.innerType?._zod?.optout);
	inst._zod.parse = (payload, ctx) => {
		if (ctx.direction === "backward") return def.innerType._zod.run(payload, ctx);
		const result = def.innerType._zod.run(payload, ctx);
		if (result instanceof Promise) return result.then(handleReadonlyResult);
		return handleReadonlyResult(result);
	};
});
function handleReadonlyResult(payload) {
	if (!payload.memo) payload.value = Object.freeze(payload.value);
	return payload;
}
var $ZodCustom = /*@__PURE__*/ $constructor("$ZodCustom", (inst, def) => {
	$ZodCheck.init(inst, def);
	$ZodType.init(inst, def);
	inst._zod.parse = (payload, _) => {
		return payload;
	};
	inst._zod.check = (payload) => {
		const input = payload.value;
		const r = def.fn(input);
		if (r instanceof Promise) return r.then((r) => handleRefineResult(r, payload, input, inst));
		handleRefineResult(r, payload, input, inst);
	};
});
function handleRefineResult(result, payload, input, inst) {
	if (!result) {
		const _iss = {
			code: "custom",
			input,
			inst,
			path: [...inst._zod.def.path ?? []],
			continue: !inst._zod.def.abort
		};
		if (inst._zod.def.params) _iss.params = inst._zod.def.params;
		payload.issues.push(issue(_iss));
	}
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/memoizer.js
var $ZodCyclicError = class extends Error {
	constructor() {
		super(`Cannot parse a reference cycle that closes through a transform`);
		this.name = "ZodCyclicError";
	}
};
/** Keyed off the context object every schema in one parse call already shares. */
var STATE = "~memo";
var NO_ISSUES = [];
function cloneIssues(issues) {
	return issues.map((iss) => iss.path ? {
		...iss,
		path: iss.path.slice()
	} : { ...iss });
}
var recursive = /*@__PURE__*/ new WeakMap();
/** Whether this schema's subtree contains a cycle, so one parse can re-enter it. */
function isRecursive(inst, stack) {
	const cached = recursive.get(inst);
	if (cached !== void 0) return cached;
	if (stack.has(inst)) return true;
	stack.add(inst);
	let result = false;
	const check = (child) => {
		if (!result && child?._zod && isRecursive(child, stack)) result = true;
	};
	const def = inst._zod.def;
	switch (def.type) {
		case "object":
			for (const key of Reflect.ownKeys(def.shape)) check(def.shape[key]);
			check(def.catchall);
			break;
		case "array":
			check(def.element);
			break;
		case "tuple":
			for (const el of def.items) check(el);
			check(def.rest);
			break;
		case "record":
		case "map":
			check(def.keyType);
			check(def.valueType);
			break;
		case "set":
			check(def.valueType);
			break;
		case "union":
			for (const el of def.options) check(el);
			break;
		case "intersection":
			check(def.left);
			check(def.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			check(def.innerType);
			break;
		case "pipe":
			check(def.in);
			check(def.out);
			break;
		case "function":
			check(def.input);
			check(def.output);
			break;
		case "lazy":
			check(inst._zod.innerType);
			break;
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (const key in def) {
			const desc = Object.getOwnPropertyDescriptor(def, key);
			if (!desc || desc.get) continue;
			const value = desc.value;
			if (!value || typeof value !== "object") continue;
			if (value._zod) check(value);
			else if (Array.isArray(value)) for (const el of value) check(el);
		}
	}
	stack.delete(inst);
	recursive.set(inst, result);
	return result;
}
function bucketFor(state, inst) {
	let bucket = state.buckets.get(inst);
	if (!bucket) {
		bucket = /* @__PURE__ */ new Map();
		state.buckets.set(inst, bucket);
	}
	return bucket;
}
var handoff;
var open = [];
var memo = {
	alloc(_inst, payload, empty) {
		const bucket = handoff;
		if (!bucket) return empty;
		handoff = void 0;
		const entry = {
			value: empty,
			issues: null
		};
		bucket.set(payload.value, entry);
		open.push(entry);
		return empty;
	},
	guard(inst) {
		var _a;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value)) throw new $ZodCyclicError();
				return base(payload, ctx);
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	},
	attach(inst) {
		var _a;
		let isRecursiveInst;
		let lastCtx;
		let lastBucket;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (isRecursiveInst === void 0) {
					isRecursiveInst = isRecursive(inst, /* @__PURE__ */ new Set());
					if (!isRecursiveInst) {
						inst._zod.parse = base;
						if (inst._zod.run === wrapped) inst._zod.run = base;
						return base(payload, ctx);
					}
				}
				const input = payload.value;
				if (input === null || typeof input !== "object") return base(payload, ctx);
				let state = ctx[STATE];
				if (!state) {
					state = {
						buckets: /* @__PURE__ */ new Map(),
						backEdges: void 0
					};
					ctx[STATE] = state;
				}
				let bucket;
				if (lastCtx === ctx) bucket = lastBucket;
				else {
					bucket = bucketFor(state, inst);
					lastCtx = ctx;
					lastBucket = bucket;
				}
				const hit = bucket.get(input);
				if (hit) {
					payload.value = hit.value;
					if (hit.issues) {
						if (hit.issues.length) payload.issues.push(...cloneIssues(hit.issues));
					} else {
						payload.memo = true;
						state.backEdges ?? (state.backEdges = /* @__PURE__ */ new Set());
						state.backEdges.add(hit.value);
					}
					return payload;
				}
				handoff = bucket;
				const depth = open.length;
				const result = base(payload, ctx);
				handoff = void 0;
				const entry = open.length > depth ? open.pop() : void 0;
				if (result instanceof Promise) return result.then((r) => {
					if (entry) entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
					return r;
				});
				if (entry) entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
				return result;
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	}
};
/** The memoizer that gives containers cycle support. `zod` installs it by default; `zod/mini` opts in with `config({ memoizer: memoizer() })`. */
function memoizer() {
	return memo;
}
/** Whether this value is a node a back-edge resolved to before it finished. */
function isBackEdge(ctx, value) {
	const backEdges = ctx[STATE]?.backEdges;
	return backEdges !== void 0 && value !== null && typeof value === "object" && backEdges.has(value);
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/locales/en.js
var error = () => {
	const Sizable = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function getSizing(origin) {
		return Sizable[origin] ?? null;
	}
	const FormatDictionary = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		credit_card: "credit card number",
		jwt: "JWT",
		template_literal: "input"
	};
	const TypeDictionary = { nan: "NaN" };
	function getTypeName(type, input) {
		if (type === "number" && typeof input === "number" && !Number.isFinite(input)) return String(input);
		return TypeDictionary[type] ?? type;
	}
	return (issue) => {
		switch (issue.code) {
			case "invalid_type": return `Invalid input: expected ${getTypeName(issue.expected)}, received ${getTypeName(parsedType(issue.input), issue.input)}`;
			case "invalid_value":
				if (issue.values.length === 1) return `Invalid input: expected ${stringifyPrimitive(issue.values[0])}`;
				return `Invalid option: expected one of ${joinValues(issue.values, "|")}`;
			case "too_big": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? "<=" : "<";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
				return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
			}
			case "too_small": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? ">=" : ">";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
				return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
			}
			case "invalid_format": {
				const _issue = issue;
				if (_issue.format === "starts_with") return `Invalid string: must start with "${_issue.prefix}"`;
				if (_issue.format === "ends_with") return `Invalid string: must end with "${_issue.suffix}"`;
				if (_issue.format === "includes") return `Invalid string: must include "${_issue.includes}"`;
				if (_issue.format === "regex") return `Invalid string: must match pattern ${_issue.pattern}`;
				return `Invalid ${FormatDictionary[_issue.format] ?? issue.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${issue.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${joinValues(issue.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${issue.origin}`;
			case "invalid_union":
				if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) return `Invalid discriminator value. Expected ${issue.options.map((o) => `'${o}'`).join(" | ")}`;
				if (issue.inclusive === false) return "Invalid input: more than one option matched";
				return "Invalid input";
			case "invalid_element": return `Invalid value in ${issue.origin}`;
			default: return `Invalid input`;
		}
	};
};
function en_default() {
	return { localeError: error() };
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/registries.js
var _a;
var $ZodRegistry = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
	}
	add(schema, ..._meta) {
		const meta = _meta[0];
		this._map.set(schema, meta);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.set(meta.id, schema);
		return this;
	}
	clear() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
		return this;
	}
	remove(schema) {
		const meta = this._map.get(schema);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.delete(meta.id);
		this._map.delete(schema);
		return this;
	}
	get(schema) {
		const p = schema._zod.parent;
		if (p) {
			const pm = { ...this.get(p) ?? {} };
			delete pm.id;
			const f = {
				...pm,
				...this._map.get(schema)
			};
			return Object.keys(f).length ? f : void 0;
		}
		return this._map.get(schema);
	}
	has(schema) {
		return this._map.has(schema);
	}
};
function registry() {
	return new $ZodRegistry();
}
(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/api.js
// @__NO_SIDE_EFFECTS__
function _string(Class, params) {
	return new Class({
		type: "string",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _email(Class, params) {
	return new Class({
		type: "string",
		format: "email",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _guid(Class, params) {
	return new Class({
		type: "string",
		format: "guid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuid(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv4(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v4",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv6(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v6",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uuidv7(Class, params) {
	return new Class({
		type: "string",
		format: "uuid",
		check: "string_format",
		abort: false,
		version: "v7",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _url(Class, params) {
	return new Class({
		type: "string",
		format: "url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _emoji(Class, params) {
	return new Class({
		type: "string",
		format: "emoji",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _nanoid(Class, params) {
	return new Class({
		type: "string",
		format: "nanoid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link _cuid2} instead.
* See https://github.com/paralleldrive/cuid.
*/
// @__NO_SIDE_EFFECTS__
function _cuid(Class, params) {
	return new Class({
		type: "string",
		format: "cuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cuid2(Class, params) {
	return new Class({
		type: "string",
		format: "cuid2",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ulid(Class, params) {
	return new Class({
		type: "string",
		format: "ulid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _xid(Class, params) {
	return new Class({
		type: "string",
		format: "xid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ksuid(Class, params) {
	return new Class({
		type: "string",
		format: "ksuid",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv4(Class, params) {
	return new Class({
		type: "string",
		format: "ipv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _ipv6(Class, params) {
	return new Class({
		type: "string",
		format: "ipv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv4(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv4",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _cidrv6(Class, params) {
	return new Class({
		type: "string",
		format: "cidrv6",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64(Class, params) {
	return new Class({
		type: "string",
		format: "base64",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _base64url(Class, params) {
	return new Class({
		type: "string",
		format: "base64url",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _e164(Class, params) {
	return new Class({
		type: "string",
		format: "e164",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _jwt(Class, params) {
	return new Class({
		type: "string",
		format: "jwt",
		check: "string_format",
		abort: false,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDateTime(Class, params) {
	return new Class({
		type: "string",
		format: "datetime",
		check: "string_format",
		offset: false,
		local: false,
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDate(Class, params) {
	return new Class({
		type: "string",
		format: "date",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoTime(Class, params) {
	return new Class({
		type: "string",
		format: "time",
		check: "string_format",
		precision: null,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _isoDuration(Class, params) {
	return new Class({
		type: "string",
		format: "duration",
		check: "string_format",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _number(Class, params) {
	return new Class({
		type: "number",
		checks: [],
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _int(Class, params) {
	return new Class({
		type: "number",
		check: "number_format",
		abort: false,
		format: "safeint",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _boolean(Class, params) {
	return new Class({
		type: "boolean",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _unknown(Class) {
	return new Class({ type: "unknown" });
}
// @__NO_SIDE_EFFECTS__
function _never(Class, params) {
	return new Class({
		type: "never",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _lt(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _lte(value, params) {
	return new $ZodCheckLessThan({
		check: "less_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _gt(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: false
	});
}
// @__NO_SIDE_EFFECTS__
function _gte(value, params) {
	return new $ZodCheckGreaterThan({
		check: "greater_than",
		...normalizeParams(params),
		value,
		inclusive: true
	});
}
// @__NO_SIDE_EFFECTS__
function _multipleOf(value, params) {
	return new $ZodCheckMultipleOf({
		check: "multiple_of",
		...normalizeParams(params),
		value
	});
}
// @__NO_SIDE_EFFECTS__
function _maxLength(maximum, params) {
	return new $ZodCheckMaxLength({
		check: "max_length",
		...normalizeParams(params),
		maximum
	});
}
// @__NO_SIDE_EFFECTS__
function _minLength(minimum, params) {
	return new $ZodCheckMinLength({
		check: "min_length",
		...normalizeParams(params),
		minimum
	});
}
// @__NO_SIDE_EFFECTS__
function _length(length, params) {
	return new $ZodCheckLengthEquals({
		check: "length_equals",
		...normalizeParams(params),
		length
	});
}
// @__NO_SIDE_EFFECTS__
function _regex(pattern, params) {
	return new $ZodCheckRegex({
		check: "string_format",
		format: "regex",
		...normalizeParams(params),
		pattern
	});
}
// @__NO_SIDE_EFFECTS__
function _lowercase(params) {
	return new $ZodCheckLowerCase({
		check: "string_format",
		format: "lowercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _uppercase(params) {
	return new $ZodCheckUpperCase({
		check: "string_format",
		format: "uppercase",
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _includes(includes, params) {
	return new $ZodCheckIncludes({
		check: "string_format",
		format: "includes",
		...normalizeParams(params),
		includes
	});
}
// @__NO_SIDE_EFFECTS__
function _startsWith(prefix, params) {
	return new $ZodCheckStartsWith({
		check: "string_format",
		format: "starts_with",
		...normalizeParams(params),
		prefix
	});
}
// @__NO_SIDE_EFFECTS__
function _endsWith(suffix, params) {
	return new $ZodCheckEndsWith({
		check: "string_format",
		format: "ends_with",
		...normalizeParams(params),
		suffix
	});
}
// @__NO_SIDE_EFFECTS__
function _overwrite(tx) {
	return new $ZodCheckOverwrite({
		check: "overwrite",
		tx
	});
}
// @__NO_SIDE_EFFECTS__
function _normalize(form) {
	return /* @__PURE__ */ _overwrite((input) => input.normalize(form));
}
// @__NO_SIDE_EFFECTS__
function _trim() {
	return /* @__PURE__ */ _overwrite((input) => input.trim());
}
// @__NO_SIDE_EFFECTS__
function _toLowerCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toLowerCase());
}
// @__NO_SIDE_EFFECTS__
function _toUpperCase() {
	return /* @__PURE__ */ _overwrite((input) => input.toUpperCase());
}
// @__NO_SIDE_EFFECTS__
function _slugify() {
	return /* @__PURE__ */ _overwrite((input) => slugify(input));
}
// @__NO_SIDE_EFFECTS__
function _array(Class, element, params) {
	return new Class({
		type: "array",
		element,
		...normalizeParams(params)
	});
}
// @__NO_SIDE_EFFECTS__
function _refine(Class, fn, _params) {
	return new Class({
		type: "custom",
		check: "custom",
		fn,
		...normalizeParams(_params)
	});
}
// @__NO_SIDE_EFFECTS__
function _superRefine(fn, params) {
	const ch = /* @__PURE__ */ _check((payload) => {
		payload.addIssue = (issue$2) => {
			if (typeof issue$2 === "string") payload.issues.push(issue(issue$2, payload.value, ch._zod.def));
			else {
				const _issue = issue$2;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = ch);
				_issue.continue ?? (_issue.continue = !ch._zod.def.abort);
				payload.issues.push(issue(_issue));
			}
		};
		return fn(payload.value, payload);
	}, params);
	return ch;
}
// @__NO_SIDE_EFFECTS__
function _check(fn, params) {
	const ch = new $ZodCheck({
		check: "custom",
		...normalizeParams(params)
	});
	ch._zod.check = fn;
	return ch;
}
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/to-json-schema.js
function assignProps(target, ...sources) {
	for (const source of sources) for (const key of Reflect.ownKeys(source)) if (Object.prototype.propertyIsEnumerable.call(source, key)) assignProp(target, key, source[key]);
	return target;
}
function initializeContext(params) {
	let target = params?.target ?? "draft-2020-12";
	if (target === "draft-4") target = "draft-04";
	if (target === "draft-7") target = "draft-07";
	return {
		processors: params.processors ?? {},
		metadataRegistry: params?.metadata ?? globalRegistry,
		target,
		unrepresentable: params?.unrepresentable ?? "throw",
		override: params?.override ?? (() => {}),
		io: params?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: params?.cycles ?? "ref",
		reused: params?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: params?.external ?? void 0
	};
}
/**
* Applies the `unrepresentable` setting at a site that has no JSON Schema equivalent. Throws
* `message` unless the setting (or the handler's return value) says otherwise. Returns `true` if a
* custom JSON Schema was written into `json`, in which case the caller must not write its own.
*/
function handleUnrepresentable(schema, ctx, json, params, message) {
	const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({
		zodSchema: schema,
		path: params.path,
		message
	}) : ctx.unrepresentable;
	if (result === "any") return false;
	if (result === void 0 || result === "throw") throw new Error(message);
	Object.assign(json, result);
	return true;
}
function process(schema, ctx, _params = {
	path: [],
	schemaPath: []
}) {
	var _a;
	const def = schema._zod.def;
	const seen = ctx.seen.get(schema);
	if (seen) {
		seen.count++;
		if (_params.schemaPath.includes(schema)) seen.cycle = _params.path;
		return seen.schema;
	}
	const result = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: _params.path
	};
	ctx.seen.set(schema, result);
	ctx.sharedDefsExtractedFor = void 0;
	ctx.sharedEmitDoneFor = void 0;
	const overrideSchema = schema._zod.toJSONSchema?.();
	if (overrideSchema) result.schema = overrideSchema;
	else {
		const params = {
			..._params,
			schemaPath: [..._params.schemaPath, schema],
			path: _params.path
		};
		if (schema._zod.processJSONSchema) schema._zod.processJSONSchema(ctx, result.schema, params);
		else {
			const _json = result.schema;
			const processor = ctx.processors[def.type];
			if (!processor) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
			processor(schema, ctx, _json, params);
		}
		const parent = schema._zod.parent;
		if (parent) {
			if (!result.ref) result.ref = parent;
			process(parent, ctx, params);
			ctx.seen.get(parent).isParent = true;
		}
	}
	const meta = ctx.metadataRegistry.get(schema);
	if (meta) assignProps(result.schema, meta);
	if (ctx.io === "input" && isTransforming(schema)) {
		delete result.schema.examples;
		delete result.schema.default;
	}
	if (ctx.io === "input" && "_prefault" in result.schema) (_a = result.schema).default ?? (_a.default = result.schema._prefault);
	delete result.schema._prefault;
	return ctx.seen.get(schema).schema;
}
function encodeJSONPointerSegment(segment) {
	return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function extractDefs(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external) return;
	const idToSchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.entries()) {
		const id = ctx.metadataRegistry.get(entry[0])?.id;
		if (id) {
			const existing = idToSchema.get(id);
			if (existing && existing !== entry[0]) throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			idToSchema.set(id, entry[0]);
		}
	}
	const makeURI = (entry) => {
		const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
		if (ctx.external) {
			const externalId = ctx.external.registry.get(entry[0])?.id;
			const uriGenerator = ctx.external.uri ?? ((id) => id);
			if (externalId) return { ref: uriGenerator(externalId) };
			const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
			entry[1].defId = id;
			return {
				defId: id,
				ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id)}`
			};
		}
		const uriPrefix = `#`;
		const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
		if (entry[1] === root && !entry[1].schema.id) return { ref: uriPrefix };
		const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
		return {
			defId,
			ref: defUriPrefix + encodeJSONPointerSegment(defId)
		};
	};
	const extractToDef = (entry) => {
		if (entry[1].schema.$ref) return;
		const seen = entry[1];
		const { ref, defId } = makeURI(entry);
		seen.def = { ...seen.schema };
		if (defId) seen.defId = defId;
		const schema = seen.schema;
		for (const key in schema) delete schema[key];
		schema.$ref = ref;
	};
	if (ctx.cycles === "throw") for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.cycle) throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (schema === entry[0]) {
			extractToDef(entry);
			continue;
		}
		if (ctx.external) {
			const ext = ctx.external.registry.get(entry[0])?.id;
			if (schema !== entry[0] && ext) {
				extractToDef(entry);
				continue;
			}
		}
		if (ctx.metadataRegistry.get(entry[0])?.id) {
			extractToDef(entry);
			continue;
		}
		if (seen.cycle) {
			extractToDef(entry);
			continue;
		}
		if (seen.count > 1) {
			if (ctx.reused === "ref") {
				extractToDef(entry);
				continue;
			}
		}
	}
	if (ctx.external) ctx.sharedDefsExtractedFor = ctx.external;
}
/** Rewrites `anyOf: [{type: "a"}, {type: "b"}]` to `type: ["a", "b"]`, which every JSON Schema draft treats as equivalent and most consumers render far better for the nullable case. Only branches that are a bare type assertion qualify — anything carrying a constraint, `$ref`, `const` or metadata is left alone. Runs after `flattenRef`, so a branch an override decorated or `$defs` extraction turned into a `$ref` is no longer bare and correctly stays in `anyOf`. `oneOf` is excluded: `integer` and `number` overlap, so "exactly one" and "at least one" are not the same there. OpenAPI 3.0 is excluded: its `type` must be a single string. */
function compactTypeUnion(schema) {
	const options = schema.anyOf;
	if (!Array.isArray(options) || options.length === 0 || schema.type !== void 0) return;
	const types = [];
	for (const option of options) {
		if (!option || typeof option !== "object") return;
		compactTypeUnion(option);
		const keys = Object.keys(option);
		if (keys.length !== 1 || keys[0] !== "type") return;
		const type = option.type;
		for (const member of Array.isArray(type) ? type : [type]) {
			if (typeof member !== "string") return;
			if (!types.includes(member)) types.push(member);
		}
	}
	delete schema.anyOf;
	schema.type = types.length === 1 ? types[0] : types;
}
/** Keywords `foldIntersection` knows how to combine. Anything else — `$ref`, `patternProperties`,
* an annotation like `description` — makes a member unfoldable, so a constraint this does not
* understand leaves the `allOf` alone instead of being silently dropped or misattributed. */
var FOLDABLE_KEYS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]);
var UNION_KEYS = ["oneOf", "anyOf"];
/** A member's constraint on a key it does not declare itself. A `catchall` states one; `false`, an absent `additionalProperties`, and the empty schema a loose object emits state nothing. */
function undeclaredConstraint(member) {
	const extra = member.additionalProperties;
	if (extra === void 0 || extra === false || typeof extra !== "object" || extra === null) return null;
	return Object.keys(extra).length ? extra : null;
}
/** Combines object members into the single object they describe together, or returns `null` if any of them carries a keyword outside {@link FOLDABLE_KEYS}. */
function foldObjects(members) {
	const objects = [];
	for (const member of members) {
		if (typeof member !== "object" || member.type !== "object") return null;
		for (const key in member) if (!FOLDABLE_KEYS.has(key)) return null;
		objects.push(member);
	}
	const properties = {};
	const required = /* @__PURE__ */ new Set();
	for (const object of objects) {
		for (const key in object.properties) {
			if (Object.prototype.hasOwnProperty.call(properties, key)) continue;
			const parts = [];
			for (const other of objects) {
				const part = other.properties?.[key] ?? undeclaredConstraint(other);
				if (part === null || part === void 0) continue;
				if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part))) parts.push(part);
			}
			assignProp(properties, key, parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts });
		}
		for (const key of object.required ?? []) required.add(key);
	}
	const folded = {
		type: "object",
		properties
	};
	if (required.size) folded.required = [...required];
	if (objects.every((object) => object.additionalProperties === false)) folded.additionalProperties = false;
	else {
		const constraints = [];
		for (const object of objects) {
			const constraint = undeclaredConstraint(object);
			if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint))) constraints.push(constraint);
		}
		if (constraints.length === 1) folded.additionalProperties = constraints[0];
		else if (constraints.length > 1) folded.additionalProperties = { allOf: constraints };
	}
	return folded;
}
/** `additionalProperties` in an `allOf` member sees only that member's own `properties`, so two
* closed object members reject each other's keys and the schema validates nothing. Zod's parser
* pools the key sets instead — `handleIntersectionResults` reports a key as unrecognized only when
* *every* side rejects it — so the emitted schema has to pool them too, and folding the members
* into one object is the encoding that says so on every target.
*
* This runs from `finalize`, after `extractDefs`, which is what keeps it clear of the `$ref`
* machinery: a member extracted into `$defs` is already a `$ref` by now and declines to fold, so it
* keeps its reference and its own closedness rather than being inlined as a stale copy. */
function foldIntersection(json) {
	const allOf = json.allOf;
	if (!Array.isArray(allOf) || allOf.length < 2) return;
	for (const key of FOLDABLE_KEYS) if (key in json) return;
	const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
	let folded = null;
	if (!unions.length) folded = foldObjects(allOf);
	else {
		const union = unions[0];
		const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));
		if (Object.keys(union).length !== 1) return;
		const rest = allOf.filter((m) => m !== union);
		const branches = union[keyword].map((branch) => foldObjects([...rest, branch]));
		if (branches.some((b) => !b)) return;
		folded = { [keyword]: branches };
	}
	if (!folded) return;
	delete json.allOf;
	assignProps(json, folded);
}
function finalize(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	const flattenRef = (zodSchema) => {
		const seen = ctx.seen.get(zodSchema);
		if (seen.ref === null) return;
		const schema = seen.def ?? seen.schema;
		const _cached = { ...schema };
		const ref = seen.ref;
		seen.ref = null;
		if (ref) {
			flattenRef(ref);
			const refSeen = ctx.seen.get(ref);
			const refSchema = refSeen.schema;
			if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
				schema.allOf = schema.allOf ?? [];
				schema.allOf.push(refSchema);
			} else assignProps(schema, refSchema);
			assignProps(schema, _cached);
			if (zodSchema._zod.parent === ref) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (!(key in _cached)) delete schema[key];
			}
			if (refSchema.$ref && refSeen.def) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) delete schema[key];
			}
		}
		const parent = zodSchema._zod.parent;
		if (parent && parent !== ref) {
			flattenRef(parent);
			const parentSeen = ctx.seen.get(parent);
			if (parentSeen?.schema.$ref) {
				schema.$ref = parentSeen.schema.$ref;
				if (parentSeen.def) for (const key in schema) {
					if (key === "$ref" || key === "allOf") continue;
					if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) delete schema[key];
				}
			}
		}
		ctx.override({
			zodSchema,
			jsonSchema: schema,
			path: seen.path ?? []
		});
	};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
		for (const entry of [...ctx.seen.entries()].reverse()) flattenRef(entry[0]);
		if (ctx.target !== "openapi-3.0") for (const entry of ctx.seen.entries()) compactTypeUnion(entry[1].def ?? entry[1].schema);
		for (const rewrite of ctx.deferred) rewrite();
		if (ctx.intersections.length) {
			const carriers = /* @__PURE__ */ new Map();
			for (const seen of ctx.seen.values()) for (const json of [seen.schema, seen.def]) {
				const allOf = json?.allOf;
				if (!Array.isArray(allOf)) continue;
				const existing = carriers.get(allOf);
				if (existing) existing.push(json);
				else carriers.set(allOf, [json]);
			}
			for (const allOf of ctx.intersections) for (const json of carriers.get(allOf) ?? []) foldIntersection(json);
		}
	}
	const result = {};
	if (ctx.target === "draft-2020-12") result.$schema = "https://json-schema.org/draft/2020-12/schema";
	else if (ctx.target === "draft-07") result.$schema = "http://json-schema.org/draft-07/schema#";
	else if (ctx.target === "draft-04") result.$schema = "http://json-schema.org/draft-04/schema#";
	else if (ctx.target === "openapi-3.0") {}
	if (ctx.external?.uri) {
		const id = ctx.external.registry.get(schema)?.id;
		if (!id) throw new Error("Schema is missing an `id` property");
		result.$id = ctx.external.uri(id);
	}
	assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
	const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
	if (rootMetaId !== void 0 && result.id === rootMetaId) delete result.id;
	const defs = ctx.external?.defs ?? {};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.def && seen.defId) {
			if (seen.def.id === seen.defId) delete seen.def.id;
			assignProp(defs, seen.defId, seen.def);
		}
	}
	if (ctx.external) ctx.sharedEmitDoneFor = ctx.external;
	if (ctx.external) {} else if (Object.keys(defs).length > 0) {
		if (ctx.target === "draft-2020-12") result.$defs = defs;
		else result.definitions = defs;
	}
	try {
		const finalized = JSON.parse(JSON.stringify(result));
		Object.defineProperty(finalized, "~standard", {
			value: {
				...schema["~standard"],
				jsonSchema: {
					input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
					output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
				}
			},
			enumerable: false,
			writable: false
		});
		return finalized;
	} catch (_err) {
		throw new Error("Error converting schema to JSON.");
	}
}
function isTransforming(_schema, _ctx) {
	const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
	if (ctx.seen.has(_schema)) return false;
	ctx.seen.add(_schema);
	const def = _schema._zod.def;
	if (def.type === "transform") return true;
	if (def.type === "array") return isTransforming(def.element, ctx);
	if (def.type === "set") return isTransforming(def.valueType, ctx);
	if (def.type === "lazy") return isTransforming(def.getter(), ctx);
	if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") return isTransforming(def.innerType, ctx);
	if (def.type === "intersection") return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
	if (def.type === "record" || def.type === "map") return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
	if (def.type === "pipe") {
		if (_schema._zod.traits.has("$ZodCodec")) return true;
		return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
	}
	if (def.type === "object") {
		for (const key in def.shape) if (isTransforming(def.shape[key], ctx)) return true;
		return false;
	}
	if (def.type === "union") {
		for (const option of def.options) if (isTransforming(option, ctx)) return true;
		return false;
	}
	if (def.type === "tuple") {
		for (const item of def.items) if (isTransforming(item, ctx)) return true;
		if (def.rest && isTransforming(def.rest, ctx)) return true;
		return false;
	}
	return false;
}
/**
* Creates a toJSONSchema method for a schema instance.
* This encapsulates the logic of initializing context, processing, extracting defs, and finalizing.
*/
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
	const ctx = initializeContext({
		...params,
		processors
	});
	process(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
	const { libraryOptions, target } = params ?? {};
	const ctx = initializeContext({
		...libraryOptions ?? {},
		target,
		io,
		processors
	});
	process(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/core/json-schema-processors.js
var formatMap = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
};
var stringProcessor = (schema, ctx, _json, _params) => {
	const json = _json;
	json.type = "string";
	const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = schema._zod.bag;
	if (typeof minimum === "number") json.minLength = minimum;
	if (typeof maximum === "number") json.maxLength = maximum;
	if (format) {
		json.format = formatMap[format] ?? format;
		if (json.format === "") delete json.format;
		if (format === "time" || laxFormat) delete json.format;
	}
	if (contentEncoding) json.contentEncoding = contentEncoding;
	if (patterns && patterns.size > 0) {
		const patternList = [...patterns];
		if (patternList.length === 1) json.pattern = patternList[0].source;
		else if (patternList.length > 1) json.allOf = [...patternList.map((regex) => ({
			...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: regex.source
		}))];
	}
};
var numberProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const { minimum, maximum, format, multipleOf, exclusiveMaximum, exclusiveMinimum } = schema._zod.bag;
	if (typeof format === "string" && format.includes("int")) json.type = "integer";
	else json.type = "number";
	const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
	const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
	const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
	if (exMin) {
		if (legacy) {
			json.minimum = exclusiveMinimum;
			json.exclusiveMinimum = true;
		} else json.exclusiveMinimum = exclusiveMinimum;
	} else if (typeof minimum === "number") json.minimum = minimum;
	if (exMax) {
		if (legacy) {
			json.maximum = exclusiveMaximum;
			json.exclusiveMaximum = true;
		} else json.exclusiveMaximum = exclusiveMaximum;
	} else if (typeof maximum === "number") json.maximum = maximum;
	if (typeof multipleOf === "number") {
		if (Number.isFinite(multipleOf) && multipleOf !== 0) json.multipleOf = Math.abs(multipleOf);
		else handleUnrepresentable(schema, ctx, json, params, `A multipleOf divisor of ${multipleOf} cannot be represented in JSON Schema`);
	}
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
	json.type = "boolean";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
	json.not = {};
};
var enumProcessor = (schema, _ctx, json, _params) => {
	const def = schema._zod.def;
	const values = getEnumValues(def.entries);
	if (values.length === 0) {
		json.not = {};
		return;
	}
	if (values.every((v) => typeof v === "number")) json.type = "number";
	if (values.every((v) => typeof v === "string")) json.type = "string";
	json.enum = values;
};
var literalProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	if (def.values.length === 0) {
		json.not = {};
		return;
	}
	const vals = [];
	for (const val of def.values) if (val === void 0) {
		if (handleUnrepresentable(schema, ctx, json, params, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof val === "bigint") {
		if (handleUnrepresentable(schema, ctx, json, params, "BigInt literals cannot be represented in JSON Schema")) return;
		vals.push(Number(val));
	} else vals.push(val);
	if (vals.length === 0) {} else if (vals.length === 1) {
		const val = vals[0];
		json.type = val === null ? "null" : typeof val;
		if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") json.enum = [val];
		else json.const = val;
	} else {
		if (vals.every((v) => typeof v === "number")) json.type = "number";
		if (vals.every((v) => typeof v === "string")) json.type = "string";
		if (vals.every((v) => typeof v === "boolean")) json.type = "boolean";
		if (vals.every((v) => v === null)) json.type = "null";
		json.enum = vals;
	}
};
var customProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Custom types cannot be represented in JSON Schema");
};
var transformProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Transforms cannot be represented in JSON Schema");
};
var arrayProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const { minimum, maximum } = schema._zod.bag;
	if (typeof minimum === "number") json.minItems = minimum;
	if (typeof maximum === "number") json.maxItems = maximum;
	json.type = "array";
	json.items = process(def.element, ctx, {
		...params,
		path: [...params.path, "items"]
	});
};
function inputOptin(schema) {
	const def = schema._zod.def;
	if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) return inputOptin(def.out);
	if (def.type === "catch") return inputOptin(def.innerType);
	return schema._zod.optin;
}
var objectProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const shape = def.shape;
	if (Object.getOwnPropertySymbols(shape).length && handleUnrepresentable(schema, ctx, json, params, "Symbol keys cannot be represented in JSON Schema")) return;
	json.type = "object";
	json.properties = {};
	for (const key in shape) assignProp(json.properties, key, process(shape[key], ctx, {
		...params,
		path: [
			...params.path,
			"properties",
			key
		]
	}));
	const allKeys = new Set(Object.keys(shape));
	const requiredKeys = new Set([...allKeys].filter((key) => {
		const field = def.shape[key];
		if (ctx.io === "input") return inputOptin(field) === void 0;
		else return field._zod.optout === void 0;
	}));
	if (requiredKeys.size > 0) json.required = Array.from(requiredKeys);
	if (def.catchall?._zod.def.type === "never") json.additionalProperties = false;
	else if (!def.catchall) {
		if (ctx.io === "output") json.additionalProperties = false;
	} else if (def.catchall) json.additionalProperties = process(def.catchall, ctx, {
		...params,
		path: [...params.path, "additionalProperties"]
	});
};
var unionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const isExclusive = def.inclusive === false;
	const options = def.options.map((x, i) => process(x, ctx, {
		...params,
		path: [
			...params.path,
			isExclusive ? "oneOf" : "anyOf",
			i
		]
	}));
	if (isExclusive) json.oneOf = options;
	else json.anyOf = options;
};
var intersectionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const a = process(def.left, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			0
		]
	});
	const b = process(def.right, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			1
		]
	});
	const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
	const allOf = [...isSimpleIntersection(a) ? a.allOf : [a], ...isSimpleIntersection(b) ? b.allOf : [b]];
	json.allOf = allOf;
	ctx.intersections.push(allOf);
};
/** JSON object keys are always strings, so a numeric record key schema is re-expressed over the
* numeric-string form the record parser matches. Deferred to `finalize`, after the flatten: a key
* behind a wrapper only carries its own `type` before then, and a union key only has its branches.
*
* A numeric bound cannot apply to a property name, so `minimum` and its siblings are dropped rather
* than carried over: keeping them beside `type: "string"` reproduces the match-nothing schema this
* exists to fix. A key that carries one therefore emits wider than the record parses — `z.record(z.number().min(5), V)`
* accepts `"3"` — which is the deliberate trade, since throwing on it would reject an ordinary schema
* outright. */
function stringifyKeyNames(bySchema, json, visited) {
	if (json.$ref) {
		if (visited.has(json)) return json;
		visited.add(json);
		const def = bySchema.get(json)?.def;
		if (!def) return json;
		const inlined = stringifyKeyNames(bySchema, def, visited);
		return inlined === def ? json : inlined;
	}
	for (const keyword of ["anyOf", "oneOf"]) {
		const branches = json[keyword];
		if (!Array.isArray(branches)) continue;
		const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
		if (mapped.some((branch, i) => branch !== branches[i])) json = {
			...json,
			[keyword]: mapped
		};
	}
	const types = Array.isArray(json.type) ? json.type : [json.type];
	const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
	const values = json.enum ?? (json.const !== void 0 ? [json.const] : void 0);
	if (!numericType && !values?.some((v) => typeof v === "number")) return json;
	const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id, ...rest } = json;
	if (rest.enum) rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
	else if (typeof rest.const === "number") rest.const = String(rest.const);
	if (!numericType) return rest;
	rest.type = "string";
	if (!values) rest.pattern = (types.includes("number") ? number$1 : integer).source;
	return rest;
}
/** Every record of one conversion, so the carriers are found in a single pass rather than once per record. */
var pendingRecords = /* @__PURE__ */ new WeakMap();
function rewriteKeyNames(ctx) {
	const bySchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.values()) if (entry.def && !bySchema.has(entry.schema)) bySchema.set(entry.schema, entry);
	const rewrites = /* @__PURE__ */ new Map();
	for (const record of pendingRecords.get(ctx) ?? []) {
		const seen = ctx.seen.get(record);
		const names = (seen?.def ?? seen?.schema)?.propertyNames;
		if (!names || names === true || rewrites.has(names)) continue;
		const rewritten = stringifyKeyNames(bySchema, names, /* @__PURE__ */ new Set());
		if (rewritten !== names) rewrites.set(names, rewritten);
	}
	if (!rewrites.size) return;
	for (const entry of ctx.seen.values()) for (const carrier of [entry.schema, entry.def]) {
		const rewritten = carrier && rewrites.get(carrier.propertyNames);
		if (rewritten) carrier.propertyNames = rewritten;
	}
}
var recordProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	json.type = "object";
	const keyType = def.keyType;
	const patterns = keyType._zod.bag?.patterns;
	if (def.mode === "loose" && patterns && patterns.size > 0) {
		const valueSchema = process(def.valueType, ctx, {
			...params,
			path: [
				...params.path,
				"patternProperties",
				"*"
			]
		});
		json.patternProperties = {};
		for (const pattern of patterns) assignProp(json.patternProperties, pattern.source, valueSchema);
	} else {
		if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
			json.propertyNames = process(def.keyType, ctx, {
				...params,
				path: [...params.path, "propertyNames"]
			});
			let pending = pendingRecords.get(ctx);
			if (!pending) {
				pending = [];
				pendingRecords.set(ctx, pending);
				ctx.deferred.push(() => rewriteKeyNames(ctx));
			}
			pending.push(schema);
		}
		json.additionalProperties = process(def.valueType, ctx, {
			...params,
			path: [...params.path, "additionalProperties"]
		});
	}
	const keyValues = keyType._zod.values;
	const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== void 0;
	if (keyValues && !def.partial && !omittableOnInput) {
		const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
		if (validKeyValues.length > 0) json.required = validKeyValues.map(String);
	}
};
var nullableProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const inner = process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	if (ctx.target === "openapi-3.0") {
		seen.ref = def.innerType;
		json.nullable = true;
	} else json.anyOf = [inner, { type: "null" }];
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
/** Round-trips a default value through JSON so the emitted schema is guaranteed to be valid JSON.
* A BigInt has no reliable encoding, so it goes through `unrepresentable` like any other
* unrepresentable value. Returns a sentinel when the caller must not write a default of its own. */
var UNREPRESENTABLE_DEFAULT = Symbol();
function serializeDefaultValue(value, schema, ctx, json, params) {
	let unrepresentable = false;
	const serialized = JSON.stringify(value, (_, val) => {
		if (typeof val !== "bigint") return val;
		unrepresentable = true;
		return null;
	});
	if (!unrepresentable) return JSON.parse(serialized);
	handleUnrepresentable(schema, ctx, json, params, "BigInt defaults cannot be represented in JSON Schema");
	return UNREPRESENTABLE_DEFAULT;
}
var defaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json.default = value;
};
var prefaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	if (ctx.io !== "input") return;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json._prefault = value;
};
var catchProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	let catchValue;
	try {
		catchValue = def.catchValue(void 0);
	} catch {
		handleUnrepresentable(schema, ctx, json, params, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	const inIsTransform = def.in._zod.traits.has("$ZodTransform");
	const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
	process(innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	process(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/errors.js
var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _lazyMethod(proto, key, make) {
	Object.defineProperty(proto, key, {
		configurable: true,
		enumerable: false,
		get() {
			const value = make(this);
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
			return value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
		}
	});
}
var initializer = (inst, issues) => {
	$ZodError.init(inst, issues);
	inst.name = "ZodError";
	const proto = Object.getPrototypeOf(inst);
	if (_installedErrorProtos.has(proto)) return;
	_installedErrorProtos.add(proto);
	_lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
	_lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
	_lazyMethod(proto, "addIssue", (self) => (issue) => {
		self.issues.push(issue);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	_lazyMethod(proto, "addIssues", (self) => (issues) => {
		self.issues.push(...issues);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	Object.defineProperty(proto, "isEmpty", {
		configurable: true,
		enumerable: false,
		get() {
			return this.issues.length === 0;
		}
	});
};
var ZodRealError = /*@__PURE__*/ $constructor("ZodError", initializer, void 0, { Parent: Error });
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/parse.js
var parse = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);
//#endregion
//#region node_modules/.pnpm/zod@4.5.4/node_modules/zod/v4/classic/schemas.js
function _ensureDefaultLocale() {
	if (!globalConfig.localeError) config(en_default());
}
function _ensureDefaultMemoizer() {
	if (!globalConfig.memoizer) config({ memoizer: memoizer() });
}
var ZodType = /*@__PURE__*/ $constructor("ZodType", (inst, def) => {
	_ensureDefaultLocale();
	$ZodType.init(inst, def);
	inst.def = def;
	inst.type = def.type;
	return inst;
}, {
	check(...chks) {
		const def = this.def;
		return this.clone(mergeDefs(def, { checks: [...def.checks ?? [], ...chks.map((ch) => typeof ch === "function" ? { _zod: {
			check: ch,
			def: { check: "custom" },
			onattach: []
		} } : ch)] }), { parent: true });
	},
	with(...chks) {
		return this.check(...chks);
	},
	clone(def, params) {
		return clone(this, def, params);
	},
	brand() {
		return this;
	},
	register(reg, meta) {
		reg.add(this, meta);
		return this;
	},
	refine(check, params) {
		return this.check(refine(check, params));
	},
	superRefine(refinement, params) {
		return this.check(superRefine(refinement, params));
	},
	overwrite(fn) {
		return this.check(/* @__PURE__ */ _overwrite(fn));
	},
	optional() {
		return optional(this);
	},
	exactOptional() {
		return exactOptional(this);
	},
	nullable() {
		return nullable(this);
	},
	nullish() {
		return optional(nullable(this));
	},
	nonoptional(params) {
		return nonoptional(this, params);
	},
	array() {
		return array(this);
	},
	or(arg) {
		return union([this, arg]);
	},
	and(arg) {
		return intersection(this, arg);
	},
	transform(tx) {
		return pipe(this, transform(tx));
	},
	default(d) {
		return _default(this, d);
	},
	prefault(d) {
		return prefault(this, d);
	},
	catch(params) {
		return _catch(this, params);
	},
	pipe(target) {
		return pipe(this, target);
	},
	readonly() {
		return readonly(this);
	},
	describe(description) {
		const cl = this.clone();
		globalRegistry.add(cl, { description });
		return cl;
	},
	meta(...args) {
		if (args.length === 0) return globalRegistry.get(this);
		const cl = this.clone();
		globalRegistry.add(cl, args[0]);
		return cl;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(fn, ...args) {
		return args.length === 0 ? fn(this) : fn(this, ...args);
	},
	get "~standard"() {
		return hide(this, "~standard", {
			...standardProps(this),
			jsonSchema: {
				input: createStandardJSONSchemaMethod(this, "input"),
				output: createStandardJSONSchemaMethod(this, "output")
			}
		});
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	},
	parse: function _parse(data, params) {
		return parse(this, data, params, { callee: _parse });
	},
	parseAsync: async function _parseAsync(data, params) {
		return await parseAsync(this, data, params, { callee: _parseAsync });
	},
	safeParse(data, params) {
		return safeParse(this, data, params);
	},
	async safeParseAsync(data, params) {
		return safeParseAsync(this, data, params);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(value) {
		own(this, "spa", value);
	},
	encode: function _encode(data, params) {
		return encode(this, data, params, { callee: _encode });
	},
	decode: function _decode(data, params) {
		return decode(this, data, params, { callee: _decode });
	},
	encodeAsync: async function _encodeAsync(data, params) {
		return await encodeAsync(this, data, params, { callee: _encodeAsync });
	},
	decodeAsync: async function _decodeAsync(data, params) {
		return await decodeAsync(this, data, params, { callee: _decodeAsync });
	},
	safeEncode(data, params) {
		return safeEncode(this, data, params);
	},
	safeDecode(data, params) {
		return safeDecode(this, data, params);
	},
	async safeEncodeAsync(data, params) {
		return safeEncodeAsync(this, data, params);
	},
	async safeDecodeAsync(data, params) {
		return safeDecodeAsync(this, data, params);
	},
	toJSONSchema(params) {
		return createToJSONSchemaMethod(this, {})(params);
	},
	get description() {
		return globalRegistry.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
});
/** @internal */
var _ZodString = /*@__PURE__*/ $constructor("_ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
	const bag = inst._zod.bag;
	inst.format = bag.format ?? null;
	inst.minLength = bag.minimum ?? null;
	inst.maxLength = bag.maximum ?? null;
}, {
	regex(...args) {
		return this.check(/* @__PURE__ */ _regex(...args));
	},
	includes(...args) {
		return this.check(/* @__PURE__ */ _includes(...args));
	},
	startsWith(...args) {
		return this.check(/* @__PURE__ */ _startsWith(...args));
	},
	endsWith(...args) {
		return this.check(/* @__PURE__ */ _endsWith(...args));
	},
	min(...args) {
		return this.check(/* @__PURE__ */ _minLength(...args));
	},
	max(...args) {
		return this.check(/* @__PURE__ */ _maxLength(...args));
	},
	length(...args) {
		return this.check(/* @__PURE__ */ _length(...args));
	},
	nonempty(...args) {
		return this.check(/* @__PURE__ */ _minLength(1, ...args));
	},
	lowercase(params) {
		return this.check(/* @__PURE__ */ _lowercase(params));
	},
	uppercase(params) {
		return this.check(/* @__PURE__ */ _uppercase(params));
	},
	trim() {
		return this.check(/* @__PURE__ */ _trim());
	},
	normalize(...args) {
		return this.check(/* @__PURE__ */ _normalize(...args));
	},
	toLowerCase() {
		return this.check(/* @__PURE__ */ _toLowerCase());
	},
	toUpperCase() {
		return this.check(/* @__PURE__ */ _toUpperCase());
	},
	slugify() {
		return this.check(/* @__PURE__ */ _slugify());
	}
});
var ZodString = /*@__PURE__*/ $constructor("ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	_ZodString.init(inst, def);
}, {
	email(params) {
		return this.check(/* @__PURE__ */ _email(ZodEmail, params));
	},
	url(params) {
		return this.check(/* @__PURE__ */ _url(ZodURL, params));
	},
	jwt(params) {
		return this.check(/* @__PURE__ */ _jwt(ZodJWT, params));
	},
	emoji(params) {
		return this.check(/* @__PURE__ */ _emoji(ZodEmoji, params));
	},
	guid(params) {
		return this.check(/* @__PURE__ */ _guid(ZodGUID, params));
	},
	uuid(params) {
		return this.check(/* @__PURE__ */ _uuid(ZodUUID, params));
	},
	uuidv4(params) {
		return this.check(/* @__PURE__ */ _uuidv4(ZodUUID, params));
	},
	uuidv6(params) {
		return this.check(/* @__PURE__ */ _uuidv6(ZodUUID, params));
	},
	uuidv7(params) {
		return this.check(/* @__PURE__ */ _uuidv7(ZodUUID, params));
	},
	nanoid(params) {
		return this.check(/* @__PURE__ */ _nanoid(ZodNanoID, params));
	},
	cuid(params) {
		return this.check(/* @__PURE__ */ _cuid(ZodCUID, params));
	},
	cuid2(params) {
		return this.check(/* @__PURE__ */ _cuid2(ZodCUID2, params));
	},
	ulid(params) {
		return this.check(/* @__PURE__ */ _ulid(ZodULID, params));
	},
	base64(params) {
		return this.check(/* @__PURE__ */ _base64(ZodBase64, params));
	},
	base64url(params) {
		return this.check(/* @__PURE__ */ _base64url(ZodBase64URL, params));
	},
	xid(params) {
		return this.check(/* @__PURE__ */ _xid(ZodXID, params));
	},
	ksuid(params) {
		return this.check(/* @__PURE__ */ _ksuid(ZodKSUID, params));
	},
	ipv4(params) {
		return this.check(/* @__PURE__ */ _ipv4(ZodIPv4, params));
	},
	ipv6(params) {
		return this.check(/* @__PURE__ */ _ipv6(ZodIPv6, params));
	},
	cidrv4(params) {
		return this.check(/* @__PURE__ */ _cidrv4(ZodCIDRv4, params));
	},
	cidrv6(params) {
		return this.check(/* @__PURE__ */ _cidrv6(ZodCIDRv6, params));
	},
	e164(params) {
		return this.check(/* @__PURE__ */ _e164(ZodE164, params));
	},
	datetime(params) {
		return this.check(/* @__PURE__ */ _isoDateTime(ZodISODateTime, params));
	},
	date(params) {
		return this.check(/* @__PURE__ */ _isoDate(ZodISODate, params));
	},
	time(params) {
		return this.check(/* @__PURE__ */ _isoTime(ZodISOTime, params));
	},
	duration(params) {
		return this.check(/* @__PURE__ */ _isoDuration(ZodISODuration, params));
	}
});
function string(params) {
	return /* @__PURE__ */ _string(ZodString, params);
}
var ZodStringFormat = /*@__PURE__*/ $constructor("ZodStringFormat", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	_ZodString.init(inst, def);
});
var ZodISODateTime = /*@__PURE__*/ $constructor("ZodISODateTime", (inst, def) => {
	$ZodISODateTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODate = /*@__PURE__*/ $constructor("ZodISODate", (inst, def) => {
	$ZodISODate.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISOTime = /*@__PURE__*/ $constructor("ZodISOTime", (inst, def) => {
	$ZodISOTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODuration = /*@__PURE__*/ $constructor("ZodISODuration", (inst, def) => {
	$ZodISODuration.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmail = /*@__PURE__*/ $constructor("ZodEmail", (inst, def) => {
	$ZodEmail.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodGUID = /*@__PURE__*/ $constructor("ZodGUID", (inst, def) => {
	$ZodGUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodUUID = /*@__PURE__*/ $constructor("ZodUUID", (inst, def) => {
	$ZodUUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodURL = /*@__PURE__*/ $constructor("ZodURL", (inst, def) => {
	$ZodURL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
function httpUrl(params) {
	return /* @__PURE__ */ _url(ZodURL, {
		protocol: httpProtocol,
		hostname: domain,
		...normalizeParams(params)
	});
}
var ZodEmoji = /*@__PURE__*/ $constructor("ZodEmoji", (inst, def) => {
	$ZodEmoji.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNanoID = /*@__PURE__*/ $constructor("ZodNanoID", (inst, def) => {
	$ZodNanoID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var ZodCUID = /*@__PURE__*/ $constructor("ZodCUID", (inst, def) => {
	$ZodCUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /*@__PURE__*/ $constructor("ZodCUID2", (inst, def) => {
	$ZodCUID2.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodULID = /*@__PURE__*/ $constructor("ZodULID", (inst, def) => {
	$ZodULID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodXID = /*@__PURE__*/ $constructor("ZodXID", (inst, def) => {
	$ZodXID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodKSUID = /*@__PURE__*/ $constructor("ZodKSUID", (inst, def) => {
	$ZodKSUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /*@__PURE__*/ $constructor("ZodIPv4", (inst, def) => {
	$ZodIPv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /*@__PURE__*/ $constructor("ZodIPv6", (inst, def) => {
	$ZodIPv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /*@__PURE__*/ $constructor("ZodCIDRv4", (inst, def) => {
	$ZodCIDRv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /*@__PURE__*/ $constructor("ZodCIDRv6", (inst, def) => {
	$ZodCIDRv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64 = /*@__PURE__*/ $constructor("ZodBase64", (inst, def) => {
	$ZodBase64.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /*@__PURE__*/ $constructor("ZodBase64URL", (inst, def) => {
	$ZodBase64URL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodE164 = /*@__PURE__*/ $constructor("ZodE164", (inst, def) => {
	$ZodE164.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodJWT = /*@__PURE__*/ $constructor("ZodJWT", (inst, def) => {
	$ZodJWT.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNumber = /*@__PURE__*/ $constructor("ZodNumber", (inst, def) => {
	$ZodNumber.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
	const bag = inst._zod.bag;
	inst.minValue = Math.max(bag.minimum ?? Number.NEGATIVE_INFINITY, bag.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null;
	inst.maxValue = Math.min(bag.maximum ?? Number.POSITIVE_INFINITY, bag.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null;
	inst.isInt = (bag.format ?? "").includes("int") || Number.isSafeInteger(bag.multipleOf ?? .5);
	inst.isFinite = true;
	inst.format = bag.format ?? null;
}, {
	gt(value, params) {
		return this.check(/* @__PURE__ */ _gt(value, params));
	},
	gte(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	min(value, params) {
		return this.check(/* @__PURE__ */ _gte(value, params));
	},
	lt(value, params) {
		return this.check(/* @__PURE__ */ _lt(value, params));
	},
	lte(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	max(value, params) {
		return this.check(/* @__PURE__ */ _lte(value, params));
	},
	int(params) {
		return this.check(int(params));
	},
	safe(params) {
		return this.check(int(params));
	},
	positive(params) {
		return this.check(/* @__PURE__ */ _gt(0, params));
	},
	nonnegative(params) {
		return this.check(/* @__PURE__ */ _gte(0, params));
	},
	negative(params) {
		return this.check(/* @__PURE__ */ _lt(0, params));
	},
	nonpositive(params) {
		return this.check(/* @__PURE__ */ _lte(0, params));
	},
	multipleOf(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	step(value, params) {
		return this.check(/* @__PURE__ */ _multipleOf(value, params));
	},
	finite() {
		return this;
	}
});
function number(params) {
	return /* @__PURE__ */ _number(ZodNumber, params);
}
var ZodNumberFormat = /*@__PURE__*/ $constructor("ZodNumberFormat", (inst, def) => {
	$ZodNumberFormat.init(inst, def);
	ZodNumber.init(inst, def);
});
function int(params) {
	return /* @__PURE__ */ _int(ZodNumberFormat, params);
}
var ZodBoolean = /*@__PURE__*/ $constructor("ZodBoolean", (inst, def) => {
	$ZodBoolean.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean(params) {
	return /* @__PURE__ */ _boolean(ZodBoolean, params);
}
var ZodUnknown = /*@__PURE__*/ $constructor("ZodUnknown", (inst, def) => {
	$ZodUnknown.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => void 0;
});
function unknown() {
	return /* @__PURE__ */ _unknown(ZodUnknown);
}
var ZodNever = /*@__PURE__*/ $constructor("ZodNever", (inst, def) => {
	$ZodNever.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
	return /* @__PURE__ */ _never(ZodNever, params);
}
var ZodArray = /*@__PURE__*/ $constructor("ZodArray", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodArray.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
	inst.element = def.element;
}, {
	min(n, params) {
		return this.check(/* @__PURE__ */ _minLength(n, params));
	},
	nonempty(params) {
		return this.check(/* @__PURE__ */ _minLength(1, params));
	},
	max(n, params) {
		return this.check(/* @__PURE__ */ _maxLength(n, params));
	},
	length(n, params) {
		return this.check(/* @__PURE__ */ _length(n, params));
	},
	unwrap() {
		return this.element;
	}
});
function array(element, params) {
	return /* @__PURE__ */ _array(ZodArray, element, params);
}
var ZodObject = /*@__PURE__*/ $constructor("ZodObject", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodObjectJIT.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
	installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
}, {
	keyof() {
		return _enum(Object.keys(this._zod.def.shape));
	},
	catchall(catchall) {
		return this.clone({
			...this._zod.def,
			catchall
		});
	},
	passthrough() {
		return this.clone({
			...this._zod.def,
			catchall: unknown()
		});
	},
	loose() {
		return this.clone({
			...this._zod.def,
			catchall: unknown()
		});
	},
	strict() {
		return this.clone({
			...this._zod.def,
			catchall: never()
		});
	},
	strip() {
		return this.clone({
			...this._zod.def,
			catchall: void 0
		});
	},
	extend(incoming) {
		return extend(this, incoming);
	},
	safeExtend(incoming) {
		return safeExtend(this, incoming);
	},
	merge(other) {
		return merge(this, other);
	},
	pick(mask) {
		return pick(this, mask);
	},
	omit(mask) {
		return omit(this, mask);
	},
	partial(...args) {
		return partial(ZodOptional, this, args[0]);
	},
	exactPartial(...args) {
		return partial(ZodExactOptional, this, args[0], "exactPartial");
	},
	required(...args) {
		return required(ZodNonOptional, this, args[0]);
	}
});
function object(shape, params) {
	return new ZodObject({
		type: "object",
		shape: shape ?? {},
		...normalizeParams(params)
	});
}
function strictObject(shape, params) {
	return new ZodObject({
		type: "object",
		shape,
		catchall: never(),
		...normalizeParams(params)
	});
}
var ZodUnion = /*@__PURE__*/ $constructor("ZodUnion", (inst, def) => {
	$ZodUnion.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
	inst.options = def.options;
});
function union(options, params) {
	return new ZodUnion({
		type: "union",
		options,
		...normalizeParams(params)
	});
}
var ZodDiscriminatedUnion = /*@__PURE__*/ $constructor("ZodDiscriminatedUnion", (inst, def) => {
	ZodUnion.init(inst, def);
	$ZodDiscriminatedUnion.init(inst, def);
});
function discriminatedUnion(discriminator, options, params) {
	return new ZodDiscriminatedUnion({
		type: "union",
		options,
		discriminator,
		...normalizeParams(params)
	});
}
var ZodIntersection = /*@__PURE__*/ $constructor("ZodIntersection", (inst, def) => {
	$ZodIntersection.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
	return new ZodIntersection({
		type: "intersection",
		left,
		right
	});
}
var ZodRecord = /*@__PURE__*/ $constructor("ZodRecord", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodRecord.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
	inst.keyType = def.keyType;
	inst.valueType = def.valueType;
});
function record(keyType, valueType, params) {
	if (!valueType || !valueType._zod) return new ZodRecord({
		type: "record",
		keyType: string(),
		valueType: keyType,
		...normalizeParams(valueType)
	});
	return new ZodRecord({
		type: "record",
		keyType,
		valueType,
		...normalizeParams(params)
	});
}
var ZodEnum = /*@__PURE__*/ $constructor("ZodEnum", (inst, def) => {
	$ZodEnum.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
	inst.enum = def.entries;
	inst.options = Object.values(def.entries);
	const keys = new Set(Object.keys(def.entries));
	inst.extract = (values, params) => {
		const newEntries = {};
		for (const value of values) if (keys.has(value)) newEntries[value] = def.entries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
	inst.exclude = (values, params) => {
		const newEntries = { ...def.entries };
		for (const value of values) if (keys.has(value)) delete newEntries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
});
function _enum(values, params) {
	return new ZodEnum({
		type: "enum",
		entries: Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values,
		...normalizeParams(params)
	});
}
var ZodLiteral = /*@__PURE__*/ $constructor("ZodLiteral", (inst, def) => {
	$ZodLiteral.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
	inst.values = new Set(def.values);
	Object.defineProperty(inst, "value", { get() {
		if (def.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return def.values[0];
	} });
});
function literal(value, params) {
	return new ZodLiteral({
		type: "literal",
		values: Array.isArray(value) ? value : [value],
		...normalizeParams(params)
	});
}
var ZodTransform = /*@__PURE__*/ $constructor("ZodTransform", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodTransform.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
	inst._zod.parse = (payload, _ctx) => {
		if (_ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		payload.addIssue = (issue$1) => {
			if (typeof issue$1 === "string") payload.issues.push(issue(issue$1, payload.value, def));
			else {
				const _issue = issue$1;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = inst);
				payload.issues.push(issue(_issue));
			}
		};
		const output = def.transform(payload.value, payload);
		if (output instanceof Promise) return output.then((output) => {
			payload.value = output;
			return payload;
		});
		payload.value = output;
		return payload;
	};
});
function transform(fn) {
	return new ZodTransform({
		type: "transform",
		transform: fn
	});
}
var ZodOptional = /*@__PURE__*/ $constructor("ZodOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
	return new ZodOptional({
		type: "optional",
		innerType
	});
}
var ZodExactOptional = /*@__PURE__*/ $constructor("ZodExactOptional", (inst, def) => {
	$ZodExactOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
	return new ZodExactOptional({
		type: "optional",
		innerType
	});
}
var ZodNullable = /*@__PURE__*/ $constructor("ZodNullable", (inst, def) => {
	$ZodNullable.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
	return new ZodNullable({
		type: "nullable",
		innerType
	});
}
var ZodDefault = /*@__PURE__*/ $constructor("ZodDefault", (inst, def) => {
	$ZodDefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
	return new ZodDefault({
		type: "default",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodPrefault = /*@__PURE__*/ $constructor("ZodPrefault", (inst, def) => {
	$ZodPrefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
	return new ZodPrefault({
		type: "prefault",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodNonOptional = /*@__PURE__*/ $constructor("ZodNonOptional", (inst, def) => {
	$ZodNonOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
	return new ZodNonOptional({
		type: "nonoptional",
		innerType,
		...normalizeParams(params)
	});
}
var ZodCatch = /*@__PURE__*/ $constructor("ZodCatch", (inst, def) => {
	$ZodCatch.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
	return new ZodCatch({
		type: "catch",
		innerType,
		catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
	});
}
var ZodPipe = /*@__PURE__*/ $constructor("ZodPipe", (inst, def) => {
	$ZodPipe.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
	inst.in = def.in;
	inst.out = def.out;
});
function pipe(in_, out) {
	return new ZodPipe({
		type: "pipe",
		in: in_,
		out
	});
}
var ZodPreprocess = /*@__PURE__*/ $constructor("ZodPreprocess", (inst, def) => {
	ZodPipe.init(inst, def);
	$ZodPreprocess.init(inst, def);
});
var ZodReadonly = /*@__PURE__*/ $constructor("ZodReadonly", (inst, def) => {
	$ZodReadonly.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
	return new ZodReadonly({
		type: "readonly",
		innerType
	});
}
var ZodCustom = /*@__PURE__*/ $constructor("ZodCustom", (inst, def) => {
	$ZodCustom.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function refine(fn, _params = {}) {
	return /* @__PURE__ */ _refine(ZodCustom, fn, _params);
}
function superRefine(fn, params) {
	return /* @__PURE__ */ _superRefine(fn, params);
}
function preprocess(fn, schema) {
	return new ZodPreprocess({
		type: "pipe",
		in: transform(fn),
		out: schema
	});
}
//#endregion
//#region src/shared/supportedLocales.ts
/** Canonical BCP 47 tags shared by storage, settings, and i18next. */
var SUPPORTED_LOCALES = [
	"en-US",
	"de",
	"es",
	"fr",
	"hi",
	"id",
	"it",
	"ja",
	"ko",
	"pt-BR",
	"ru",
	"th",
	"tr",
	"vi",
	"zh-CN",
	"zh-TW"
];
var LOCALE_NAMES = {
	"en-US": "English",
	de: "Deutsch",
	es: "Español",
	fr: "Français",
	hi: "हिन्दी",
	id: "Bahasa Indonesia",
	it: "Italiano",
	ja: "日本語",
	ko: "한국어",
	"pt-BR": "Português (Brasil)",
	ru: "Русский",
	th: "ไทย",
	tr: "Türkçe",
	vi: "Tiếng Việt",
	"zh-CN": "简体中文",
	"zh-TW": "繁體中文"
};
function isSupportedLocale(value) {
	return SUPPORTED_LOCALES.some((locale) => locale === value);
}
function resolveLocale(language) {
	const parts = language.toLowerCase().replaceAll("_", "-").split("-");
	const base = parts[0];
	if (base === "zh") {
		if (parts.includes("hans")) return "zh-CN";
		if (parts.includes("hant")) return "zh-TW";
		return parts.some((part) => [
			"tw",
			"hk",
			"mo"
		].includes(part)) ? "zh-TW" : "zh-CN";
	}
	if (base === "pt") return "pt-BR";
	if (isSupportedLocale(base)) return base;
	return "en-US";
}
//#endregion
//#region src/shared/browser.ts
var import_browser_polyfill = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	(function(global, factory) {
		if (typeof define === "function" && define.amd) define("webextension-polyfill", ["module"], factory);
		else if (typeof exports !== "undefined") factory(module);
		else {
			var mod = { exports: {} };
			factory(mod);
			global.browser = mod.exports;
		}
	})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module$1) {
		"use strict";
		if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) throw new Error("This script should only be loaded in a browser extension.");
		if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
			const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
			const wrapAPIs = (extensionAPIs) => {
				const apiMetadata = {
					"alarms": {
						"clear": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"clearAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"get": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"getAll": {
							"minArgs": 0,
							"maxArgs": 0
						}
					},
					"bookmarks": {
						"create": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"get": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getChildren": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getRecent": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getSubTree": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getTree": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"move": {
							"minArgs": 2,
							"maxArgs": 2
						},
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeTree": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"search": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"update": {
							"minArgs": 2,
							"maxArgs": 2
						}
					},
					"browserAction": {
						"disable": {
							"minArgs": 0,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"enable": {
							"minArgs": 0,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"getBadgeBackgroundColor": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getBadgeText": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getPopup": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getTitle": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"openPopup": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"setBadgeBackgroundColor": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"setBadgeText": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"setIcon": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"setPopup": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"setTitle": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						}
					},
					"browsingData": {
						"remove": {
							"minArgs": 2,
							"maxArgs": 2
						},
						"removeCache": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeCookies": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeDownloads": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeFormData": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeHistory": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeLocalStorage": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removePasswords": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removePluginData": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"settings": {
							"minArgs": 0,
							"maxArgs": 0
						}
					},
					"commands": { "getAll": {
						"minArgs": 0,
						"maxArgs": 0
					} },
					"contextMenus": {
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"update": {
							"minArgs": 2,
							"maxArgs": 2
						}
					},
					"cookies": {
						"get": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getAll": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getAllCookieStores": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"set": {
							"minArgs": 1,
							"maxArgs": 1
						}
					},
					"devtools": {
						"inspectedWindow": { "eval": {
							"minArgs": 1,
							"maxArgs": 2,
							"singleCallbackArg": false
						} },
						"panels": {
							"create": {
								"minArgs": 3,
								"maxArgs": 3,
								"singleCallbackArg": true
							},
							"elements": { "createSidebarPane": {
								"minArgs": 1,
								"maxArgs": 1
							} }
						}
					},
					"downloads": {
						"cancel": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"download": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"erase": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getFileIcon": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"open": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"pause": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeFile": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"resume": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"search": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"show": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						}
					},
					"extension": {
						"isAllowedFileSchemeAccess": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"isAllowedIncognitoAccess": {
							"minArgs": 0,
							"maxArgs": 0
						}
					},
					"history": {
						"addUrl": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"deleteAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"deleteRange": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"deleteUrl": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getVisits": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"search": {
							"minArgs": 1,
							"maxArgs": 1
						}
					},
					"i18n": {
						"detectLanguage": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getAcceptLanguages": {
							"minArgs": 0,
							"maxArgs": 0
						}
					},
					"identity": { "launchWebAuthFlow": {
						"minArgs": 1,
						"maxArgs": 1
					} },
					"idle": { "queryState": {
						"minArgs": 1,
						"maxArgs": 1
					} },
					"management": {
						"get": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"getSelf": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"setEnabled": {
							"minArgs": 2,
							"maxArgs": 2
						},
						"uninstallSelf": {
							"minArgs": 0,
							"maxArgs": 1
						}
					},
					"notifications": {
						"clear": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"create": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"getAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"getPermissionLevel": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"update": {
							"minArgs": 2,
							"maxArgs": 2
						}
					},
					"pageAction": {
						"getPopup": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getTitle": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"hide": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"setIcon": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"setPopup": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"setTitle": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						},
						"show": {
							"minArgs": 1,
							"maxArgs": 1,
							"fallbackToNoCallback": true
						}
					},
					"permissions": {
						"contains": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getAll": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"request": {
							"minArgs": 1,
							"maxArgs": 1
						}
					},
					"runtime": {
						"getBackgroundPage": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"getPlatformInfo": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"openOptionsPage": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"requestUpdateCheck": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"sendMessage": {
							"minArgs": 1,
							"maxArgs": 3
						},
						"sendNativeMessage": {
							"minArgs": 2,
							"maxArgs": 2
						},
						"setUninstallURL": {
							"minArgs": 1,
							"maxArgs": 1
						}
					},
					"sessions": {
						"getDevices": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"getRecentlyClosed": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"restore": {
							"minArgs": 0,
							"maxArgs": 1
						}
					},
					"storage": {
						"local": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getBytesInUse": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						},
						"managed": {
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getBytesInUse": {
								"minArgs": 0,
								"maxArgs": 1
							}
						},
						"sync": {
							"clear": {
								"minArgs": 0,
								"maxArgs": 0
							},
							"get": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"getBytesInUse": {
								"minArgs": 0,
								"maxArgs": 1
							},
							"remove": {
								"minArgs": 1,
								"maxArgs": 1
							},
							"set": {
								"minArgs": 1,
								"maxArgs": 1
							}
						}
					},
					"tabs": {
						"captureVisibleTab": {
							"minArgs": 0,
							"maxArgs": 2
						},
						"create": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"detectLanguage": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"discard": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"duplicate": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"executeScript": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"get": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getCurrent": {
							"minArgs": 0,
							"maxArgs": 0
						},
						"getZoom": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"getZoomSettings": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"goBack": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"goForward": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"highlight": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"insertCSS": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"move": {
							"minArgs": 2,
							"maxArgs": 2
						},
						"query": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"reload": {
							"minArgs": 0,
							"maxArgs": 2
						},
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"removeCSS": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"sendMessage": {
							"minArgs": 2,
							"maxArgs": 3
						},
						"setZoom": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"setZoomSettings": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"update": {
							"minArgs": 1,
							"maxArgs": 2
						}
					},
					"topSites": { "get": {
						"minArgs": 0,
						"maxArgs": 0
					} },
					"webNavigation": {
						"getAllFrames": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"getFrame": {
							"minArgs": 1,
							"maxArgs": 1
						}
					},
					"webRequest": { "handlerBehaviorChanged": {
						"minArgs": 0,
						"maxArgs": 0
					} },
					"windows": {
						"create": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"get": {
							"minArgs": 1,
							"maxArgs": 2
						},
						"getAll": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"getCurrent": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"getLastFocused": {
							"minArgs": 0,
							"maxArgs": 1
						},
						"remove": {
							"minArgs": 1,
							"maxArgs": 1
						},
						"update": {
							"minArgs": 2,
							"maxArgs": 2
						}
					}
				};
				if (Object.keys(apiMetadata).length === 0) throw new Error("api-metadata.json has not been included in browser-polyfill");
				/**
				* A WeakMap subclass which creates and stores a value for any key which does
				* not exist when accessed, but behaves exactly as an ordinary WeakMap
				* otherwise.
				*
				* @param {function} createItem
				*        A function which will be called in order to create the value for any
				*        key which does not exist, the first time it is accessed. The
				*        function receives, as its only argument, the key being created.
				*/
				class DefaultWeakMap extends WeakMap {
					constructor(createItem, items = void 0) {
						super(items);
						this.createItem = createItem;
					}
					get(key) {
						if (!this.has(key)) this.set(key, this.createItem(key));
						return super.get(key);
					}
				}
				/**
				* Returns true if the given object is an object with a `then` method, and can
				* therefore be assumed to behave as a Promise.
				*
				* @param {*} value The value to test.
				* @returns {boolean} True if the value is thenable.
				*/
				const isThenable = (value) => {
					return value && typeof value === "object" && typeof value.then === "function";
				};
				/**
				* Creates and returns a function which, when called, will resolve or reject
				* the given promise based on how it is called:
				*
				* - If, when called, `chrome.runtime.lastError` contains a non-null object,
				*   the promise is rejected with that value.
				* - If the function is called with exactly one argument, the promise is
				*   resolved to that value.
				* - Otherwise, the promise is resolved to an array containing all of the
				*   function's arguments.
				*
				* @param {object} promise
				*        An object containing the resolution and rejection functions of a
				*        promise.
				* @param {function} promise.resolve
				*        The promise's resolution function.
				* @param {function} promise.reject
				*        The promise's rejection function.
				* @param {object} metadata
				*        Metadata about the wrapped method which has created the callback.
				* @param {boolean} metadata.singleCallbackArg
				*        Whether or not the promise is resolved with only the first
				*        argument of the callback, alternatively an array of all the
				*        callback arguments is resolved. By default, if the callback
				*        function is invoked with only a single argument, that will be
				*        resolved to the promise, while all arguments will be resolved as
				*        an array if multiple are given.
				*
				* @returns {function}
				*        The generated callback function.
				*/
				const makeCallback = (promise, metadata) => {
					return (...callbackArgs) => {
						if (extensionAPIs.runtime.lastError) promise.reject(new Error(extensionAPIs.runtime.lastError.message));
						else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) promise.resolve(callbackArgs[0]);
						else promise.resolve(callbackArgs);
					};
				};
				const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
				/**
				* Creates a wrapper function for a method with the given name and metadata.
				*
				* @param {string} name
				*        The name of the method which is being wrapped.
				* @param {object} metadata
				*        Metadata about the method being wrapped.
				* @param {integer} metadata.minArgs
				*        The minimum number of arguments which must be passed to the
				*        function. If called with fewer than this number of arguments, the
				*        wrapper will raise an exception.
				* @param {integer} metadata.maxArgs
				*        The maximum number of arguments which may be passed to the
				*        function. If called with more than this number of arguments, the
				*        wrapper will raise an exception.
				* @param {boolean} metadata.singleCallbackArg
				*        Whether or not the promise is resolved with only the first
				*        argument of the callback, alternatively an array of all the
				*        callback arguments is resolved. By default, if the callback
				*        function is invoked with only a single argument, that will be
				*        resolved to the promise, while all arguments will be resolved as
				*        an array if multiple are given.
				*
				* @returns {function(object, ...*)}
				*       The generated wrapper function.
				*/
				const wrapAsyncFunction = (name, metadata) => {
					return function asyncFunctionWrapper(target, ...args) {
						if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
						if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
						return new Promise((resolve, reject) => {
							if (metadata.fallbackToNoCallback) try {
								target[name](...args, makeCallback({
									resolve,
									reject
								}, metadata));
							} catch (cbError) {
								console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
								target[name](...args);
								metadata.fallbackToNoCallback = false;
								metadata.noCallback = true;
								resolve();
							}
							else if (metadata.noCallback) {
								target[name](...args);
								resolve();
							} else target[name](...args, makeCallback({
								resolve,
								reject
							}, metadata));
						});
					};
				};
				/**
				* Wraps an existing method of the target object, so that calls to it are
				* intercepted by the given wrapper function. The wrapper function receives,
				* as its first argument, the original `target` object, followed by each of
				* the arguments passed to the original method.
				*
				* @param {object} target
				*        The original target object that the wrapped method belongs to.
				* @param {function} method
				*        The method being wrapped. This is used as the target of the Proxy
				*        object which is created to wrap the method.
				* @param {function} wrapper
				*        The wrapper function which is called in place of a direct invocation
				*        of the wrapped method.
				*
				* @returns {Proxy<function>}
				*        A Proxy object for the given method, which invokes the given wrapper
				*        method in its place.
				*/
				const wrapMethod = (target, method, wrapper) => {
					return new Proxy(method, { apply(targetMethod, thisObj, args) {
						return wrapper.call(thisObj, target, ...args);
					} });
				};
				let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
				/**
				* Wraps an object in a Proxy which intercepts and wraps certain methods
				* based on the given `wrappers` and `metadata` objects.
				*
				* @param {object} target
				*        The target object to wrap.
				*
				* @param {object} [wrappers = {}]
				*        An object tree containing wrapper functions for special cases. Any
				*        function present in this object tree is called in place of the
				*        method in the same location in the `target` object tree. These
				*        wrapper methods are invoked as described in {@see wrapMethod}.
				*
				* @param {object} [metadata = {}]
				*        An object tree containing metadata used to automatically generate
				*        Promise-based wrapper functions for asynchronous. Any function in
				*        the `target` object tree which has a corresponding metadata object
				*        in the same location in the `metadata` tree is replaced with an
				*        automatically-generated wrapper function, as described in
				*        {@see wrapAsyncFunction}
				*
				* @returns {Proxy<object>}
				*/
				const wrapObject = (target, wrappers = {}, metadata = {}) => {
					let cache = Object.create(null);
					let handlers = {
						has(proxyTarget, prop) {
							return prop in target || prop in cache;
						},
						get(proxyTarget, prop, receiver) {
							if (prop in cache) return cache[prop];
							if (!(prop in target)) return;
							let value = target[prop];
							if (typeof value === "function") {
								if (typeof wrappers[prop] === "function") value = wrapMethod(target, target[prop], wrappers[prop]);
								else if (hasOwnProperty(metadata, prop)) {
									let wrapper = wrapAsyncFunction(prop, metadata[prop]);
									value = wrapMethod(target, target[prop], wrapper);
								} else value = value.bind(target);
							} else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) value = wrapObject(value, wrappers[prop], metadata[prop]);
							else if (hasOwnProperty(metadata, "*")) value = wrapObject(value, wrappers[prop], metadata["*"]);
							else {
								Object.defineProperty(cache, prop, {
									configurable: true,
									enumerable: true,
									get() {
										return target[prop];
									},
									set(value) {
										target[prop] = value;
									}
								});
								return value;
							}
							cache[prop] = value;
							return value;
						},
						set(proxyTarget, prop, value, receiver) {
							if (prop in cache) cache[prop] = value;
							else target[prop] = value;
							return true;
						},
						defineProperty(proxyTarget, prop, desc) {
							return Reflect.defineProperty(cache, prop, desc);
						},
						deleteProperty(proxyTarget, prop) {
							return Reflect.deleteProperty(cache, prop);
						}
					};
					let proxyTarget = Object.create(target);
					return new Proxy(proxyTarget, handlers);
				};
				/**
				* Creates a set of wrapper functions for an event object, which handles
				* wrapping of listener functions that those messages are passed.
				*
				* A single wrapper is created for each listener function, and stored in a
				* map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
				* retrieve the original wrapper, so that  attempts to remove a
				* previously-added listener work as expected.
				*
				* @param {DefaultWeakMap<function, function>} wrapperMap
				*        A DefaultWeakMap object which will create the appropriate wrapper
				*        for a given listener function when one does not exist, and retrieve
				*        an existing one when it does.
				*
				* @returns {object}
				*/
				const wrapEvent = (wrapperMap) => ({
					addListener(target, listener, ...args) {
						target.addListener(wrapperMap.get(listener), ...args);
					},
					hasListener(target, listener) {
						return target.hasListener(wrapperMap.get(listener));
					},
					removeListener(target, listener) {
						target.removeListener(wrapperMap.get(listener));
					}
				});
				const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
					if (typeof listener !== "function") return listener;
					/**
					* Wraps an onRequestFinished listener function so that it will return a
					* `getContent()` property which returns a `Promise` rather than using a
					* callback API.
					*
					* @param {object} req
					*        The HAR entry object representing the network request.
					*/
					return function onRequestFinished(req) {
						listener(wrapObject(req, {}, { getContent: {
							minArgs: 0,
							maxArgs: 0
						} }));
					};
				});
				const onMessageWrappers = new DefaultWeakMap((listener) => {
					if (typeof listener !== "function") return listener;
					/**
					* Wraps a message listener function so that it may send responses based on
					* its return value, rather than by returning a sentinel value and calling a
					* callback. If the listener function returns a Promise, the response is
					* sent when the promise either resolves or rejects.
					*
					* @param {*} message
					*        The message sent by the other end of the channel.
					* @param {object} sender
					*        Details about the sender of the message.
					* @param {function(*)} sendResponse
					*        A callback which, when called with an arbitrary argument, sends
					*        that value as a response.
					* @returns {boolean}
					*        True if the wrapped listener returned a Promise, which will later
					*        yield a response. False otherwise.
					*/
					return function onMessage(message, sender, sendResponse) {
						let didCallSendResponse = false;
						let wrappedSendResponse;
						let sendResponsePromise = new Promise((resolve) => {
							wrappedSendResponse = function(response) {
								didCallSendResponse = true;
								resolve(response);
							};
						});
						let result;
						try {
							result = listener(message, sender, wrappedSendResponse);
						} catch (err) {
							result = Promise.reject(err);
						}
						const isResultThenable = result !== true && isThenable(result);
						if (result !== true && !isResultThenable && !didCallSendResponse) return false;
						const sendPromisedResult = (promise) => {
							promise.then((msg) => {
								sendResponse(msg);
							}, (error) => {
								let message;
								if (error && (error instanceof Error || typeof error.message === "string")) message = error.message;
								else message = "An unexpected error occurred";
								sendResponse({
									__mozWebExtensionPolyfillReject__: true,
									message
								});
							}).catch((err) => {
								console.error("Failed to send onMessage rejected reply", err);
							});
						};
						if (isResultThenable) sendPromisedResult(result);
						else sendPromisedResult(sendResponsePromise);
						return true;
					};
				});
				const wrappedSendMessageCallback = ({ reject, resolve }, reply) => {
					if (extensionAPIs.runtime.lastError) {
						if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) resolve();
						else reject(new Error(extensionAPIs.runtime.lastError.message));
					} else if (reply && reply.__mozWebExtensionPolyfillReject__) reject(new Error(reply.message));
					else resolve(reply);
				};
				const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
					if (args.length < metadata.minArgs) throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
					if (args.length > metadata.maxArgs) throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
					return new Promise((resolve, reject) => {
						const wrappedCb = wrappedSendMessageCallback.bind(null, {
							resolve,
							reject
						});
						args.push(wrappedCb);
						apiNamespaceObj.sendMessage(...args);
					});
				};
				const staticWrappers = {
					devtools: { network: { onRequestFinished: wrapEvent(onRequestFinishedWrappers) } },
					runtime: {
						onMessage: wrapEvent(onMessageWrappers),
						onMessageExternal: wrapEvent(onMessageWrappers),
						sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
							minArgs: 1,
							maxArgs: 3
						})
					},
					tabs: { sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
						minArgs: 2,
						maxArgs: 3
					}) }
				};
				const settingMetadata = {
					clear: {
						minArgs: 1,
						maxArgs: 1
					},
					get: {
						minArgs: 1,
						maxArgs: 1
					},
					set: {
						minArgs: 1,
						maxArgs: 1
					}
				};
				apiMetadata.privacy = {
					network: { "*": settingMetadata },
					services: { "*": settingMetadata },
					websites: { "*": settingMetadata }
				};
				return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
			};
			module$1.exports = wrapAPIs(chrome);
		} else module$1.exports = globalThis.browser;
	});
})))(), 1);
var extensionGlobals = globalThis;
extensionGlobals.browser ??= import_browser_polyfill.default;
var extensionBrowser = extensionGlobals.browser;
//#endregion
//#region src/shared/localeStore.ts
var LOCALE_KEY = "motrix.locale";
async function getLocaleOverride() {
	const v = (await extensionBrowser.storage.local.get(LOCALE_KEY))[LOCALE_KEY];
	return isSupportedLocale(v) ? v : null;
}
async function setLocaleOverride(v) {
	if (v === null) await extensionBrowser.storage.local.remove(LOCALE_KEY);
	else await extensionBrowser.storage.local.set({ [LOCALE_KEY]: v });
}
//#endregion
//#region src/shared/i18n.ts
var resources = {
	"en-US": { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: connected",
			"disconnected": "Motrix: not connected",
			"connecting": "Motrix: connecting…",
			"downloading": "Motrix: downloading",
			"denied": "Motrix: pairing refused — open to re-pair",
			"error": "Motrix: handoff failed — click for details"
		} },
		contextMenu: {
			"downloadWithMotrix": "Download with Motrix",
			"pairThenDownload": "Pair Motrix, then download"
		},
		notify: {
			"browserFallbackBody": "Motrix is unavailable, so the browser will download it instead.",
			"browserFallbackTitle": "Downloading in browser",
			"downloadComplete": "Download complete",
			"downloadFailed": "Download failed",
			"handedToMotrix": "Handed to Motrix",
			"notConnectedBody": "Pair Motrix to take over downloads.",
			"notConnectedTitle": "Motrix not connected",
			"notReachableBody": "Pair Motrix, then try the download again.",
			"notReachableTitle": "Motrix not reachable",
			"pairNudgeBody": "Open Motrix to finish pairing.",
			"pairNudgeTitle": "Pair Motrix",
			"pairRevokedBody": "Motrix revoked this browser's pairing.",
			"pairRevokedTitle": "Pairing revoked",
			"sensitiveSkippedBody": "Sensitive site left to the browser.",
			"sensitiveSkippedTitle": "Skipped",
			"submitFailedBody": "Re-downloading in the browser.",
			"submitFailedTitle": "Motrix submit failed"
		},
		options: {
			"diagnostics": {
				"adapters": "Adapters",
				"extensionId": "Extension ID",
				"logLevel": "Log level",
				"logLevels": {
					"silent": "Silent",
					"error": "Error",
					"warn": "Warn",
					"info": "Info",
					"debug": "Debug"
				},
				"noneRegistered": "none registered yet",
				"title": "Diagnostics",
				"version": "Version"
			},
			"endpoint": {
				"activate": "Use",
				"activateAria": "Use {{name}}",
				"connection": {
					"bootstrapping": "Starting",
					"connected": "Connected",
					"connecting": "Connecting",
					"denied": "Denied",
					"disconnected": "Disconnected",
					"handshaking": "Authorizing",
					"awaiting-code": "Waiting for code"
				},
				"currentDescription": "Choose one App or Server for downloads, tasks, and page-sniffed resources.",
				"currentTitle": "Motrix backends",
				"listLabel": "Available Motrix backends",
				"localDescription": "This computer discovered through Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Send downloads to"
			},
			"language": {
				"label": "Language",
				"system": "Follow system"
			},
			"notifications": {
				"title": "System notifications",
				"masterLabel": "Enable system notifications",
				"masterAria": "Enable system notifications",
				"confirmLabel": "Success / confirmations",
				"confirmDesc": "Handed to Motrix, download complete",
				"errorLabel": "Failures / errors",
				"errorDesc": "Submit failed, not reachable, download failed",
				"reminderLabel": "Reminders",
				"reminderDesc": "Pairing prompts, pairing revoked, skipped sites"
			},
			"pairing": {
				"backendTitle": "Pairing {{name}}",
				"forget": "Forget pairing",
				"loading": "Loading pair status...",
				"localHelp": "Click Pair to discover Motrix on this computer and enter its pairing code.",
				"localTitle": "Pair through Motrix App",
				"remoteTitle": "Pair with Motrix Server",
				"remoteHelp": "Click Pair, confirm the request in the Server operator UI, then enter the displayed code here. Both WS and WSS endpoints are supported; WSS is recommended.",
				"serverRequiredTitle": "Motrix Server required",
				"serverRequiredHelp": "Firefox for Android connects through Motrix Server. Add a Server above, then select it to pair.",
				"remoteConsentTitle": "Remote downloads",
				"remoteConsentBody": "Remote downloads send the target URL, source page URL and title, filename, selection, and task controls to this Server. Cookies and request headers stay off unless enabled separately.",
				"remoteConsentOffline": "Data permissions are bound to the authenticated Server. Connect before changing them.",
				"remoteHeadersLabel": "Send request headers",
				"remoteHeadersHelp": "Allows page-derived headers such as Referer and media playback headers. Authentication headers still require the credential permission below.",
				"remoteCredentialsLabel": "Send cookies and authentication",
				"remoteCredentialsHelp": "Allows cookies and credential headers for this Server only. Enable only for a Server you control.",
				"notPaired": "Not paired",
				"paired": "Paired with Motrix",
				"pairedHelp": "A committed MBP1 credential is retained for this backend. Current connection status is shown separately.",
				"pairedTitle": "Pairing ready",
				"reconnect": "Reconnect",
				"scopedHelp": "Pairing trust and credentials are isolated for every backend. Switching backends never reuses another backend's trust.",
				"pair": "Pair",
				"pairDialogTitle": "Pair with Motrix"
			},
			"servers": {
				"add": "Add server",
				"addTitle": "Add Motrix Server",
				"current": "Current",
				"delete": "Delete server",
				"deleteActiveDescription": "Delete {{name}} and its locally stored pairing credentials and consent? The current backend will fall back to Motrix App without connecting to or launching it.",
				"deleteActiveServerOnlyDescription": "Delete {{name}} and its locally stored pairing credentials and consent? You will need to add or select another Motrix Server before downloading.",
				"deleteAria": "Delete {{name}}",
				"deleteDescription": "Delete {{name}} and its locally stored pairing credentials and consent? This does not revoke anything on the server.",
				"deleteTitle": "Delete Motrix Server?",
				"description": "Save multiple Motrix Server addresses and switch between them from Options or the popup.",
				"dialogDescription": "Name this backend and enter its WebSocket base URL.",
				"editAria": "Edit {{name}}",
				"editTitle": "Edit Motrix Server",
				"emptyDescription": "Add a server to connect to Motrix beyond this computer.",
				"emptyTitle": "No Motrix Servers yet",
				"footer": "Changing a server address requires pairing again. Pairing information is never shared between addresses.",
				"nameLabel": "Server name",
				"namePlaceholder": "Home server",
				"nameRequired": "Server name is required",
				"save": "Save server",
				"statusAuthority": "Server address: {{value}}",
				"statusRuntime": "Motrix version: {{name}} {{version}}",
				"statusTitle": "Server information",
				"statusTransportSecure": "Connection security: WSS is in use and TLS verifies the server identity",
				"statusTransportPlain": "Connection security: encrypted, but WS cannot verify the server identity and may expose connection information. WSS is recommended",
				"title": "Motrix Servers",
				"urlDescription": "Use a ws:// or wss:// base URL. An optional path is kept as an exact reverse-proxy prefix; WSS is recommended.",
				"urlDuplicate": "This Motrix Server address is already saved",
				"urlInvalid": "Enter a valid ws:// or wss:// base URL without whitespace, credentials, query, or fragment",
				"urlLabel": "WebSocket URL",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "This connection does not use WSS",
				"transportWarningBody": "Content exchanged with Motrix is still encrypted, but WS cannot verify the server identity and may expose connection information. Use WSS if your NAS supports it.",
				"urlRequired": "WebSocket URL is required"
			},
			"takeover": {
				"consentBody": "Motrix receives the site's login cookies to download files. Sensitive sites stay in the browser.",
				"consentCancel": "Cancel",
				"consentConfirm": "Enable",
				"consentDialogLabel": "Send downloads to Motrix?",
				"denylistLabel": "Denylist (one host per line — always left to the browser)",
				"enableAria": "Enable takeover",
				"enableLabel": "Send eligible downloads to Motrix",
				"loading": "Loading takeover settings…",
				"minSizeLabel": "Minimum size (MB)",
				"minSizePlaceholder": "0 = all",
				"thresholdInvalid": "Minimum size must be a non-negative number",
				"save": "Save",
				"saved": "Saved",
				"title": "Download takeover",
				"remoteUnavailable": "Automatic takeover currently requires the local Motrix App. Remote downloads and header or cookie permissions do not enable it. You can still send downloads to this Server manually or from the right-click menu.",
				"availabilityUnknown": "Takeover is unavailable until the selected backend can be checked.",
				"remoteUnavailableShort": "Local App only. Right-click sending works with Servers."
			},
			"tabs": {
				"general": "General",
				"download": "Downloads",
				"integration": "Integration",
				"help": "Help"
			},
			"common": {
				"apply": "Apply",
				"cancel": "Cancel",
				"loadError": "Settings could not be loaded because the extension background failed to start. Reload the extension and try again.",
				"saved": "Saved",
				"saving": "Saving…",
				"saveError": "Save failed"
			},
			"appearance": {
				"title": "Appearance",
				"theme": {
					"label": "Theme",
					"system": "Follow system",
					"light": "Light",
					"dark": "Dark"
				}
			},
			"help": {
				"title": "Help & Support",
				"description": "Browse guides, get support, and view extension diagnostics.",
				"reportBug": "Report a problem",
				"reportBugDescription": "Open a GitHub issue or share feedback.",
				"issues": "GitHub Issues",
				"docs": "Documentation",
				"docsDescription": "Read setup, pairing, download takeover, and troubleshooting guides.",
				"copyDiagnostics": "Copy diagnostics",
				"copied": "Copied",
				"diagnostics": "Diagnostics",
				"diagnosticsDescription": "Adjust logging and copy details useful for troubleshooting."
			},
			"about": {
				"subtitle": "Download files from the web with Motrix",
				"website": "Official website"
			},
			"title": "Motrix Extension Settings"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "This computer",
				"choose": "Choose Motrix backend",
				"configureServer": "Manage Motrix Servers",
				"notConfigured": "Not configured",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "engine {{state}}",
				"noDownloads": "No downloads",
				"pause": "Pause",
				"remove": "Remove",
				"resume": "Resume",
				"statsSummary": "{{active}} active {{waiting}} waiting"
			},
			"dashboard": {
				"activity": "Activity",
				"resources": "Resources",
				"showResources": "Show resources from this page",
				"showTasks": "Show active tasks",
				"title": "Transfer overview"
			},
			"loading": "Loading...",
			"quickSettings": {
				"fullSettings": "Full settings",
				"fullSettingsDescription": "General, downloads, backend, help",
				"loadError": "Couldn’t load quick settings.",
				"notificationsDescription": "Manage extension system notifications",
				"retry": "Retry",
				"saveError": "Couldn’t save setting. Try again.",
				"takeoverDescription": "Send browser downloads to the current Motrix Backend"
			},
			"quickAdd": {
				"title": "New task",
				"description": "Paste an HTTP, HTTPS, or magnet link.",
				"inputLabel": "Download address",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Cancel",
				"add": "Add",
				"submitting": "Adding…",
				"error": {
					"empty": "Enter a download address.",
					"unsupported": "Only HTTP, HTTPS, or magnet links are supported.",
					"invalid": "The download address is invalid.",
					"submitFailed": "Couldn’t add the task. Try again."
				}
			},
			"reconnect": "Connect",
			"settings": "Open settings",
			"sniffer": {
				"clearFilters": "Clear filters",
				"detected": "{{count}} items",
				"downloadCount": "Download {{count}}",
				"downloadSelected": "Download selected",
				"downloadedResource": "Sent {{name}}",
				"downloadingResource": "Downloading {{name}}",
				"emptyDescription": "Play media, then try again.",
				"emptyFilter": "No matching resources",
				"emptyTitle": "No media found",
				"filteredCount": "{{matched}} / {{total}} images",
				"filters": {
					"all": "All",
					"audio": "Audio",
					"image": "Images",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "{{count}} active filters",
					"dimensions": "Dimensions and size",
					"done": "Done",
					"fields": {
						"height": "Height",
						"size": "Size",
						"width": "Width"
					},
					"formatOptionLabel": "Filter {{format}} images",
					"formats": "Image format",
					"operatorLabel": "{{label}} comparison",
					"reset": "Reset",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "File size unit",
					"title": "Quick filters",
					"trigger": "Filter",
					"valueLabel": "{{label}} value"
				},
				"imageCount": "{{count}} images",
				"noImageMatches": "No matching images",
				"pageAction": {
					"bilibili": "Send this bilibili video",
					"youtube": "Send this YouTube video"
				},
				"pageSubmitted": "Video sent to Motrix {{taskId}}",
				"pageResources": "Page resources",
				"quickDownloadResource": "Quick download {{name}}",
				"connectToSubmit": "Connect to Motrix to send resources.",
				"scan": "Scan again",
				"scanning": "Scanning…",
				"selectAll": "Select all",
				"selected": "{{count}} selected",
				"selectResource": "Select {{name}}",
				"sourceHost": "Source: {{host}}",
				"sendResource": "Send {{name}} to Motrix",
				"sent": "Sent",
				"sending": "Sending",
				"submitFailed": "Couldn’t send the resource. Try again.",
				"title": "Sniffer",
				"unavailableDescription": "Switch pages or try again later.",
				"unavailableTitle": "Page can’t be scanned",
				"unsupported": "Requires ffmpeg",
				"unsupportedReason": "The selected backend cannot submit {{kind}} resources because ffmpeg support is unavailable.",
				"unsupportedSelectionReason": "The selected backend cannot submit one or more selected resource types.",
				"unsupportedResource": "{{name}} cannot be sent. {{reason}}"
			},
			"speed": {
				"download": "Download",
				"upload": "Upload"
			},
			"status": {
				"bootstrapping": "Discovering Motrix...",
				"connected": "Connected",
				"connecting": "Connecting...",
				"denied": "Pairing denied",
				"disconnected": "Disconnected",
				"handshaking": "Handshake in progress",
				"awaiting-code": "Waiting for the pairing code…"
			},
			"tabs": {
				"settings": "Settings",
				"sniffer": "Sniffer",
				"tasks": "Tasks"
			},
			"takeover": {
				"aria": "Toggle download takeover",
				"label": "Takeover"
			},
			"tasks": {
				"actions": "Actions for {{name}}",
				"openFolder": "Open containing folder in Motrix",
				"openFolderError": "Couldn't open the task folder. Try again.",
				"openFolderMetadataPending": "Wait for task metadata before opening the folder",
				"openFolderTask": "Open the folder containing {{name}}",
				"openFolderUnsupported": "Update Motrix to open folders",
				"pauseTask": "Pause {{name}}",
				"removeTask": "Remove {{name}}",
				"removeConfirmTitle": "Remove task?",
				"removeConfirmDescription": "“{{name}}” will be removed from the download list.",
				"removeDeleteFilesLabel": "Delete downloaded files",
				"removeConfirmAction": "Remove",
				"resumeTask": "Resume {{name}}",
				"bytes": "{{done}} of {{total}}",
				"disconnectedDescription": "Connect to view tasks.",
				"disconnectedTitle": "Motrix is offline",
				"empty": {
					"active": "No active tasks",
					"failed": "No failed tasks",
					"recent": "No completed tasks"
				},
				"filters": {
					"active": "Active",
					"failed": "Failed",
					"recent": "Completed"
				},
				"loading": "Loading tasks",
				"status": {
					"completed": "Completed",
					"downloading": "Downloading",
					"error": "Failed",
					"fetching_metadata": "Fetching metadata",
					"finalizing": "Finalizing",
					"paused": "Paused",
					"queued": "Queued",
					"seeding": "Seeding"
				},
				"title": "Tasks"
			},
			"pairing": {
				"attemptOf": "Attempt {{run}} of {{maxRuns}}",
				"attemptsRemaining": "{{attemptsRemaining}} attempts remaining",
				"codeLabel": "Pairing code",
				"codeDescription": "Enter the 8-character code in the Motrix pairing dialog.",
				"codeInvalid": "Enter the 8-character code in the pairing dialog.",
				"dialogTitle": "Enter pairing code",
				"dismissPrompt": "Enter later and keep browsing",
				"enterCode": "Enter pairing code",
				"expiresIn": "Expires in {{time}}",
				"pairButton": "Pair",
				"pickerHelp": "Multiple Motrix instances found. Choose one to pair.",
				"rescan": "Rescan",
				"noCandidates": "No Motrix instance found.",
				"candidatesLabel": "Discovered Motrix instances",
				"candidatePort": "Port {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "unknown version",
				"choose": "Choose",
				"backoffTitle": "Too many pairing attempts",
				"backoffBody": "Try again at {{time}}.",
				"retryIn": "Retry in {{seconds}}s",
				"permissionMissingTitle": "Permission needed",
				"permissionMissingBody": "Grant access to localhost to discover Motrix on this computer.",
				"grantPermission": "Grant permission",
				"degradedTitle": "Motrix is connected",
				"degradedBody": "You can use Motrix normally. This connection has basic verification only. For stronger protection, update Motrix and pair again.",
				"recoveryExhaustedTitle": "Couldn't reconnect automatically",
				"recoveryExhaustedBody": "None of the saved Motrix pairings worked. Press Connect to pair again."
			}
		},
		errors: { "connection": {
			"generic": "The connection failed. Try again.",
			"backoffLocked": "Too many pairing attempts. Try again later.",
			"staleAttempt": "A newer connection attempt took over.",
			"aborted": "The pairing was cancelled.",
			"deadlineExceeded": "The attempt timed out. Try again.",
			"runsExhausted": "Too many incorrect codes. Start pairing again for a fresh code.",
			"invalidCode": "The code isn't in the expected format. Check the Motrix dialog.",
			"missingNonce": "Motrix didn't offer a pairing slot. Make sure Motrix is running, then try again.",
			"unsupportedBrowser": "Pairing isn't supported in this browser.",
			"ticketPreparationFailed": "Pairing couldn't be prepared. Try again.",
			"protocolViolation": "Motrix sent an unexpected response. Try again.",
			"unsupportedVersion": "This extension and Motrix use different protocol versions. Update both and try again.",
			"backendUpgradeRequired": "This Motrix version is too old for secure pairing. Update Motrix, then try again.",
			"extensionUpgradeRequired": "This extension version is too old for this Motrix. Update the Motrix extension, then try again.",
			"unsupportedRemote": "The authenticated Motrix is not the App or Server selected for this connection. Check the endpoint and try again.",
			"remoteDiscoveryUnavailable": "The remote Motrix Server could not be reached. Check its address, listener, and network; for WSS, also check the certificate and reverse proxy.",
			"remotePairingUnavailable": "The remote Motrix Server could not open a secure pairing session. Try again shortly.",
			"remoteTransportUnavailable": "The remote Motrix Server connection failed. Check its address, listener, DNS, and network; for WSS, also check the certificate and reverse proxy. The browser cannot identify which one failed.",
			"peerRejected": "Motrix declined the pairing.",
			"peerBusy": "Motrix is handling too many pairing requests. Try again shortly.",
			"securityCheckFailed": "The connection failed a security check and was stopped.",
			"peerNotAuthentic": "The other side couldn't prove it is your Motrix. The connection was stopped.",
			"credentialPhaseFailed": "The pairing couldn't be saved. Try pairing again.",
			"internalError": "Something went wrong in the extension. Try again.",
			"authFailed": "Motrix didn't recognize this pairing. It may have been revoked — try pairing again.",
			"serverMacMismatch": "The reply failed verification, so the connection was stopped. It may not be your Motrix.",
			"channelClosed": "The connection was closed. Reconnect to continue.",
			"channelUnavailable": "Motrix isn't reachable right now. Make sure it's running."
		} }
	} },
	"zh-CN": { translation: {
		badge: { "tooltip": {
			"connected": "Motrix：已连接",
			"disconnected": "Motrix：未连接",
			"connecting": "Motrix：连接中…",
			"downloading": "Motrix：下载中",
			"denied": "Motrix：配对被拒——点击重新配对",
			"error": "Motrix：交接失败——点击查看"
		} },
		contextMenu: {
			"downloadWithMotrix": "用 Motrix 下载",
			"pairThenDownload": "先配对 Motrix，再下载"
		},
		notify: {
			"browserFallbackBody": "无法连接 Motrix，已改用浏览器下载。",
			"browserFallbackTitle": "已改用浏览器下载",
			"downloadComplete": "下载完成",
			"downloadFailed": "下载失败",
			"handedToMotrix": "已交给 Motrix",
			"notConnectedBody": "请配对 Motrix 以接管下载。",
			"notConnectedTitle": "Motrix 未连接",
			"notReachableBody": "请先配对 Motrix，再重试下载。",
			"notReachableTitle": "无法连接 Motrix",
			"pairNudgeBody": "打开 Motrix 完成配对。",
			"pairNudgeTitle": "配对 Motrix",
			"pairRevokedBody": "Motrix 撤销了此浏览器的配对。",
			"pairRevokedTitle": "配对已被撤销",
			"sensitiveSkippedBody": "敏感站点交由浏览器下载。",
			"sensitiveSkippedTitle": "已跳过",
			"submitFailedBody": "改用浏览器重新下载。",
			"submitFailedTitle": "Motrix 提交失败"
		},
		options: {
			"diagnostics": {
				"adapters": "适配器",
				"extensionId": "扩展 ID",
				"logLevel": "日志级别",
				"logLevels": {
					"silent": "静默",
					"error": "错误",
					"warn": "警告",
					"info": "信息",
					"debug": "调试"
				},
				"noneRegistered": "暂无已注册适配器",
				"title": "诊断信息",
				"version": "版本"
			},
			"endpoint": {
				"activate": "使用",
				"activateAria": "使用 {{name}}",
				"connection": {
					"bootstrapping": "正在启动",
					"connected": "已连接",
					"connecting": "正在连接",
					"denied": "已拒绝",
					"disconnected": "未连接",
					"handshaking": "正在授权",
					"awaiting-code": "等待配对码"
				},
				"currentDescription": "选择一个 App 或 Server，用于下载、任务和页面资源嗅探。",
				"currentTitle": "Motrix 后端",
				"listLabel": "可用 Motrix 后端",
				"localDescription": "这台电脑 通过 Motrix App 自动发现",
				"localName": "Motrix App",
				"selectLabel": "下载提交到"
			},
			"language": {
				"label": "语言",
				"system": "跟随系统"
			},
			"notifications": {
				"title": "系统通知",
				"masterLabel": "启用系统通知",
				"masterAria": "启用系统通知",
				"confirmLabel": "成功 / 确认",
				"confirmDesc": "已交给 Motrix、下载完成",
				"errorLabel": "失败 / 错误",
				"errorDesc": "提交失败、连不上、下载失败",
				"reminderLabel": "提醒",
				"reminderDesc": "配对提醒、配对被撤销、已跳过站点"
			},
			"pairing": {
				"backendTitle": "配对 {{name}}",
				"forget": "忘记配对",
				"loading": "加载配对状态…",
				"localHelp": "点击“配对”即可发现这台电脑上的 Motrix，并输入配对码完成授权。",
				"localTitle": "通过 Motrix App 配对",
				"remoteTitle": "与 Motrix Server 配对",
				"remoteHelp": "点击“配对”，在 Server 管理界面确认请求，然后在此输入显示的配对码。WS 与 WSS 地址均可连接，建议优先使用 WSS。",
				"serverRequiredTitle": "需要配置 Motrix Server",
				"serverRequiredHelp": "Firefox Android 通过 Motrix Server 连接。请先在上方添加 Server，然后选择并配对。",
				"remoteConsentTitle": "远程下载",
				"remoteConsentBody": "远程下载会把目标 URL、来源页面 URL 与标题、文件名、选择结果和任务控制发送给此 Server。Cookie 与请求标头需另行开启，默认不会发送。",
				"remoteConsentOffline": "数据权限与当前已认证的 Server 绑定，请先连接后再修改。",
				"remoteHeadersLabel": "发送请求标头",
				"remoteHeadersHelp": "允许发送 Referer、媒体播放标头等页面派生标头；认证标头仍需同时开启下方的凭据权限。",
				"remoteCredentialsLabel": "发送 Cookie 与认证信息",
				"remoteCredentialsHelp": "仅向此 Server 发送 Cookie 与认证标头。请只对你控制的 Server 开启。",
				"notPaired": "未配对",
				"paired": "已与 Motrix 配对",
				"pairedHelp": "这个后端保留了已提交的 MBP1 凭据；当前是否已连接会单独显示。",
				"pairedTitle": "配对已就绪",
				"reconnect": "重新连接",
				"scopedHelp": "每个后端的配对信任和凭据彼此隔离；切换后端不会复用其他后端的信任。",
				"pair": "配对",
				"pairDialogTitle": "与 Motrix 配对"
			},
			"servers": {
				"add": "添加 Server",
				"addTitle": "添加 Motrix Server",
				"current": "当前",
				"delete": "删除 Server",
				"deleteActiveDescription": "删除 {{name}} 及其保存在本地的配对凭据和授权？当前后端将回退到 Motrix App，但不会自动连接或启动它。",
				"deleteActiveServerOnlyDescription": "删除 {{name}} 及其保存在本地的配对凭据和授权？继续下载前，需要添加或选择另一个 Motrix Server。",
				"deleteAria": "删除 {{name}}",
				"deleteDescription": "删除 {{name}} 及其保存在本地的配对凭据和授权？此操作不会撤销 Server 端的配对。",
				"deleteTitle": "删除 Motrix Server？",
				"description": "保存多个 Motrix Server 地址，并可从设置页或 Popup 随时切换。",
				"dialogDescription": "为这个后端设置一个易识别的名称，并填写 WebSocket 基础地址。",
				"editAria": "编辑 {{name}}",
				"editTitle": "编辑 Motrix Server",
				"emptyDescription": "添加一个 Server，即可连接这台电脑之外的 Motrix。",
				"emptyTitle": "尚无 Motrix Server",
				"footer": "修改 Server 地址后需要重新配对；不同地址的配对信息不会共用。",
				"nameLabel": "Server 名称",
				"namePlaceholder": "家庭服务器",
				"nameRequired": "请输入 Server 名称",
				"save": "保存 Server",
				"statusAuthority": "服务器地址：{{value}}",
				"statusRuntime": "Motrix 版本：{{name}} {{version}}",
				"statusTitle": "服务器信息",
				"statusTransportSecure": "连接安全：已使用 WSS，并通过 TLS 验证服务器身份",
				"statusTransportPlain": "连接安全：内容已加密，但 WS 无法验证服务器身份，且可能暴露连接信息。建议改用 WSS",
				"title": "Motrix Servers",
				"urlDescription": "可填写 ws:// 或 wss:// 基础地址；可选路径会作为精确的反向代理前缀保留，建议优先使用 WSS。",
				"urlDuplicate": "这个 Motrix Server 地址已经保存",
				"urlInvalid": "请输入不含空白、凭据、查询参数或片段的有效 ws:// 或 wss:// 基础地址",
				"urlLabel": "WebSocket 地址",
				"urlPlaceholder": "ws(s)://主机[:端口][/基础路径]",
				"transportWarningTitle": "此连接未使用 WSS",
				"transportWarningBody": "与 Motrix 交换的内容仍会加密，但 WS 无法验证服务器身份，也可能暴露连接信息。如果 NAS 支持，建议优先使用 WSS。",
				"urlRequired": "请输入 WebSocket 地址"
			},
			"takeover": {
				"consentBody": "Motrix 会收到网站的登录 Cookie，用于下载文件。敏感网站仍由浏览器下载。",
				"consentCancel": "取消",
				"consentConfirm": "开启",
				"consentDialogLabel": "让 Motrix 接管下载？",
				"denylistLabel": "黑名单（每行一个域名——始终交由浏览器处理）",
				"enableAria": "启用接管",
				"enableLabel": "将符合条件的下载发送到 Motrix",
				"loading": "加载接管设置…",
				"minSizeLabel": "最小体积（MB）",
				"minSizePlaceholder": "0 = 全部",
				"thresholdInvalid": "最小体积必须是非负数字",
				"save": "保存",
				"saved": "已保存",
				"title": "下载接管",
				"remoteUnavailable": "自动接管目前仅支持本机 Motrix App。开启远程下载、请求头或 Cookie 权限不会启用自动接管。你仍可手动添加下载或通过右键菜单发送到此 Server。",
				"availabilityUnknown": "确认当前后端之前，自动接管暂不可用。",
				"remoteUnavailableShort": "仅支持本机 App；远程 Server 可通过右键发送。"
			},
			"tabs": {
				"general": "通用",
				"download": "下载",
				"integration": "集成",
				"help": "帮助"
			},
			"common": {
				"apply": "应用",
				"cancel": "取消",
				"loadError": "设置加载失败：扩展后台未能启动。请重新加载扩展后重试。",
				"saved": "已保存",
				"saving": "保存中…",
				"saveError": "保存失败"
			},
			"appearance": {
				"title": "外观",
				"theme": {
					"label": "主题",
					"system": "跟随系统",
					"light": "浅色",
					"dark": "深色"
				}
			},
			"help": {
				"title": "帮助与支持",
				"description": "查阅文档、获取支持、检查扩展运行信息。",
				"reportBug": "报告问题",
				"reportBugDescription": "在 GitHub 提交问题或反馈建议。",
				"issues": "GitHub Issues",
				"docs": "使用文档",
				"docsDescription": "查看安装、配对、下载接管与常见问题。",
				"copyDiagnostics": "复制诊断信息",
				"copied": "已复制",
				"diagnostics": "诊断详情",
				"diagnosticsDescription": "调整日志级别并复制排障所需信息。"
			},
			"about": {
				"subtitle": "使用 Motrix 下载网页中的文件",
				"website": "官方网站"
			},
			"title": "Motrix 扩展设置"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "这台电脑",
				"choose": "选择 Motrix 后端",
				"configureServer": "管理 Motrix Servers",
				"notConfigured": "尚未配置",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "引擎 {{state}}",
				"noDownloads": "暂无下载",
				"pause": "暂停",
				"remove": "删除",
				"resume": "继续",
				"statsSummary": "{{active}} 活动 {{waiting}} 等待"
			},
			"dashboard": {
				"activity": "活动",
				"resources": "资源",
				"showResources": "查看当前页面资源",
				"showTasks": "查看活动任务",
				"title": "传输概览"
			},
			"loading": "加载中…",
			"quickSettings": {
				"fullSettings": "完整设置",
				"fullSettingsDescription": "通用、下载、后端与帮助",
				"loadError": "无法读取快速设置。",
				"notificationsDescription": "控制扩展发送的系统通知",
				"retry": "重试",
				"saveError": "设置保存失败，请重试。",
				"takeoverDescription": "将浏览器下载交给当前 Motrix 后端"
			},
			"quickAdd": {
				"title": "新建任务",
				"description": "粘贴 HTTP、HTTPS 或 magnet 地址。",
				"inputLabel": "下载地址",
				"placeholder": "https://example.com/file.zip",
				"cancel": "取消",
				"add": "添加",
				"submitting": "正在添加…",
				"error": {
					"empty": "请输入下载地址。",
					"unsupported": "仅支持 HTTP、HTTPS 或 magnet 地址。",
					"invalid": "下载地址格式不正确。",
					"submitFailed": "任务添加失败，请重试。"
				}
			},
			"reconnect": "连接",
			"settings": "打开设置",
			"sniffer": {
				"clearFilters": "清除筛选",
				"detected": "{{count}} 项",
				"downloadCount": "下载 {{count}}",
				"downloadSelected": "下载所选",
				"downloadedResource": "已发送 {{name}}",
				"downloadingResource": "正在下载 {{name}}",
				"emptyDescription": "播放媒体后重试。",
				"emptyFilter": "无匹配资源",
				"emptyTitle": "未发现媒体",
				"filteredCount": "{{matched}} / {{total}} 张",
				"filters": {
					"all": "全部",
					"audio": "音频",
					"image": "图片",
					"video": "视频"
				},
				"imageFilters": {
					"activeCount": "{{count}} 个筛选条件",
					"dimensions": "尺寸与大小",
					"done": "完成",
					"fields": {
						"height": "高度",
						"size": "大小",
						"width": "宽度"
					},
					"formatOptionLabel": "筛选 {{format}} 图片",
					"formats": "图片格式",
					"operatorLabel": "{{label}}比较方式",
					"reset": "重置",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "文件大小单位",
					"title": "快速筛选",
					"trigger": "筛选",
					"valueLabel": "{{label}}数值"
				},
				"imageCount": "{{count}} 张",
				"noImageMatches": "没有匹配图片",
				"pageAction": {
					"bilibili": "提交此哔哩哔哩视频",
					"youtube": "提交此 YouTube 视频"
				},
				"pageSubmitted": "视频已提交到 Motrix {{taskId}}",
				"pageResources": "页面资源",
				"quickDownloadResource": "快速下载 {{name}}",
				"connectToSubmit": "连接 Motrix 后可提交资源。",
				"scan": "重新扫描",
				"scanning": "扫描中…",
				"selectAll": "全选",
				"selected": "已选 {{count}} 项",
				"selectResource": "选择 {{name}}",
				"sourceHost": "来源：{{host}}",
				"sendResource": "将 {{name}} 提交到 Motrix",
				"sent": "已提交",
				"sending": "正在提交",
				"submitFailed": "资源提交失败，请重试。",
				"title": "嗅探",
				"unavailableDescription": "切换页面或稍后重试。",
				"unavailableTitle": "当前页面不可扫描",
				"unsupported": "需要 ffmpeg",
				"unsupportedReason": "所选后端不支持提交 {{kind}} 资源，因为当前没有 ffmpeg 能力。",
				"unsupportedSelectionReason": "所选后端不支持一个或多个已选资源类型。",
				"unsupportedResource": "无法提交 {{name}}。{{reason}}"
			},
			"speed": {
				"download": "下载",
				"upload": "上传"
			},
			"status": {
				"bootstrapping": "正在发现 Motrix…",
				"connected": "已连接",
				"connecting": "连接中…",
				"denied": "配对被拒",
				"disconnected": "未连接",
				"handshaking": "正在握手",
				"awaiting-code": "等待输入配对码…"
			},
			"tabs": {
				"settings": "设置",
				"sniffer": "嗅探",
				"tasks": "任务"
			},
			"takeover": {
				"aria": "切换下载接管",
				"label": "接管"
			},
			"tasks": {
				"actions": "{{name}} 的操作",
				"openFolder": "在 Motrix 中打开所在目录",
				"openFolderError": "无法打开任务所在目录，请重试。",
				"openFolderMetadataPending": "获取任务元数据后可打开目录",
				"openFolderTask": "打开 {{name}} 所在目录",
				"openFolderUnsupported": "升级 Motrix 后可打开目录",
				"pauseTask": "暂停 {{name}}",
				"removeTask": "移除 {{name}}",
				"removeConfirmTitle": "移除任务？",
				"removeConfirmDescription": "「{{name}}」将从下载列表中移除。",
				"removeDeleteFilesLabel": "同时删除已下载的文件",
				"removeConfirmAction": "移除",
				"resumeTask": "继续 {{name}}",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "连接后查看任务。",
				"disconnectedTitle": "Motrix 当前离线",
				"empty": {
					"active": "暂无活动任务",
					"failed": "暂无失败任务",
					"recent": "暂无已完成任务"
				},
				"filters": {
					"active": "进行中",
					"failed": "失败",
					"recent": "已完成"
				},
				"loading": "正在加载任务",
				"status": {
					"completed": "已完成",
					"downloading": "正在下载",
					"error": "失败",
					"fetching_metadata": "正在获取元数据",
					"finalizing": "正在收尾",
					"paused": "已暂停",
					"queued": "排队中",
					"seeding": "做种中"
				},
				"title": "任务"
			},
			"pairing": {
				"attemptOf": "第 {{run}} 次尝试，共 {{maxRuns}} 次",
				"attemptsRemaining": "剩余 {{attemptsRemaining}} 次尝试",
				"codeLabel": "配对码",
				"codeDescription": "输入 Motrix 配对对话框中的 8 位字符配对码。",
				"codeInvalid": "输入配对对话框中的 8 位字符配对码。",
				"dialogTitle": "输入配对码",
				"dismissPrompt": "稍后输入，继续浏览",
				"enterCode": "输入配对码",
				"expiresIn": "有效期 {{time}}",
				"pairButton": "配对",
				"pickerHelp": "发现了多个 Motrix 实例，请选择要配对的一个。",
				"rescan": "重新扫描",
				"noCandidates": "未发现 Motrix 实例。",
				"candidatesLabel": "已发现的 Motrix 实例",
				"candidatePort": "端口 {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "未知版本",
				"choose": "选择",
				"backoffTitle": "配对尝试次数过多",
				"backoffBody": "请在 {{time}} 后重试。",
				"retryIn": "{{seconds}} 秒后可重试",
				"permissionMissingTitle": "需要授权",
				"permissionMissingBody": "请授予访问本机地址的权限，以便发现这台电脑上的 Motrix。",
				"grantPermission": "授予权限",
				"degradedTitle": "Motrix 已连接",
				"degradedBody": "你可以正常使用 Motrix。当前连接仅完成基础验证；如需更完整的安全保护，请更新 Motrix 后重新配对。",
				"recoveryExhaustedTitle": "无法自动重新连接",
				"recoveryExhaustedBody": "已保存的 Motrix 配对均未生效，请点击「连接」重新配对。"
			}
		},
		errors: { "connection": {
			"generic": "连接失败，请重试。",
			"backoffLocked": "配对尝试过于频繁，请稍后再试。",
			"staleAttempt": "已被更新的连接尝试取代。",
			"aborted": "配对已取消。",
			"deadlineExceeded": "本次尝试已超时，请重试。",
			"runsExhausted": "配对码错误次数过多，请重新发起配对获取新码。",
			"invalidCode": "配对码格式不正确，请对照 Motrix 对话框检查。",
			"missingNonce": "未能从 Motrix 获取配对凭据，请确认 Motrix 正在运行后重试。",
			"unsupportedBrowser": "当前浏览器不支持配对。",
			"ticketPreparationFailed": "配对准备失败，请重试。",
			"protocolViolation": "Motrix 返回了异常响应，请重试。",
			"unsupportedVersion": "扩展与 Motrix 的协议版本不一致，请更新两端后重试。",
			"backendUpgradeRequired": "当前 Motrix 版本过旧，无法进行安全配对。请先升级 Motrix，再重试。",
			"extensionUpgradeRequired": "当前 Motrix 扩展版本过旧。请先更新浏览器中的 Motrix 扩展，再重试。",
			"unsupportedRemote": "已认证的 Motrix 与当前选择的 App 或 Server 类型不一致，请检查连接目标后重试。",
			"remoteDiscoveryUnavailable": "无法连接远程 Motrix Server。请检查地址、服务监听和网络；若使用 WSS，请同时检查证书和反向代理。",
			"remotePairingUnavailable": "远程 Motrix Server 暂时无法建立安全配对会话，请稍后重试。",
			"remoteTransportUnavailable": "无法连接远程 Motrix Server。请检查地址、服务监听、DNS 和网络；若使用 WSS，请同时检查证书和反向代理。浏览器无法判断具体是哪一项失败。",
			"peerRejected": "Motrix 拒绝了本次配对。",
			"peerBusy": "Motrix 当前配对请求过多，请稍后再试。",
			"securityCheckFailed": "连接未通过安全校验，已中止。",
			"peerNotAuthentic": "对端无法证明自己是你的 Motrix，连接已中止。",
			"credentialPhaseFailed": "配对凭据保存失败，请重新配对。",
			"internalError": "扩展内部出错，请重试。",
			"authFailed": "Motrix 不认可当前配对，可能已被撤销——请重新配对。",
			"serverMacMismatch": "响应校验失败，连接已中止；对端可能不是你的 Motrix。",
			"channelClosed": "连接已断开，请重新连接。",
			"channelUnavailable": "当前无法连接到 Motrix，请确认它正在运行。"
		} }
	} },
	de: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: verbunden",
			"disconnected": "Motrix: nicht verbunden",
			"connecting": "Motrix: Verbindung wird hergestellt…",
			"downloading": "Motrix: Download läuft",
			"denied": "Motrix: Kopplung abgelehnt – zum erneuten Koppeln öffnen",
			"error": "Motrix: Übergabe fehlgeschlagen – für Details klicken"
		} },
		contextMenu: {
			"downloadWithMotrix": "Mit Motrix herunterladen",
			"pairThenDownload": "Motrix koppeln und herunterladen"
		},
		notify: {
			"browserFallbackBody": "Motrix ist nicht verfügbar. Der Download wird vom Browser übernommen.",
			"browserFallbackTitle": "Download im Browser",
			"downloadComplete": "Download abgeschlossen",
			"downloadFailed": "Download fehlgeschlagen",
			"handedToMotrix": "An Motrix übergeben",
			"notConnectedBody": "Koppeln Sie Motrix, um Downloads zu übernehmen.",
			"notConnectedTitle": "Motrix nicht verbunden",
			"notReachableBody": "Koppeln Sie Motrix und versuchen Sie den Download erneut.",
			"notReachableTitle": "Motrix nicht erreichbar",
			"pairNudgeBody": "Öffnen Sie Motrix, um die Kopplung abzuschließen.",
			"pairNudgeTitle": "Motrix koppeln",
			"pairRevokedBody": "Motrix hat die Kopplung dieses Browsers widerrufen.",
			"pairRevokedTitle": "Kopplung widerrufen",
			"sensitiveSkippedBody": "Downloads von sensiblen Websites verbleiben im Browser.",
			"sensitiveSkippedTitle": "Übersprungen",
			"submitFailedBody": "Download wird erneut im Browser gestartet.",
			"submitFailedTitle": "Übermittlung an Motrix fehlgeschlagen"
		},
		options: {
			"diagnostics": {
				"adapters": "Adapter",
				"extensionId": "Erweiterungs-ID",
				"logLevel": "Protokollstufe",
				"logLevels": {
					"silent": "Keine Protokollierung",
					"error": "Fehler",
					"warn": "Warnung",
					"info": "Information",
					"debug": "Debugging"
				},
				"noneRegistered": "Noch keine registriert",
				"title": "Diagnose",
				"version": "Version"
			},
			"endpoint": {
				"activate": "Verwenden",
				"activateAria": "{{name}} verwenden",
				"connection": {
					"bootstrapping": "Wird gestartet",
					"connected": "Verbunden",
					"connecting": "Verbindung wird hergestellt",
					"denied": "Abgelehnt",
					"disconnected": "Getrennt",
					"handshaking": "Autorisierung läuft",
					"awaiting-code": "Warten auf Code"
				},
				"currentDescription": "Wählen Sie eine App oder einen Server für Downloads, Aufgaben und auf Webseiten erkannte Ressourcen.",
				"currentTitle": "Motrix-Backends",
				"listLabel": "Verfügbare Motrix-Backends",
				"localDescription": "Dieser Computer, erkannt über Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Downloads senden an"
			},
			"language": {
				"label": "Sprache",
				"system": "Systemeinstellung"
			},
			"notifications": {
				"title": "Systembenachrichtigungen",
				"masterLabel": "Systembenachrichtigungen aktivieren",
				"masterAria": "Systembenachrichtigungen aktivieren",
				"confirmLabel": "Erfolge / Bestätigungen",
				"confirmDesc": "An Motrix übergeben, Download abgeschlossen",
				"errorLabel": "Fehlschläge / Fehler",
				"errorDesc": "Übermittlung fehlgeschlagen, nicht erreichbar, Download fehlgeschlagen",
				"reminderLabel": "Erinnerungen",
				"reminderDesc": "Kopplungsaufforderungen, widerrufene Kopplungen, übersprungene Websites"
			},
			"pairing": {
				"backendTitle": "Kopplung mit {{name}}",
				"forget": "Kopplung vergessen",
				"loading": "Kopplungsstatus laden…",
				"localHelp": "Klicken Sie auf „Koppeln“, um Motrix auf diesem Computer zu finden, und geben Sie den Kopplungscode ein.",
				"localTitle": "Über Motrix App koppeln",
				"remoteTitle": "Mit Motrix Server koppeln",
				"remoteHelp": "Klicken Sie auf „Koppeln“, bestätigen Sie die Anfrage in der Verwaltungsoberfläche des Servers und geben Sie den angezeigten Code hier ein. WS- und WSS-Endpunkte werden unterstützt; WSS wird empfohlen.",
				"serverRequiredTitle": "Motrix Server erforderlich",
				"serverRequiredHelp": "Firefox für Android verbindet sich über Motrix Server. Fügen Sie oben einen Server hinzu und wählen Sie ihn zum Koppeln aus.",
				"remoteConsentTitle": "Remote-Downloads",
				"remoteConsentBody": "Bei Remote-Downloads werden Ziel-URL, URL und Titel der Quellseite, Dateiname, Auswahl und Aufgabensteuerung an diesen Server gesendet. Cookies und Anfrageheader werden nur bei gesonderter Aktivierung gesendet.",
				"remoteConsentOffline": "Datenberechtigungen sind an den authentifizierten Server gebunden. Stellen Sie vor Änderungen eine Verbindung her.",
				"remoteHeadersLabel": "Anfrageheader senden",
				"remoteHeadersHelp": "Erlaubt aus Webseiten abgeleitete Header wie Referer und Medienwiedergabe-Header. Authentifizierungsheader benötigen weiterhin die unten stehende Berechtigung für Zugangsdaten.",
				"remoteCredentialsLabel": "Cookies und Authentifizierungsdaten senden",
				"remoteCredentialsHelp": "Erlaubt Cookies und Zugangsdaten-Header nur für diesen Server. Aktivieren Sie dies nur für einen Server, den Sie kontrollieren.",
				"notPaired": "Nicht gekoppelt",
				"paired": "Mit Motrix gekoppelt",
				"pairedHelp": "Für dieses Backend sind bestätigte MBP1-Zugangsdaten gespeichert. Der aktuelle Verbindungsstatus wird separat angezeigt.",
				"pairedTitle": "Kopplung bereit",
				"reconnect": "Erneut verbinden",
				"scopedHelp": "Kopplungsvertrauen und Zugangsdaten sind für jedes Backend getrennt. Beim Wechsel wird das Vertrauen eines anderen Backends niemals übernommen.",
				"pair": "Koppeln",
				"pairDialogTitle": "Mit Motrix koppeln"
			},
			"servers": {
				"add": "Server hinzufügen",
				"addTitle": "Motrix Server hinzufügen",
				"current": "Aktuell",
				"delete": "Server löschen",
				"deleteActiveDescription": "{{name}} sowie die lokal gespeicherten Kopplungsdaten und Einwilligungen löschen? Als aktuelles Backend wird wieder Motrix App ausgewählt, ohne sie zu verbinden oder zu starten.",
				"deleteActiveServerOnlyDescription": "{{name}} sowie die lokal gespeicherten Kopplungsdaten und Einwilligungen löschen? Vor dem nächsten Download müssen Sie einen anderen Motrix Server hinzufügen oder auswählen.",
				"deleteAria": "{{name}} löschen",
				"deleteDescription": "{{name}} sowie die lokal gespeicherten Kopplungsdaten und Einwilligungen löschen? Auf dem Server wird dadurch nichts widerrufen.",
				"deleteTitle": "Motrix Server löschen?",
				"description": "Speichern Sie mehrere Motrix-Server-Adressen und wechseln Sie in den Einstellungen oder im Popup zwischen ihnen.",
				"dialogDescription": "Geben Sie diesem Backend einen aussagekräftigen Namen und tragen Sie seine WebSocket-Basis-URL ein.",
				"editAria": "{{name}} bearbeiten",
				"editTitle": "Motrix Server bearbeiten",
				"emptyDescription": "Fügen Sie einen Server hinzu, um Motrix außerhalb dieses Computers zu nutzen.",
				"emptyTitle": "Noch keine Motrix Server",
				"footer": "Nach einer Adressänderung muss der Server erneut gekoppelt werden. Kopplungsdaten werden niemals zwischen Adressen geteilt.",
				"nameLabel": "Servername",
				"namePlaceholder": "Heimserver",
				"nameRequired": "Ein Servername ist erforderlich",
				"save": "Server speichern",
				"statusAuthority": "Serveradresse: {{value}}",
				"statusRuntime": "Motrix-Version: {{name}} {{version}}",
				"statusTitle": "Serverinformationen",
				"statusTransportSecure": "Verbindungssicherheit: WSS wird verwendet und TLS prüft die Serveridentität",
				"statusTransportPlain": "Verbindungssicherheit: verschlüsselt, aber WS kann die Serveridentität nicht prüfen und kann Verbindungsinformationen offenlegen. WSS wird empfohlen",
				"title": "Motrix Server",
				"urlDescription": "Verwenden Sie eine ws://- oder wss://-Basis-URL. Ein optionaler Pfad bleibt als exaktes Reverse-Proxy-Präfix erhalten; WSS wird empfohlen.",
				"urlDuplicate": "Diese Motrix-Server-Adresse ist bereits gespeichert",
				"urlInvalid": "Geben Sie eine gültige ws://- oder wss://-Basis-URL ohne Leerzeichen, Zugangsdaten, Abfrage oder Fragment ein",
				"urlLabel": "WebSocket-URL",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Diese Verbindung verwendet kein WSS",
				"transportWarningBody": "Die mit Motrix ausgetauschten Inhalte sind weiterhin verschlüsselt, aber WS kann die Serveridentität nicht prüfen und kann Verbindungsinformationen offenlegen. Nutzen Sie WSS, wenn Ihr NAS es unterstützt.",
				"urlRequired": "Eine WebSocket-URL ist erforderlich"
			},
			"takeover": {
				"consentBody": "Motrix erhält die Anmelde-Cookies der Website, um Dateien herunterzuladen. Downloads von sensiblen Websites verbleiben im Browser.",
				"consentCancel": "Abbrechen",
				"consentConfirm": "Aktivieren",
				"consentDialogLabel": "Downloads an Motrix senden?",
				"denylistLabel": "Sperrliste (ein Host pro Zeile – Downloads bleiben immer im Browser)",
				"enableAria": "Download-Übernahme aktivieren",
				"enableLabel": "Geeignete Downloads an Motrix senden",
				"loading": "Übernahmeeinstellungen laden…",
				"minSizeLabel": "Mindestgröße (MB)",
				"minSizePlaceholder": "0 = alle",
				"thresholdInvalid": "Die Mindestgröße muss eine nicht negative Zahl sein",
				"save": "Speichern",
				"saved": "Gespeichert",
				"title": "Download-Übernahme",
				"remoteUnavailable": "Die automatische Übernahme erfordert derzeit die lokale Motrix App. Remote-Downloads und Berechtigungen für Header oder Cookies aktivieren sie nicht. Sie können Downloads weiterhin manuell oder über das Kontextmenü an diesen Server senden.",
				"availabilityUnknown": "Die Übernahme ist erst verfügbar, wenn das ausgewählte Backend überprüft werden kann.",
				"remoteUnavailableShort": "Nur lokale App. Senden per Rechtsklick funktioniert mit Servern."
			},
			"tabs": {
				"general": "Allgemein",
				"download": "Downloads",
				"integration": "Integration",
				"help": "Hilfe"
			},
			"common": {
				"apply": "Anwenden",
				"cancel": "Abbrechen",
				"loadError": "Die Einstellungen konnten nicht geladen werden, da der Hintergrundprozess der Erweiterung nicht gestartet wurde. Laden Sie die Erweiterung neu und versuchen Sie es erneut.",
				"saved": "Gespeichert",
				"saving": "Wird gespeichert…",
				"saveError": "Speichern fehlgeschlagen"
			},
			"appearance": {
				"title": "Darstellung",
				"theme": {
					"label": "Design",
					"system": "Systemeinstellung",
					"light": "Hell",
					"dark": "Dunkel"
				}
			},
			"help": {
				"title": "Hilfe und Support",
				"description": "Anleitungen, Hilfe und Diagnosedaten der Erweiterung ansehen.",
				"reportBug": "Problem melden",
				"reportBugDescription": "Erstellen Sie ein GitHub-Issue oder geben Sie Feedback.",
				"issues": "GitHub Issues",
				"docs": "Dokumentation",
				"docsDescription": "Lesen Sie Anleitungen zu Einrichtung, Kopplung, Download-Übernahme und Fehlerbehebung.",
				"copyDiagnostics": "Diagnosedaten kopieren",
				"copied": "Kopiert",
				"diagnostics": "Diagnose",
				"diagnosticsDescription": "Passen Sie die Protokollierung an und kopieren Sie hilfreiche Informationen zur Fehlerbehebung."
			},
			"about": {
				"subtitle": "Dateien aus dem Web mit Motrix herunterladen",
				"website": "Offizielle Website"
			},
			"title": "Einstellungen der Motrix-Erweiterung"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Dieser Computer",
				"choose": "Motrix-Backend auswählen",
				"configureServer": "Motrix Server verwalten",
				"notConfigured": "Nicht konfiguriert",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "Engine: {{state}}",
				"noDownloads": "Keine Downloads",
				"pause": "Pausieren",
				"remove": "Entfernen",
				"resume": "Fortsetzen",
				"statsSummary": "Aktiv: {{active}} · Wartend: {{waiting}}"
			},
			"dashboard": {
				"activity": "Aktivität",
				"resources": "Ressourcen",
				"showResources": "Ressourcen dieser Seite anzeigen",
				"showTasks": "Aktive Aufgaben anzeigen",
				"title": "Übertragungsübersicht"
			},
			"loading": "Wird geladen…",
			"quickSettings": {
				"fullSettings": "Alle Einstellungen",
				"fullSettingsDescription": "Allgemein, Downloads, Backend und Hilfe",
				"loadError": "Schnelleinstellungen nicht geladen.",
				"notificationsDescription": "Systembenachrichtigungen der Erweiterung steuern",
				"retry": "Erneut versuchen",
				"saveError": "Einstellung nicht gespeichert. Erneut versuchen.",
				"takeoverDescription": "Browser-Downloads an das aktuelle Motrix-Backend senden"
			},
			"quickAdd": {
				"title": "Neue Aufgabe",
				"description": "Fügen Sie einen HTTP-, HTTPS- oder Magnet-Link ein.",
				"inputLabel": "Download-Adresse",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Abbrechen",
				"add": "Hinzufügen",
				"submitting": "Wird hinzugefügt…",
				"error": {
					"empty": "Geben Sie eine Download-Adresse ein.",
					"unsupported": "Es werden nur HTTP-, HTTPS- und Magnet-Links unterstützt.",
					"invalid": "Die Download-Adresse ist ungültig.",
					"submitFailed": "Die Aufgabe konnte nicht hinzugefügt werden. Bitte erneut versuchen."
				}
			},
			"reconnect": "Verbinden",
			"settings": "Einstellungen öffnen",
			"sniffer": {
				"clearFilters": "Filter löschen",
				"detected": "Einträge: {{count}}",
				"downloadCount": "Herunterladen ({{count}})",
				"downloadSelected": "Auswahl herunterladen",
				"downloadedResource": "{{name}} gesendet",
				"downloadingResource": "{{name}} wird heruntergeladen",
				"emptyDescription": "Medien abspielen und erneut versuchen.",
				"emptyFilter": "Keine passenden Ressourcen",
				"emptyTitle": "Keine Medien",
				"filteredCount": "{{matched}} / {{total}} Bilder",
				"filters": {
					"all": "Alle",
					"audio": "Audio",
					"image": "Bilder",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "Aktive Filter: {{count}}",
					"dimensions": "Maße und Größe",
					"done": "Fertig",
					"fields": {
						"height": "Höhe",
						"size": "Größe",
						"width": "Breite"
					},
					"formatOptionLabel": "{{format}}-Bilder filtern",
					"formats": "Bildformat",
					"operatorLabel": "{{label}} vergleichen",
					"reset": "Zurücksetzen",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Dateigrößeneinheit",
					"title": "Schnellfilter",
					"trigger": "Filtern",
					"valueLabel": "{{label}}-Wert"
				},
				"imageCount": "Bilder: {{count}}",
				"noImageMatches": "Keine passenden Bilder",
				"pageAction": {
					"bilibili": "Dieses bilibili-Video senden",
					"youtube": "Dieses YouTube-Video senden"
				},
				"pageSubmitted": "Video an Motrix gesendet {{taskId}}",
				"pageResources": "Seitenressourcen",
				"quickDownloadResource": "{{name}} schnell herunterladen",
				"connectToSubmit": "Zum Senden von Ressourcen mit Motrix verbinden.",
				"scan": "Erneut scannen",
				"scanning": "Scan läuft…",
				"selectAll": "Alle auswählen",
				"selected": "Ausgewählt: {{count}}",
				"selectResource": "{{name}} auswählen",
				"sourceHost": "Quelle: {{host}}",
				"sendResource": "{{name}} an Motrix senden",
				"sent": "Gesendet",
				"sending": "Wird gesendet",
				"submitFailed": "Die Ressource konnte nicht gesendet werden. Bitte erneut versuchen.",
				"title": "Ressourcen erkennen",
				"unavailableDescription": "Seite wechseln oder später erneut versuchen.",
				"unavailableTitle": "Seite nicht scanbar",
				"unsupported": "Erfordert ffmpeg",
				"unsupportedReason": "Das ausgewählte Backend kann keine Ressourcen vom Typ {{kind}} übermitteln, da ffmpeg nicht verfügbar ist.",
				"unsupportedSelectionReason": "Das ausgewählte Backend kann einen oder mehrere der ausgewählten Ressourcentypen nicht übermitteln.",
				"unsupportedResource": "{{name}} kann nicht gesendet werden. {{reason}}"
			},
			"speed": {
				"download": "Download",
				"upload": "Upload"
			},
			"status": {
				"bootstrapping": "Motrix wird gesucht…",
				"connected": "Verbunden",
				"connecting": "Verbindung wird hergestellt…",
				"denied": "Kopplung abgelehnt",
				"disconnected": "Getrennt",
				"handshaking": "Handshake läuft",
				"awaiting-code": "Warten auf den Kopplungscode…"
			},
			"tabs": {
				"settings": "Einstellungen",
				"sniffer": "Ressourcen",
				"tasks": "Aufgaben"
			},
			"takeover": {
				"aria": "Download-Übernahme umschalten",
				"label": "Übernahme"
			},
			"tasks": {
				"actions": "Aktionen für {{name}}",
				"openFolder": "Enthaltenden Ordner in Motrix öffnen",
				"openFolderError": "Der Aufgabenordner konnte nicht geöffnet werden. Bitte erneut versuchen.",
				"openFolderMetadataPending": "Vor dem Öffnen des Ordners auf Aufgabenmetadaten warten",
				"openFolderTask": "Ordner mit {{name}} öffnen",
				"openFolderUnsupported": "Aktualisieren Sie Motrix, um Ordner zu öffnen",
				"pauseTask": "{{name}} pausieren",
				"removeTask": "{{name}} entfernen",
				"removeConfirmTitle": "Aufgabe entfernen?",
				"removeConfirmDescription": "„{{name}}“ wird aus der Download-Liste entfernt.",
				"removeDeleteFilesLabel": "Heruntergeladene Dateien löschen",
				"removeConfirmAction": "Entfernen",
				"resumeTask": "{{name}} fortsetzen",
				"bytes": "{{done}} von {{total}}",
				"disconnectedDescription": "Verbinden Sie sich, um Aufgaben anzuzeigen.",
				"disconnectedTitle": "Motrix ist offline",
				"empty": {
					"active": "Keine aktiven Aufgaben",
					"failed": "Keine gescheiterten Aufgaben",
					"recent": "Keine fertigen Aufgaben"
				},
				"filters": {
					"active": "Aktiv",
					"failed": "Gescheitert",
					"recent": "Fertig"
				},
				"loading": "Aufgaben werden geladen",
				"status": {
					"completed": "Abgeschlossen",
					"downloading": "Wird heruntergeladen",
					"error": "Fehlgeschlagen",
					"fetching_metadata": "Metadaten werden abgerufen",
					"finalizing": "Wird abgeschlossen",
					"paused": "Pausiert",
					"queued": "In Warteschlange",
					"seeding": "Seeding"
				},
				"title": "Aufgaben"
			},
			"pairing": {
				"attemptOf": "Versuch {{run}} von {{maxRuns}}",
				"attemptsRemaining": "Verbleibende Versuche: {{attemptsRemaining}}",
				"codeLabel": "Kopplungscode",
				"codeDescription": "8-stelligen Code aus dem Motrix-Kopplungsdialog eingeben.",
				"codeInvalid": "8-stelligen Code aus dem Kopplungsdialog eingeben.",
				"dialogTitle": "Kopplungscode eingeben",
				"dismissPrompt": "Später eingeben und weitersurfen",
				"enterCode": "Kopplungscode eingeben",
				"expiresIn": "Läuft in {{time}} ab",
				"pairButton": "Koppeln",
				"pickerHelp": "Mehrere Motrix-Instanzen wurden gefunden. Wählen Sie eine zum Koppeln aus.",
				"rescan": "Erneut suchen",
				"noCandidates": "Keine Motrix-Instanz gefunden.",
				"candidatesLabel": "Gefundene Motrix-Instanzen",
				"candidatePort": "Port {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "unbekannte Version",
				"choose": "Auswählen",
				"backoffTitle": "Zu viele Kopplungsversuche",
				"backoffBody": "Versuchen Sie es um {{time}} erneut.",
				"retryIn": "In {{seconds}} s erneut versuchen",
				"permissionMissingTitle": "Berechtigung erforderlich",
				"permissionMissingBody": "Erlauben Sie den Zugriff auf localhost, um Motrix auf diesem Computer zu finden.",
				"grantPermission": "Berechtigung erteilen",
				"degradedTitle": "Motrix ist verbunden",
				"degradedBody": "Sie können Motrix normal nutzen. Diese Verbindung wurde nur grundlegend überprüft. Aktualisieren Sie Motrix und koppeln Sie es erneut, um den Schutz zu verbessern.",
				"recoveryExhaustedTitle": "Automatische Wiederverbindung fehlgeschlagen",
				"recoveryExhaustedBody": "Keine der gespeicherten Motrix-Kopplungen hat funktioniert. Klicken Sie auf „Verbinden“, um erneut zu koppeln."
			}
		},
		errors: { "connection": {
			"generic": "Die Verbindung ist fehlgeschlagen. Bitte erneut versuchen.",
			"backoffLocked": "Zu viele Kopplungsversuche. Versuchen Sie es später erneut.",
			"staleAttempt": "Ein neuerer Verbindungsversuch hat diesen ersetzt.",
			"aborted": "Die Kopplung wurde abgebrochen.",
			"deadlineExceeded": "Zeitüberschreitung. Bitte erneut versuchen.",
			"runsExhausted": "Zu viele falsche Codes. Starten Sie die Kopplung neu, um einen neuen Code zu erhalten.",
			"invalidCode": "Der Code hat nicht das erwartete Format. Prüfen Sie den Motrix-Dialog.",
			"missingNonce": "Motrix hat keinen Kopplungsplatz angeboten. Stellen Sie sicher, dass Motrix läuft, und versuchen Sie es erneut.",
			"unsupportedBrowser": "Dieser Browser unterstützt keine Kopplung.",
			"ticketPreparationFailed": "Die Kopplung konnte nicht vorbereitet werden. Bitte erneut versuchen.",
			"protocolViolation": "Motrix hat eine unerwartete Antwort gesendet. Bitte erneut versuchen.",
			"unsupportedVersion": "Diese Erweiterung und Motrix verwenden unterschiedliche Protokollversionen. Aktualisieren Sie beide und versuchen Sie es erneut.",
			"backendUpgradeRequired": "Diese Motrix-Version ist für eine sichere Kopplung zu alt. Aktualisieren Sie Motrix und versuchen Sie es erneut.",
			"extensionUpgradeRequired": "Diese Erweiterungsversion ist für dieses Motrix zu alt. Aktualisieren Sie die Motrix-Erweiterung und versuchen Sie es erneut.",
			"unsupportedRemote": "Das authentifizierte Motrix ist nicht die für diese Verbindung ausgewählte App oder der ausgewählte Server. Prüfen Sie den Endpunkt und versuchen Sie es erneut.",
			"remoteDiscoveryUnavailable": "Der entfernte Motrix Server ist nicht erreichbar. Prüfen Sie Adresse, Listener und Netzwerk; bei WSS auch Zertifikat und Reverse-Proxy.",
			"remotePairingUnavailable": "Der entfernte Motrix Server konnte keine sichere Kopplungssitzung öffnen. Versuchen Sie es in Kürze erneut.",
			"remoteTransportUnavailable": "Die Verbindung zum entfernten Motrix Server ist fehlgeschlagen. Prüfen Sie Adresse, Listener, DNS und Netzwerk; bei WSS auch Zertifikat und Reverse-Proxy. Der Browser kann die genaue Fehlerquelle nicht ermitteln.",
			"peerRejected": "Motrix hat die Kopplung abgelehnt.",
			"peerBusy": "Motrix bearbeitet zu viele Kopplungsanfragen. Versuchen Sie es in Kürze erneut.",
			"securityCheckFailed": "Die Verbindung hat eine Sicherheitsprüfung nicht bestanden und wurde beendet.",
			"peerNotAuthentic": "Die Gegenstelle konnte nicht nachweisen, dass sie Ihr Motrix ist. Die Verbindung wurde beendet.",
			"credentialPhaseFailed": "Die Kopplung konnte nicht gespeichert werden. Koppeln Sie erneut.",
			"internalError": "In der Erweiterung ist ein Fehler aufgetreten. Bitte erneut versuchen.",
			"authFailed": "Motrix hat diese Kopplung nicht erkannt. Sie wurde möglicherweise widerrufen. Koppeln Sie erneut.",
			"serverMacMismatch": "Die Antwort konnte nicht verifiziert werden. Die Verbindung wurde beendet, da es möglicherweise nicht Ihr Motrix ist.",
			"channelClosed": "Die Verbindung wurde geschlossen. Verbinden Sie sich erneut, um fortzufahren.",
			"channelUnavailable": "Motrix ist derzeit nicht erreichbar. Stellen Sie sicher, dass es läuft."
		} }
	} },
	es: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: conectado",
			"disconnected": "Motrix: sin conexión",
			"connecting": "Motrix: conectando…",
			"downloading": "Motrix: descargando",
			"denied": "Motrix: vinculación rechazada; abre para volver a vincular",
			"error": "Motrix: transferencia fallida; haz clic para ver los detalles"
		} },
		contextMenu: {
			"downloadWithMotrix": "Descargar con Motrix",
			"pairThenDownload": "Vincular Motrix y descargar"
		},
		notify: {
			"browserFallbackBody": "Motrix no está disponible. El navegador se encargará de la descarga.",
			"browserFallbackTitle": "Descargando en el navegador",
			"downloadComplete": "Descarga completada",
			"downloadFailed": "Error de descarga",
			"handedToMotrix": "Enviado a Motrix",
			"notConnectedBody": "Vincula Motrix para que gestione las descargas.",
			"notConnectedTitle": "Motrix sin conexión",
			"notReachableBody": "Vincula Motrix y vuelve a intentar la descarga.",
			"notReachableTitle": "No se puede acceder a Motrix",
			"pairNudgeBody": "Abre Motrix para completar la vinculación.",
			"pairNudgeTitle": "Vincular Motrix",
			"pairRevokedBody": "Motrix ha revocado la vinculación de este navegador.",
			"pairRevokedTitle": "Vinculación revocada",
			"sensitiveSkippedBody": "La descarga del sitio sensible se deja al navegador.",
			"sensitiveSkippedTitle": "Omitido",
			"submitFailedBody": "Reiniciando la descarga en el navegador.",
			"submitFailedTitle": "Error al enviar a Motrix"
		},
		options: {
			"diagnostics": {
				"adapters": "Adaptadores",
				"extensionId": "ID de la extensión",
				"logLevel": "Nivel de registro",
				"logLevels": {
					"silent": "Sin registros",
					"error": "Error",
					"warn": "Advertencia",
					"info": "Información",
					"debug": "Depuración"
				},
				"noneRegistered": "Ninguno registrado aún",
				"title": "Diagnóstico",
				"version": "Versión"
			},
			"endpoint": {
				"activate": "Usar",
				"activateAria": "Usar {{name}}",
				"connection": {
					"bootstrapping": "Iniciando",
					"connected": "Conectado",
					"connecting": "Conectando",
					"denied": "Rechazado",
					"disconnected": "Desconectado",
					"handshaking": "Autorizando",
					"awaiting-code": "Esperando el código"
				},
				"currentDescription": "Elige una App o un Server para las descargas, las tareas y los recursos detectados en las páginas.",
				"currentTitle": "Servicios Motrix",
				"listLabel": "Servicios Motrix disponibles",
				"localDescription": "Este equipo, detectado mediante Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Enviar descargas a"
			},
			"language": {
				"label": "Idioma",
				"system": "Seguir al sistema"
			},
			"notifications": {
				"title": "Notificaciones del sistema",
				"masterLabel": "Activar notificaciones del sistema",
				"masterAria": "Activar notificaciones del sistema",
				"confirmLabel": "Éxitos / confirmaciones",
				"confirmDesc": "Envío a Motrix, descarga completada",
				"errorLabel": "Fallos / errores",
				"errorDesc": "Error de envío, sin acceso, error de descarga",
				"reminderLabel": "Recordatorios",
				"reminderDesc": "Solicitudes de vinculación, vinculación revocada, sitios omitidos"
			},
			"pairing": {
				"backendTitle": "Vinculando {{name}}",
				"forget": "Olvidar vinculación",
				"loading": "Cargando estado de vinculación…",
				"localHelp": "Haz clic en Vincular para buscar Motrix en este equipo e introduce su código de vinculación.",
				"localTitle": "Vincular mediante Motrix App",
				"remoteTitle": "Vincular con Motrix Server",
				"remoteHelp": "Haz clic en Vincular, confirma la solicitud en la interfaz de administración del Server e introduce aquí el código mostrado. Se admiten conexiones WS y WSS; se recomienda WSS.",
				"serverRequiredTitle": "Se requiere Motrix Server",
				"serverRequiredHelp": "Firefox para Android se conecta mediante Motrix Server. Añade un Server arriba y selecciónalo para vincularlo.",
				"remoteConsentTitle": "Descargas remotas",
				"remoteConsentBody": "Las descargas remotas envían a este Server la URL de destino, la URL y el título de la página de origen, el nombre del archivo, la selección y los controles de tareas. Las cookies y las cabeceras de solicitud solo se envían si se activan por separado.",
				"remoteConsentOffline": "Los permisos de datos están asociados al Server autenticado. Conéctate antes de modificarlos.",
				"remoteHeadersLabel": "Enviar cabeceras de solicitud",
				"remoteHeadersHelp": "Permite cabeceras obtenidas de la página, como Referer y las de reproducción multimedia. Las cabeceras de autenticación siguen requiriendo el permiso de credenciales indicado abajo.",
				"remoteCredentialsLabel": "Enviar cookies y autenticación",
				"remoteCredentialsHelp": "Permite cookies y cabeceras de credenciales solo para este Server. Actívalo únicamente en un Server que controles.",
				"notPaired": "Sin vincular",
				"paired": "Vinculado con Motrix",
				"pairedHelp": "Se conserva una credencial MBP1 confirmada para este servicio. El estado actual de la conexión se muestra por separado.",
				"pairedTitle": "Vinculación lista",
				"reconnect": "Reconectar",
				"scopedHelp": "La confianza y las credenciales de vinculación son independientes para cada servicio. Al cambiar de servicio nunca se reutiliza la confianza de otro.",
				"pair": "Vincular",
				"pairDialogTitle": "Vincular con Motrix"
			},
			"servers": {
				"add": "Añadir servidor",
				"addTitle": "Añadir Motrix Server",
				"current": "Actual",
				"delete": "Eliminar servidor",
				"deleteActiveDescription": "¿Eliminar {{name}} y sus credenciales de vinculación y consentimientos guardados localmente? Se volverá a seleccionar Motrix App sin conectarla ni iniciarla.",
				"deleteActiveServerOnlyDescription": "¿Eliminar {{name}} y sus credenciales de vinculación y consentimientos guardados localmente? Tendrás que añadir o seleccionar otro Motrix Server antes de descargar.",
				"deleteAria": "Eliminar {{name}}",
				"deleteDescription": "¿Eliminar {{name}} y sus credenciales de vinculación y consentimientos guardados localmente? Esto no revoca nada en el servidor.",
				"deleteTitle": "¿Eliminar Motrix Server?",
				"description": "Guarda varias direcciones de Motrix Server y cambia entre ellas desde las opciones o la ventana emergente.",
				"dialogDescription": "Asigna un nombre reconocible a este servicio e introduce su URL base de WebSocket.",
				"editAria": "Editar {{name}}",
				"editTitle": "Editar Motrix Server",
				"emptyDescription": "Añade un servidor para conectarte a Motrix fuera de este equipo.",
				"emptyTitle": "Aún sin Motrix Servers",
				"footer": "Cambiar la dirección de un servidor requiere volver a vincularlo. La información de vinculación nunca se comparte entre direcciones.",
				"nameLabel": "Nombre del servidor",
				"namePlaceholder": "Servidor doméstico",
				"nameRequired": "El nombre del servidor es obligatorio",
				"save": "Guardar servidor",
				"statusAuthority": "Dirección del servidor: {{value}}",
				"statusRuntime": "Versión de Motrix: {{name}} {{version}}",
				"statusTitle": "Información del servidor",
				"statusTransportSecure": "Seguridad de la conexión: se usa WSS y TLS verifica la identidad del servidor",
				"statusTransportPlain": "Seguridad de la conexión: cifrada, pero WS no puede verificar la identidad del servidor y puede exponer información de conexión. Se recomienda WSS",
				"title": "Servidores Motrix",
				"urlDescription": "Usa una URL base ws:// o wss://. La ruta opcional se conserva como prefijo exacto del proxy inverso; se recomienda WSS.",
				"urlDuplicate": "Esta dirección de Motrix Server ya está guardada",
				"urlInvalid": "Introduce una URL base ws:// o wss:// válida sin espacios, credenciales, consulta ni fragmento",
				"urlLabel": "URL de WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Esta conexión no usa WSS",
				"transportWarningBody": "El contenido intercambiado con Motrix sigue cifrado, pero WS no puede verificar la identidad del servidor y puede exponer información de conexión. Usa WSS si tu NAS lo admite.",
				"urlRequired": "La URL de WebSocket es obligatoria"
			},
			"takeover": {
				"consentBody": "Motrix recibe las cookies de inicio de sesión del sitio para descargar archivos. Las descargas de sitios sensibles permanecen en el navegador.",
				"consentCancel": "Cancelar",
				"consentConfirm": "Activar",
				"consentDialogLabel": "¿Enviar las descargas a Motrix?",
				"denylistLabel": "Lista de exclusión (un host por línea; siempre se deja al navegador)",
				"enableAria": "Activar gestión de descargas",
				"enableLabel": "Enviar las descargas compatibles a Motrix",
				"loading": "Cargando ajustes de gestión de descargas…",
				"minSizeLabel": "Tamaño mínimo (MB)",
				"minSizePlaceholder": "0 = todas",
				"thresholdInvalid": "El tamaño mínimo debe ser un número no negativo",
				"save": "Guardar",
				"saved": "Guardado",
				"title": "Gestión de descargas",
				"remoteUnavailable": "La gestión automática requiere actualmente Motrix App en este equipo. Las descargas remotas y los permisos de cabeceras o cookies no la activan. Puedes seguir enviando descargas a este Server manualmente o desde el menú contextual.",
				"availabilityUnknown": "La gestión de descargas no está disponible hasta que se pueda comprobar el servicio seleccionado.",
				"remoteUnavailableShort": "Solo App local. El envío con clic derecho funciona con Servers."
			},
			"tabs": {
				"general": "General",
				"download": "Descargas",
				"integration": "Integración",
				"help": "Ayuda"
			},
			"common": {
				"apply": "Aplicar",
				"cancel": "Cancelar",
				"loadError": "No se pudieron cargar los ajustes porque el proceso en segundo plano de la extensión no se inició. Recarga la extensión e reinténtalo.",
				"saved": "Guardado",
				"saving": "Guardando…",
				"saveError": "Error al guardar"
			},
			"appearance": {
				"title": "Apariencia",
				"theme": {
					"label": "Tema",
					"system": "Seguir al sistema",
					"light": "Claro",
					"dark": "Oscuro"
				}
			},
			"help": {
				"title": "Ayuda y soporte",
				"description": "Consulta guías, ayuda y diagnóstico de la extensión.",
				"reportBug": "Informar de un problema",
				"reportBugDescription": "Abre una incidencia en GitHub o envía tus comentarios.",
				"issues": "GitHub Issues",
				"docs": "Documentación",
				"docsDescription": "Consulta las guías de configuración, vinculación, gestión de descargas y resolución de problemas.",
				"copyDiagnostics": "Copiar diagnóstico",
				"copied": "Copiado",
				"diagnostics": "Diagnóstico",
				"diagnosticsDescription": "Ajusta el registro y copia información útil para resolver problemas."
			},
			"about": {
				"subtitle": "Descarga archivos de la web con Motrix",
				"website": "Sitio web oficial"
			},
			"title": "Ajustes de la extensión Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Este equipo",
				"choose": "Elegir servicio de Motrix",
				"configureServer": "Gestionar Motrix Servers",
				"notConfigured": "Sin configurar",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "motor: {{state}}",
				"noDownloads": "Sin descargas",
				"pause": "Pausar",
				"remove": "Quitar",
				"resume": "Reanudar",
				"statsSummary": "En curso: {{active}} · En espera: {{waiting}}"
			},
			"dashboard": {
				"activity": "Actividad",
				"resources": "Recursos",
				"showResources": "Mostrar recursos de esta página",
				"showTasks": "Mostrar tareas activas",
				"title": "Resumen de transferencias"
			},
			"loading": "Cargando…",
			"quickSettings": {
				"fullSettings": "Todos los ajustes",
				"fullSettingsDescription": "General, descargas, servicio y ayuda",
				"loadError": "Error al cargar los ajustes rápidos.",
				"notificationsDescription": "Gestionar notificaciones del sistema de la extensión",
				"retry": "Reintentar",
				"saveError": "Error al guardar el ajuste. Reinténtalo.",
				"takeoverDescription": "Enviar descargas del navegador al servicio Motrix actual"
			},
			"quickAdd": {
				"title": "Nueva tarea",
				"description": "Pega un enlace HTTP, HTTPS o magnet.",
				"inputLabel": "Dirección de descarga",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Cancelar",
				"add": "Añadir",
				"submitting": "Añadiendo…",
				"error": {
					"empty": "Introduce una dirección de descarga.",
					"unsupported": "Solo se admiten enlaces HTTP, HTTPS o magnet.",
					"invalid": "La dirección de descarga no es válida.",
					"submitFailed": "No se pudo añadir la tarea. Reinténtalo."
				}
			},
			"reconnect": "Conectar",
			"settings": "Abrir ajustes",
			"sniffer": {
				"clearFilters": "Borrar filtros",
				"detected": "Elementos: {{count}}",
				"downloadCount": "Descargar ({{count}})",
				"downloadSelected": "Descargar selección",
				"downloadedResource": "Enviado: {{name}}",
				"downloadingResource": "Descargando {{name}}",
				"emptyDescription": "Reproduce multimedia y reinténtalo.",
				"emptyFilter": "Sin recursos coincidentes",
				"emptyTitle": "Sin contenido multimedia",
				"filteredCount": "{{matched}} / {{total}} imágenes",
				"filters": {
					"all": "Todo",
					"audio": "Audio",
					"image": "Imágenes",
					"video": "Vídeo"
				},
				"imageFilters": {
					"activeCount": "Filtros activos: {{count}}",
					"dimensions": "Dimensiones y tamaño",
					"done": "Listo",
					"fields": {
						"height": "Alto",
						"size": "Tamaño",
						"width": "Ancho"
					},
					"formatOptionLabel": "Filtrar imágenes {{format}}",
					"formats": "Formato de imagen",
					"operatorLabel": "Comparación de {{label}}",
					"reset": "Restablecer",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Unidad de tamaño de archivo",
					"title": "Filtros rápidos",
					"trigger": "Filtrar",
					"valueLabel": "Valor de {{label}}"
				},
				"imageCount": "Imágenes: {{count}}",
				"noImageMatches": "No hay imágenes coincidentes",
				"pageAction": {
					"bilibili": "Enviar este vídeo de bilibili",
					"youtube": "Enviar este vídeo de YouTube"
				},
				"pageSubmitted": "Vídeo enviado a Motrix {{taskId}}",
				"pageResources": "Recursos",
				"quickDownloadResource": "Descarga rápida de {{name}}",
				"connectToSubmit": "Conéctate a Motrix para enviar recursos.",
				"scan": "Volver a analizar",
				"scanning": "Analizando…",
				"selectAll": "Seleccionar todo",
				"selected": "Seleccionados: {{count}}",
				"selectResource": "Seleccionar {{name}}",
				"sourceHost": "Origen: {{host}}",
				"sendResource": "Enviar {{name}} a Motrix",
				"sent": "Enviado",
				"sending": "Enviando",
				"submitFailed": "No se pudo enviar el recurso. Reinténtalo.",
				"title": "Detectar recursos",
				"unavailableDescription": "Cambia de página o inténtalo más tarde.",
				"unavailableTitle": "No se puede analizar la página",
				"unsupported": "Requiere ffmpeg",
				"unsupportedReason": "El servicio seleccionado no puede enviar recursos de tipo {{kind}} porque no dispone de compatibilidad con ffmpeg.",
				"unsupportedSelectionReason": "El servicio seleccionado no puede enviar uno o más de los tipos de recursos seleccionados.",
				"unsupportedResource": "No se puede enviar {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Descarga",
				"upload": "Subida"
			},
			"status": {
				"bootstrapping": "Buscando Motrix…",
				"connected": "Conectado",
				"connecting": "Conectando…",
				"denied": "Vinculación rechazada",
				"disconnected": "Desconectado",
				"handshaking": "Negociando conexión",
				"awaiting-code": "Esperando el código de vinculación…"
			},
			"tabs": {
				"settings": "Ajustes",
				"sniffer": "Recursos",
				"tasks": "Tareas"
			},
			"takeover": {
				"aria": "Alternar gestión de descargas",
				"label": "Interceptar"
			},
			"tasks": {
				"actions": "Acciones para {{name}}",
				"openFolder": "Abrir carpeta contenedora en Motrix",
				"openFolderError": "No se pudo abrir la carpeta de la tarea. Reinténtalo.",
				"openFolderMetadataPending": "Espera los metadatos de la tarea antes de abrir la carpeta",
				"openFolderTask": "Abrir la carpeta que contiene {{name}}",
				"openFolderUnsupported": "Actualiza Motrix para abrir carpetas",
				"pauseTask": "Pausar {{name}}",
				"removeTask": "Quitar {{name}}",
				"removeConfirmTitle": "¿Quitar tarea?",
				"removeConfirmDescription": "Se quitará «{{name}}» de la lista de descargas.",
				"removeDeleteFilesLabel": "Eliminar los archivos descargados",
				"removeConfirmAction": "Quitar",
				"resumeTask": "Reanudar {{name}}",
				"bytes": "{{done}} de {{total}}",
				"disconnectedDescription": "Conéctate para ver las tareas.",
				"disconnectedTitle": "Motrix está sin conexión",
				"empty": {
					"active": "Sin tareas activas",
					"failed": "Sin tareas fallidas",
					"recent": "Sin tareas completadas"
				},
				"filters": {
					"active": "En curso",
					"failed": "Fallidas",
					"recent": "Completadas"
				},
				"loading": "Cargando tareas",
				"status": {
					"completed": "Completadas",
					"downloading": "Descargando",
					"error": "Fallidas",
					"fetching_metadata": "Obteniendo metadatos",
					"finalizing": "Finalizando",
					"paused": "En pausa",
					"queued": "En cola",
					"seeding": "Compartiendo"
				},
				"title": "Tareas"
			},
			"pairing": {
				"attemptOf": "Intento {{run}} de {{maxRuns}}",
				"attemptsRemaining": "Intentos restantes: {{attemptsRemaining}}",
				"codeLabel": "Código de vinculación",
				"codeDescription": "Introduce el código de 8 caracteres del diálogo de vinculación de Motrix.",
				"codeInvalid": "Introduce el código de 8 caracteres del diálogo de vinculación.",
				"dialogTitle": "Introducir código de vinculación",
				"dismissPrompt": "Introducir después y seguir navegando",
				"enterCode": "Introducir código de vinculación",
				"expiresIn": "Caduca en {{time}}",
				"pairButton": "Vincular",
				"pickerHelp": "Se encontraron varias instancias de Motrix. Elige una para vincularla.",
				"rescan": "Volver a buscar",
				"noCandidates": "No se encontró ninguna instancia de Motrix.",
				"candidatesLabel": "Instancias de Motrix detectadas",
				"candidatePort": "Puerto {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "versión desconocida",
				"choose": "Elegir",
				"backoffTitle": "Demasiados intentos de vinculación",
				"backoffBody": "Inténtalo de nuevo a las {{time}}.",
				"retryIn": "Reintentar en {{seconds}} s",
				"permissionMissingTitle": "Se necesita permiso",
				"permissionMissingBody": "Permite el acceso a localhost para detectar Motrix en este equipo.",
				"grantPermission": "Conceder permiso",
				"degradedTitle": "Motrix está conectado",
				"degradedBody": "Puedes usar Motrix con normalidad. Esta conexión solo tiene verificación básica. Para una mayor protección, actualiza Motrix y vuelve a vincularlo.",
				"recoveryExhaustedTitle": "No se pudo reconectar automáticamente",
				"recoveryExhaustedBody": "Ninguna de las vinculaciones guardadas de Motrix funcionó. Pulsa Conectar para volver a vincularlo."
			}
		},
		errors: { "connection": {
			"generic": "La conexión falló. Reinténtalo.",
			"backoffLocked": "Demasiados intentos de vinculación. Inténtalo más tarde.",
			"staleAttempt": "Un intento de conexión más reciente sustituyó a este.",
			"aborted": "Se canceló la vinculación.",
			"deadlineExceeded": "Se agotó el tiempo de espera. Reinténtalo.",
			"runsExhausted": "Demasiados códigos incorrectos. Inicia de nuevo la vinculación para obtener otro código.",
			"invalidCode": "El código no tiene el formato esperado. Revisa el diálogo de Motrix.",
			"missingNonce": "Motrix no ofreció una sesión de vinculación. Comprueba que esté en ejecución e reinténtalo.",
			"unsupportedBrowser": "Este navegador no admite la vinculación.",
			"ticketPreparationFailed": "No se pudo preparar la vinculación. Reinténtalo.",
			"protocolViolation": "Motrix envió una respuesta inesperada. Reinténtalo.",
			"unsupportedVersion": "La extensión y Motrix usan versiones distintas del protocolo. Actualiza ambos e reinténtalo.",
			"backendUpgradeRequired": "Esta versión de Motrix es demasiado antigua para una vinculación segura. Actualiza Motrix e reinténtalo.",
			"extensionUpgradeRequired": "Esta versión de la extensión es demasiado antigua para este Motrix. Actualiza la extensión Motrix e reinténtalo.",
			"unsupportedRemote": "El Motrix autenticado no es la App ni el Server seleccionado para esta conexión. Revisa el destino e reinténtalo.",
			"remoteDiscoveryUnavailable": "No se pudo acceder al Motrix Server remoto. Revisa la dirección, el servicio de escucha y la red; para WSS, revisa también el certificado y el proxy inverso.",
			"remotePairingUnavailable": "El Motrix Server remoto no pudo abrir una sesión de vinculación segura. Inténtalo en unos instantes.",
			"remoteTransportUnavailable": "Falló la conexión con el Motrix Server remoto. Revisa la dirección, el servicio de escucha, el DNS y la red; para WSS, revisa también el certificado y el proxy inverso. El navegador no puede identificar cuál falló.",
			"peerRejected": "Motrix rechazó la vinculación.",
			"peerBusy": "Motrix está procesando demasiadas solicitudes de vinculación. Inténtalo en unos instantes.",
			"securityCheckFailed": "La conexión no superó una comprobación de seguridad y se detuvo.",
			"peerNotAuthentic": "El otro extremo no pudo demostrar que es tu Motrix. Se detuvo la conexión.",
			"credentialPhaseFailed": "No se pudo guardar la vinculación. Intenta vincular de nuevo.",
			"internalError": "Se produjo un error en la extensión. Reinténtalo.",
			"authFailed": "Motrix no reconoció esta vinculación. Es posible que se haya revocado; vuelve a vincularlo.",
			"serverMacMismatch": "La respuesta no superó la verificación y se detuvo la conexión. Puede que no sea tu Motrix.",
			"channelClosed": "Se cerró la conexión. Vuelve a conectarte para continuar.",
			"channelUnavailable": "No se puede acceder a Motrix ahora. Comprueba que esté en ejecución."
		} }
	} },
	fr: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix : connecté",
			"disconnected": "Motrix : non connecté",
			"connecting": "Motrix : connexion…",
			"downloading": "Motrix : téléchargement en cours",
			"denied": "Motrix : association refusée — ouvrir pour réassocier",
			"error": "Motrix : transfert échoué — cliquer pour les détails"
		} },
		contextMenu: {
			"downloadWithMotrix": "Télécharger avec Motrix",
			"pairThenDownload": "Associer Motrix, puis télécharger"
		},
		notify: {
			"browserFallbackBody": "Motrix est indisponible. Le navigateur prend en charge le téléchargement.",
			"browserFallbackTitle": "Téléchargement dans le navigateur",
			"downloadComplete": "Téléchargement terminé",
			"downloadFailed": "Échec du téléchargement",
			"handedToMotrix": "Transmis à Motrix",
			"notConnectedBody": "Associez Motrix pour lui confier les téléchargements.",
			"notConnectedTitle": "Motrix non connecté",
			"notReachableBody": "Associez Motrix, puis réessayez le téléchargement.",
			"notReachableTitle": "Motrix inaccessible",
			"pairNudgeBody": "Ouvrez Motrix pour terminer l’association.",
			"pairNudgeTitle": "Associer Motrix",
			"pairRevokedBody": "Motrix a révoqué l’association de ce navigateur.",
			"pairRevokedTitle": "Association révoquée",
			"sensitiveSkippedBody": "Le téléchargement du site sensible reste dans le navigateur.",
			"sensitiveSkippedTitle": "Ignoré",
			"submitFailedBody": "Relance du téléchargement dans le navigateur.",
			"submitFailedTitle": "Échec de l’envoi à Motrix"
		},
		options: {
			"diagnostics": {
				"adapters": "Adaptateurs",
				"extensionId": "Identifiant de l’extension",
				"logLevel": "Niveau de journalisation",
				"logLevels": {
					"silent": "Aucun",
					"error": "Erreur",
					"warn": "Avertissement",
					"info": "Information",
					"debug": "Débogage"
				},
				"noneRegistered": "Aucun enregistré",
				"title": "Diagnostic",
				"version": "Version"
			},
			"endpoint": {
				"activate": "Utiliser",
				"activateAria": "Utiliser {{name}}",
				"connection": {
					"bootstrapping": "Démarrage",
					"connected": "Connecté",
					"connecting": "Connexion",
					"denied": "Refusé",
					"disconnected": "Déconnecté",
					"handshaking": "Autorisation",
					"awaiting-code": "En attente du code"
				},
				"currentDescription": "Choisissez une App ou un Server pour les téléchargements, les tâches et les ressources détectées sur les pages.",
				"currentTitle": "Services Motrix",
				"listLabel": "Services Motrix disponibles",
				"localDescription": "Cet ordinateur, détecté via Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Envoyer les téléchargements vers"
			},
			"language": {
				"label": "Langue",
				"system": "Suivre le système"
			},
			"notifications": {
				"title": "Notifications système",
				"masterLabel": "Activer les notifications système",
				"masterAria": "Activer les notifications système",
				"confirmLabel": "Réussites / confirmations",
				"confirmDesc": "Transmission à Motrix, téléchargement terminé",
				"errorLabel": "Échecs / erreurs",
				"errorDesc": "Échec d’envoi, service inaccessible, échec de téléchargement",
				"reminderLabel": "Rappels",
				"reminderDesc": "Demandes d’association, association révoquée, sites ignorés"
			},
			"pairing": {
				"backendTitle": "Association de {{name}}",
				"forget": "Oublier l’association",
				"loading": "Chargement de l’état d’association…",
				"localHelp": "Cliquez sur Associer pour détecter Motrix sur cet ordinateur, puis saisissez son code d’association.",
				"localTitle": "Associer via Motrix App",
				"remoteTitle": "Associer à Motrix Server",
				"remoteHelp": "Cliquez sur Associer, confirmez la demande dans l’interface d’administration du Server, puis saisissez ici le code affiché. WS et WSS sont pris en charge ; WSS est recommandé.",
				"serverRequiredTitle": "Motrix Server requis",
				"serverRequiredHelp": "Firefox pour Android se connecte via Motrix Server. Ajoutez un Server ci-dessus, puis sélectionnez-le pour l’associer.",
				"remoteConsentTitle": "Téléchargements distants",
				"remoteConsentBody": "Les téléchargements distants transmettent à ce Server l’URL cible, l’URL et le titre de la page source, le nom du fichier, la sélection et les commandes des tâches. Les cookies et les en-têtes de requête ne sont envoyés que s’ils sont activés séparément.",
				"remoteConsentOffline": "Les autorisations de données sont liées au Server authentifié. Connectez-vous avant de les modifier.",
				"remoteHeadersLabel": "Envoyer les en-têtes de requête",
				"remoteHeadersHelp": "Autorise les en-têtes issus des pages, comme Referer et les en-têtes de lecture multimédia. Les en-têtes d’authentification nécessitent toujours l’autorisation d’identifiants ci-dessous.",
				"remoteCredentialsLabel": "Envoyer les cookies et l’authentification",
				"remoteCredentialsHelp": "Autorise les cookies et les en-têtes d’identifiants pour ce Server uniquement. À activer uniquement pour un Server que vous contrôlez.",
				"notPaired": "Non associé",
				"paired": "Associé à Motrix",
				"pairedHelp": "Un identifiant MBP1 confirmé est conservé pour ce service. L’état actuel de la connexion est affiché séparément.",
				"pairedTitle": "Association prête",
				"reconnect": "Reconnecter",
				"scopedHelp": "La confiance et les identifiants d’association sont propres à chaque service. Changer de service ne réutilise jamais la confiance accordée à un autre.",
				"pair": "Associer",
				"pairDialogTitle": "Associer à Motrix"
			},
			"servers": {
				"add": "Ajouter un serveur",
				"addTitle": "Ajouter Motrix Server",
				"current": "Actuel",
				"delete": "Supprimer le serveur",
				"deleteActiveDescription": "Supprimer {{name}}, ses identifiants d’association et ses consentements stockés localement ? Motrix App sera à nouveau sélectionné, sans connexion ni lancement.",
				"deleteActiveServerOnlyDescription": "Supprimer {{name}}, ses identifiants d’association et ses consentements stockés localement ? Vous devrez ajouter ou sélectionner un autre Motrix Server avant de télécharger.",
				"deleteAria": "Supprimer {{name}}",
				"deleteDescription": "Supprimer {{name}}, ses identifiants d’association et ses consentements stockés localement ? Cela ne révoque rien sur le serveur.",
				"deleteTitle": "Supprimer Motrix Server ?",
				"description": "Enregistrez plusieurs adresses Motrix Server et passez de l’une à l’autre depuis les options ou la fenêtre contextuelle.",
				"dialogDescription": "Donnez un nom reconnaissable à ce service et saisissez son URL de base WebSocket.",
				"editAria": "Modifier {{name}}",
				"editTitle": "Modifier Motrix Server",
				"emptyDescription": "Ajoutez un serveur pour vous connecter à Motrix sur une autre machine.",
				"emptyTitle": "Aucun Motrix Server ajouté",
				"footer": "Changer l’adresse d’un serveur nécessite une nouvelle association. Les informations d’association ne sont jamais partagées entre les adresses.",
				"nameLabel": "Nom du serveur",
				"namePlaceholder": "Serveur domestique",
				"nameRequired": "Le nom du serveur est requis",
				"save": "Enregistrer le serveur",
				"statusAuthority": "Adresse du serveur : {{value}}",
				"statusRuntime": "Version de Motrix : {{name}} {{version}}",
				"statusTitle": "Informations du serveur",
				"statusTransportSecure": "Sécurité de la connexion : WSS est utilisé et TLS vérifie l’identité du serveur",
				"statusTransportPlain": "Sécurité de la connexion : chiffrée, mais WS ne peut pas vérifier l’identité du serveur et peut exposer des informations de connexion. WSS est recommandé",
				"title": "Serveurs Motrix",
				"urlDescription": "Utilisez une URL de base ws:// ou wss://. Le chemin facultatif est conservé comme préfixe exact du proxy inverse ; WSS est recommandé.",
				"urlDuplicate": "Cette adresse Motrix Server est déjà enregistrée",
				"urlInvalid": "Saisissez une URL de base ws:// ou wss:// valide, sans espace, identifiants, réglages de requête ni fragment",
				"urlLabel": "URL WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Cette connexion n’utilise pas WSS",
				"transportWarningBody": "Le contenu échangé avec Motrix reste chiffré, mais WS ne peut pas vérifier l’identité du serveur et peut exposer des informations de connexion. Utilisez WSS si votre NAS le prend en charge.",
				"urlRequired": "L’URL WebSocket est requise"
			},
			"takeover": {
				"consentBody": "Motrix reçoit les cookies de connexion du site pour télécharger les fichiers. Les téléchargements des sites sensibles restent dans le navigateur.",
				"consentCancel": "Annuler",
				"consentConfirm": "Activer",
				"consentDialogLabel": "Envoyer les téléchargements à Motrix ?",
				"denylistLabel": "Liste d’exclusion (un hôte par ligne — toujours laissé au navigateur)",
				"enableAria": "Activer la prise en charge",
				"enableLabel": "Envoyer les téléchargements compatibles à Motrix",
				"loading": "Chargement des réglages de prise en charge…",
				"minSizeLabel": "Taille minimale (Mo)",
				"minSizePlaceholder": "0 = tous",
				"thresholdInvalid": "La taille minimale doit être un nombre positif ou nul",
				"save": "Enregistrer",
				"saved": "Enregistré",
				"title": "Prise en charge des téléchargements",
				"remoteUnavailable": "La prise en charge automatique nécessite actuellement Motrix App en local. Les téléchargements distants et les autorisations d’en-têtes ou de cookies ne l’activent pas. Vous pouvez toujours envoyer des téléchargements à ce Server manuellement ou par le menu contextuel.",
				"availabilityUnknown": "La prise en charge reste indisponible tant que le service sélectionné ne peut pas être vérifié.",
				"remoteUnavailableShort": "App locale uniquement. L’envoi par clic droit fonctionne avec les Servers."
			},
			"tabs": {
				"general": "Général",
				"download": "Téléchargements",
				"integration": "Intégration",
				"help": "Aide"
			},
			"common": {
				"apply": "Appliquer",
				"cancel": "Annuler",
				"loadError": "Impossible de charger les réglages : le processus d’arrière-plan de l’extension n’a pas démarré. Rechargez l’extension et réessayez.",
				"saved": "Enregistré",
				"saving": "Enregistrement…",
				"saveError": "Échec de l’enregistrement"
			},
			"appearance": {
				"title": "Apparence",
				"theme": {
					"label": "Thème",
					"system": "Suivre le système",
					"light": "Clair",
					"dark": "Sombre"
				}
			},
			"help": {
				"title": "Aide et assistance",
				"description": "Consultez guides, aide et diagnostic de l’extension.",
				"reportBug": "Signaler un problème",
				"reportBugDescription": "Ouvrez un ticket sur GitHub ou partagez vos commentaires.",
				"issues": "GitHub Issues",
				"docs": "Documentation",
				"docsDescription": "Consultez les guides de configuration, d’association, de prise en charge des téléchargements et de dépannage.",
				"copyDiagnostics": "Copier le diagnostic",
				"copied": "Copié",
				"diagnostics": "Diagnostic",
				"diagnosticsDescription": "Réglez la journalisation et copiez les informations utiles au dépannage."
			},
			"about": {
				"subtitle": "Téléchargez des fichiers du Web avec Motrix",
				"website": "Site officiel"
			},
			"title": "Réglages de l’extension Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Cet ordinateur",
				"choose": "Choisir un service Motrix",
				"configureServer": "Gérer les Motrix Servers",
				"notConfigured": "Non configuré",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "moteur : {{state}}",
				"noDownloads": "Aucun téléchargement",
				"pause": "Suspendre",
				"remove": "Retirer",
				"resume": "Reprendre",
				"statsSummary": "En cours : {{active}} · En attente : {{waiting}}"
			},
			"dashboard": {
				"activity": "Activité",
				"resources": "Ressources",
				"showResources": "Afficher les ressources de cette page",
				"showTasks": "Afficher les tâches actives",
				"title": "Vue d’ensemble des transferts"
			},
			"loading": "Chargement…",
			"quickSettings": {
				"fullSettings": "Tous les réglages",
				"fullSettingsDescription": "Général, téléchargements, service et aide",
				"loadError": "Échec du chargement des réglages rapides.",
				"notificationsDescription": "Gérer les notifications système de l’extension",
				"retry": "Réessayer",
				"saveError": "Échec de l’enregistrement du réglage. Réessayez.",
				"takeoverDescription": "Envoyer les téléchargements du navigateur au service Motrix actuel"
			},
			"quickAdd": {
				"title": "Nouvelle tâche",
				"description": "Collez un lien HTTP, HTTPS ou magnet.",
				"inputLabel": "Adresse de téléchargement",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Annuler",
				"add": "Ajouter",
				"submitting": "Ajout…",
				"error": {
					"empty": "Saisissez une adresse de téléchargement.",
					"unsupported": "Seuls les liens HTTP, HTTPS ou magnet sont pris en charge.",
					"invalid": "L’adresse de téléchargement est invalide.",
					"submitFailed": "Impossible d’ajouter la tâche. Réessayez."
				}
			},
			"reconnect": "Connecter",
			"settings": "Ouvrir les réglages",
			"sniffer": {
				"clearFilters": "Effacer les filtres",
				"detected": "Éléments : {{count}}",
				"downloadCount": "Télécharger ({{count}})",
				"downloadSelected": "Télécharger la sélection",
				"downloadedResource": "{{name}} envoyé",
				"downloadingResource": "Téléchargement de {{name}}",
				"emptyDescription": "Lisez un média, puis réessayez.",
				"emptyFilter": "Aucune ressource correspondante",
				"emptyTitle": "Aucun média",
				"filteredCount": "{{matched}} / {{total}} images",
				"filters": {
					"all": "Tout",
					"audio": "Audio",
					"image": "Images",
					"video": "Vidéo"
				},
				"imageFilters": {
					"activeCount": "Filtres actifs : {{count}}",
					"dimensions": "Dimensions et taille",
					"done": "Terminé",
					"fields": {
						"height": "Hauteur",
						"size": "Taille",
						"width": "Largeur"
					},
					"formatOptionLabel": "Filtrer les images {{format}}",
					"formats": "Format d’image",
					"operatorLabel": "Comparaison pour {{label}}",
					"reset": "Réinitialiser",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Unité de taille du fichier",
					"title": "Filtres rapides",
					"trigger": "Filtrer",
					"valueLabel": "Valeur de {{label}}"
				},
				"imageCount": "Images : {{count}}",
				"noImageMatches": "Aucune image correspondante",
				"pageAction": {
					"bilibili": "Envoyer cette vidéo bilibili",
					"youtube": "Envoyer cette vidéo YouTube"
				},
				"pageSubmitted": "Vidéo envoyée à Motrix {{taskId}}",
				"pageResources": "Ressources",
				"quickDownloadResource": "Téléchargement rapide de {{name}}",
				"connectToSubmit": "Connectez-vous à Motrix pour envoyer des ressources.",
				"scan": "Analyser à nouveau",
				"scanning": "Analyse…",
				"selectAll": "Tout sélectionner",
				"selected": "Sélection : {{count}}",
				"selectResource": "Sélectionner {{name}}",
				"sourceHost": "Source : {{host}}",
				"sendResource": "Envoyer {{name}} à Motrix",
				"sent": "Envoyé",
				"sending": "Envoi",
				"submitFailed": "Impossible d’envoyer la ressource. Réessayez.",
				"title": "Détection de ressources",
				"unavailableDescription": "Changez de page ou réessayez plus tard.",
				"unavailableTitle": "Impossible d’analyser cette page",
				"unsupported": "Nécessite ffmpeg",
				"unsupportedReason": "Le service sélectionné ne peut pas envoyer les ressources {{kind}}, car la prise en charge de ffmpeg est indisponible.",
				"unsupportedSelectionReason": "Le service sélectionné ne peut pas envoyer un ou plusieurs types de ressources sélectionnés.",
				"unsupportedResource": "Impossible d’envoyer {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Téléchargement",
				"upload": "Envoi"
			},
			"status": {
				"bootstrapping": "Recherche de Motrix…",
				"connected": "Connecté",
				"connecting": "Connexion…",
				"denied": "Association refusée",
				"disconnected": "Déconnecté",
				"handshaking": "Négociation en cours",
				"awaiting-code": "En attente du code d’association…"
			},
			"tabs": {
				"settings": "Réglages",
				"sniffer": "Ressources",
				"tasks": "Tâches"
			},
			"takeover": {
				"aria": "Basculer la prise en charge des téléchargements",
				"label": "Intercepter"
			},
			"tasks": {
				"actions": "Actions pour {{name}}",
				"openFolder": "Ouvrir le dossier contenant le fichier dans Motrix",
				"openFolderError": "Impossible d’ouvrir le dossier de la tâche. Réessayez.",
				"openFolderMetadataPending": "Attendez les métadonnées de la tâche avant d’ouvrir le dossier",
				"openFolderTask": "Ouvrir le dossier contenant {{name}}",
				"openFolderUnsupported": "Mettez Motrix à jour pour ouvrir les dossiers",
				"pauseTask": "Suspendre {{name}}",
				"removeTask": "Retirer {{name}}",
				"removeConfirmTitle": "Retirer la tâche ?",
				"removeConfirmDescription": "« {{name}} » sera retiré de la liste des téléchargements.",
				"removeDeleteFilesLabel": "Supprimer les fichiers téléchargés",
				"removeConfirmAction": "Retirer",
				"resumeTask": "Reprendre {{name}}",
				"bytes": "{{done}} sur {{total}}",
				"disconnectedDescription": "Connectez-vous pour voir les tâches.",
				"disconnectedTitle": "Motrix est hors ligne",
				"empty": {
					"active": "Aucune tâche active",
					"failed": "Aucune tâche en échec",
					"recent": "Aucune tâche terminée"
				},
				"filters": {
					"active": "En cours",
					"failed": "En échec",
					"recent": "Terminées"
				},
				"loading": "Chargement des tâches",
				"status": {
					"completed": "Terminées",
					"downloading": "Téléchargement",
					"error": "En échec",
					"fetching_metadata": "Récupération des métadonnées",
					"finalizing": "Finalisation",
					"paused": "En pause",
					"queued": "En attente",
					"seeding": "Partage"
				},
				"title": "Tâches"
			},
			"pairing": {
				"attemptOf": "Tentative {{run}} sur {{maxRuns}}",
				"attemptsRemaining": "Tentatives restantes : {{attemptsRemaining}}",
				"codeLabel": "Code d’association",
				"codeDescription": "Saisissez le code à 8 caractères du dialogue d’association Motrix.",
				"codeInvalid": "Saisissez le code à 8 caractères du dialogue d’association.",
				"dialogTitle": "Saisir le code d’association",
				"dismissPrompt": "Saisir plus tard et continuer à naviguer",
				"enterCode": "Saisir le code d’association",
				"expiresIn": "Expire dans {{time}}",
				"pairButton": "Associer",
				"pickerHelp": "Plusieurs instances de Motrix ont été trouvées. Choisissez celle à associer.",
				"rescan": "Relancer la recherche",
				"noCandidates": "Aucune instance de Motrix trouvée.",
				"candidatesLabel": "Instances de Motrix détectées",
				"candidatePort": "Port {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "version inconnue",
				"choose": "Choisir",
				"backoffTitle": "Trop de tentatives d’association",
				"backoffBody": "Réessayez à {{time}}.",
				"retryIn": "Réessayer dans {{seconds}} s",
				"permissionMissingTitle": "Autorisation nécessaire",
				"permissionMissingBody": "Autorisez l’accès à localhost pour détecter Motrix sur cet ordinateur.",
				"grantPermission": "Accorder l’autorisation",
				"degradedTitle": "Motrix est connecté",
				"degradedBody": "Vous pouvez utiliser Motrix normalement. Cette connexion ne dispose que d’une vérification de base. Pour une meilleure protection, mettez Motrix à jour et associez-le à nouveau.",
				"recoveryExhaustedTitle": "Reconnexion automatique impossible",
				"recoveryExhaustedBody": "Aucune association Motrix enregistrée n’a fonctionné. Appuyez sur Connecter pour réassocier Motrix."
			}
		},
		errors: { "connection": {
			"generic": "La connexion a échoué. Réessayez.",
			"backoffLocked": "Trop de tentatives d’association. Réessayez plus tard.",
			"staleAttempt": "Une tentative de connexion plus récente a pris le relais.",
			"aborted": "L’association a été annulée.",
			"deadlineExceeded": "Le délai de la tentative est dépassé. Réessayez.",
			"runsExhausted": "Trop de codes incorrects. Relancez l’association pour obtenir un nouveau code.",
			"invalidCode": "Le format du code est incorrect. Vérifiez la boîte de dialogue Motrix.",
			"missingNonce": "Motrix n’a pas proposé de session d’association. Vérifiez qu’il est en cours d’exécution, puis réessayez.",
			"unsupportedBrowser": "Ce navigateur ne prend pas en charge l’association.",
			"ticketPreparationFailed": "Impossible de préparer l’association. Réessayez.",
			"protocolViolation": "Motrix a envoyé une réponse inattendue. Réessayez.",
			"unsupportedVersion": "Cette extension et Motrix utilisent des versions de protocole différentes. Mettez les deux à jour, puis réessayez.",
			"backendUpgradeRequired": "Cette version de Motrix est trop ancienne pour une association sécurisée. Mettez Motrix à jour, puis réessayez.",
			"extensionUpgradeRequired": "Cette version de l’extension est trop ancienne pour ce Motrix. Mettez l’extension Motrix à jour, puis réessayez.",
			"unsupportedRemote": "Le Motrix authentifié n’est pas l’App ou le Server sélectionné pour cette connexion. Vérifiez le point de connexion et réessayez.",
			"remoteDiscoveryUnavailable": "Le Motrix Server distant est inaccessible. Vérifiez son adresse, son service d’écoute et le réseau ; pour WSS, vérifiez aussi le certificat et le proxy inverse.",
			"remotePairingUnavailable": "Le Motrix Server distant n’a pas pu ouvrir de session d’association sécurisée. Réessayez dans un instant.",
			"remoteTransportUnavailable": "La connexion au Motrix Server distant a échoué. Vérifiez son adresse, son service d’écoute, le DNS et le réseau ; pour WSS, vérifiez aussi le certificat et le proxy inverse. Le navigateur ne peut pas identifier l’élément en cause.",
			"peerRejected": "Motrix a refusé l’association.",
			"peerBusy": "Motrix traite trop de demandes d’association. Réessayez dans un instant.",
			"securityCheckFailed": "La connexion a échoué à un contrôle de sécurité et a été interrompue.",
			"peerNotAuthentic": "Le correspondant n’a pas pu prouver qu’il s’agit de votre Motrix. La connexion a été interrompue.",
			"credentialPhaseFailed": "Impossible d’enregistrer l’association. Réessayez de l’associer.",
			"internalError": "Une erreur s’est produite dans l’extension. Réessayez.",
			"authFailed": "Motrix n’a pas reconnu cette association. Elle a peut-être été révoquée ; associez-le à nouveau.",
			"serverMacMismatch": "La réponse n’a pas pu être vérifiée et la connexion a été interrompue. Il ne s’agit peut-être pas de votre Motrix.",
			"channelClosed": "La connexion a été fermée. Reconnectez-vous pour continuer.",
			"channelUnavailable": "Motrix est actuellement inaccessible. Vérifiez qu’il est en cours d’exécution."
		} }
	} },
	hi: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: कनेक्ट है",
			"disconnected": "Motrix: कनेक्ट नहीं है",
			"connecting": "Motrix: कनेक्ट हो रहा है…",
			"downloading": "Motrix: डाउनलोड हो रहा है",
			"denied": "Motrix: पेयरिंग अस्वीकार हुई — दोबारा पेयर करने के लिए खोलें",
			"error": "Motrix: भेजना विफल हुआ — विवरण के लिए क्लिक करें"
		} },
		contextMenu: {
			"downloadWithMotrix": "Motrix से डाउनलोड करें",
			"pairThenDownload": "Motrix को पेयर करें, फिर डाउनलोड करें"
		},
		notify: {
			"browserFallbackBody": "Motrix उपलब्ध नहीं है। डाउनलोड अब ब्राउज़र करेगा।",
			"browserFallbackTitle": "ब्राउज़र में डाउनलोड हो रहा है",
			"downloadComplete": "डाउनलोड पूरा हुआ",
			"downloadFailed": "डाउनलोड विफल हुआ",
			"handedToMotrix": "Motrix को भेज दिया गया",
			"notConnectedBody": "डाउनलोड संभालने के लिए Motrix को पेयर करें।",
			"notConnectedTitle": "Motrix कनेक्ट नहीं है",
			"notReachableBody": "Motrix को पेयर करें, फिर डाउनलोड दोबारा आज़माएँ।",
			"notReachableTitle": "Motrix से संपर्क नहीं हो पा रहा",
			"pairNudgeBody": "पेयरिंग पूरी करने के लिए Motrix खोलें।",
			"pairNudgeTitle": "Motrix को पेयर करें",
			"pairRevokedBody": "Motrix ने इस ब्राउज़र की पेयरिंग रद्द कर दी है।",
			"pairRevokedTitle": "पेयरिंग रद्द कर दी गई",
			"sensitiveSkippedBody": "संवेदनशील साइट का डाउनलोड ब्राउज़र को सौंप दिया गया।",
			"sensitiveSkippedTitle": "छोड़ दिया गया",
			"submitFailedBody": "ब्राउज़र में दोबारा डाउनलोड हो रहा है।",
			"submitFailedTitle": "Motrix को भेजना विफल हुआ"
		},
		options: /* @__PURE__ */ JSON.parse("{\"diagnostics\":{\"adapters\":\"अडैप्टर\",\"extensionId\":\"एक्सटेंशन आईडी\",\"logLevel\":\"लॉग स्तर\",\"logLevels\":{\"silent\":\"लॉग बंद\",\"error\":\"त्रुटि\",\"warn\":\"चेतावनी\",\"info\":\"जानकारी\",\"debug\":\"डीबग\"},\"noneRegistered\":\"अभी कोई पंजीकृत नहीं है\",\"title\":\"निदान\",\"version\":\"संस्करण\"},\"endpoint\":{\"activate\":\"इस्तेमाल करें\",\"activateAria\":\"{{name}} इस्तेमाल करें\",\"connection\":{\"bootstrapping\":\"शुरू हो रहा है\",\"connected\":\"कनेक्ट है\",\"connecting\":\"कनेक्ट हो रहा है\",\"denied\":\"अस्वीकार किया गया\",\"disconnected\":\"डिस्कनेक्ट है\",\"handshaking\":\"अनुमति की पुष्टि हो रही है\",\"awaiting-code\":\"कोड का इंतज़ार है\"},\"currentDescription\":\"डाउनलोड, कार्यों और पेज पर मिले संसाधनों के लिए एक App या Server चुनें।\",\"currentTitle\":\"Motrix बैकएंड\",\"listLabel\":\"उपलब्ध Motrix बैकएंड\",\"localDescription\":\"Motrix App के ज़रिए मिला यह कंप्यूटर\",\"localName\":\"Motrix App\",\"selectLabel\":\"डाउनलोड यहाँ भेजें\"},\"language\":{\"label\":\"भाषा\",\"system\":\"सिस्टम के अनुसार\"},\"notifications\":{\"title\":\"सिस्टम सूचनाएँ\",\"masterLabel\":\"सिस्टम सूचनाएँ चालू करें\",\"masterAria\":\"सिस्टम सूचनाएँ चालू करें\",\"confirmLabel\":\"सफलता / पुष्टि\",\"confirmDesc\":\"Motrix को भेजा गया, डाउनलोड पूरा हुआ\",\"errorLabel\":\"विफलताएँ / त्रुटियाँ\",\"errorDesc\":\"भेजना विफल, संपर्क नहीं हो पाया, डाउनलोड विफल\",\"reminderLabel\":\"रिमाइंडर\",\"reminderDesc\":\"पेयरिंग अनुरोध, रद्द की गई पेयरिंग, छोड़ी गई साइटें\"},\"pairing\":{\"backendTitle\":\"{{name}} से पेयरिंग\",\"forget\":\"पेयरिंग भूलें\",\"loading\":\"पेयरिंग स्थिति लोड हो रही है…\",\"localHelp\":\"इस कंप्यूटर पर Motrix खोजने के लिए पेयर करें पर क्लिक करें और उसका पेयरिंग कोड डालें।\",\"localTitle\":\"Motrix App के ज़रिए पेयर करें\",\"remoteTitle\":\"Motrix Server से पेयर करें\",\"remoteHelp\":\"पेयर करें पर क्लिक करें, Server के प्रबंधन इंटरफ़ेस में अनुरोध स्वीकार करें और वहाँ दिखाया गया कोड यहाँ डालें। WS और WSS दोनों एंडपॉइंट समर्थित हैं; WSS की सलाह दी जाती है।\",\"serverRequiredTitle\":\"Motrix Server ज़रूरी है\",\"serverRequiredHelp\":\"Android के लिए Firefox, Motrix Server के ज़रिए कनेक्ट होता है। ऊपर Server जोड़ें, फिर पेयर करने के लिए उसे चुनें।\",\"remoteConsentTitle\":\"रिमोट डाउनलोड\",\"remoteConsentBody\":\"रिमोट डाउनलोड में लक्ष्य URL, स्रोत पेज का URL और शीर्षक, फ़ाइल नाम, चयन और कार्य नियंत्रण इस Server को भेजे जाते हैं। कुकीज़ और अनुरोध हेडर अलग से चालू किए बिना नहीं भेजे जाते।\",\"remoteConsentOffline\":\"डेटा अनुमतियाँ प्रमाणित Server से जुड़ी होती हैं। इन्हें बदलने से पहले कनेक्ट करें।\",\"remoteHeadersLabel\":\"अनुरोध हेडर भेजें\",\"remoteHeadersHelp\":\"पेज से मिले Referer और मीडिया प्लेबैक हेडर जैसे हेडर भेजने की अनुमति देता है। प्रमाणीकरण हेडर के लिए नीचे दी गई क्रेडेंशियल अनुमति अब भी ज़रूरी है।\",\"remoteCredentialsLabel\":\"कुकीज़ और प्रमाणीकरण जानकारी भेजें\",\"remoteCredentialsHelp\":\"केवल इस Server के लिए कुकीज़ और क्रेडेंशियल हेडर की अनुमति देता है। इसे केवल अपने नियंत्रण वाले Server के लिए चालू करें।\",\"notPaired\":\"पेयर नहीं है\",\"paired\":\"Motrix से पेयर है\",\"pairedHelp\":\"इस बैकएंड के लिए पुष्टि किया गया MBP1 क्रेडेंशियल सहेजा गया है। मौजूदा कनेक्शन की स्थिति अलग दिखाई जाती है।\",\"pairedTitle\":\"पेयरिंग तैयार है\",\"reconnect\":\"दोबारा कनेक्ट करें\",\"scopedHelp\":\"पेयरिंग का भरोसा और क्रेडेंशियल हर बैकएंड के लिए अलग हैं। बैकएंड बदलने पर दूसरे बैकएंड का भरोसा कभी इस्तेमाल नहीं होता।\",\"pair\":\"पेयर करें\",\"pairDialogTitle\":\"Motrix से पेयर करें\"},\"servers\":{\"add\":\"सर्वर जोड़ें\",\"addTitle\":\"Motrix Server जोड़ें\",\"current\":\"मौजूदा\",\"delete\":\"सर्वर मिटाएँ\",\"deleteActiveDescription\":\"क्या {{name}} और स्थानीय रूप से सहेजे गए उसके पेयरिंग क्रेडेंशियल व सहमतियाँ मिटाएँ? मौजूदा बैकएंड Motrix App पर लौट जाएगा, लेकिन उसे कनेक्ट या शुरू नहीं किया जाएगा।\",\"deleteActiveServerOnlyDescription\":\"क्या {{name}} और स्थानीय रूप से सहेजे गए उसके पेयरिंग क्रेडेंशियल व सहमतियाँ मिटाएँ? डाउनलोड करने से पहले आपको दूसरा Motrix Server जोड़ना या चुनना होगा।\",\"deleteAria\":\"{{name}} मिटाएँ\",\"deleteDescription\":\"क्या {{name}} और स्थानीय रूप से सहेजे गए उसके पेयरिंग क्रेडेंशियल व सहमतियाँ मिटाएँ? इससे सर्वर पर कुछ भी रद्द नहीं होगा।\",\"deleteTitle\":\"Motrix Server मिटाएँ?\",\"description\":\"कई Motrix Server पते सहेजें और विकल्पों या पॉपअप से उनके बीच स्विच करें।\",\"dialogDescription\":\"इस बैकएंड को पहचानने योग्य नाम दें और उसका WebSocket बेस URL डालें।\",\"editAria\":\"{{name}} संपादित करें\",\"editTitle\":\"Motrix Server संपादित करें\",\"emptyDescription\":\"इस कंप्यूटर से बाहर Motrix से कनेक्ट करने के लिए सर्वर जोड़ें।\",\"emptyTitle\":\"अभी कोई Motrix Server नहीं\",\"footer\":\"सर्वर का पता बदलने पर दोबारा पेयरिंग ज़रूरी है। पेयरिंग जानकारी कभी भी अलग-अलग पतों के बीच साझा नहीं होती।\",\"nameLabel\":\"सर्वर का नाम\",\"namePlaceholder\":\"घर का सर्वर\",\"nameRequired\":\"सर्वर का नाम ज़रूरी है\",\"save\":\"सर्वर सहेजें\",\"statusAuthority\":\"सर्वर का पता: {{value}}\",\"statusRuntime\":\"Motrix संस्करण: {{name}} {{version}}\",\"statusTitle\":\"सर्वर की जानकारी\",\"statusTransportSecure\":\"कनेक्शन सुरक्षा: WSS इस्तेमाल हो रहा है और TLS सर्वर की पहचान सत्यापित करता है\",\"statusTransportPlain\":\"कनेक्शन सुरक्षा: एन्क्रिप्टेड है, लेकिन WS सर्वर की पहचान सत्यापित नहीं कर सकता और कनेक्शन जानकारी उजागर हो सकती है। WSS की सलाह दी जाती है\",\"title\":\"Motrix सर्वर\",\"urlDescription\":\"ws:// या wss:// बेस URL इस्तेमाल करें। वैकल्पिक पाथ रिवर्स प्रॉक्सी प्रीफ़िक्स के रूप में हूबहू रखा जाता है; WSS की सलाह दी जाती है।\",\"urlDuplicate\":\"यह Motrix Server पता पहले से सहेजा गया है\",\"urlInvalid\":\"बिना खाली जगह, क्रेडेंशियल, क्वेरी या फ़्रैगमेंट वाला मान्य ws:// या wss:// बेस URL डालें\",\"urlLabel\":\"WebSocket URL\",\"urlPlaceholder\":\"ws(s)://host[:port][/base-path]\",\"transportWarningTitle\":\"यह कनेक्शन WSS इस्तेमाल नहीं करता\",\"transportWarningBody\":\"Motrix के साथ भेजी और प्राप्त की गई सामग्री एन्क्रिप्टेड रहती है, लेकिन WS सर्वर की पहचान सत्यापित नहीं कर सकता और कनेक्शन जानकारी उजागर हो सकती है। अगर आपका NAS समर्थन करता है, तो WSS इस्तेमाल करें।\",\"urlRequired\":\"WebSocket URL ज़रूरी है\"},\"takeover\":{\"consentBody\":\"फ़ाइलें डाउनलोड करने के लिए Motrix को साइट की लॉगिन कुकीज़ मिलती हैं। संवेदनशील साइटों के डाउनलोड ब्राउज़र में ही रहते हैं।\",\"consentCancel\":\"रद्द करें\",\"consentConfirm\":\"चालू करें\",\"consentDialogLabel\":\"डाउनलोड Motrix को भेजें?\",\"denylistLabel\":\"बहिष्करण सूची (हर पंक्ति में एक होस्ट — हमेशा ब्राउज़र संभालेगा)\",\"enableAria\":\"डाउनलोड टेकओवर चालू करें\",\"enableLabel\":\"उपयुक्त डाउनलोड Motrix को भेजें\",\"loading\":\"टेकओवर सेटिंग लोड हो रही हैं…\",\"minSizeLabel\":\"न्यूनतम आकार (MB)\",\"minSizePlaceholder\":\"0 = सभी\",\"thresholdInvalid\":\"न्यूनतम आकार शून्य या उससे बड़ा होना चाहिए\",\"save\":\"सहेजें\",\"saved\":\"सहेजा गया\",\"title\":\"डाउनलोड टेकओवर\",\"remoteUnavailable\":\"अपने-आप डाउनलोड संभालने के लिए अभी स्थानीय Motrix App ज़रूरी है। रिमोट डाउनलोड और हेडर या कुकी अनुमतियाँ इसे चालू नहीं करतीं। आप इस Server को मैन्युअल रूप से या राइट-क्लिक मेन्यू से डाउनलोड भेज सकते हैं।\",\"availabilityUnknown\":\"चुने गए बैकएंड की जाँच होने तक टेकओवर उपलब्ध नहीं है।\",\"remoteUnavailableShort\":\"केवल स्थानीय App। राइट-क्लिक से भेजना Server के साथ भी काम करता है।\"},\"tabs\":{\"general\":\"सामान्य\",\"download\":\"डाउनलोड\",\"integration\":\"एकीकरण\",\"help\":\"मदद\"},\"common\":{\"apply\":\"लागू करें\",\"cancel\":\"रद्द करें\",\"loadError\":\"एक्सटेंशन की बैकग्राउंड प्रक्रिया शुरू नहीं हुई, इसलिए सेटिंग लोड नहीं हो सकीं। एक्सटेंशन दोबारा लोड करके फिर कोशिश करें।\",\"saved\":\"सहेजा गया\",\"saving\":\"सहेजा जा रहा है…\",\"saveError\":\"सहेजना विफल हुआ\"},\"appearance\":{\"title\":\"दिखावट\",\"theme\":{\"label\":\"थीम\",\"system\":\"सिस्टम के अनुसार\",\"light\":\"हल्की\",\"dark\":\"गहरी\"}},\"help\":{\"title\":\"मदद और सहायता\",\"description\":\"गाइड पढ़ें, सहायता पाएँ और एक्सटेंशन की निदान जानकारी देखें।\",\"reportBug\":\"समस्या की रिपोर्ट करें\",\"reportBugDescription\":\"GitHub पर issue खोलें या प्रतिक्रिया भेजें।\",\"issues\":\"GitHub Issues\",\"docs\":\"दस्तावेज़\",\"docsDescription\":\"सेटअप, पेयरिंग, डाउनलोड टेकओवर और समस्या निवारण की गाइड पढ़ें।\",\"copyDiagnostics\":\"निदान जानकारी कॉपी करें\",\"copied\":\"कॉपी किया गया\",\"diagnostics\":\"निदान\",\"diagnosticsDescription\":\"लॉगिंग बदलें और समस्या निवारण के लिए उपयोगी जानकारी कॉपी करें।\"},\"about\":{\"subtitle\":\"Motrix से वेब पर मौजूद फ़ाइलें डाउनलोड करें\",\"website\":\"आधिकारिक वेबसाइट\"},\"title\":\"Motrix एक्सटेंशन सेटिंग\"}"),
		popup: /* @__PURE__ */ JSON.parse("{\"backend\":{\"app\":\"Motrix App\",\"appDescription\":\"यह कंप्यूटर\",\"choose\":\"Motrix बैकएंड चुनें\",\"configureServer\":\"Motrix Server प्रबंधित करें\",\"notConfigured\":\"कॉन्फ़िगर नहीं किया गया\",\"server\":\"Motrix Server\",\"version\":\"v{{version}}\"},\"controlPanel\":{\"engineState\":\"इंजन: {{state}}\",\"noDownloads\":\"कोई डाउनलोड नहीं\",\"pause\":\"रोकें\",\"remove\":\"हटाएँ\",\"resume\":\"जारी रखें\",\"statsSummary\":\"सक्रिय: {{active}} · प्रतीक्षा में: {{waiting}}\"},\"dashboard\":{\"activity\":\"गतिविधि\",\"resources\":\"संसाधन\",\"showResources\":\"इस पेज के संसाधन दिखाएँ\",\"showTasks\":\"सक्रिय कार्य दिखाएँ\",\"title\":\"ट्रांसफ़र सारांश\"},\"loading\":\"लोड हो रहा है…\",\"quickSettings\":{\"fullSettings\":\"सभी सेटिंग\",\"fullSettingsDescription\":\"सामान्य, डाउनलोड, बैकएंड और मदद\",\"loadError\":\"त्वरित सेटिंग लोड नहीं हुईं।\",\"notificationsDescription\":\"एक्सटेंशन की सिस्टम सूचनाएँ नियंत्रित करें\",\"retry\":\"फिर कोशिश करें\",\"saveError\":\"सेटिंग सहेजना विफल। फिर कोशिश करें।\",\"takeoverDescription\":\"ब्राउज़र के डाउनलोड मौजूदा Motrix बैकएंड को भेजें\"},\"quickAdd\":{\"title\":\"नया कार्य\",\"description\":\"HTTP, HTTPS या मैग्नेट लिंक पेस्ट करें।\",\"inputLabel\":\"डाउनलोड पता\",\"placeholder\":\"https://example.com/file.zip\",\"cancel\":\"रद्द करें\",\"add\":\"जोड़ें\",\"submitting\":\"जोड़ा जा रहा है…\",\"error\":{\"empty\":\"डाउनलोड पता डालें।\",\"unsupported\":\"केवल HTTP, HTTPS या मैग्नेट लिंक समर्थित हैं।\",\"invalid\":\"डाउनलोड पता अमान्य है।\",\"submitFailed\":\"कार्य जोड़ा नहीं जा सका। फिर कोशिश करें।\"}},\"reconnect\":\"कनेक्ट करें\",\"settings\":\"सेटिंग खोलें\",\"sniffer\":{\"clearFilters\":\"फ़िल्टर साफ़ करें\",\"detected\":\"{{count}} आइटम\",\"downloadCount\":\"{{count}} डाउनलोड करें\",\"downloadSelected\":\"चयनित आइटम डाउनलोड करें\",\"downloadedResource\":\"{{name}} भेज दिया गया\",\"downloadingResource\":\"{{name}} डाउनलोड हो रहा है\",\"emptyDescription\":\"मीडिया चलाएँ, फिर कोशिश करें।\",\"emptyFilter\":\"कोई मेल खाता संसाधन नहीं\",\"emptyTitle\":\"मीडिया नहीं मिला\",\"filteredCount\":\"{{matched}} / {{total}} चित्र\",\"filters\":{\"all\":\"सभी\",\"audio\":\"ऑडियो\",\"image\":\"चित्र\",\"video\":\"वीडियो\"},\"imageFilters\":{\"activeCount\":\"{{count}} सक्रिय फ़िल्टर\",\"dimensions\":\"आयाम और आकार\",\"done\":\"हो गया\",\"fields\":{\"height\":\"ऊँचाई\",\"size\":\"आकार\",\"width\":\"चौड़ाई\"},\"formatOptionLabel\":\"{{format}} चित्र फ़िल्टर करें\",\"formats\":\"चित्र फ़ॉर्मैट\",\"operatorLabel\":\"{{label}} की तुलना\",\"reset\":\"रीसेट करें\",\"result\":\"{{matched}} / {{total}}\",\"sizeUnitLabel\":\"फ़ाइल आकार की इकाई\",\"title\":\"त्वरित फ़िल्टर\",\"trigger\":\"फ़िल्टर\",\"valueLabel\":\"{{label}} का मान\"},\"imageCount\":\"{{count}} चित्र\",\"noImageMatches\":\"कोई मेल खाने वाला चित्र नहीं\",\"pageAction\":{\"bilibili\":\"यह bilibili वीडियो भेजें\",\"youtube\":\"यह YouTube वीडियो भेजें\"},\"pageSubmitted\":\"वीडियो Motrix को भेज दिया गया {{taskId}}\",\"pageResources\":\"पेज के संसाधन\",\"quickDownloadResource\":\"{{name}} तुरंत डाउनलोड करें\",\"connectToSubmit\":\"संसाधन भेजने के लिए Motrix से कनेक्ट करें।\",\"scan\":\"फिर स्कैन करें\",\"scanning\":\"स्कैन हो रहा है…\",\"selectAll\":\"सभी चुनें\",\"selected\":\"{{count}} चुने गए\",\"selectResource\":\"{{name}} चुनें\",\"sourceHost\":\"स्रोत: {{host}}\",\"sendResource\":\"{{name}} को Motrix पर भेजें\",\"sent\":\"भेज दिया गया\",\"sending\":\"भेजा जा रहा है\",\"submitFailed\":\"संसाधन भेजा नहीं जा सका। फिर कोशिश करें।\",\"title\":\"संसाधन खोज\",\"unavailableDescription\":\"पेज बदलें या बाद में कोशिश करें।\",\"unavailableTitle\":\"यह पेज स्कैन नहीं हो सकता\",\"unsupported\":\"ffmpeg ज़रूरी है\",\"unsupportedReason\":\"ffmpeg समर्थन उपलब्ध नहीं है, इसलिए चुना गया बैकएंड {{kind}} संसाधन नहीं भेज सकता।\",\"unsupportedSelectionReason\":\"चुना गया बैकएंड चयनित संसाधनों में से एक या अधिक प्रकार नहीं भेज सकता।\",\"unsupportedResource\":\"{{name}} भेजा नहीं जा सकता। {{reason}}\"},\"speed\":{\"download\":\"डाउनलोड\",\"upload\":\"अपलोड\"},\"status\":{\"bootstrapping\":\"Motrix खोजा जा रहा है…\",\"connected\":\"कनेक्ट है\",\"connecting\":\"कनेक्ट हो रहा है…\",\"denied\":\"पेयरिंग अस्वीकार हुई\",\"disconnected\":\"डिस्कनेक्ट है\",\"handshaking\":\"हैंडशेक चल रहा है\",\"awaiting-code\":\"पेयरिंग कोड का इंतज़ार है…\"},\"tabs\":{\"settings\":\"सेटिंग\",\"sniffer\":\"संसाधन\",\"tasks\":\"कार्य\"},\"takeover\":{\"aria\":\"डाउनलोड टेकओवर चालू/बंद करें\",\"label\":\"टेकओवर\"},\"tasks\":{\"actions\":\"{{name}} के लिए कार्रवाइयाँ\",\"openFolder\":\"फ़ाइल वाला फ़ोल्डर Motrix में खोलें\",\"openFolderError\":\"कार्य का फ़ोल्डर खुल नहीं सका। फिर कोशिश करें।\",\"openFolderMetadataPending\":\"फ़ोल्डर खोलने से पहले कार्य के मेटाडेटा का इंतज़ार करें\",\"openFolderTask\":\"{{name}} वाला फ़ोल्डर खोलें\",\"openFolderUnsupported\":\"फ़ोल्डर खोलने के लिए Motrix अपडेट करें\",\"pauseTask\":\"{{name}} रोकें\",\"removeTask\":\"{{name}} हटाएँ\",\"removeConfirmTitle\":\"कार्य हटाएँ?\",\"removeConfirmDescription\":\"“{{name}}” को डाउनलोड सूची से हटा दिया जाएगा।\",\"removeDeleteFilesLabel\":\"डाउनलोड की गई फ़ाइलें मिटाएँ\",\"removeConfirmAction\":\"हटाएँ\",\"resumeTask\":\"{{name}} जारी रखें\",\"bytes\":\"{{total}} में से {{done}}\",\"disconnectedDescription\":\"कार्य देखने के लिए कनेक्ट करें।\",\"disconnectedTitle\":\"Motrix ऑफ़लाइन है\",\"empty\":{\"active\":\"कोई सक्रिय कार्य नहीं\",\"failed\":\"कोई विफल कार्य नहीं\",\"recent\":\"कोई पूर्ण कार्य नहीं\"},\"filters\":{\"active\":\"सक्रिय\",\"failed\":\"विफल\",\"recent\":\"पूर्ण\"},\"loading\":\"कार्य लोड हो रहे हैं\",\"status\":{\"completed\":\"पूर्ण\",\"downloading\":\"डाउनलोड हो रहा है\",\"error\":\"विफल\",\"fetching_metadata\":\"मेटाडेटा मिल रहा है\",\"finalizing\":\"अंतिम प्रक्रिया चल रही है\",\"paused\":\"रुका हुआ\",\"queued\":\"कतार में\",\"seeding\":\"सीडिंग हो रही है\"},\"title\":\"कार्य\"},\"pairing\":{\"attemptOf\":\"प्रयास {{run}} / {{maxRuns}}\",\"attemptsRemaining\":\"{{attemptsRemaining}} प्रयास बाकी हैं\",\"codeLabel\":\"पेयरिंग कोड\",\"codeDescription\":\"Motrix पेयरिंग डायलॉग का 8-अक्षर का कोड डालें।\",\"codeInvalid\":\"पेयरिंग डायलॉग का 8-अक्षर का कोड डालें।\",\"dialogTitle\":\"पेयरिंग कोड डालें\",\"dismissPrompt\":\"बाद में डालें और ब्राउज़िंग जारी रखें\",\"enterCode\":\"पेयरिंग कोड डालें\",\"expiresIn\":\"{{time}} में समय समाप्त होगा\",\"pairButton\":\"पेयर करें\",\"pickerHelp\":\"Motrix के कई इंस्टेंस मिले हैं। पेयर करने के लिए एक चुनें।\",\"rescan\":\"दोबारा खोजें\",\"noCandidates\":\"Motrix का कोई इंस्टेंस नहीं मिला।\",\"candidatesLabel\":\"मिले हुए Motrix इंस्टेंस\",\"candidatePort\":\"पोर्ट {{port}}\",\"candidateDetail\":\"{{instanceId}} · v{{appVersion}}\",\"unknownVersion\":\"अज्ञात संस्करण\",\"choose\":\"चुनें\",\"backoffTitle\":\"पेयरिंग के बहुत ज़्यादा प्रयास\",\"backoffBody\":\"{{time}} पर फिर कोशिश करें।\",\"retryIn\":\"{{seconds}} सेकंड में फिर कोशिश करें\",\"permissionMissingTitle\":\"अनुमति ज़रूरी है\",\"permissionMissingBody\":\"इस कंप्यूटर पर Motrix खोजने के लिए localhost की पहुँच दें।\",\"grantPermission\":\"अनुमति दें\",\"degradedTitle\":\"Motrix कनेक्ट है\",\"degradedBody\":\"आप Motrix सामान्य रूप से इस्तेमाल कर सकते हैं। इस कनेक्शन में केवल बुनियादी सत्यापन है। बेहतर सुरक्षा के लिए Motrix अपडेट करके दोबारा पेयर करें।\",\"recoveryExhaustedTitle\":\"अपने-आप दोबारा कनेक्ट नहीं हो सका\",\"recoveryExhaustedBody\":\"Motrix की कोई भी सहेजी गई पेयरिंग काम नहीं आई। दोबारा पेयर करने के लिए कनेक्ट करें दबाएँ।\"}}"),
		errors: { "connection": {
			"generic": "कनेक्शन विफल हुआ। फिर कोशिश करें।",
			"backoffLocked": "पेयरिंग के बहुत ज़्यादा प्रयास हुए। बाद में कोशिश करें।",
			"staleAttempt": "नए कनेक्शन प्रयास ने इसकी जगह ले ली।",
			"aborted": "पेयरिंग रद्द की गई।",
			"deadlineExceeded": "प्रयास का समय समाप्त हुआ। फिर कोशिश करें।",
			"runsExhausted": "बहुत ज़्यादा गलत कोड डाले गए। नए कोड के लिए पेयरिंग फिर शुरू करें।",
			"invalidCode": "कोड का फ़ॉर्मैट सही नहीं है। Motrix डायलॉग देखें।",
			"missingNonce": "Motrix ने पेयरिंग स्लॉट नहीं दिया। पक्का करें कि Motrix चल रहा है, फिर कोशिश करें।",
			"unsupportedBrowser": "इस ब्राउज़र में पेयरिंग समर्थित नहीं है।",
			"ticketPreparationFailed": "पेयरिंग तैयार नहीं हो सकी। फिर कोशिश करें।",
			"protocolViolation": "Motrix ने अनपेक्षित जवाब भेजा। फिर कोशिश करें।",
			"unsupportedVersion": "यह एक्सटेंशन और Motrix अलग प्रोटोकॉल संस्करण इस्तेमाल करते हैं। दोनों अपडेट करके फिर कोशिश करें।",
			"backendUpgradeRequired": "सुरक्षित पेयरिंग के लिए Motrix का यह संस्करण बहुत पुराना है। Motrix अपडेट करके फिर कोशिश करें।",
			"extensionUpgradeRequired": "इस Motrix के लिए एक्सटेंशन का यह संस्करण बहुत पुराना है। Motrix एक्सटेंशन अपडेट करके फिर कोशिश करें।",
			"unsupportedRemote": "प्रमाणित Motrix इस कनेक्शन के लिए चुना गया App या Server नहीं है। एंडपॉइंट जाँचकर फिर कोशिश करें।",
			"remoteDiscoveryUnavailable": "रिमोट Motrix Server से संपर्क नहीं हो सका। उसका पता, लिसनर और नेटवर्क जाँचें; WSS के लिए प्रमाणपत्र और रिवर्स प्रॉक्सी भी जाँचें।",
			"remotePairingUnavailable": "रिमोट Motrix Server सुरक्षित पेयरिंग सत्र शुरू नहीं कर सका। थोड़ी देर बाद कोशिश करें।",
			"remoteTransportUnavailable": "रिमोट Motrix Server कनेक्शन विफल हुआ। पता, लिसनर, DNS और नेटवर्क जाँचें; WSS के लिए प्रमाणपत्र और रिवर्स प्रॉक्सी भी जाँचें। ब्राउज़र नहीं बता सकता कि किसमें समस्या आई।",
			"peerRejected": "Motrix ने पेयरिंग अस्वीकार कर दी।",
			"peerBusy": "Motrix बहुत ज़्यादा पेयरिंग अनुरोध संभाल रहा है। थोड़ी देर बाद कोशिश करें।",
			"securityCheckFailed": "कनेक्शन सुरक्षा जाँच में विफल हुआ और रोक दिया गया।",
			"peerNotAuthentic": "दूसरा पक्ष साबित नहीं कर सका कि वह आपका Motrix है। कनेक्शन रोक दिया गया।",
			"credentialPhaseFailed": "पेयरिंग सहेजी नहीं जा सकी। फिर पेयर करें।",
			"internalError": "एक्सटेंशन में समस्या आई। फिर कोशिश करें।",
			"authFailed": "Motrix ने इस पेयरिंग को नहीं पहचाना। शायद इसे रद्द किया गया है — दोबारा पेयर करें।",
			"serverMacMismatch": "जवाब का सत्यापन विफल हुआ, इसलिए कनेक्शन रोक दिया गया। शायद वह आपका Motrix नहीं है।",
			"channelClosed": "कनेक्शन बंद हो गया। जारी रखने के लिए दोबारा कनेक्ट करें।",
			"channelUnavailable": "अभी Motrix से संपर्क नहीं हो पा रहा। पक्का करें कि वह चल रहा है।"
		} }
	} },
	id: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: terhubung",
			"disconnected": "Motrix: tidak terhubung",
			"connecting": "Motrix: menghubungkan…",
			"downloading": "Motrix: mengunduh",
			"denied": "Motrix: penyandingan ditolak — buka untuk menyandingkan ulang",
			"error": "Motrix: pengiriman gagal — klik untuk detail"
		} },
		contextMenu: {
			"downloadWithMotrix": "Unduh dengan Motrix",
			"pairThenDownload": "Sandingkan Motrix, lalu unduh"
		},
		notify: {
			"browserFallbackBody": "Motrix tidak tersedia. Unduhan akan ditangani oleh browser.",
			"browserFallbackTitle": "Mengunduh di browser",
			"downloadComplete": "Unduhan selesai",
			"downloadFailed": "Unduhan gagal",
			"handedToMotrix": "Dikirim ke Motrix",
			"notConnectedBody": "Sandingkan Motrix untuk mengambil alih unduhan.",
			"notConnectedTitle": "Motrix tidak terhubung",
			"notReachableBody": "Sandingkan Motrix, lalu coba unduh lagi.",
			"notReachableTitle": "Motrix tidak dapat dijangkau",
			"pairNudgeBody": "Buka Motrix untuk menyelesaikan penyandingan.",
			"pairNudgeTitle": "Sandingkan Motrix",
			"pairRevokedBody": "Motrix mencabut penyandingan browser ini.",
			"pairRevokedTitle": "Penyandingan dicabut",
			"sensitiveSkippedBody": "Unduhan dari situs sensitif tetap ditangani browser.",
			"sensitiveSkippedTitle": "Dilewati",
			"submitFailedBody": "Mengunduh ulang di browser.",
			"submitFailedTitle": "Pengiriman ke Motrix gagal"
		},
		options: {
			"diagnostics": {
				"adapters": "Adaptor",
				"extensionId": "ID ekstensi",
				"logLevel": "Tingkat log",
				"logLevels": {
					"silent": "Tanpa log",
					"error": "Kesalahan",
					"warn": "Peringatan",
					"info": "Informasi",
					"debug": "Debug"
				},
				"noneRegistered": "Belum ada yang terdaftar",
				"title": "Diagnostik",
				"version": "Versi"
			},
			"endpoint": {
				"activate": "Gunakan",
				"activateAria": "Gunakan {{name}}",
				"connection": {
					"bootstrapping": "Memulai",
					"connected": "Terhubung",
					"connecting": "Menghubungkan",
					"denied": "Ditolak",
					"disconnected": "Terputus",
					"handshaking": "Mengotorisasi",
					"awaiting-code": "Menunggu kode"
				},
				"currentDescription": "Pilih satu App atau Server untuk unduhan, tugas, dan sumber daya yang terdeteksi di halaman.",
				"currentTitle": "Backend Motrix",
				"listLabel": "Backend Motrix tersedia",
				"localDescription": "Komputer ini, ditemukan melalui Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Kirim unduhan ke"
			},
			"language": {
				"label": "Bahasa",
				"system": "Ikuti sistem"
			},
			"notifications": {
				"title": "Notifikasi sistem",
				"masterLabel": "Aktifkan notifikasi sistem",
				"masterAria": "Aktifkan notifikasi sistem",
				"confirmLabel": "Keberhasilan / konfirmasi",
				"confirmDesc": "Dikirim ke Motrix, unduhan selesai",
				"errorLabel": "Kegagalan / kesalahan",
				"errorDesc": "Pengiriman gagal, tidak dapat dijangkau, unduhan gagal",
				"reminderLabel": "Pengingat",
				"reminderDesc": "Permintaan penyandingan, penyandingan dicabut, situs dilewati"
			},
			"pairing": {
				"backendTitle": "Menyandingkan {{name}}",
				"forget": "Lupakan penyandingan",
				"loading": "Memuat status penyandingan…",
				"localHelp": "Klik Sandingkan untuk menemukan Motrix di komputer ini, lalu masukkan kode penyandingannya.",
				"localTitle": "Sandingkan melalui Motrix App",
				"remoteTitle": "Sandingkan dengan Motrix Server",
				"remoteHelp": "Klik Sandingkan, konfirmasikan permintaan di antarmuka pengelola Server, lalu masukkan kode yang ditampilkan di sini. Endpoint WS dan WSS didukung; WSS disarankan.",
				"serverRequiredTitle": "Memerlukan Motrix Server",
				"serverRequiredHelp": "Firefox untuk Android terhubung melalui Motrix Server. Tambahkan Server di atas, lalu pilih untuk menyandingkan.",
				"remoteConsentTitle": "Unduhan jarak jauh",
				"remoteConsentBody": "Unduhan jarak jauh mengirim URL tujuan, URL dan judul halaman sumber, nama file, pilihan, serta kontrol tugas ke Server ini. Cookie dan header permintaan tidak dikirim kecuali diaktifkan secara terpisah.",
				"remoteConsentOffline": "Izin data terikat pada Server yang diautentikasi. Hubungkan sebelum mengubahnya.",
				"remoteHeadersLabel": "Kirim header permintaan",
				"remoteHeadersHelp": "Mengizinkan header dari halaman, seperti Referer dan header pemutaran media. Header autentikasi tetap memerlukan izin kredensial di bawah.",
				"remoteCredentialsLabel": "Kirim cookie dan autentikasi",
				"remoteCredentialsHelp": "Mengizinkan cookie dan header kredensial hanya untuk Server ini. Aktifkan hanya untuk Server yang Anda kendalikan.",
				"notPaired": "Belum disandingkan",
				"paired": "Disandingkan dengan Motrix",
				"pairedHelp": "Kredensial MBP1 yang telah dikonfirmasi disimpan untuk backend ini. Status koneksi saat ini ditampilkan secara terpisah.",
				"pairedTitle": "Penyandingan siap",
				"reconnect": "Hubungkan ulang",
				"scopedHelp": "Kepercayaan dan kredensial penyandingan dipisahkan untuk setiap backend. Beralih backend tidak pernah menggunakan kepercayaan backend lain.",
				"pair": "Sandingkan",
				"pairDialogTitle": "Sandingkan dengan Motrix"
			},
			"servers": {
				"add": "Tambah server",
				"addTitle": "Tambah Motrix Server",
				"current": "Saat ini",
				"delete": "Hapus server",
				"deleteActiveDescription": "Hapus {{name}} beserta kredensial penyandingan dan persetujuan yang disimpan secara lokal? Backend akan kembali ke Motrix App tanpa menghubungkan atau menjalankannya.",
				"deleteActiveServerOnlyDescription": "Hapus {{name}} beserta kredensial penyandingan dan persetujuan yang disimpan secara lokal? Anda harus menambah atau memilih Motrix Server lain sebelum mengunduh.",
				"deleteAria": "Hapus {{name}}",
				"deleteDescription": "Hapus {{name}} beserta kredensial penyandingan dan persetujuan yang disimpan secara lokal? Tindakan ini tidak mencabut apa pun di server.",
				"deleteTitle": "Hapus Motrix Server?",
				"description": "Simpan beberapa alamat Motrix Server dan beralih di antaranya melalui Opsi atau popup.",
				"dialogDescription": "Beri backend ini nama yang mudah dikenali dan masukkan URL dasar WebSocket-nya.",
				"editAria": "Edit {{name}}",
				"editTitle": "Edit Motrix Server",
				"emptyDescription": "Tambahkan server untuk terhubung ke Motrix di luar komputer ini.",
				"emptyTitle": "Belum ada Motrix Server",
				"footer": "Mengubah alamat server memerlukan penyandingan ulang. Informasi penyandingan tidak pernah dibagikan antaralamat.",
				"nameLabel": "Nama server",
				"namePlaceholder": "Server rumah",
				"nameRequired": "Nama server wajib diisi",
				"save": "Simpan server",
				"statusAuthority": "Alamat server: {{value}}",
				"statusRuntime": "Versi Motrix: {{name}} {{version}}",
				"statusTitle": "Informasi server",
				"statusTransportSecure": "Keamanan koneksi: menggunakan WSS dan TLS memverifikasi identitas server",
				"statusTransportPlain": "Keamanan koneksi: terenkripsi, tetapi WS tidak dapat memverifikasi identitas server dan dapat mengekspos informasi koneksi. WSS disarankan",
				"title": "Server Motrix",
				"urlDescription": "Gunakan URL dasar ws:// atau wss://. Jalur opsional dipertahankan persis sebagai prefiks reverse proxy; WSS disarankan.",
				"urlDuplicate": "Alamat Motrix Server ini sudah disimpan",
				"urlInvalid": "Masukkan URL dasar ws:// atau wss:// yang valid tanpa spasi, kredensial, kueri, atau fragmen",
				"urlLabel": "URL WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Koneksi ini tidak menggunakan WSS",
				"transportWarningBody": "Konten yang dipertukarkan dengan Motrix tetap terenkripsi, tetapi WS tidak dapat memverifikasi identitas server dan dapat mengekspos informasi koneksi. Gunakan WSS jika NAS Anda mendukungnya.",
				"urlRequired": "URL WebSocket wajib diisi"
			},
			"takeover": {
				"consentBody": "Motrix menerima cookie login situs untuk mengunduh file. Unduhan dari situs sensitif tetap di browser.",
				"consentCancel": "Batal",
				"consentConfirm": "Aktifkan",
				"consentDialogLabel": "Kirim unduhan ke Motrix?",
				"denylistLabel": "Daftar pengecualian (satu host per baris — selalu ditangani browser)",
				"enableAria": "Aktifkan pengambilalihan",
				"enableLabel": "Kirim unduhan yang memenuhi syarat ke Motrix",
				"loading": "Memuat setelan pengambilalihan…",
				"minSizeLabel": "Ukuran minimum (MB)",
				"minSizePlaceholder": "0 = semua",
				"thresholdInvalid": "Ukuran minimum harus berupa angka nonnegatif",
				"save": "Simpan",
				"saved": "Disimpan",
				"title": "Pengambilalihan unduhan",
				"remoteUnavailable": "Pengambilalihan otomatis saat ini memerlukan Motrix App lokal. Unduhan jarak jauh serta izin header atau cookie tidak mengaktifkannya. Anda tetap dapat mengirim unduhan ke Server ini secara manual atau melalui menu klik kanan.",
				"availabilityUnknown": "Pengambilalihan tidak tersedia hingga backend yang dipilih dapat diperiksa.",
				"remoteUnavailableShort": "Hanya App lokal. Pengiriman lewat klik kanan mendukung Server."
			},
			"tabs": {
				"general": "Umum",
				"download": "Unduhan",
				"integration": "Integrasi",
				"help": "Bantuan"
			},
			"common": {
				"apply": "Terapkan",
				"cancel": "Batal",
				"loadError": "Setelan tidak dapat dimuat karena proses latar belakang ekstensi gagal dimulai. Muat ulang ekstensi dan coba lagi.",
				"saved": "Disimpan",
				"saving": "Menyimpan…",
				"saveError": "Gagal menyimpan"
			},
			"appearance": {
				"title": "Tampilan",
				"theme": {
					"label": "Tema",
					"system": "Ikuti sistem",
					"light": "Terang",
					"dark": "Gelap"
				}
			},
			"help": {
				"title": "Bantuan dan dukungan",
				"description": "Lihat panduan, bantuan, dan diagnostik ekstensi.",
				"reportBug": "Laporkan masalah",
				"reportBugDescription": "Buka issue di GitHub atau kirim masukan.",
				"issues": "GitHub Issues",
				"docs": "Dokumentasi",
				"docsDescription": "Baca panduan penyiapan, penyandingan, pengambilalihan unduhan, dan pemecahan masalah.",
				"copyDiagnostics": "Salin diagnostik",
				"copied": "Disalin",
				"diagnostics": "Diagnostik",
				"diagnosticsDescription": "Atur pencatatan log dan salin informasi yang berguna untuk pemecahan masalah."
			},
			"about": {
				"subtitle": "Unduh file dari web dengan Motrix",
				"website": "Situs resmi"
			},
			"title": "Setelan Ekstensi Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Komputer ini",
				"choose": "Pilih backend Motrix",
				"configureServer": "Kelola Motrix Server",
				"notConfigured": "Belum dikonfigurasi",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "mesin: {{state}}",
				"noDownloads": "Tidak ada unduhan",
				"pause": "Jeda",
				"remove": "Hapus",
				"resume": "Lanjutkan",
				"statsSummary": "Aktif: {{active}} · Menunggu: {{waiting}}"
			},
			"dashboard": {
				"activity": "Aktivitas",
				"resources": "Sumber daya",
				"showResources": "Tampilkan sumber daya dari halaman ini",
				"showTasks": "Tampilkan tugas aktif",
				"title": "Ringkasan transfer"
			},
			"loading": "Memuat…",
			"quickSettings": {
				"fullSettings": "Semua setelan",
				"fullSettingsDescription": "Umum, unduhan, backend, dan bantuan",
				"loadError": "Gagal memuat setelan cepat.",
				"notificationsDescription": "Atur notifikasi sistem dari ekstensi",
				"retry": "Coba lagi",
				"saveError": "Gagal menyimpan setelan. Coba lagi.",
				"takeoverDescription": "Kirim unduhan browser ke backend Motrix saat ini"
			},
			"quickAdd": {
				"title": "Tugas baru",
				"description": "Tempel tautan HTTP, HTTPS, atau magnet.",
				"inputLabel": "Alamat unduhan",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Batal",
				"add": "Tambah",
				"submitting": "Menambahkan…",
				"error": {
					"empty": "Masukkan alamat unduhan.",
					"unsupported": "Hanya tautan HTTP, HTTPS, atau magnet yang didukung.",
					"invalid": "Alamat unduhan tidak valid.",
					"submitFailed": "Tidak dapat menambahkan tugas. Coba lagi."
				}
			},
			"reconnect": "Hubungkan",
			"settings": "Buka setelan",
			"sniffer": {
				"clearFilters": "Hapus filter",
				"detected": "{{count}} item",
				"downloadCount": "Unduh {{count}}",
				"downloadSelected": "Unduh pilihan",
				"downloadedResource": "{{name}} dikirim",
				"downloadingResource": "Mengunduh {{name}}",
				"emptyDescription": "Putar media, lalu coba lagi.",
				"emptyFilter": "Tidak ada sumber daya yang cocok",
				"emptyTitle": "Media tidak ditemukan",
				"filteredCount": "{{matched}} / {{total}} gambar",
				"filters": {
					"all": "Semua",
					"audio": "Audio",
					"image": "Gambar",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "{{count}} filter aktif",
					"dimensions": "Dimensi dan ukuran",
					"done": "Selesai",
					"fields": {
						"height": "Tinggi",
						"size": "Ukuran",
						"width": "Lebar"
					},
					"formatOptionLabel": "Filter gambar {{format}}",
					"formats": "Format gambar",
					"operatorLabel": "Perbandingan {{label}}",
					"reset": "Reset",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Satuan ukuran file",
					"title": "Filter cepat",
					"trigger": "Filter",
					"valueLabel": "Nilai {{label}}"
				},
				"imageCount": "{{count}} gambar",
				"noImageMatches": "Tidak ada gambar yang cocok",
				"pageAction": {
					"bilibili": "Kirim video bilibili ini",
					"youtube": "Kirim video YouTube ini"
				},
				"pageSubmitted": "Video dikirim ke Motrix {{taskId}}",
				"pageResources": "Sumber daya",
				"quickDownloadResource": "Unduh cepat {{name}}",
				"connectToSubmit": "Hubungkan Motrix untuk mengirim sumber daya.",
				"scan": "Pindai lagi",
				"scanning": "Memindai…",
				"selectAll": "Pilih semua",
				"selected": "{{count}} dipilih",
				"selectResource": "Pilih {{name}}",
				"sourceHost": "Sumber: {{host}}",
				"sendResource": "Kirim {{name}} ke Motrix",
				"sent": "Terkirim",
				"sending": "Mengirim",
				"submitFailed": "Tidak dapat mengirim sumber daya. Coba lagi.",
				"title": "Deteksi sumber daya",
				"unavailableDescription": "Pindah halaman atau coba lagi nanti.",
				"unavailableTitle": "Halaman ini tak bisa dipindai",
				"unsupported": "Memerlukan ffmpeg",
				"unsupportedReason": "Backend yang dipilih tidak dapat mengirim sumber daya {{kind}} karena dukungan ffmpeg tidak tersedia.",
				"unsupportedSelectionReason": "Backend yang dipilih tidak dapat mengirim satu atau beberapa jenis sumber daya yang dipilih.",
				"unsupportedResource": "{{name}} tidak dapat dikirim. {{reason}}"
			},
			"speed": {
				"download": "Unduh",
				"upload": "Unggah"
			},
			"status": {
				"bootstrapping": "Mencari Motrix…",
				"connected": "Terhubung",
				"connecting": "Menghubungkan…",
				"denied": "Penyandingan ditolak",
				"disconnected": "Terputus",
				"handshaking": "Negosiasi koneksi berlangsung",
				"awaiting-code": "Menunggu kode penyandingan…"
			},
			"tabs": {
				"settings": "Setelan",
				"sniffer": "Sumber daya",
				"tasks": "Tugas"
			},
			"takeover": {
				"aria": "Alihkan pengambilalihan unduhan",
				"label": "Ambil alih"
			},
			"tasks": {
				"actions": "Tindakan untuk {{name}}",
				"openFolder": "Buka folder file di Motrix",
				"openFolderError": "Tidak dapat membuka folder tugas. Coba lagi.",
				"openFolderMetadataPending": "Tunggu metadata tugas sebelum membuka folder",
				"openFolderTask": "Buka folder yang berisi {{name}}",
				"openFolderUnsupported": "Perbarui Motrix untuk membuka folder",
				"pauseTask": "Jeda {{name}}",
				"removeTask": "Hapus {{name}}",
				"removeConfirmTitle": "Hapus tugas?",
				"removeConfirmDescription": "“{{name}}” akan dihapus dari daftar unduhan.",
				"removeDeleteFilesLabel": "Hapus file yang diunduh",
				"removeConfirmAction": "Hapus",
				"resumeTask": "Lanjutkan {{name}}",
				"bytes": "{{done}} dari {{total}}",
				"disconnectedDescription": "Hubungkan untuk melihat tugas.",
				"disconnectedTitle": "Motrix sedang offline",
				"empty": {
					"active": "Tidak ada tugas aktif",
					"failed": "Tidak ada tugas gagal",
					"recent": "Tidak ada tugas selesai"
				},
				"filters": {
					"active": "Aktif",
					"failed": "Gagal",
					"recent": "Selesai"
				},
				"loading": "Memuat tugas",
				"status": {
					"completed": "Selesai",
					"downloading": "Mengunduh",
					"error": "Gagal",
					"fetching_metadata": "Mengambil metadata",
					"finalizing": "Menyelesaikan",
					"paused": "Dijeda",
					"queued": "Dalam antrean",
					"seeding": "Seeding"
				},
				"title": "Tugas"
			},
			"pairing": {
				"attemptOf": "Percobaan {{run}} dari {{maxRuns}}",
				"attemptsRemaining": "{{attemptsRemaining}} percobaan tersisa",
				"codeLabel": "Kode penyandingan",
				"codeDescription": "Masukkan kode 8 karakter di dialog penyandingan Motrix.",
				"codeInvalid": "Masukkan kode 8 karakter di dialog penyandingan.",
				"dialogTitle": "Masukkan kode penyandingan",
				"dismissPrompt": "Isi nanti dan lanjut menjelajah",
				"enterCode": "Masukkan kode penyandingan",
				"expiresIn": "Kedaluwarsa dalam {{time}}",
				"pairButton": "Sandingkan",
				"pickerHelp": "Beberapa instans Motrix ditemukan. Pilih satu untuk disandingkan.",
				"rescan": "Cari ulang",
				"noCandidates": "Tidak ada instans Motrix ditemukan.",
				"candidatesLabel": "Instans Motrix yang ditemukan",
				"candidatePort": "Port {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "versi tidak diketahui",
				"choose": "Pilih",
				"backoffTitle": "Terlalu banyak percobaan penyandingan",
				"backoffBody": "Coba lagi pada {{time}}.",
				"retryIn": "Coba lagi dalam {{seconds}} dtk",
				"permissionMissingTitle": "Memerlukan izin",
				"permissionMissingBody": "Izinkan akses ke localhost untuk menemukan Motrix di komputer ini.",
				"grantPermission": "Berikan izin",
				"degradedTitle": "Motrix terhubung",
				"degradedBody": "Anda dapat menggunakan Motrix seperti biasa. Koneksi ini hanya memiliki verifikasi dasar. Untuk perlindungan lebih kuat, perbarui Motrix dan sandingkan ulang.",
				"recoveryExhaustedTitle": "Tidak dapat terhubung ulang secara otomatis",
				"recoveryExhaustedBody": "Tidak ada penyandingan Motrix tersimpan yang berhasil. Tekan Hubungkan untuk menyandingkan ulang."
			}
		},
		errors: { "connection": {
			"generic": "Koneksi gagal. Coba lagi.",
			"backoffLocked": "Terlalu banyak percobaan penyandingan. Coba lagi nanti.",
			"staleAttempt": "Percobaan koneksi yang lebih baru telah mengambil alih.",
			"aborted": "Penyandingan dibatalkan.",
			"deadlineExceeded": "Waktu percobaan habis. Coba lagi.",
			"runsExhausted": "Terlalu banyak kode salah. Mulai penyandingan lagi untuk memperoleh kode baru.",
			"invalidCode": "Format kode tidak sesuai. Periksa dialog Motrix.",
			"missingNonce": "Motrix tidak menyediakan slot penyandingan. Pastikan Motrix berjalan, lalu coba lagi.",
			"unsupportedBrowser": "Penyandingan tidak didukung di browser ini.",
			"ticketPreparationFailed": "Penyandingan tidak dapat disiapkan. Coba lagi.",
			"protocolViolation": "Motrix mengirim respons yang tidak diharapkan. Coba lagi.",
			"unsupportedVersion": "Ekstensi ini dan Motrix menggunakan versi protokol yang berbeda. Perbarui keduanya dan coba lagi.",
			"backendUpgradeRequired": "Versi Motrix ini terlalu lama untuk penyandingan aman. Perbarui Motrix, lalu coba lagi.",
			"extensionUpgradeRequired": "Versi ekstensi ini terlalu lama untuk Motrix ini. Perbarui ekstensi Motrix, lalu coba lagi.",
			"unsupportedRemote": "Motrix yang diautentikasi bukan App atau Server yang dipilih untuk koneksi ini. Periksa endpoint dan coba lagi.",
			"remoteDiscoveryUnavailable": "Motrix Server jarak jauh tidak dapat dijangkau. Periksa alamat, layanan listener, dan jaringan; untuk WSS, periksa juga sertifikat dan reverse proxy.",
			"remotePairingUnavailable": "Motrix Server jarak jauh tidak dapat membuka sesi penyandingan aman. Coba lagi sebentar lagi.",
			"remoteTransportUnavailable": "Koneksi ke Motrix Server jarak jauh gagal. Periksa alamat, layanan listener, DNS, dan jaringan; untuk WSS, periksa juga sertifikat dan reverse proxy. Browser tidak dapat menentukan bagian mana yang gagal.",
			"peerRejected": "Motrix menolak penyandingan.",
			"peerBusy": "Motrix sedang menangani terlalu banyak permintaan penyandingan. Coba lagi sebentar lagi.",
			"securityCheckFailed": "Koneksi gagal melewati pemeriksaan keamanan dan dihentikan.",
			"peerNotAuthentic": "Pihak lain tidak dapat membuktikan bahwa itu Motrix Anda. Koneksi dihentikan.",
			"credentialPhaseFailed": "Penyandingan tidak dapat disimpan. Coba sandingkan lagi.",
			"internalError": "Terjadi kesalahan pada ekstensi. Coba lagi.",
			"authFailed": "Motrix tidak mengenali penyandingan ini. Mungkin telah dicabut — coba sandingkan ulang.",
			"serverMacMismatch": "Balasan gagal diverifikasi sehingga koneksi dihentikan. Mungkin itu bukan Motrix Anda.",
			"channelClosed": "Koneksi ditutup. Hubungkan ulang untuk melanjutkan.",
			"channelUnavailable": "Motrix tidak dapat dijangkau saat ini. Pastikan Motrix berjalan."
		} }
	} },
	it: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: connesso",
			"disconnected": "Motrix: non connesso",
			"connecting": "Motrix: connessione…",
			"downloading": "Motrix: download in corso",
			"denied": "Motrix: associazione rifiutata — apri per riprovare",
			"error": "Motrix: invio non riuscito — fai clic per i dettagli"
		} },
		contextMenu: {
			"downloadWithMotrix": "Scarica con Motrix",
			"pairThenDownload": "Associa Motrix, poi scarica"
		},
		notify: {
			"browserFallbackBody": "Motrix non è disponibile. Il download verrà gestito dal browser.",
			"browserFallbackTitle": "Download nel browser",
			"downloadComplete": "Download completato",
			"downloadFailed": "Download non riuscito",
			"handedToMotrix": "Inviato a Motrix",
			"notConnectedBody": "Associa Motrix per gestire i download.",
			"notConnectedTitle": "Motrix non connesso",
			"notReachableBody": "Associa Motrix e riprova il download.",
			"notReachableTitle": "Motrix non raggiungibile",
			"pairNudgeBody": "Apri Motrix per completare l’associazione.",
			"pairNudgeTitle": "Associa Motrix",
			"pairRevokedBody": "Motrix ha revocato l’associazione di questo browser.",
			"pairRevokedTitle": "Associazione revocata",
			"sensitiveSkippedBody": "Il download dal sito sensibile resta nel browser.",
			"sensitiveSkippedTitle": "Ignorato",
			"submitFailedBody": "Riavvio del download nel browser.",
			"submitFailedTitle": "Invio a Motrix non riuscito"
		},
		options: {
			"diagnostics": {
				"adapters": "Adattatori",
				"extensionId": "ID estensione",
				"logLevel": "Livello di registrazione",
				"logLevels": {
					"silent": "Nessuno",
					"error": "Errore",
					"warn": "Avviso",
					"info": "Informazioni",
					"debug": "Debug"
				},
				"noneRegistered": "Nessuno registrato",
				"title": "Diagnostica",
				"version": "Versione"
			},
			"endpoint": {
				"activate": "Usa",
				"activateAria": "Usa {{name}}",
				"connection": {
					"bootstrapping": "Avvio",
					"connected": "Connesso",
					"connecting": "Connessione",
					"denied": "Rifiutato",
					"disconnected": "Disconnesso",
					"handshaking": "Autorizzazione",
					"awaiting-code": "In attesa del codice"
				},
				"currentDescription": "Scegli un’App o un Server per download, attività e risorse rilevate nelle pagine.",
				"currentTitle": "Servizi Motrix",
				"listLabel": "Servizi Motrix disponibili",
				"localDescription": "Questo computer, rilevato tramite Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Invia download a"
			},
			"language": {
				"label": "Lingua",
				"system": "Segui il sistema"
			},
			"notifications": {
				"title": "Notifiche di sistema",
				"masterLabel": "Abilita notifiche di sistema",
				"masterAria": "Abilita notifiche di sistema",
				"confirmLabel": "Successi / conferme",
				"confirmDesc": "Invio a Motrix, download completato",
				"errorLabel": "Problemi / errori",
				"errorDesc": "Invio non riuscito, non raggiungibile, download non riuscito",
				"reminderLabel": "Promemoria",
				"reminderDesc": "Richieste di associazione, associazione revocata, siti ignorati"
			},
			"pairing": {
				"backendTitle": "Associazione di {{name}}",
				"forget": "Dimentica associazione",
				"loading": "Caricamento stato associazione…",
				"localHelp": "Fai clic su Associa per trovare Motrix su questo computer e inserisci il codice di associazione.",
				"localTitle": "Associa tramite Motrix App",
				"remoteTitle": "Associa a Motrix Server",
				"remoteHelp": "Fai clic su Associa, conferma la richiesta nell’interfaccia di amministrazione del Server e inserisci qui il codice visualizzato. Sono supportati endpoint WS e WSS; si consiglia WSS.",
				"serverRequiredTitle": "È richiesto Motrix Server",
				"serverRequiredHelp": "Firefox per Android si connette tramite Motrix Server. Aggiungi un Server qui sopra e selezionalo per associarlo.",
				"remoteConsentTitle": "Download remoti",
				"remoteConsentBody": "I download remoti inviano a questo Server l’URL di destinazione, l’URL e il titolo della pagina di origine, il nome del file, la selezione e i comandi delle attività. Cookie e intestazioni delle richieste restano disabilitati salvo attivazione separata.",
				"remoteConsentOffline": "Le autorizzazioni sui dati sono legate al Server autenticato. Connettiti prima di modificarle.",
				"remoteHeadersLabel": "Invia intestazioni delle richieste",
				"remoteHeadersHelp": "Consente intestazioni ricavate dalla pagina, come Referer e quelle per la riproduzione multimediale. Le intestazioni di autenticazione richiedono comunque l’autorizzazione alle credenziali qui sotto.",
				"remoteCredentialsLabel": "Invia cookie e autenticazione",
				"remoteCredentialsHelp": "Consente cookie e intestazioni con credenziali solo per questo Server. Abilita solo per un Server sotto il tuo controllo.",
				"notPaired": "Non associato",
				"paired": "Associato a Motrix",
				"pairedHelp": "Per questo servizio è conservata una credenziale MBP1 confermata. Lo stato attuale della connessione è mostrato separatamente.",
				"pairedTitle": "Associazione pronta",
				"reconnect": "Riconnetti",
				"scopedHelp": "Fiducia e credenziali di associazione sono isolate per ogni servizio. Cambiare servizio non riutilizza mai la fiducia accordata a un altro.",
				"pair": "Associa",
				"pairDialogTitle": "Associa a Motrix"
			},
			"servers": {
				"add": "Aggiungi server",
				"addTitle": "Aggiungi Motrix Server",
				"current": "Attuale",
				"delete": "Elimina server",
				"deleteActiveDescription": "Eliminare {{name}}, le credenziali di associazione e i consensi salvati localmente? Verrà selezionato Motrix App senza connetterlo né avviarlo.",
				"deleteActiveServerOnlyDescription": "Eliminare {{name}}, le credenziali di associazione e i consensi salvati localmente? Prima di scaricare dovrai aggiungere o selezionare un altro Motrix Server.",
				"deleteAria": "Elimina {{name}}",
				"deleteDescription": "Eliminare {{name}}, le credenziali di associazione e i consensi salvati localmente? Nulla verrà revocato sul server.",
				"deleteTitle": "Eliminare Motrix Server?",
				"description": "Salva più indirizzi Motrix Server e passa dall’uno all’altro dalle opzioni o dal popup.",
				"dialogDescription": "Assegna un nome riconoscibile a questo servizio e inserisci l’URL di base WebSocket.",
				"editAria": "Modifica {{name}}",
				"editTitle": "Modifica Motrix Server",
				"emptyDescription": "Aggiungi un server per connetterti a Motrix su un altro computer.",
				"emptyTitle": "Nessun Motrix Server",
				"footer": "Cambiare l’indirizzo del server richiede una nuova associazione. I dati di associazione non vengono mai condivisi tra indirizzi.",
				"nameLabel": "Nome del server",
				"namePlaceholder": "Server di casa",
				"nameRequired": "Il nome del server è obbligatorio",
				"save": "Salva server",
				"statusAuthority": "Indirizzo del server: {{value}}",
				"statusRuntime": "Versione Motrix: {{name}} {{version}}",
				"statusTitle": "Informazioni sul server",
				"statusTransportSecure": "Sicurezza della connessione: WSS in uso e identità del server verificata tramite TLS",
				"statusTransportPlain": "Sicurezza della connessione: crittografata, ma WS non può verificare l’identità del server e può esporre informazioni sulla connessione. Si consiglia WSS",
				"title": "Server Motrix",
				"urlDescription": "Usa un URL di base ws:// o wss://. Il percorso facoltativo viene conservato come prefisso esatto del proxy inverso; si consiglia WSS.",
				"urlDuplicate": "Questo indirizzo Motrix Server è già salvato",
				"urlInvalid": "Inserisci un URL di base ws:// o wss:// valido, senza spazi, credenziali, query o frammenti",
				"urlLabel": "URL WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Questa connessione non usa WSS",
				"transportWarningBody": "I contenuti scambiati con Motrix restano crittografati, ma WS non può verificare l’identità del server e può esporre informazioni sulla connessione. Usa WSS se il tuo NAS lo supporta.",
				"urlRequired": "L’URL WebSocket è obbligatorio"
			},
			"takeover": {
				"consentBody": "Motrix riceve i cookie di accesso del sito per scaricare i file. I download dai siti sensibili restano nel browser.",
				"consentCancel": "Annulla",
				"consentConfirm": "Abilita",
				"consentDialogLabel": "Inviare i download a Motrix?",
				"denylistLabel": "Elenco esclusioni (un host per riga — sempre gestito dal browser)",
				"enableAria": "Abilita gestione dei download",
				"enableLabel": "Invia i download idonei a Motrix",
				"loading": "Caricamento impostazioni di gestione dei download…",
				"minSizeLabel": "Dimensione minima (MB)",
				"minSizePlaceholder": "0 = tutti",
				"thresholdInvalid": "La dimensione minima deve essere un numero non negativo",
				"save": "Salva",
				"saved": "Salvato",
				"title": "Gestione dei download",
				"remoteUnavailable": "La gestione automatica richiede attualmente Motrix App in locale. I download remoti e le autorizzazioni per intestazioni o cookie non la abilitano. Puoi comunque inviare download a questo Server manualmente o dal menu contestuale.",
				"availabilityUnknown": "La gestione dei download non è disponibile finché non è possibile verificare il servizio selezionato.",
				"remoteUnavailableShort": "Solo App locale. L’invio con clic destro funziona con i Server."
			},
			"tabs": {
				"general": "Generali",
				"download": "Download",
				"integration": "Integrazione",
				"help": "Aiuto"
			},
			"common": {
				"apply": "Applica",
				"cancel": "Annulla",
				"loadError": "Impossibile caricare le impostazioni perché il processo in background dell’estensione non si è avviato. Ricarica l’estensione e riprova.",
				"saved": "Salvato",
				"saving": "Salvataggio…",
				"saveError": "Salvataggio non riuscito"
			},
			"appearance": {
				"title": "Aspetto",
				"theme": {
					"label": "Tema",
					"system": "Segui il sistema",
					"light": "Chiaro",
					"dark": "Scuro"
				}
			},
			"help": {
				"title": "Aiuto e supporto",
				"description": "Consulta guide, assistenza e diagnostica dell’estensione.",
				"reportBug": "Segnala un problema",
				"reportBugDescription": "Apri una segnalazione su GitHub o invia un commento.",
				"issues": "GitHub Issues",
				"docs": "Documentazione",
				"docsDescription": "Leggi le guide su configurazione, associazione, gestione dei download e risoluzione dei problemi.",
				"copyDiagnostics": "Copia diagnostica",
				"copied": "Copiato",
				"diagnostics": "Diagnostica",
				"diagnosticsDescription": "Regola la registrazione e copia le informazioni utili per risolvere i problemi."
			},
			"about": {
				"subtitle": "Scarica file dal web con Motrix",
				"website": "Sito ufficiale"
			},
			"title": "Impostazioni dell’estensione Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Questo computer",
				"choose": "Scegli servizio Motrix",
				"configureServer": "Gestisci Motrix Server",
				"notConfigured": "Non configurato",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "motore: {{state}}",
				"noDownloads": "Nessun download",
				"pause": "Pausa",
				"remove": "Rimuovi",
				"resume": "Riprendi",
				"statsSummary": "Attivi: {{active}} · In attesa: {{waiting}}"
			},
			"dashboard": {
				"activity": "Attività",
				"resources": "Risorse",
				"showResources": "Mostra risorse di questa pagina",
				"showTasks": "Mostra attività in corso",
				"title": "Panoramica trasferimenti"
			},
			"loading": "Caricamento…",
			"quickSettings": {
				"fullSettings": "Tutte le impostazioni",
				"fullSettingsDescription": "Generali, download, servizio e aiuto",
				"loadError": "Impossibile caricare le impostazioni rapide.",
				"notificationsDescription": "Gestisci notifiche di sistema dell’estensione",
				"retry": "Riprova",
				"saveError": "Impossibile salvare l’impostazione. Riprova.",
				"takeoverDescription": "Invia i download del browser al servizio Motrix attuale"
			},
			"quickAdd": {
				"title": "Nuova attività",
				"description": "Incolla un link HTTP, HTTPS o magnet.",
				"inputLabel": "Indirizzo di download",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Annulla",
				"add": "Aggiungi",
				"submitting": "Aggiunta…",
				"error": {
					"empty": "Inserisci un indirizzo di download.",
					"unsupported": "Sono supportati solo link HTTP, HTTPS o magnet.",
					"invalid": "L’indirizzo di download non è valido.",
					"submitFailed": "Impossibile aggiungere l’attività. Riprova."
				}
			},
			"reconnect": "Connetti",
			"settings": "Apri impostazioni",
			"sniffer": {
				"clearFilters": "Cancella filtri",
				"detected": "Elementi: {{count}}",
				"downloadCount": "Scarica ({{count}})",
				"downloadSelected": "Scarica selezionati",
				"downloadedResource": "Inviato: {{name}}",
				"downloadingResource": "Download di {{name}}",
				"emptyDescription": "Riproduci un media e riprova.",
				"emptyFilter": "Nessuna risorsa corrispondente",
				"emptyTitle": "Nessun media trovato",
				"filteredCount": "{{matched}} / {{total}} immagini",
				"filters": {
					"all": "Tutti",
					"audio": "Audio",
					"image": "Immagini",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "Filtri attivi: {{count}}",
					"dimensions": "Dimensioni e peso",
					"done": "Fine",
					"fields": {
						"height": "Altezza",
						"size": "Dimensione",
						"width": "Larghezza"
					},
					"formatOptionLabel": "Filtra immagini {{format}}",
					"formats": "Formato immagine",
					"operatorLabel": "Confronto per {{label}}",
					"reset": "Reimposta",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Unità di dimensione del file",
					"title": "Filtri rapidi",
					"trigger": "Filtra",
					"valueLabel": "Valore di {{label}}"
				},
				"imageCount": "Immagini: {{count}}",
				"noImageMatches": "Nessuna immagine corrispondente",
				"pageAction": {
					"bilibili": "Invia questo video bilibili",
					"youtube": "Invia questo video YouTube"
				},
				"pageSubmitted": "Video inviato a Motrix {{taskId}}",
				"pageResources": "Risorse",
				"quickDownloadResource": "Download rapido di {{name}}",
				"connectToSubmit": "Connettiti a Motrix per inviare risorse.",
				"scan": "Ripeti scansione",
				"scanning": "Scansione…",
				"selectAll": "Seleziona tutto",
				"selected": "Selezionati: {{count}}",
				"selectResource": "Seleziona {{name}}",
				"sourceHost": "Origine: {{host}}",
				"sendResource": "Invia {{name}} a Motrix",
				"sent": "Inviato",
				"sending": "Invio",
				"submitFailed": "Impossibile inviare la risorsa. Riprova.",
				"title": "Rileva risorse",
				"unavailableDescription": "Cambia pagina o riprova più tardi.",
				"unavailableTitle": "Pagina non analizzabile",
				"unsupported": "Richiede ffmpeg",
				"unsupportedReason": "Il servizio selezionato non può inviare risorse {{kind}} perché il supporto ffmpeg non è disponibile.",
				"unsupportedSelectionReason": "Il servizio selezionato non può inviare uno o più tipi di risorse selezionati.",
				"unsupportedResource": "Impossibile inviare {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Download",
				"upload": "Caricamento"
			},
			"status": {
				"bootstrapping": "Ricerca di Motrix…",
				"connected": "Connesso",
				"connecting": "Connessione…",
				"denied": "Associazione rifiutata",
				"disconnected": "Disconnesso",
				"handshaking": "Negoziazione in corso",
				"awaiting-code": "In attesa del codice di associazione…"
			},
			"tabs": {
				"settings": "Impostazioni",
				"sniffer": "Risorse",
				"tasks": "Attività"
			},
			"takeover": {
				"aria": "Attiva o disattiva la gestione dei download",
				"label": "Intercetta"
			},
			"tasks": {
				"actions": "Azioni per {{name}}",
				"openFolder": "Apri cartella contenente il file in Motrix",
				"openFolderError": "Impossibile aprire la cartella dell’attività. Riprova.",
				"openFolderMetadataPending": "Attendi i metadati dell’attività prima di aprire la cartella",
				"openFolderTask": "Apri la cartella contenente {{name}}",
				"openFolderUnsupported": "Aggiorna Motrix per aprire le cartelle",
				"pauseTask": "Metti in pausa {{name}}",
				"removeTask": "Rimuovi {{name}}",
				"removeConfirmTitle": "Rimuovere l’attività?",
				"removeConfirmDescription": "«{{name}}» verrà rimosso dall’elenco dei download.",
				"removeDeleteFilesLabel": "Elimina i file scaricati",
				"removeConfirmAction": "Rimuovi",
				"resumeTask": "Riprendi {{name}}",
				"bytes": "{{done}} di {{total}}",
				"disconnectedDescription": "Connettiti per visualizzare le attività.",
				"disconnectedTitle": "Motrix è offline",
				"empty": {
					"active": "Nessuna attività in corso",
					"failed": "Nessuna attività fallita",
					"recent": "Nessuna attività conclusa"
				},
				"filters": {
					"active": "In corso",
					"failed": "Fallite",
					"recent": "Concluse"
				},
				"loading": "Caricamento attività",
				"status": {
					"completed": "Completate",
					"downloading": "Download in corso",
					"error": "Non riuscite",
					"fetching_metadata": "Recupero metadati",
					"finalizing": "Finalizzazione",
					"paused": "In pausa",
					"queued": "In coda",
					"seeding": "Condivisione"
				},
				"title": "Attività"
			},
			"pairing": {
				"attemptOf": "Tentativo {{run}} di {{maxRuns}}",
				"attemptsRemaining": "Tentativi rimanenti: {{attemptsRemaining}}",
				"codeLabel": "Codice di associazione",
				"codeDescription": "Inserisci il codice di 8 caratteri nella finestra di associazione Motrix.",
				"codeInvalid": "Inserisci il codice di 8 caratteri nella finestra di associazione.",
				"dialogTitle": "Inserisci codice di associazione",
				"dismissPrompt": "Inserisci dopo e continua a navigare",
				"enterCode": "Inserisci codice di associazione",
				"expiresIn": "Scade tra {{time}}",
				"pairButton": "Associa",
				"pickerHelp": "Sono state trovate più istanze di Motrix. Scegli quale associare.",
				"rescan": "Ripeti ricerca",
				"noCandidates": "Nessuna istanza di Motrix trovata.",
				"candidatesLabel": "Istanze di Motrix rilevate",
				"candidatePort": "Porta {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "versione sconosciuta",
				"choose": "Scegli",
				"backoffTitle": "Troppi tentativi di associazione",
				"backoffBody": "Riprova alle {{time}}.",
				"retryIn": "Riprova tra {{seconds}} s",
				"permissionMissingTitle": "Autorizzazione necessaria",
				"permissionMissingBody": "Consenti l’accesso a localhost per trovare Motrix su questo computer.",
				"grantPermission": "Concedi autorizzazione",
				"degradedTitle": "Motrix è connesso",
				"degradedBody": "Puoi usare Motrix normalmente. Questa connessione dispone solo di una verifica di base. Per una maggiore protezione, aggiorna Motrix e associalo di nuovo.",
				"recoveryExhaustedTitle": "Riconnessione automatica non riuscita",
				"recoveryExhaustedBody": "Nessuna associazione Motrix salvata ha funzionato. Premi Connetti per ripetere l’associazione."
			}
		},
		errors: { "connection": {
			"generic": "Connessione non riuscita. Riprova.",
			"backoffLocked": "Troppi tentativi di associazione. Riprova più tardi.",
			"staleAttempt": "Un tentativo di connessione più recente ha sostituito questo.",
			"aborted": "L’associazione è stata annullata.",
			"deadlineExceeded": "Tempo scaduto. Riprova.",
			"runsExhausted": "Troppi codici errati. Riavvia l’associazione per ottenere un nuovo codice.",
			"invalidCode": "Il codice non ha il formato previsto. Controlla la finestra di Motrix.",
			"missingNonce": "Motrix non ha offerto una sessione di associazione. Assicurati che sia in esecuzione e riprova.",
			"unsupportedBrowser": "L’associazione non è supportata in questo browser.",
			"ticketPreparationFailed": "Impossibile preparare l’associazione. Riprova.",
			"protocolViolation": "Motrix ha inviato una risposta imprevista. Riprova.",
			"unsupportedVersion": "L’estensione e Motrix usano versioni diverse del protocollo. Aggiorna entrambi e riprova.",
			"backendUpgradeRequired": "Questa versione di Motrix è troppo vecchia per un’associazione sicura. Aggiorna Motrix e riprova.",
			"extensionUpgradeRequired": "Questa versione dell’estensione è troppo vecchia per questo Motrix. Aggiorna l’estensione Motrix e riprova.",
			"unsupportedRemote": "Il Motrix autenticato non è l’App o il Server selezionato per questa connessione. Controlla l’endpoint e riprova.",
			"remoteDiscoveryUnavailable": "Il Motrix Server remoto non è raggiungibile. Controlla indirizzo, servizio in ascolto e rete; per WSS, controlla anche certificato e proxy inverso.",
			"remotePairingUnavailable": "Il Motrix Server remoto non ha potuto aprire una sessione di associazione sicura. Riprova tra poco.",
			"remoteTransportUnavailable": "Connessione al Motrix Server remoto non riuscita. Controlla indirizzo, servizio in ascolto, DNS e rete; per WSS, controlla anche certificato e proxy inverso. Il browser non può identificare la causa precisa.",
			"peerRejected": "Motrix ha rifiutato l’associazione.",
			"peerBusy": "Motrix sta gestendo troppe richieste di associazione. Riprova tra poco.",
			"securityCheckFailed": "La connessione non ha superato un controllo di sicurezza ed è stata interrotta.",
			"peerNotAuthentic": "L’altra parte non ha potuto dimostrare di essere il tuo Motrix. La connessione è stata interrotta.",
			"credentialPhaseFailed": "Impossibile salvare l’associazione. Riprova ad associare.",
			"internalError": "Si è verificato un errore nell’estensione. Riprova.",
			"authFailed": "Motrix non ha riconosciuto questa associazione. Potrebbe essere stata revocata; ripeti l’associazione.",
			"serverMacMismatch": "La risposta non ha superato la verifica e la connessione è stata interrotta. Potrebbe non essere il tuo Motrix.",
			"channelClosed": "La connessione è stata chiusa. Riconnettiti per continuare.",
			"channelUnavailable": "Motrix non è raggiungibile al momento. Assicurati che sia in esecuzione."
		} }
	} },
	ja: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix：接続済み",
			"disconnected": "Motrix：未接続",
			"connecting": "Motrix：接続中…",
			"downloading": "Motrix：ダウンロード中",
			"denied": "Motrix：ペアリングが拒否されました — 開いて再ペアリング",
			"error": "Motrix：転送に失敗しました — クリックして詳細を表示"
		} },
		contextMenu: {
			"downloadWithMotrix": "Motrix でダウンロード",
			"pairThenDownload": "Motrix をペアリングしてダウンロード"
		},
		notify: {
			"browserFallbackBody": "Motrix を利用できないため、ブラウザーでダウンロードします。",
			"browserFallbackTitle": "ブラウザーでダウンロード中",
			"downloadComplete": "ダウンロード完了",
			"downloadFailed": "ダウンロード失敗",
			"handedToMotrix": "Motrix に送信しました",
			"notConnectedBody": "Motrix をペアリングすると、ダウンロードを引き継げます。",
			"notConnectedTitle": "Motrix 未接続",
			"notReachableBody": "Motrix をペアリングしてから、もう一度ダウンロードしてください。",
			"notReachableTitle": "Motrix に接続できません",
			"pairNudgeBody": "Motrix を開いてペアリングを完了してください。",
			"pairNudgeTitle": "Motrix をペアリング",
			"pairRevokedBody": "Motrix がこのブラウザーのペアリングを解除しました。",
			"pairRevokedTitle": "ペアリングが解除されました",
			"sensitiveSkippedBody": "機密性の高いサイトのダウンロードはブラウザーで処理します。",
			"sensitiveSkippedTitle": "スキップしました",
			"submitFailedBody": "ブラウザーで再ダウンロードしています。",
			"submitFailedTitle": "Motrix への送信に失敗しました"
		},
		options: /* @__PURE__ */ JSON.parse("{\"diagnostics\":{\"adapters\":\"アダプター\",\"extensionId\":\"拡張機能 ID\",\"logLevel\":\"ログレベル\",\"logLevels\":{\"silent\":\"出力しない\",\"error\":\"エラー\",\"warn\":\"警告\",\"info\":\"情報\",\"debug\":\"デバッグ\"},\"noneRegistered\":\"まだ登録されていません\",\"title\":\"診断\",\"version\":\"バージョン\"},\"endpoint\":{\"activate\":\"使用\",\"activateAria\":\"{{name}} を使用\",\"connection\":{\"bootstrapping\":\"起動中\",\"connected\":\"接続済み\",\"connecting\":\"接続中\",\"denied\":\"拒否されました\",\"disconnected\":\"未接続\",\"handshaking\":\"認証中\",\"awaiting-code\":\"コード待機中\"},\"currentDescription\":\"ダウンロード、タスク、ページから検出したリソースに使用する App または Server を選択します。\",\"currentTitle\":\"Motrix バックエンド\",\"listLabel\":\"利用可能な Motrix バックエンド\",\"localDescription\":\"Motrix App で検出されたこのコンピューター\",\"localName\":\"Motrix App\",\"selectLabel\":\"ダウンロードの送信先\"},\"language\":{\"label\":\"言語\",\"system\":\"システムに合わせる\"},\"notifications\":{\"title\":\"システム通知\",\"masterLabel\":\"システム通知を有効にする\",\"masterAria\":\"システム通知を有効にする\",\"confirmLabel\":\"成功・確認\",\"confirmDesc\":\"Motrix への送信、ダウンロード完了\",\"errorLabel\":\"失敗・エラー\",\"errorDesc\":\"送信失敗、接続不可、ダウンロード失敗\",\"reminderLabel\":\"リマインダー\",\"reminderDesc\":\"ペアリングの案内、ペアリング解除、サイトのスキップ\"},\"pairing\":{\"backendTitle\":\"{{name}} とペアリング\",\"forget\":\"ペアリング情報を削除\",\"loading\":\"ペアリング状態を読み込み中…\",\"localHelp\":\"「ペアリング」をクリックしてこのコンピューター上の Motrix を検出し、ペアリングコードを入力してください。\",\"localTitle\":\"Motrix App 経由でペアリング\",\"remoteTitle\":\"Motrix Server とペアリング\",\"remoteHelp\":\"「ペアリング」をクリックし、Server の管理画面でリクエストを承認してから、表示されたコードをここに入力してください。WS と WSS の両方に対応しています。WSS を推奨します。\",\"serverRequiredTitle\":\"Motrix Server が必要です\",\"serverRequiredHelp\":\"Android 版 Firefox は Motrix Server 経由で接続します。上で Server を追加し、選択してペアリングしてください。\",\"remoteConsentTitle\":\"リモートダウンロード\",\"remoteConsentBody\":\"リモートダウンロードでは、対象 URL、元のページの URL とタイトル、ファイル名、選択内容、タスク操作をこの Server に送信します。Cookie とリクエストヘッダーは、個別に有効にしない限り送信しません。\",\"remoteConsentOffline\":\"データの権限は認証済みの Server に紐づきます。変更する前に接続してください。\",\"remoteHeadersLabel\":\"リクエストヘッダーを送信\",\"remoteHeadersHelp\":\"Referer やメディア再生用ヘッダーなど、ページ由来のヘッダーを許可します。認証ヘッダーには、下の認証情報の権限が別途必要です。\",\"remoteCredentialsLabel\":\"Cookie と認証情報を送信\",\"remoteCredentialsHelp\":\"この Server に限り、Cookie と認証情報ヘッダーを許可します。自分で管理する Server にのみ有効にしてください。\",\"notPaired\":\"未ペアリング\",\"paired\":\"Motrix とペアリング済み\",\"pairedHelp\":\"このバックエンドには確定済みの MBP1 認証情報が保存されています。現在の接続状態は別途表示されます。\",\"pairedTitle\":\"ペアリング準備完了\",\"reconnect\":\"再接続\",\"scopedHelp\":\"ペアリングの信頼関係と認証情報はバックエンドごとに分離されています。切り替えても、別のバックエンドの信頼関係は引き継ぎません。\",\"pair\":\"ペアリング\",\"pairDialogTitle\":\"Motrix とペアリング\"},\"servers\":{\"add\":\"サーバーを追加\",\"addTitle\":\"Motrix Server を追加\",\"current\":\"現在使用中\",\"delete\":\"サーバーを削除\",\"deleteActiveDescription\":\"{{name}} と、ローカルに保存されたペアリング認証情報および同意を削除しますか？使用するバックエンドは Motrix App に戻りますが、接続や起動は行いません。\",\"deleteActiveServerOnlyDescription\":\"{{name}} と、ローカルに保存されたペアリング認証情報および同意を削除しますか？ダウンロードするには別の Motrix Server を追加または選択する必要があります。\",\"deleteAria\":\"{{name}} を削除\",\"deleteDescription\":\"{{name}} と、ローカルに保存されたペアリング認証情報および同意を削除しますか？サーバー側の情報や権限は取り消されません。\",\"deleteTitle\":\"Motrix Server を削除しますか？\",\"description\":\"複数の Motrix Server のアドレスを保存し、設定画面やポップアップから切り替えられます。\",\"dialogDescription\":\"このバックエンドにわかりやすい名前を付け、WebSocket のベース URL を入力してください。\",\"editAria\":\"{{name}} を編集\",\"editTitle\":\"Motrix Server を編集\",\"emptyDescription\":\"サーバーを追加すると、別のコンピューター上の Motrix に接続できます。\",\"emptyTitle\":\"Motrix Server は未登録\",\"footer\":\"サーバーのアドレスを変更すると、再ペアリングが必要です。ペアリング情報はアドレス間で共有されません。\",\"nameLabel\":\"サーバー名\",\"namePlaceholder\":\"自宅サーバー\",\"nameRequired\":\"サーバー名は必須です\",\"save\":\"サーバーを保存\",\"statusAuthority\":\"サーバーアドレス：{{value}}\",\"statusRuntime\":\"Motrix バージョン：{{name}} {{version}}\",\"statusTitle\":\"サーバー情報\",\"statusTransportSecure\":\"接続の安全性：WSS を使用し、TLS でサーバーの身元を検証しています\",\"statusTransportPlain\":\"接続の安全性：暗号化されていますが、WS ではサーバーの身元を検証できず、接続情報が漏れる可能性があります。WSS を推奨します\",\"title\":\"Motrix サーバー\",\"urlDescription\":\"ws:// または wss:// のベース URL を使用してください。任意のパスはリバースプロキシのプレフィックスとしてそのまま保持されます。WSS を推奨します。\",\"urlDuplicate\":\"この Motrix Server のアドレスは保存済みです\",\"urlInvalid\":\"空白、認証情報、クエリ、フラグメントを含まない、有効な ws:// または wss:// のベース URL を入力してください\",\"urlLabel\":\"WebSocket URL\",\"urlPlaceholder\":\"ws(s)://host[:port][/base-path]\",\"transportWarningTitle\":\"この接続は WSS を使用していません\",\"transportWarningBody\":\"Motrix とやり取りする内容は暗号化されていますが、WS ではサーバーの身元を検証できず、接続情報が漏れる可能性があります。NAS が対応している場合は WSS を使用してください。\",\"urlRequired\":\"WebSocket URL は必須です\"},\"takeover\":{\"consentBody\":\"ファイルをダウンロードするため、サイトのログイン Cookie が Motrix に渡されます。機密性の高いサイトのダウンロードはブラウザーで処理します。\",\"consentCancel\":\"キャンセル\",\"consentConfirm\":\"有効にする\",\"consentDialogLabel\":\"ダウンロードを Motrix に送信しますか？\",\"denylistLabel\":\"除外リスト（1 行に 1 ホスト — 常にブラウザーで処理）\",\"enableAria\":\"ダウンロードの引き継ぎを有効にする\",\"enableLabel\":\"対象のダウンロードを Motrix に送信\",\"loading\":\"引き継ぎ設定を読み込み中…\",\"minSizeLabel\":\"最小サイズ（MB）\",\"minSizePlaceholder\":\"0 = すべて\",\"thresholdInvalid\":\"最小サイズには 0 以上の数値を指定してください\",\"save\":\"保存\",\"saved\":\"保存しました\",\"title\":\"ダウンロードの引き継ぎ\",\"remoteUnavailable\":\"自動引き継ぎには現在、ローカルの Motrix App が必要です。リモートダウンロードやヘッダー・Cookie の権限では有効になりません。この Server には引き続き手動または右クリックメニューからダウンロードを送信できます。\",\"availabilityUnknown\":\"選択したバックエンドを確認できるまで、引き継ぎは利用できません。\",\"remoteUnavailableShort\":\"ローカル App のみ対応。右クリックでの送信は Server でも利用できます。\"},\"tabs\":{\"general\":\"一般\",\"download\":\"ダウンロード\",\"integration\":\"連携\",\"help\":\"ヘルプ\"},\"common\":{\"apply\":\"適用\",\"cancel\":\"キャンセル\",\"loadError\":\"拡張機能のバックグラウンド処理が起動しなかったため、設定を読み込めませんでした。拡張機能を再読み込みして、再試行してください。\",\"saved\":\"保存しました\",\"saving\":\"保存中…\",\"saveError\":\"保存に失敗しました\"},\"appearance\":{\"title\":\"外観\",\"theme\":{\"label\":\"テーマ\",\"system\":\"システムに合わせる\",\"light\":\"ライト\",\"dark\":\"ダーク\"}},\"help\":{\"title\":\"ヘルプとサポート\",\"description\":\"ガイド、サポート、拡張機能の診断情報を確認できます。\",\"reportBug\":\"問題を報告\",\"reportBugDescription\":\"GitHub で Issue を作成するか、フィードバックをお寄せください。\",\"issues\":\"GitHub Issues\",\"docs\":\"ドキュメント\",\"docsDescription\":\"設定、ペアリング、ダウンロードの引き継ぎ、トラブルシューティングのガイドを確認できます。\",\"copyDiagnostics\":\"診断情報をコピー\",\"copied\":\"コピーしました\",\"diagnostics\":\"診断\",\"diagnosticsDescription\":\"ログ設定を調整し、問題の解決に役立つ情報をコピーできます。\"},\"about\":{\"subtitle\":\"ウェブ上のファイルを Motrix でダウンロード\",\"website\":\"公式サイト\"},\"title\":\"Motrix 拡張機能の設定\"}"),
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "このコンピューター",
				"choose": "Motrix バックエンドを選択",
				"configureServer": "Motrix Server を管理",
				"notConfigured": "未設定",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "エンジン：{{state}}",
				"noDownloads": "ダウンロードはありません",
				"pause": "一時停止",
				"remove": "削除",
				"resume": "再開",
				"statsSummary": "実行中：{{active}} · 待機中：{{waiting}}"
			},
			"dashboard": {
				"activity": "アクティビティ",
				"resources": "リソース",
				"showResources": "このページのリソースを表示",
				"showTasks": "実行中のタスクを表示",
				"title": "転送の概要"
			},
			"loading": "読み込み中…",
			"quickSettings": {
				"fullSettings": "すべての設定",
				"fullSettingsDescription": "一般、ダウンロード、バックエンド、ヘルプ",
				"loadError": "クイック設定を読み込めません。",
				"notificationsDescription": "拡張機能のシステム通知を設定",
				"retry": "再試行",
				"saveError": "設定の保存に失敗しました。再試行してください。",
				"takeoverDescription": "ブラウザーのダウンロードを現在の Motrix バックエンドに送信"
			},
			"quickAdd": {
				"title": "新しいタスク",
				"description": "HTTP、HTTPS、またはマグネットリンクを貼り付けてください。",
				"inputLabel": "ダウンロードアドレス",
				"placeholder": "https://example.com/file.zip",
				"cancel": "キャンセル",
				"add": "追加",
				"submitting": "追加中…",
				"error": {
					"empty": "ダウンロードアドレスを入力してください。",
					"unsupported": "HTTP、HTTPS、マグネットリンクのみに対応しています。",
					"invalid": "ダウンロードアドレスが無効です。",
					"submitFailed": "タスクを追加できませんでした。再試行してください。"
				}
			},
			"reconnect": "接続",
			"settings": "設定を開く",
			"sniffer": {
				"clearFilters": "フィルターをクリア",
				"detected": "{{count}} 件",
				"downloadCount": "{{count}} 件をダウンロード",
				"downloadSelected": "選択項目をダウンロード",
				"downloadedResource": "{{name}} を送信しました",
				"downloadingResource": "{{name}} をダウンロード中",
				"emptyDescription": "メディアを再生して再試行してください。",
				"emptyFilter": "一致するリソースなし",
				"emptyTitle": "メディアが見つかりません",
				"filteredCount": "画像 {{matched}} / {{total}} 件",
				"filters": {
					"all": "すべて",
					"audio": "音声",
					"image": "画像",
					"video": "動画"
				},
				"imageFilters": {
					"activeCount": "有効なフィルター：{{count}} 個",
					"dimensions": "寸法とサイズ",
					"done": "完了",
					"fields": {
						"height": "高さ",
						"size": "サイズ",
						"width": "幅"
					},
					"formatOptionLabel": "{{format}} 画像で絞り込む",
					"formats": "画像形式",
					"operatorLabel": "{{label}} の比較条件",
					"reset": "リセット",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "ファイルサイズの単位",
					"title": "クイックフィルター",
					"trigger": "絞り込み",
					"valueLabel": "{{label}} の値"
				},
				"imageCount": "画像 {{count}} 件",
				"noImageMatches": "一致する画像はありません",
				"pageAction": {
					"bilibili": "この bilibili 動画を送信",
					"youtube": "この YouTube 動画を送信"
				},
				"pageSubmitted": "動画を Motrix に送信しました {{taskId}}",
				"pageResources": "リソース",
				"quickDownloadResource": "{{name}} をクイックダウンロード",
				"connectToSubmit": "リソースを送信するには Motrix に接続してください。",
				"scan": "再スキャン",
				"scanning": "スキャン中…",
				"selectAll": "すべて選択",
				"selected": "{{count}} 件選択中",
				"selectResource": "{{name}} を選択",
				"sourceHost": "取得元：{{host}}",
				"sendResource": "{{name}} を Motrix に送信",
				"sent": "送信済み",
				"sending": "送信中",
				"submitFailed": "リソースを送信できませんでした。再試行してください。",
				"title": "リソース検出",
				"unavailableDescription": "ページを変えるか、後で再試行してください。",
				"unavailableTitle": "このページはスキャン不可",
				"unsupported": "ffmpeg が必要です",
				"unsupportedReason": "選択したバックエンドは ffmpeg に対応していないため、{{kind}} リソースを送信できません。",
				"unsupportedSelectionReason": "選択したバックエンドでは、選択されたリソースの一部またはすべての種類を送信できません。",
				"unsupportedResource": "{{name}} を送信できません。{{reason}}"
			},
			"speed": {
				"download": "ダウンロード",
				"upload": "アップロード"
			},
			"status": {
				"bootstrapping": "Motrix を検索中…",
				"connected": "接続済み",
				"connecting": "接続中…",
				"denied": "ペアリングが拒否されました",
				"disconnected": "未接続",
				"handshaking": "ハンドシェイク中",
				"awaiting-code": "ペアリングコード待機中…"
			},
			"tabs": {
				"settings": "設定",
				"sniffer": "リソース",
				"tasks": "タスク"
			},
			"takeover": {
				"aria": "ダウンロードの引き継ぎを切り替え",
				"label": "引き継ぎ"
			},
			"tasks": {
				"actions": "{{name}} の操作",
				"openFolder": "保存先フォルダーを Motrix で開く",
				"openFolderError": "タスクのフォルダーを開けませんでした。再試行してください。",
				"openFolderMetadataPending": "タスクのメタデータ取得後にフォルダーを開いてください",
				"openFolderTask": "{{name}} があるフォルダーを開く",
				"openFolderUnsupported": "フォルダーを開くには Motrix を更新してください",
				"pauseTask": "{{name}} を一時停止",
				"removeTask": "{{name}} を削除",
				"removeConfirmTitle": "タスクを削除しますか？",
				"removeConfirmDescription": "「{{name}}」をダウンロード一覧から削除します。",
				"removeDeleteFilesLabel": "ダウンロードしたファイルを削除",
				"removeConfirmAction": "削除",
				"resumeTask": "{{name}} を再開",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "タスクを表示するには接続してください。",
				"disconnectedTitle": "Motrix はオフラインです",
				"empty": {
					"active": "実行中のタスクなし",
					"failed": "失敗したタスクなし",
					"recent": "完了したタスクなし"
				},
				"filters": {
					"active": "実行中",
					"failed": "失敗",
					"recent": "完了"
				},
				"loading": "タスクを読み込み中",
				"status": {
					"completed": "完了",
					"downloading": "ダウンロード中",
					"error": "失敗",
					"fetching_metadata": "メタデータを取得中",
					"finalizing": "完了処理中",
					"paused": "一時停止中",
					"queued": "待機中",
					"seeding": "シード中"
				},
				"title": "タスク"
			},
			"pairing": {
				"attemptOf": "試行 {{run}} / {{maxRuns}} 回",
				"attemptsRemaining": "残り {{attemptsRemaining}} 回",
				"codeLabel": "ペアリングコード",
				"codeDescription": "Motrix のペアリング画面にある 8 文字のコードを入力してください。",
				"codeInvalid": "ペアリング画面にある 8 文字のコードを入力してください。",
				"dialogTitle": "ペアリングコードを入力",
				"dismissPrompt": "後で入力して閲覧を続ける",
				"enterCode": "ペアリングコードを入力",
				"expiresIn": "有効期限まで {{time}}",
				"pairButton": "ペアリング",
				"pickerHelp": "複数の Motrix インスタンスが見つかりました。ペアリングするものを選択してください。",
				"rescan": "再検索",
				"noCandidates": "Motrix インスタンスが見つかりませんでした。",
				"candidatesLabel": "検出された Motrix インスタンス",
				"candidatePort": "ポート {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "バージョン不明",
				"choose": "選択",
				"backoffTitle": "ペアリングの試行回数が多すぎます",
				"backoffBody": "{{time}} に再試行してください。",
				"retryIn": "{{seconds}} 秒後に再試行",
				"permissionMissingTitle": "権限が必要です",
				"permissionMissingBody": "このコンピューター上の Motrix を検出するには、localhost へのアクセスを許可してください。",
				"grantPermission": "権限を許可",
				"degradedTitle": "Motrix に接続しました",
				"degradedBody": "Motrix を通常どおり使用できます。この接続は基本的な検証のみ行われています。保護を強化するには、Motrix を更新して再ペアリングしてください。",
				"recoveryExhaustedTitle": "自動再接続できませんでした",
				"recoveryExhaustedBody": "保存済みの Motrix ペアリングはどれも使用できませんでした。「接続」を押して再ペアリングしてください。"
			}
		},
		errors: { "connection": {
			"generic": "接続に失敗しました。再試行してください。",
			"backoffLocked": "ペアリングの試行回数が多すぎます。後で再試行してください。",
			"staleAttempt": "新しい接続試行に切り替わりました。",
			"aborted": "ペアリングはキャンセルされました。",
			"deadlineExceeded": "試行がタイムアウトしました。再試行してください。",
			"runsExhausted": "コードの入力間違いが多すぎます。ペアリングをやり直して、新しいコードを取得してください。",
			"invalidCode": "コードの形式が正しくありません。Motrix のダイアログを確認してください。",
			"missingNonce": "Motrix がペアリング枠を提供しませんでした。Motrix が起動していることを確認して、再試行してください。",
			"unsupportedBrowser": "このブラウザーはペアリングに対応していません。",
			"ticketPreparationFailed": "ペアリングを準備できませんでした。再試行してください。",
			"protocolViolation": "Motrix から予期しない応答がありました。再試行してください。",
			"unsupportedVersion": "この拡張機能と Motrix のプロトコルバージョンが異なります。両方を更新して、再試行してください。",
			"backendUpgradeRequired": "この Motrix は古すぎるため、安全にペアリングできません。Motrix を更新して、再試行してください。",
			"extensionUpgradeRequired": "この拡張機能は古すぎるため、この Motrix に対応していません。Motrix 拡張機能を更新して、再試行してください。",
			"unsupportedRemote": "認証された Motrix は、この接続で選択した App または Server ではありません。接続先を確認して、再試行してください。",
			"remoteDiscoveryUnavailable": "リモートの Motrix Server に接続できません。アドレス、待ち受けサービス、ネットワークを確認してください。WSS の場合は証明書とリバースプロキシも確認してください。",
			"remotePairingUnavailable": "リモートの Motrix Server が安全なペアリングセッションを開始できませんでした。しばらくしてから再試行してください。",
			"remoteTransportUnavailable": "リモートの Motrix Server への接続に失敗しました。アドレス、待ち受けサービス、DNS、ネットワークを確認してください。WSS の場合は証明書とリバースプロキシも確認してください。ブラウザーでは原因を特定できません。",
			"peerRejected": "Motrix がペアリングを拒否しました。",
			"peerBusy": "Motrix が多数のペアリング要求を処理しています。しばらくしてから再試行してください。",
			"securityCheckFailed": "接続がセキュリティチェックに失敗したため、停止しました。",
			"peerNotAuthentic": "接続先があなたの Motrix であることを確認できなかったため、接続を停止しました。",
			"credentialPhaseFailed": "ペアリングを保存できませんでした。もう一度ペアリングしてください。",
			"internalError": "拡張機能で問題が発生しました。再試行してください。",
			"authFailed": "Motrix がこのペアリングを認識しませんでした。解除された可能性があります。再ペアリングしてください。",
			"serverMacMismatch": "応答を検証できなかったため、接続を停止しました。あなたの Motrix ではない可能性があります。",
			"channelClosed": "接続が閉じられました。続行するには再接続してください。",
			"channelUnavailable": "現在 Motrix に接続できません。起動していることを確認してください。"
		} }
	} },
	ko: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: 연결됨",
			"disconnected": "Motrix: 연결되지 않음",
			"connecting": "Motrix: 연결 중…",
			"downloading": "Motrix: 다운로드 중",
			"denied": "Motrix: 페어링 거부됨 — 열어서 다시 페어링하세요",
			"error": "Motrix: 전송 실패 — 클릭하여 세부 정보 확인"
		} },
		contextMenu: {
			"downloadWithMotrix": "Motrix로 다운로드",
			"pairThenDownload": "Motrix를 페어링한 후 다운로드"
		},
		notify: {
			"browserFallbackBody": "Motrix를 사용할 수 없어 브라우저에서 다운로드합니다.",
			"browserFallbackTitle": "브라우저에서 다운로드 중",
			"downloadComplete": "다운로드 완료",
			"downloadFailed": "다운로드 실패",
			"handedToMotrix": "Motrix로 전송됨",
			"notConnectedBody": "Motrix를 페어링하여 다운로드를 넘겨주세요.",
			"notConnectedTitle": "Motrix가 연결되지 않음",
			"notReachableBody": "Motrix를 페어링한 후 다운로드를 다시 시도하세요.",
			"notReachableTitle": "Motrix에 연결할 수 없음",
			"pairNudgeBody": "Motrix를 열어 페어링을 완료하세요.",
			"pairNudgeTitle": "Motrix 페어링",
			"pairRevokedBody": "Motrix가 이 브라우저의 페어링을 해제했습니다.",
			"pairRevokedTitle": "페어링 해제됨",
			"sensitiveSkippedBody": "민감한 사이트의 다운로드는 브라우저에서 처리합니다.",
			"sensitiveSkippedTitle": "건너뜀",
			"submitFailedBody": "브라우저에서 다시 다운로드합니다.",
			"submitFailedTitle": "Motrix 전송 실패"
		},
		options: {
			"diagnostics": {
				"adapters": "어댑터",
				"extensionId": "확장 프로그램 ID",
				"logLevel": "로그 수준",
				"logLevels": {
					"silent": "기록 안 함",
					"error": "오류",
					"warn": "경고",
					"info": "정보",
					"debug": "디버그"
				},
				"noneRegistered": "아직 등록되지 않음",
				"title": "진단",
				"version": "버전"
			},
			"endpoint": {
				"activate": "사용",
				"activateAria": "{{name}} 사용",
				"connection": {
					"bootstrapping": "시작 중",
					"connected": "연결됨",
					"connecting": "연결 중",
					"denied": "거부됨",
					"disconnected": "연결 끊김",
					"handshaking": "인증 중",
					"awaiting-code": "코드 대기 중"
				},
				"currentDescription": "다운로드, 작업 및 페이지에서 감지한 리소스에 사용할 App 또는 Server를 선택하세요.",
				"currentTitle": "Motrix 백엔드",
				"listLabel": "사용 가능한 Motrix 백엔드",
				"localDescription": "Motrix App으로 감지한 이 컴퓨터",
				"localName": "Motrix App",
				"selectLabel": "다운로드 전송 대상"
			},
			"language": {
				"label": "언어",
				"system": "시스템 설정 따르기"
			},
			"notifications": {
				"title": "시스템 알림",
				"masterLabel": "시스템 알림 사용",
				"masterAria": "시스템 알림 사용",
				"confirmLabel": "성공 / 확인",
				"confirmDesc": "Motrix로 전송됨, 다운로드 완료",
				"errorLabel": "실패 / 오류",
				"errorDesc": "전송 실패, 연결 불가, 다운로드 실패",
				"reminderLabel": "알림 메시지",
				"reminderDesc": "페어링 안내, 페어링 해제, 건너뛴 사이트"
			},
			"pairing": {
				"backendTitle": "{{name}} 페어링",
				"forget": "페어링 정보 삭제",
				"loading": "페어링 상태 불러오는 중…",
				"localHelp": "페어링을 클릭하여 이 컴퓨터의 Motrix를 찾고 페어링 코드를 입력하세요.",
				"localTitle": "Motrix App을 통해 페어링",
				"remoteTitle": "Motrix Server와 페어링",
				"remoteHelp": "페어링을 클릭하고 Server 관리 화면에서 요청을 승인한 다음 표시된 코드를 여기에 입력하세요. WS와 WSS 엔드포인트를 모두 지원하며 WSS를 권장합니다.",
				"serverRequiredTitle": "Motrix Server 필요",
				"serverRequiredHelp": "Android용 Firefox는 Motrix Server를 통해 연결합니다. 위에서 Server를 추가한 후 선택하여 페어링하세요.",
				"remoteConsentTitle": "원격 다운로드",
				"remoteConsentBody": "원격 다운로드는 대상 URL, 원본 페이지의 URL과 제목, 파일명, 선택 내용 및 작업 제어 명령을 이 Server로 전송합니다. 쿠키와 요청 헤더는 별도로 활성화해야 전송됩니다.",
				"remoteConsentOffline": "데이터 권한은 인증된 Server에 연결됩니다. 변경하기 전에 연결하세요.",
				"remoteHeadersLabel": "요청 헤더 전송",
				"remoteHeadersHelp": "Referer 및 미디어 재생 헤더 등 페이지에서 가져온 헤더를 허용합니다. 인증 헤더에는 아래의 자격 증명 권한이 여전히 필요합니다.",
				"remoteCredentialsLabel": "쿠키 및 인증 정보 전송",
				"remoteCredentialsHelp": "이 Server에만 쿠키와 자격 증명 헤더를 허용합니다. 직접 관리하는 Server에만 활성화하세요.",
				"notPaired": "페어링되지 않음",
				"paired": "Motrix와 페어링됨",
				"pairedHelp": "이 백엔드에 확정된 MBP1 자격 증명이 저장되어 있습니다. 현재 연결 상태는 별도로 표시됩니다.",
				"pairedTitle": "페어링 준비 완료",
				"reconnect": "다시 연결",
				"scopedHelp": "페어링 신뢰 관계와 자격 증명은 백엔드별로 분리됩니다. 백엔드를 전환해도 다른 백엔드의 신뢰 관계를 재사용하지 않습니다.",
				"pair": "페어링",
				"pairDialogTitle": "Motrix와 페어링"
			},
			"servers": {
				"add": "서버 추가",
				"addTitle": "Motrix Server 추가",
				"current": "현재 사용 중",
				"delete": "서버 삭제",
				"deleteActiveDescription": "{{name}} 및 로컬에 저장된 페어링 자격 증명과 동의 정보를 삭제할까요? 현재 백엔드는 Motrix App으로 돌아가지만 연결하거나 실행하지 않습니다.",
				"deleteActiveServerOnlyDescription": "{{name}} 및 로컬에 저장된 페어링 자격 증명과 동의 정보를 삭제할까요? 다운로드하려면 다른 Motrix Server를 추가하거나 선택해야 합니다.",
				"deleteAria": "{{name}} 삭제",
				"deleteDescription": "{{name}} 및 로컬에 저장된 페어링 자격 증명과 동의 정보를 삭제할까요? 서버의 정보나 권한은 해제되지 않습니다.",
				"deleteTitle": "Motrix Server를 삭제할까요?",
				"description": "여러 Motrix Server 주소를 저장하고 설정이나 팝업에서 전환할 수 있습니다.",
				"dialogDescription": "이 백엔드를 알아보기 쉬운 이름과 WebSocket 기본 URL을 입력하세요.",
				"editAria": "{{name}} 편집",
				"editTitle": "Motrix Server 편집",
				"emptyDescription": "서버를 추가하여 다른 컴퓨터의 Motrix에 연결하세요.",
				"emptyTitle": "아직 Motrix Server 없음",
				"footer": "서버 주소를 변경하면 다시 페어링해야 합니다. 페어링 정보는 주소 간에 공유되지 않습니다.",
				"nameLabel": "서버 이름",
				"namePlaceholder": "홈 서버",
				"nameRequired": "서버 이름을 입력하세요",
				"save": "서버 저장",
				"statusAuthority": "서버 주소: {{value}}",
				"statusRuntime": "Motrix 버전: {{name}} {{version}}",
				"statusTitle": "서버 정보",
				"statusTransportSecure": "연결 보안: WSS를 사용하며 TLS로 서버 신원을 확인합니다",
				"statusTransportPlain": "연결 보안: 암호화되어 있지만 WS는 서버 신원을 확인할 수 없으며 연결 정보가 노출될 수 있습니다. WSS를 권장합니다",
				"title": "Motrix 서버",
				"urlDescription": "ws:// 또는 wss:// 기본 URL을 사용하세요. 선택적으로 지정한 경로는 역방향 프록시 접두사로 그대로 유지됩니다. WSS를 권장합니다.",
				"urlDuplicate": "이미 저장된 Motrix Server 주소입니다",
				"urlInvalid": "공백, 자격 증명, 쿼리 또는 프래그먼트가 없는 유효한 ws:// 또는 wss:// 기본 URL을 입력하세요",
				"urlLabel": "WebSocket URL",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "이 연결은 WSS를 사용하지 않습니다",
				"transportWarningBody": "Motrix와 주고받는 내용은 암호화되지만 WS는 서버 신원을 확인할 수 없으며 연결 정보가 노출될 수 있습니다. NAS가 지원한다면 WSS를 사용하세요.",
				"urlRequired": "WebSocket URL을 입력하세요"
			},
			"takeover": {
				"consentBody": "Motrix는 파일을 다운로드하기 위해 사이트의 로그인 쿠키를 받습니다. 민감한 사이트의 다운로드는 브라우저에서 처리합니다.",
				"consentCancel": "취소",
				"consentConfirm": "사용",
				"consentDialogLabel": "다운로드를 Motrix로 보낼까요?",
				"denylistLabel": "제외 목록(한 줄에 호스트 하나 — 항상 브라우저에서 처리)",
				"enableAria": "다운로드 인계 사용",
				"enableLabel": "해당하는 다운로드를 Motrix로 전송",
				"loading": "다운로드 인계 설정 불러오는 중…",
				"minSizeLabel": "최소 크기(MB)",
				"minSizePlaceholder": "0 = 모두",
				"thresholdInvalid": "최소 크기는 0 이상의 숫자여야 합니다",
				"save": "저장",
				"saved": "저장됨",
				"title": "다운로드 인계",
				"remoteUnavailable": "자동 인계에는 현재 로컬 Motrix App이 필요합니다. 원격 다운로드 및 헤더나 쿠키 권한으로는 활성화되지 않습니다. 이 Server에는 수동으로 또는 마우스 오른쪽 버튼 메뉴에서 다운로드를 보낼 수 있습니다.",
				"availabilityUnknown": "선택한 백엔드를 확인할 수 있을 때까지 인계를 사용할 수 없습니다.",
				"remoteUnavailableShort": "로컬 App 전용. 오른쪽 클릭 전송은 Server에서도 가능합니다."
			},
			"tabs": {
				"general": "일반",
				"download": "다운로드",
				"integration": "연동",
				"help": "도움말"
			},
			"common": {
				"apply": "적용",
				"cancel": "취소",
				"loadError": "확장 프로그램의 백그라운드 프로세스가 시작되지 않아 설정을 불러오지 못했습니다. 확장 프로그램을 새로고침한 후 다시 시도하세요.",
				"saved": "저장됨",
				"saving": "저장 중…",
				"saveError": "저장 실패"
			},
			"appearance": {
				"title": "화면 설정",
				"theme": {
					"label": "테마",
					"system": "시스템 설정 따르기",
					"light": "밝게",
					"dark": "어둡게"
				}
			},
			"help": {
				"title": "도움말 및 지원",
				"description": "가이드, 지원 및 확장 프로그램 진단 정보를 확인하세요.",
				"reportBug": "문제 신고",
				"reportBugDescription": "GitHub 이슈를 등록하거나 의견을 보내주세요.",
				"issues": "GitHub Issues",
				"docs": "문서",
				"docsDescription": "설정, 페어링, 다운로드 인계 및 문제 해결 가이드를 읽어보세요.",
				"copyDiagnostics": "진단 정보 복사",
				"copied": "복사됨",
				"diagnostics": "진단",
				"diagnosticsDescription": "로그 설정을 조정하고 문제 해결에 도움이 되는 정보를 복사하세요."
			},
			"about": {
				"subtitle": "Motrix로 웹에서 파일 다운로드",
				"website": "공식 웹사이트"
			},
			"title": "Motrix 확장 프로그램 설정"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "이 컴퓨터",
				"choose": "Motrix 백엔드 선택",
				"configureServer": "Motrix Server 관리",
				"notConfigured": "설정되지 않음",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "엔진: {{state}}",
				"noDownloads": "다운로드 없음",
				"pause": "일시 정지",
				"remove": "제거",
				"resume": "다시 시작",
				"statsSummary": "진행 중 {{active}} · 대기 중 {{waiting}}"
			},
			"dashboard": {
				"activity": "활동",
				"resources": "리소스",
				"showResources": "이 페이지의 리소스 표시",
				"showTasks": "진행 중인 작업 표시",
				"title": "전송 개요"
			},
			"loading": "불러오는 중…",
			"quickSettings": {
				"fullSettings": "전체 설정",
				"fullSettingsDescription": "일반, 다운로드, 백엔드 및 도움말",
				"loadError": "빠른 설정을 불러올 수 없습니다.",
				"notificationsDescription": "확장 프로그램의 시스템 알림 제어",
				"retry": "다시 시도",
				"saveError": "설정 저장 실패. 다시 시도하세요.",
				"takeoverDescription": "브라우저 다운로드를 현재 Motrix 백엔드로 전송"
			},
			"quickAdd": {
				"title": "새 작업",
				"description": "HTTP, HTTPS 또는 마그넷 링크를 붙여 넣으세요.",
				"inputLabel": "다운로드 주소",
				"placeholder": "https://example.com/file.zip",
				"cancel": "취소",
				"add": "추가",
				"submitting": "추가 중…",
				"error": {
					"empty": "다운로드 주소를 입력하세요.",
					"unsupported": "HTTP, HTTPS 또는 마그넷 링크만 지원합니다.",
					"invalid": "유효하지 않은 다운로드 주소입니다.",
					"submitFailed": "작업을 추가하지 못했습니다. 다시 시도하세요."
				}
			},
			"reconnect": "연결",
			"settings": "설정 열기",
			"sniffer": {
				"clearFilters": "필터 지우기",
				"detected": "항목 {{count}}개",
				"downloadCount": "{{count}}개 다운로드",
				"downloadSelected": "선택 항목 다운로드",
				"downloadedResource": "{{name}} 전송됨",
				"downloadingResource": "{{name}} 다운로드 중",
				"emptyDescription": "미디어를 재생한 후 다시 시도하세요.",
				"emptyFilter": "일치하는 리소스 없음",
				"emptyTitle": "미디어 없음",
				"filteredCount": "이미지 {{matched}} / {{total}}개",
				"filters": {
					"all": "모두",
					"audio": "오디오",
					"image": "이미지",
					"video": "비디오"
				},
				"imageFilters": {
					"activeCount": "활성 필터 {{count}}개",
					"dimensions": "해상도 및 크기",
					"done": "완료",
					"fields": {
						"height": "높이",
						"size": "크기",
						"width": "너비"
					},
					"formatOptionLabel": "{{format}} 이미지 필터링",
					"formats": "이미지 형식",
					"operatorLabel": "{{label}} 비교",
					"reset": "초기화",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "파일 크기 단위",
					"title": "빠른 필터",
					"trigger": "필터",
					"valueLabel": "{{label}} 값"
				},
				"imageCount": "이미지 {{count}}개",
				"noImageMatches": "일치하는 이미지 없음",
				"pageAction": {
					"bilibili": "이 bilibili 동영상 전송",
					"youtube": "이 YouTube 동영상 전송"
				},
				"pageSubmitted": "Motrix로 동영상을 전송했습니다 {{taskId}}",
				"pageResources": "리소스",
				"quickDownloadResource": "{{name}} 빠른 다운로드",
				"connectToSubmit": "리소스를 보내려면 Motrix에 연결하세요.",
				"scan": "다시 검색",
				"scanning": "검색 중…",
				"selectAll": "모두 선택",
				"selected": "{{count}}개 선택됨",
				"selectResource": "{{name}} 선택",
				"sourceHost": "출처: {{host}}",
				"sendResource": "{{name}}을(를) Motrix로 전송",
				"sent": "전송됨",
				"sending": "전송 중",
				"submitFailed": "리소스를 전송하지 못했습니다. 다시 시도하세요.",
				"title": "리소스 감지",
				"unavailableDescription": "페이지를 바꾸거나 나중에 다시 시도하세요.",
				"unavailableTitle": "이 페이지는 검색 불가",
				"unsupported": "ffmpeg 필요",
				"unsupportedReason": "선택한 백엔드에서 ffmpeg를 지원하지 않아 {{kind}} 리소스를 전송할 수 없습니다.",
				"unsupportedSelectionReason": "선택한 백엔드에서 선택된 리소스 유형 중 하나 이상을 전송할 수 없습니다.",
				"unsupportedResource": "{{name}}을(를) 전송할 수 없습니다. {{reason}}"
			},
			"speed": {
				"download": "다운로드",
				"upload": "업로드"
			},
			"status": {
				"bootstrapping": "Motrix 찾는 중…",
				"connected": "연결됨",
				"connecting": "연결 중…",
				"denied": "페어링 거부됨",
				"disconnected": "연결 끊김",
				"handshaking": "핸드셰이크 진행 중",
				"awaiting-code": "페어링 코드 대기 중…"
			},
			"tabs": {
				"settings": "설정",
				"sniffer": "리소스",
				"tasks": "작업"
			},
			"takeover": {
				"aria": "다운로드 인계 전환",
				"label": "인계"
			},
			"tasks": {
				"actions": "{{name}} 작업 메뉴",
				"openFolder": "Motrix에서 파일이 있는 폴더 열기",
				"openFolderError": "작업 폴더를 열지 못했습니다. 다시 시도하세요.",
				"openFolderMetadataPending": "작업 메타데이터를 받은 후 폴더를 여세요",
				"openFolderTask": "{{name}}이(가) 있는 폴더 열기",
				"openFolderUnsupported": "폴더를 열려면 Motrix를 업데이트하세요",
				"pauseTask": "{{name}} 일시 정지",
				"removeTask": "{{name}} 제거",
				"removeConfirmTitle": "작업을 제거할까요?",
				"removeConfirmDescription": "다운로드 목록에서 “{{name}}”이(가) 제거됩니다.",
				"removeDeleteFilesLabel": "다운로드한 파일 삭제",
				"removeConfirmAction": "제거",
				"resumeTask": "{{name}} 다시 시작",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "작업을 보려면 연결하세요.",
				"disconnectedTitle": "Motrix가 오프라인입니다",
				"empty": {
					"active": "진행 중 작업 없음",
					"failed": "실패 작업 없음",
					"recent": "완료 작업 없음"
				},
				"filters": {
					"active": "진행 중",
					"failed": "실패",
					"recent": "완료"
				},
				"loading": "작업 불러오는 중",
				"status": {
					"completed": "완료",
					"downloading": "다운로드 중",
					"error": "실패",
					"fetching_metadata": "메타데이터 가져오는 중",
					"finalizing": "마무리 중",
					"paused": "일시 정지됨",
					"queued": "대기 중",
					"seeding": "시딩 중"
				},
				"title": "작업"
			},
			"pairing": {
				"attemptOf": "시도 {{run}} / {{maxRuns}}",
				"attemptsRemaining": "남은 시도 {{attemptsRemaining}}회",
				"codeLabel": "페어링 코드",
				"codeDescription": "Motrix 페어링 창의 8자리 코드를 입력하세요.",
				"codeInvalid": "페어링 창의 8자리 코드를 입력하세요.",
				"dialogTitle": "페어링 코드 입력",
				"dismissPrompt": "나중에 입력하고 계속 탐색",
				"enterCode": "페어링 코드 입력",
				"expiresIn": "{{time}} 후 만료",
				"pairButton": "페어링",
				"pickerHelp": "여러 Motrix 인스턴스를 찾았습니다. 페어링할 인스턴스를 선택하세요.",
				"rescan": "다시 찾기",
				"noCandidates": "Motrix 인스턴스를 찾지 못했습니다.",
				"candidatesLabel": "검색된 Motrix 인스턴스",
				"candidatePort": "포트 {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "알 수 없는 버전",
				"choose": "선택",
				"backoffTitle": "페어링 시도 횟수가 너무 많습니다",
				"backoffBody": "{{time}}에 다시 시도하세요.",
				"retryIn": "{{seconds}}초 후 다시 시도",
				"permissionMissingTitle": "권한 필요",
				"permissionMissingBody": "이 컴퓨터에서 Motrix를 찾으려면 localhost 접근을 허용하세요.",
				"grantPermission": "권한 허용",
				"degradedTitle": "Motrix가 연결되었습니다",
				"degradedBody": "Motrix를 정상적으로 사용할 수 있습니다. 이 연결에는 기본 검증만 적용됩니다. 보안을 강화하려면 Motrix를 업데이트하고 다시 페어링하세요.",
				"recoveryExhaustedTitle": "자동으로 다시 연결하지 못했습니다",
				"recoveryExhaustedBody": "저장된 Motrix 페어링이 모두 작동하지 않았습니다. 연결을 눌러 다시 페어링하세요."
			}
		},
		errors: { "connection": {
			"generic": "연결에 실패했습니다. 다시 시도하세요.",
			"backoffLocked": "페어링 시도 횟수가 너무 많습니다. 나중에 다시 시도하세요.",
			"staleAttempt": "새로운 연결 시도로 전환되었습니다.",
			"aborted": "페어링이 취소되었습니다.",
			"deadlineExceeded": "시도 시간이 초과되었습니다. 다시 시도하세요.",
			"runsExhausted": "잘못된 코드를 너무 많이 입력했습니다. 페어링을 다시 시작하여 새 코드를 받으세요.",
			"invalidCode": "코드 형식이 올바르지 않습니다. Motrix 대화 상자를 확인하세요.",
			"missingNonce": "Motrix가 페어링 슬롯을 제공하지 않았습니다. Motrix가 실행 중인지 확인한 후 다시 시도하세요.",
			"unsupportedBrowser": "이 브라우저에서는 페어링을 지원하지 않습니다.",
			"ticketPreparationFailed": "페어링을 준비하지 못했습니다. 다시 시도하세요.",
			"protocolViolation": "Motrix가 예상하지 못한 응답을 보냈습니다. 다시 시도하세요.",
			"unsupportedVersion": "이 확장 프로그램과 Motrix의 프로토콜 버전이 다릅니다. 둘 다 업데이트한 후 다시 시도하세요.",
			"backendUpgradeRequired": "이 Motrix 버전은 너무 오래되어 안전하게 페어링할 수 없습니다. Motrix를 업데이트한 후 다시 시도하세요.",
			"extensionUpgradeRequired": "이 확장 프로그램 버전은 너무 오래되어 이 Motrix와 호환되지 않습니다. Motrix 확장 프로그램을 업데이트한 후 다시 시도하세요.",
			"unsupportedRemote": "인증된 Motrix가 이 연결에서 선택한 App 또는 Server가 아닙니다. 엔드포인트를 확인한 후 다시 시도하세요.",
			"remoteDiscoveryUnavailable": "원격 Motrix Server에 연결할 수 없습니다. 주소, 수신 서비스 및 네트워크를 확인하세요. WSS의 경우 인증서와 역방향 프록시도 확인하세요.",
			"remotePairingUnavailable": "원격 Motrix Server가 안전한 페어링 세션을 열지 못했습니다. 잠시 후 다시 시도하세요.",
			"remoteTransportUnavailable": "원격 Motrix Server 연결에 실패했습니다. 주소, 수신 서비스, DNS 및 네트워크를 확인하세요. WSS의 경우 인증서와 역방향 프록시도 확인하세요. 브라우저에서는 정확한 실패 원인을 확인할 수 없습니다.",
			"peerRejected": "Motrix가 페어링을 거부했습니다.",
			"peerBusy": "Motrix가 너무 많은 페어링 요청을 처리하고 있습니다. 잠시 후 다시 시도하세요.",
			"securityCheckFailed": "보안 검사를 통과하지 못해 연결을 중단했습니다.",
			"peerNotAuthentic": "연결 상대가 사용자의 Motrix임을 증명하지 못해 연결을 중단했습니다.",
			"credentialPhaseFailed": "페어링을 저장하지 못했습니다. 다시 페어링하세요.",
			"internalError": "확장 프로그램에서 문제가 발생했습니다. 다시 시도하세요.",
			"authFailed": "Motrix가 이 페어링을 인식하지 못했습니다. 해제되었을 수 있으니 다시 페어링하세요.",
			"serverMacMismatch": "응답 검증에 실패하여 연결을 중단했습니다. 사용자의 Motrix가 아닐 수 있습니다.",
			"channelClosed": "연결이 닫혔습니다. 계속하려면 다시 연결하세요.",
			"channelUnavailable": "현재 Motrix에 연결할 수 없습니다. 실행 중인지 확인하세요."
		} }
	} },
	"pt-BR": { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: conectado",
			"disconnected": "Motrix: desconectado",
			"connecting": "Motrix: conectando…",
			"downloading": "Motrix: baixando",
			"denied": "Motrix: pareamento recusado — abra para parear novamente",
			"error": "Motrix: envio falhou — clique para ver detalhes"
		} },
		contextMenu: {
			"downloadWithMotrix": "Baixar com o Motrix",
			"pairThenDownload": "Parear o Motrix e baixar"
		},
		notify: {
			"browserFallbackBody": "O Motrix está indisponível. O navegador fará o download.",
			"browserFallbackTitle": "Baixando no navegador",
			"downloadComplete": "Download concluído",
			"downloadFailed": "Falha no download",
			"handedToMotrix": "Enviado ao Motrix",
			"notConnectedBody": "Pareie o Motrix para gerenciar os downloads.",
			"notConnectedTitle": "Motrix desconectado",
			"notReachableBody": "Pareie o Motrix e tente baixar novamente.",
			"notReachableTitle": "Motrix inacessível",
			"pairNudgeBody": "Abra o Motrix para concluir o pareamento.",
			"pairNudgeTitle": "Parear o Motrix",
			"pairRevokedBody": "O Motrix revogou o pareamento deste navegador.",
			"pairRevokedTitle": "Pareamento revogado",
			"sensitiveSkippedBody": "O download do site sensível ficou no navegador.",
			"sensitiveSkippedTitle": "Ignorado",
			"submitFailedBody": "Reiniciando o download no navegador.",
			"submitFailedTitle": "Falha ao enviar ao Motrix"
		},
		options: {
			"diagnostics": {
				"adapters": "Adaptadores",
				"extensionId": "ID da extensão",
				"logLevel": "Nível de registro",
				"logLevels": {
					"silent": "Sem registros",
					"error": "Erro",
					"warn": "Aviso",
					"info": "Informações",
					"debug": "Depuração"
				},
				"noneRegistered": "Nenhum registrado ainda",
				"title": "Diagnóstico",
				"version": "Versão"
			},
			"endpoint": {
				"activate": "Usar",
				"activateAria": "Usar {{name}}",
				"connection": {
					"bootstrapping": "Iniciando",
					"connected": "Conectado",
					"connecting": "Conectando",
					"denied": "Recusado",
					"disconnected": "Desconectado",
					"handshaking": "Autorizando",
					"awaiting-code": "Aguardando código"
				},
				"currentDescription": "Escolha um App ou Server para downloads, tarefas e recursos detectados nas páginas.",
				"currentTitle": "Serviços Motrix",
				"listLabel": "Serviços Motrix disponíveis",
				"localDescription": "Este computador, detectado pelo Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Enviar downloads para"
			},
			"language": {
				"label": "Idioma",
				"system": "Seguir o sistema"
			},
			"notifications": {
				"title": "Notificações do sistema",
				"masterLabel": "Ativar notificações do sistema",
				"masterAria": "Ativar notificações do sistema",
				"confirmLabel": "Sucessos / confirmações",
				"confirmDesc": "Envio ao Motrix, download concluído",
				"errorLabel": "Falhas / erros",
				"errorDesc": "Falha no envio, inacessível, falha no download",
				"reminderLabel": "Lembretes",
				"reminderDesc": "Solicitações de pareamento, pareamento revogado, sites ignorados"
			},
			"pairing": {
				"backendTitle": "Pareando {{name}}",
				"forget": "Esquecer pareamento",
				"loading": "Carregando status do pareamento…",
				"localHelp": "Clique em Parear para encontrar o Motrix neste computador e digite o código de pareamento.",
				"localTitle": "Parear pelo Motrix App",
				"remoteTitle": "Parear com o Motrix Server",
				"remoteHelp": "Clique em Parear, confirme a solicitação na interface de administração do Server e digite aqui o código exibido. Conexões WS e WSS são aceitas; recomenda-se WSS.",
				"serverRequiredTitle": "Motrix Server necessário",
				"serverRequiredHelp": "O Firefox para Android se conecta pelo Motrix Server. Adicione um Server acima e selecione-o para parear.",
				"remoteConsentTitle": "Downloads remotos",
				"remoteConsentBody": "Os downloads remotos enviam a este Server a URL de destino, a URL e o título da página de origem, o nome do arquivo, a seleção e os comandos das tarefas. Cookies e cabeçalhos de requisição só são enviados se ativados separadamente.",
				"remoteConsentOffline": "As permissões de dados estão vinculadas ao Server autenticado. Conecte-se antes de alterá-las.",
				"remoteHeadersLabel": "Enviar cabeçalhos de requisição",
				"remoteHeadersHelp": "Permite cabeçalhos obtidos da página, como Referer e cabeçalhos de reprodução de mídia. Cabeçalhos de autenticação ainda exigem a permissão de credenciais abaixo.",
				"remoteCredentialsLabel": "Enviar cookies e autenticação",
				"remoteCredentialsHelp": "Permite cookies e cabeçalhos de credenciais apenas para este Server. Ative somente para um Server que você controla.",
				"notPaired": "Não pareado",
				"paired": "Pareado com o Motrix",
				"pairedHelp": "Uma credencial MBP1 confirmada é mantida para este serviço. O status atual da conexão é exibido separadamente.",
				"pairedTitle": "Pareamento pronto",
				"reconnect": "Reconectar",
				"scopedHelp": "A confiança e as credenciais de pareamento são isoladas por serviço. Trocar de serviço nunca reutiliza a confiança de outro.",
				"pair": "Parear",
				"pairDialogTitle": "Parear com o Motrix"
			},
			"servers": {
				"add": "Adicionar servidor",
				"addTitle": "Adicionar Motrix Server",
				"current": "Atual",
				"delete": "Excluir servidor",
				"deleteActiveDescription": "Excluir {{name}} e suas credenciais de pareamento e consentimentos salvos localmente? O Motrix App será selecionado novamente, sem conexão nem inicialização.",
				"deleteActiveServerOnlyDescription": "Excluir {{name}} e suas credenciais de pareamento e consentimentos salvos localmente? Você precisará adicionar ou selecionar outro Motrix Server antes de baixar.",
				"deleteAria": "Excluir {{name}}",
				"deleteDescription": "Excluir {{name}} e suas credenciais de pareamento e consentimentos salvos localmente? Isso não revoga nada no servidor.",
				"deleteTitle": "Excluir Motrix Server?",
				"description": "Salve vários endereços do Motrix Server e alterne entre eles nas opções ou no popup.",
				"dialogDescription": "Dê um nome reconhecível a este serviço e insira sua URL base WebSocket.",
				"editAria": "Editar {{name}}",
				"editTitle": "Editar Motrix Server",
				"emptyDescription": "Adicione um servidor para se conectar ao Motrix fora deste computador.",
				"emptyTitle": "Nenhum Motrix Server ainda",
				"footer": "Alterar o endereço de um servidor exige um novo pareamento. As informações de pareamento nunca são compartilhadas entre endereços.",
				"nameLabel": "Nome do servidor",
				"namePlaceholder": "Servidor de casa",
				"nameRequired": "O nome do servidor é obrigatório",
				"save": "Salvar servidor",
				"statusAuthority": "Endereço do servidor: {{value}}",
				"statusRuntime": "Versão do Motrix: {{name}} {{version}}",
				"statusTitle": "Informações do servidor",
				"statusTransportSecure": "Segurança da conexão: WSS em uso e identidade do servidor verificada por TLS",
				"statusTransportPlain": "Segurança da conexão: criptografada, mas WS não verifica a identidade do servidor e pode expor informações da conexão. Recomenda-se WSS",
				"title": "Servidores Motrix",
				"urlDescription": "Use uma URL base ws:// ou wss://. O caminho opcional é mantido como prefixo exato do proxy reverso; recomenda-se WSS.",
				"urlDuplicate": "Este endereço do Motrix Server já está salvo",
				"urlInvalid": "Insira uma URL base ws:// ou wss:// válida, sem espaços, credenciais, consulta ou fragmento",
				"urlLabel": "URL WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Esta conexão não usa WSS",
				"transportWarningBody": "O conteúdo trocado com o Motrix continua criptografado, mas WS não verifica a identidade do servidor e pode expor informações da conexão. Use WSS se o seu NAS for compatível.",
				"urlRequired": "A URL WebSocket é obrigatória"
			},
			"takeover": {
				"consentBody": "O Motrix recebe os cookies de login do site para baixar arquivos. Downloads de sites sensíveis permanecem no navegador.",
				"consentCancel": "Cancelar",
				"consentConfirm": "Ativar",
				"consentDialogLabel": "Enviar downloads ao Motrix?",
				"denylistLabel": "Lista de exclusão (um host por linha — sempre fica no navegador)",
				"enableAria": "Ativar captura de downloads",
				"enableLabel": "Enviar downloads compatíveis ao Motrix",
				"loading": "Carregando configurações de captura…",
				"minSizeLabel": "Tamanho mínimo (MB)",
				"minSizePlaceholder": "0 = todos",
				"thresholdInvalid": "O tamanho mínimo deve ser um número não negativo",
				"save": "Salvar",
				"saved": "Salvo",
				"title": "Captura de downloads",
				"remoteUnavailable": "A captura automática exige atualmente o Motrix App local. Downloads remotos e permissões de cabeçalhos ou cookies não a ativam. Você ainda pode enviar downloads a este Server manualmente ou pelo menu de contexto.",
				"availabilityUnknown": "A captura fica indisponível até que o serviço selecionado possa ser verificado.",
				"remoteUnavailableShort": "Somente App local. O envio por clique direito funciona com Servers."
			},
			"tabs": {
				"general": "Geral",
				"download": "Downloads",
				"integration": "Integração",
				"help": "Ajuda"
			},
			"common": {
				"apply": "Aplicar",
				"cancel": "Cancelar",
				"loadError": "Não foi possível carregar as configurações porque o processo em segundo plano da extensão não iniciou. Recarregue a extensão e tente novamente.",
				"saved": "Salvo",
				"saving": "Salvando…",
				"saveError": "Falha ao salvar"
			},
			"appearance": {
				"title": "Aparência",
				"theme": {
					"label": "Tema",
					"system": "Seguir o sistema",
					"light": "Claro",
					"dark": "Escuro"
				}
			},
			"help": {
				"title": "Ajuda e suporte",
				"description": "Consulte guias, suporte e diagnóstico da extensão.",
				"reportBug": "Relatar um problema",
				"reportBugDescription": "Abra uma issue no GitHub ou envie seus comentários.",
				"issues": "GitHub Issues",
				"docs": "Documentação",
				"docsDescription": "Leia os guias de configuração, pareamento, captura de downloads e solução de problemas.",
				"copyDiagnostics": "Copiar diagnóstico",
				"copied": "Copiado",
				"diagnostics": "Diagnóstico",
				"diagnosticsDescription": "Ajuste os registros e copie informações úteis para solucionar problemas."
			},
			"about": {
				"subtitle": "Baixe arquivos da web com o Motrix",
				"website": "Site oficial"
			},
			"title": "Configurações da extensão Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Este computador",
				"choose": "Escolher serviço do Motrix",
				"configureServer": "Gerenciar Motrix Servers",
				"notConfigured": "Não configurado",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "mecanismo: {{state}}",
				"noDownloads": "Nenhum download",
				"pause": "Pausar",
				"remove": "Remover",
				"resume": "Retomar",
				"statsSummary": "Ativos: {{active}} · Aguardando: {{waiting}}"
			},
			"dashboard": {
				"activity": "Atividade",
				"resources": "Recursos",
				"showResources": "Mostrar recursos desta página",
				"showTasks": "Mostrar tarefas ativas",
				"title": "Visão geral das transferências"
			},
			"loading": "Carregando…",
			"quickSettings": {
				"fullSettings": "Todos os ajustes",
				"fullSettingsDescription": "Geral, downloads, serviço e ajuda",
				"loadError": "Falha ao carregar ajustes rápidos.",
				"notificationsDescription": "Gerenciar notificações do sistema da extensão",
				"retry": "Tentar de novo",
				"saveError": "Falha ao salvar o ajuste. Tente novamente.",
				"takeoverDescription": "Enviar downloads do navegador ao serviço atual do Motrix"
			},
			"quickAdd": {
				"title": "Nova tarefa",
				"description": "Cole um link HTTP, HTTPS ou magnet.",
				"inputLabel": "Endereço de download",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Cancelar",
				"add": "Adicionar",
				"submitting": "Adicionando…",
				"error": {
					"empty": "Insira um endereço de download.",
					"unsupported": "Apenas links HTTP, HTTPS ou magnet são aceitos.",
					"invalid": "O endereço de download é inválido.",
					"submitFailed": "Não foi possível adicionar a tarefa. Tente novamente."
				}
			},
			"reconnect": "Conectar",
			"settings": "Abrir configurações",
			"sniffer": {
				"clearFilters": "Limpar filtros",
				"detected": "Itens: {{count}}",
				"downloadCount": "Baixar ({{count}})",
				"downloadSelected": "Baixar selecionados",
				"downloadedResource": "Enviado: {{name}}",
				"downloadingResource": "Baixando {{name}}",
				"emptyDescription": "Reproduza uma mídia e tente novamente.",
				"emptyFilter": "Nenhum recurso correspondente",
				"emptyTitle": "Nenhuma mídia",
				"filteredCount": "{{matched}} / {{total}} imagens",
				"filters": {
					"all": "Todos",
					"audio": "Áudio",
					"image": "Imagens",
					"video": "Vídeo"
				},
				"imageFilters": {
					"activeCount": "Filtros ativos: {{count}}",
					"dimensions": "Dimensões e tamanho",
					"done": "Concluído",
					"fields": {
						"height": "Altura",
						"size": "Tamanho",
						"width": "Largura"
					},
					"formatOptionLabel": "Filtrar imagens {{format}}",
					"formats": "Formato de imagem",
					"operatorLabel": "Comparação de {{label}}",
					"reset": "Redefinir",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Unidade de tamanho do arquivo",
					"title": "Filtros rápidos",
					"trigger": "Filtrar",
					"valueLabel": "Valor de {{label}}"
				},
				"imageCount": "Imagens: {{count}}",
				"noImageMatches": "Nenhuma imagem correspondente",
				"pageAction": {
					"bilibili": "Enviar este vídeo do bilibili",
					"youtube": "Enviar este vídeo do YouTube"
				},
				"pageSubmitted": "Vídeo enviado ao Motrix {{taskId}}",
				"pageResources": "Recursos",
				"quickDownloadResource": "Download rápido de {{name}}",
				"connectToSubmit": "Conecte-se ao Motrix para enviar recursos.",
				"scan": "Verificar novamente",
				"scanning": "Verificando…",
				"selectAll": "Selecionar tudo",
				"selected": "Selecionados: {{count}}",
				"selectResource": "Selecionar {{name}}",
				"sourceHost": "Origem: {{host}}",
				"sendResource": "Enviar {{name}} ao Motrix",
				"sent": "Enviado",
				"sending": "Enviando",
				"submitFailed": "Não foi possível enviar o recurso. Tente novamente.",
				"title": "Detectar recursos",
				"unavailableDescription": "Mude de página ou tente mais tarde.",
				"unavailableTitle": "Não é possível verificar a página",
				"unsupported": "Requer ffmpeg",
				"unsupportedReason": "O serviço selecionado não pode enviar recursos {{kind}} porque o suporte a ffmpeg está indisponível.",
				"unsupportedSelectionReason": "O serviço selecionado não pode enviar um ou mais tipos de recursos selecionados.",
				"unsupportedResource": "Não é possível enviar {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Download",
				"upload": "Upload"
			},
			"status": {
				"bootstrapping": "Procurando Motrix…",
				"connected": "Conectado",
				"connecting": "Conectando…",
				"denied": "Pareamento recusado",
				"disconnected": "Desconectado",
				"handshaking": "Negociação em andamento",
				"awaiting-code": "Aguardando código de pareamento…"
			},
			"tabs": {
				"settings": "Ajustes",
				"sniffer": "Recursos",
				"tasks": "Tarefas"
			},
			"takeover": {
				"aria": "Alternar captura de downloads",
				"label": "Captura"
			},
			"tasks": {
				"actions": "Ações para {{name}}",
				"openFolder": "Abrir pasta do arquivo no Motrix",
				"openFolderError": "Não foi possível abrir a pasta da tarefa. Tente novamente.",
				"openFolderMetadataPending": "Aguarde os metadados da tarefa antes de abrir a pasta",
				"openFolderTask": "Abrir a pasta que contém {{name}}",
				"openFolderUnsupported": "Atualize o Motrix para abrir pastas",
				"pauseTask": "Pausar {{name}}",
				"removeTask": "Remover {{name}}",
				"removeConfirmTitle": "Remover tarefa?",
				"removeConfirmDescription": "“{{name}}” será removido da lista de downloads.",
				"removeDeleteFilesLabel": "Excluir arquivos baixados",
				"removeConfirmAction": "Remover",
				"resumeTask": "Retomar {{name}}",
				"bytes": "{{done}} de {{total}}",
				"disconnectedDescription": "Conecte-se para ver as tarefas.",
				"disconnectedTitle": "O Motrix está offline",
				"empty": {
					"active": "Nenhuma tarefa ativa",
					"failed": "Nenhuma tarefa com falha",
					"recent": "Nenhuma tarefa concluída"
				},
				"filters": {
					"active": "Ativas",
					"failed": "Com falha",
					"recent": "Concluídas"
				},
				"loading": "Carregando tarefas",
				"status": {
					"completed": "Concluídas",
					"downloading": "Baixando",
					"error": "Com falha",
					"fetching_metadata": "Obtendo metadados",
					"finalizing": "Finalizando",
					"paused": "Pausado",
					"queued": "Na fila",
					"seeding": "Semeando"
				},
				"title": "Tarefas"
			},
			"pairing": {
				"attemptOf": "Tentativa {{run}} de {{maxRuns}}",
				"attemptsRemaining": "Tentativas restantes: {{attemptsRemaining}}",
				"codeLabel": "Código de pareamento",
				"codeDescription": "Digite o código de 8 caracteres da janela de pareamento do Motrix.",
				"codeInvalid": "Digite o código de 8 caracteres da janela de pareamento.",
				"dialogTitle": "Inserir código de pareamento",
				"dismissPrompt": "Inserir depois e continuar navegando",
				"enterCode": "Inserir código de pareamento",
				"expiresIn": "Expira em {{time}}",
				"pairButton": "Parear",
				"pickerHelp": "Foram encontradas várias instâncias do Motrix. Escolha uma para parear.",
				"rescan": "Buscar novamente",
				"noCandidates": "Nenhuma instância do Motrix encontrada.",
				"candidatesLabel": "Instâncias do Motrix detectadas",
				"candidatePort": "Porta {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "versão desconhecida",
				"choose": "Escolher",
				"backoffTitle": "Muitas tentativas de pareamento",
				"backoffBody": "Tente novamente às {{time}}.",
				"retryIn": "Tentar novamente em {{seconds}} s",
				"permissionMissingTitle": "Permissão necessária",
				"permissionMissingBody": "Permita o acesso a localhost para encontrar o Motrix neste computador.",
				"grantPermission": "Conceder permissão",
				"degradedTitle": "O Motrix está conectado",
				"degradedBody": "Você pode usar o Motrix normalmente. Esta conexão tem apenas verificação básica. Para maior proteção, atualize o Motrix e pareie novamente.",
				"recoveryExhaustedTitle": "Não foi possível reconectar automaticamente",
				"recoveryExhaustedBody": "Nenhum pareamento salvo do Motrix funcionou. Pressione Conectar para parear novamente."
			}
		},
		errors: { "connection": {
			"generic": "A conexão falhou. Tente novamente.",
			"backoffLocked": "Muitas tentativas de pareamento. Tente mais tarde.",
			"staleAttempt": "Uma tentativa de conexão mais recente substituiu esta.",
			"aborted": "O pareamento foi cancelado.",
			"deadlineExceeded": "O tempo da tentativa expirou. Tente novamente.",
			"runsExhausted": "Muitos códigos incorretos. Reinicie o pareamento para obter um novo código.",
			"invalidCode": "O código não está no formato esperado. Confira a janela do Motrix.",
			"missingNonce": "O Motrix não ofereceu uma sessão de pareamento. Verifique se ele está em execução e tente novamente.",
			"unsupportedBrowser": "Este navegador não oferece suporte ao pareamento.",
			"ticketPreparationFailed": "Não foi possível preparar o pareamento. Tente novamente.",
			"protocolViolation": "O Motrix enviou uma resposta inesperada. Tente novamente.",
			"unsupportedVersion": "A extensão e o Motrix usam versões diferentes do protocolo. Atualize ambos e tente novamente.",
			"backendUpgradeRequired": "Esta versão do Motrix é antiga demais para um pareamento seguro. Atualize o Motrix e tente novamente.",
			"extensionUpgradeRequired": "Esta versão da extensão é antiga demais para este Motrix. Atualize a extensão Motrix e tente novamente.",
			"unsupportedRemote": "O Motrix autenticado não é o App ou Server selecionado para esta conexão. Verifique o endpoint e tente novamente.",
			"remoteDiscoveryUnavailable": "Não foi possível acessar o Motrix Server remoto. Verifique endereço, serviço de escuta e rede; para WSS, confira também o certificado e o proxy reverso.",
			"remotePairingUnavailable": "O Motrix Server remoto não conseguiu abrir uma sessão segura de pareamento. Tente novamente em instantes.",
			"remoteTransportUnavailable": "A conexão com o Motrix Server remoto falhou. Verifique endereço, serviço de escuta, DNS e rede; para WSS, confira também o certificado e o proxy reverso. O navegador não consegue identificar qual deles falhou.",
			"peerRejected": "O Motrix recusou o pareamento.",
			"peerBusy": "O Motrix está processando muitas solicitações de pareamento. Tente novamente em instantes.",
			"securityCheckFailed": "A conexão falhou em uma verificação de segurança e foi interrompida.",
			"peerNotAuthentic": "A outra parte não conseguiu provar que é o seu Motrix. A conexão foi interrompida.",
			"credentialPhaseFailed": "Não foi possível salvar o pareamento. Tente parear novamente.",
			"internalError": "Ocorreu um erro na extensão. Tente novamente.",
			"authFailed": "O Motrix não reconheceu este pareamento. Ele pode ter sido revogado; tente parear novamente.",
			"serverMacMismatch": "A resposta falhou na verificação e a conexão foi interrompida. Pode não ser o seu Motrix.",
			"channelClosed": "A conexão foi fechada. Reconecte-se para continuar.",
			"channelUnavailable": "O Motrix está inacessível no momento. Verifique se ele está em execução."
		} }
	} },
	ru: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: подключён",
			"disconnected": "Motrix: не подключён",
			"connecting": "Motrix: подключение…",
			"downloading": "Motrix: загрузка",
			"denied": "Motrix: сопряжение отклонено — откройте для повторного сопряжения",
			"error": "Motrix: передача не удалась — нажмите для подробностей"
		} },
		contextMenu: {
			"downloadWithMotrix": "Скачать через Motrix",
			"pairThenDownload": "Выполнить сопряжение с Motrix и скачать"
		},
		notify: {
			"browserFallbackBody": "Motrix недоступен. Файл будет скачан браузером.",
			"browserFallbackTitle": "Загрузка в браузере",
			"downloadComplete": "Загрузка завершена",
			"downloadFailed": "Ошибка загрузки",
			"handedToMotrix": "Передано в Motrix",
			"notConnectedBody": "Выполните сопряжение с Motrix для перехвата загрузок.",
			"notConnectedTitle": "Motrix не подключён",
			"notReachableBody": "Выполните сопряжение с Motrix и повторите загрузку.",
			"notReachableTitle": "Motrix недоступен",
			"pairNudgeBody": "Откройте Motrix для завершения сопряжения.",
			"pairNudgeTitle": "Выполнить сопряжение с Motrix",
			"pairRevokedBody": "Motrix отозвал сопряжение с этим браузером.",
			"pairRevokedTitle": "Сопряжение отозвано",
			"sensitiveSkippedBody": "Загрузка с конфиденциального сайта оставлена браузеру.",
			"sensitiveSkippedTitle": "Пропущено",
			"submitFailedBody": "Повторная загрузка в браузере.",
			"submitFailedTitle": "Ошибка отправки в Motrix"
		},
		options: /* @__PURE__ */ JSON.parse("{\"diagnostics\":{\"adapters\":\"Адаптеры\",\"extensionId\":\"ID расширения\",\"logLevel\":\"Уровень журналирования\",\"logLevels\":{\"silent\":\"Без записи\",\"error\":\"Ошибка\",\"warn\":\"Предупреждение\",\"info\":\"Информация\",\"debug\":\"Отладка\"},\"noneRegistered\":\"Пока не зарегистрированы\",\"title\":\"Диагностика\",\"version\":\"Версия\"},\"endpoint\":{\"activate\":\"Использовать\",\"activateAria\":\"Использовать {{name}}\",\"connection\":{\"bootstrapping\":\"Запуск\",\"connected\":\"Подключён\",\"connecting\":\"Подключение\",\"denied\":\"Отклонено\",\"disconnected\":\"Отключён\",\"handshaking\":\"Авторизация\",\"awaiting-code\":\"Ожидание кода\"},\"currentDescription\":\"Выберите App или Server для загрузок, задач и ресурсов, обнаруженных на страницах.\",\"currentTitle\":\"Службы Motrix\",\"listLabel\":\"Доступные службы Motrix\",\"localDescription\":\"Этот компьютер, обнаруженный через Motrix App\",\"localName\":\"Motrix App\",\"selectLabel\":\"Отправлять загрузки в\"},\"language\":{\"label\":\"Язык\",\"system\":\"Как в системе\"},\"notifications\":{\"title\":\"Системные уведомления\",\"masterLabel\":\"Включить системные уведомления\",\"masterAria\":\"Включить системные уведомления\",\"confirmLabel\":\"Успех / подтверждения\",\"confirmDesc\":\"Передано в Motrix, загрузка завершена\",\"errorLabel\":\"Сбои / ошибки\",\"errorDesc\":\"Ошибка отправки, недоступность, ошибка загрузки\",\"reminderLabel\":\"Напоминания\",\"reminderDesc\":\"Запросы сопряжения, отзыв сопряжения, пропущенные сайты\"},\"pairing\":{\"backendTitle\":\"Сопряжение с {{name}}\",\"forget\":\"Забыть сопряжение\",\"loading\":\"Загрузка состояния сопряжения…\",\"localHelp\":\"Нажмите «Сопряжение», чтобы найти Motrix на этом компьютере, и введите код сопряжения.\",\"localTitle\":\"Сопряжение через Motrix App\",\"remoteTitle\":\"Сопряжение с Motrix Server\",\"remoteHelp\":\"Нажмите «Сопряжение», подтвердите запрос в интерфейсе управления Server и введите здесь показанный код. Поддерживаются адреса WS и WSS; рекомендуется WSS.\",\"serverRequiredTitle\":\"Требуется Motrix Server\",\"serverRequiredHelp\":\"Firefox для Android подключается через Motrix Server. Добавьте Server выше и выберите его для сопряжения.\",\"remoteConsentTitle\":\"Удалённые загрузки\",\"remoteConsentBody\":\"При удалённых загрузках на этот Server передаются целевой URL, URL и заголовок исходной страницы, имя файла, выделение и команды управления задачами. Файлы cookie и заголовки запросов отправляются только при отдельном включении.\",\"remoteConsentOffline\":\"Разрешения на передачу данных привязаны к аутентифицированному Server. Подключитесь перед их изменением.\",\"remoteHeadersLabel\":\"Отправлять заголовки запросов\",\"remoteHeadersHelp\":\"Разрешает заголовки, полученные со страницы, например Referer и заголовки воспроизведения медиа. Для заголовков аутентификации по-прежнему требуется разрешение на учётные данные ниже.\",\"remoteCredentialsLabel\":\"Отправлять cookie и данные аутентификации\",\"remoteCredentialsHelp\":\"Разрешает cookie и заголовки с учётными данными только для этого Server. Включайте только для Server под вашим контролем.\",\"notPaired\":\"Не сопряжён\",\"paired\":\"Сопряжён с Motrix\",\"pairedHelp\":\"Для этой службы сохранены подтверждённые учётные данные MBP1. Текущее состояние подключения показано отдельно.\",\"pairedTitle\":\"Сопряжение готово\",\"reconnect\":\"Переподключиться\",\"scopedHelp\":\"Доверие и учётные данные сопряжения изолированы для каждой службы. При переключении доверие к другой службе никогда не используется.\",\"pair\":\"Сопряжение\",\"pairDialogTitle\":\"Сопряжение с Motrix\"},\"servers\":{\"add\":\"Добавить сервер\",\"addTitle\":\"Добавить Motrix Server\",\"current\":\"Текущий\",\"delete\":\"Удалить сервер\",\"deleteActiveDescription\":\"Удалить {{name}}, локально сохранённые учётные данные сопряжения и согласия? Текущая служба сменится на Motrix App без подключения к нему или его запуска.\",\"deleteActiveServerOnlyDescription\":\"Удалить {{name}}, локально сохранённые учётные данные сопряжения и согласия? Перед загрузкой потребуется добавить или выбрать другой Motrix Server.\",\"deleteAria\":\"Удалить {{name}}\",\"deleteDescription\":\"Удалить {{name}}, локально сохранённые учётные данные сопряжения и согласия? На сервере ничего не будет отозвано.\",\"deleteTitle\":\"Удалить Motrix Server?\",\"description\":\"Сохраните несколько адресов Motrix Server и переключайтесь между ними в настройках или всплывающем окне.\",\"dialogDescription\":\"Задайте понятное имя этой службы и введите её базовый URL WebSocket.\",\"editAria\":\"Изменить {{name}}\",\"editTitle\":\"Изменить Motrix Server\",\"emptyDescription\":\"Добавьте сервер для подключения к Motrix на другом компьютере.\",\"emptyTitle\":\"Серверов Motrix пока нет\",\"footer\":\"После изменения адреса сервера требуется повторное сопряжение. Данные сопряжения никогда не передаются между адресами.\",\"nameLabel\":\"Имя сервера\",\"namePlaceholder\":\"Домашний сервер\",\"nameRequired\":\"Укажите имя сервера\",\"save\":\"Сохранить сервер\",\"statusAuthority\":\"Адрес сервера: {{value}}\",\"statusRuntime\":\"Версия Motrix: {{name}} {{version}}\",\"statusTitle\":\"Сведения о сервере\",\"statusTransportSecure\":\"Безопасность подключения: используется WSS, TLS проверяет подлинность сервера\",\"statusTransportPlain\":\"Безопасность подключения: зашифровано, но WS не проверяет подлинность сервера и может раскрыть сведения о соединении. Рекомендуется WSS\",\"title\":\"Серверы Motrix\",\"urlDescription\":\"Используйте базовый URL ws:// или wss://. Необязательный путь сохраняется без изменений как префикс обратного прокси; рекомендуется WSS.\",\"urlDuplicate\":\"Этот адрес Motrix Server уже сохранён\",\"urlInvalid\":\"Введите корректный базовый URL ws:// или wss:// без пробелов, учётных данных, строки запроса и фрагмента\",\"urlLabel\":\"URL WebSocket\",\"urlPlaceholder\":\"ws(s)://host[:port][/base-path]\",\"transportWarningTitle\":\"Это подключение не использует WSS\",\"transportWarningBody\":\"Содержимое обмена с Motrix зашифровано, но WS не проверяет подлинность сервера и может раскрыть сведения о соединении. Используйте WSS, если ваш NAS его поддерживает.\",\"urlRequired\":\"Укажите URL WebSocket\"},\"takeover\":{\"consentBody\":\"Motrix получает cookie авторизации сайта для скачивания файлов. Загрузки с конфиденциальных сайтов остаются в браузере.\",\"consentCancel\":\"Отмена\",\"consentConfirm\":\"Включить\",\"consentDialogLabel\":\"Отправлять загрузки в Motrix?\",\"denylistLabel\":\"Список исключений (один хост на строку — всегда обрабатывается браузером)\",\"enableAria\":\"Включить перехват\",\"enableLabel\":\"Отправлять подходящие загрузки в Motrix\",\"loading\":\"Загрузка настроек перехвата…\",\"minSizeLabel\":\"Минимальный размер (МБ)\",\"minSizePlaceholder\":\"0 = все\",\"thresholdInvalid\":\"Минимальный размер должен быть неотрицательным числом\",\"save\":\"Сохранить\",\"saved\":\"Сохранено\",\"title\":\"Перехват загрузок\",\"remoteUnavailable\":\"Автоматический перехват пока требует локального Motrix App. Удалённые загрузки и разрешения на заголовки или cookie его не включают. Вы по-прежнему можете отправлять загрузки на этот Server вручную или через контекстное меню.\",\"availabilityUnknown\":\"Перехват недоступен, пока выбранную службу нельзя проверить.\",\"remoteUnavailableShort\":\"Только локальный App. Отправка через контекстное меню работает и с Server.\"},\"tabs\":{\"general\":\"Общие\",\"download\":\"Загрузки\",\"integration\":\"Интеграция\",\"help\":\"Справка\"},\"common\":{\"apply\":\"Применить\",\"cancel\":\"Отмена\",\"loadError\":\"Не удалось загрузить настройки: фоновый процесс расширения не запустился. Перезагрузите расширение и повторите.\",\"saved\":\"Сохранено\",\"saving\":\"Сохранение…\",\"saveError\":\"Ошибка сохранения\"},\"appearance\":{\"title\":\"Внешний вид\",\"theme\":{\"label\":\"Тема\",\"system\":\"Как в системе\",\"light\":\"Светлая\",\"dark\":\"Тёмная\"}},\"help\":{\"title\":\"Справка и поддержка\",\"description\":\"Руководства, поддержка и диагностика расширения.\",\"reportBug\":\"Сообщить о проблеме\",\"reportBugDescription\":\"Создайте issue на GitHub или отправьте отзыв.\",\"issues\":\"GitHub Issues\",\"docs\":\"Документация\",\"docsDescription\":\"Руководства по настройке, сопряжению, перехвату загрузок и устранению неполадок.\",\"copyDiagnostics\":\"Копировать диагностику\",\"copied\":\"Скопировано\",\"diagnostics\":\"Диагностика\",\"diagnosticsDescription\":\"Настройте журналирование и скопируйте сведения для устранения неполадок.\"},\"about\":{\"subtitle\":\"Скачивайте файлы из интернета с Motrix\",\"website\":\"Официальный сайт\"},\"title\":\"Настройки расширения Motrix\"}"),
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Этот компьютер",
				"choose": "Выбрать службу Motrix",
				"configureServer": "Управление Motrix Server",
				"notConfigured": "Не настроено",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "движок: {{state}}",
				"noDownloads": "Нет загрузок",
				"pause": "Приостановить",
				"remove": "Убрать",
				"resume": "Возобновить",
				"statsSummary": "Активных: {{active}} · Ожидающих: {{waiting}}"
			},
			"dashboard": {
				"activity": "Активность",
				"resources": "Ресурсы",
				"showResources": "Показать ресурсы этой страницы",
				"showTasks": "Показать активные задачи",
				"title": "Обзор передач"
			},
			"loading": "Загрузка…",
			"quickSettings": {
				"fullSettings": "Все настройки",
				"fullSettingsDescription": "Общие, загрузки, служба и справка",
				"loadError": "Не удалось загрузить быстрые настройки.",
				"notificationsDescription": "Системные уведомления расширения",
				"retry": "Повторить",
				"saveError": "Настройка не сохранена. Повторите.",
				"takeoverDescription": "Отправлять загрузки браузера в текущую службу Motrix"
			},
			"quickAdd": {
				"title": "Новая задача",
				"description": "Вставьте ссылку HTTP, HTTPS или magnet.",
				"inputLabel": "Адрес загрузки",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Отмена",
				"add": "Добавить",
				"submitting": "Добавление…",
				"error": {
					"empty": "Введите адрес загрузки.",
					"unsupported": "Поддерживаются только ссылки HTTP, HTTPS и magnet.",
					"invalid": "Некорректный адрес загрузки.",
					"submitFailed": "Не удалось добавить задачу. Повторите."
				}
			},
			"reconnect": "Подключиться",
			"settings": "Открыть настройки",
			"sniffer": {
				"clearFilters": "Сбросить фильтры",
				"detected": "Объектов: {{count}}",
				"downloadCount": "Скачать: {{count}}",
				"downloadSelected": "Скачать выбранное",
				"downloadedResource": "Отправлено: {{name}}",
				"downloadingResource": "Загрузка {{name}}",
				"emptyDescription": "Воспроизведите медиа и повторите.",
				"emptyFilter": "Нет подходящих ресурсов",
				"emptyTitle": "Медиа не найдены",
				"filteredCount": "Изображения: {{matched}} / {{total}}",
				"filters": {
					"all": "Все",
					"audio": "Аудио",
					"image": "Изображения",
					"video": "Видео"
				},
				"imageFilters": {
					"activeCount": "Активных фильтров: {{count}}",
					"dimensions": "Размеры и объём",
					"done": "Готово",
					"fields": {
						"height": "Высота",
						"size": "Размер",
						"width": "Ширина"
					},
					"formatOptionLabel": "Фильтровать изображения {{format}}",
					"formats": "Формат изображения",
					"operatorLabel": "Сравнение: {{label}}",
					"reset": "Сбросить",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Единица размера файла",
					"title": "Быстрые фильтры",
					"trigger": "Фильтр",
					"valueLabel": "Значение: {{label}}"
				},
				"imageCount": "Изображений: {{count}}",
				"noImageMatches": "Нет подходящих изображений",
				"pageAction": {
					"bilibili": "Отправить это видео bilibili",
					"youtube": "Отправить это видео YouTube"
				},
				"pageSubmitted": "Видео отправлено в Motrix {{taskId}}",
				"pageResources": "Ресурсы",
				"quickDownloadResource": "Быстро скачать {{name}}",
				"connectToSubmit": "Подключитесь к Motrix для отправки ресурсов.",
				"scan": "Сканировать снова",
				"scanning": "Сканирование…",
				"selectAll": "Выбрать всё",
				"selected": "Выбрано: {{count}}",
				"selectResource": "Выбрать {{name}}",
				"sourceHost": "Источник: {{host}}",
				"sendResource": "Отправить {{name}} в Motrix",
				"sent": "Отправлено",
				"sending": "Отправка",
				"submitFailed": "Не удалось отправить ресурс. Повторите.",
				"title": "Поиск ресурсов",
				"unavailableDescription": "Смените страницу или повторите позже.",
				"unavailableTitle": "Страницу нельзя сканировать",
				"unsupported": "Требуется ffmpeg",
				"unsupportedReason": "Выбранная служба не может отправить ресурсы {{kind}}, поскольку поддержка ffmpeg недоступна.",
				"unsupportedSelectionReason": "Выбранная служба не может отправить один или несколько выбранных типов ресурсов.",
				"unsupportedResource": "Не удаётся отправить {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Скачивание",
				"upload": "Отдача"
			},
			"status": {
				"bootstrapping": "Поиск Motrix…",
				"connected": "Подключён",
				"connecting": "Подключение…",
				"denied": "Сопряжение отклонено",
				"disconnected": "Отключён",
				"handshaking": "Согласование соединения",
				"awaiting-code": "Ожидание кода сопряжения…"
			},
			"tabs": {
				"settings": "Настройки",
				"sniffer": "Ресурсы",
				"tasks": "Задачи"
			},
			"takeover": {
				"aria": "Переключить перехват загрузок",
				"label": "Перехват"
			},
			"tasks": {
				"actions": "Действия с {{name}}",
				"openFolder": "Открыть папку файла в Motrix",
				"openFolderError": "Не удалось открыть папку задачи. Повторите.",
				"openFolderMetadataPending": "Перед открытием папки дождитесь метаданных задачи",
				"openFolderTask": "Открыть папку с {{name}}",
				"openFolderUnsupported": "Обновите Motrix для открытия папок",
				"pauseTask": "Приостановить {{name}}",
				"removeTask": "Убрать {{name}}",
				"removeConfirmTitle": "Убрать задачу?",
				"removeConfirmDescription": "«{{name}}» будет убрано из списка загрузок.",
				"removeDeleteFilesLabel": "Удалить скачанные файлы",
				"removeConfirmAction": "Убрать",
				"resumeTask": "Возобновить {{name}}",
				"bytes": "{{done}} из {{total}}",
				"disconnectedDescription": "Подключитесь для просмотра задач.",
				"disconnectedTitle": "Motrix не в сети",
				"empty": {
					"active": "Нет активных задач",
					"failed": "Нет задач с ошибками",
					"recent": "Нет готовых задач"
				},
				"filters": {
					"active": "Активные",
					"failed": "С ошибками",
					"recent": "Готовые"
				},
				"loading": "Загрузка задач",
				"status": {
					"completed": "Завершённые",
					"downloading": "Скачивание",
					"error": "С ошибками",
					"fetching_metadata": "Получение метаданных",
					"finalizing": "Завершение",
					"paused": "Приостановлено",
					"queued": "В очереди",
					"seeding": "Раздача"
				},
				"title": "Задачи"
			},
			"pairing": {
				"attemptOf": "Попытка {{run}} из {{maxRuns}}",
				"attemptsRemaining": "Осталось попыток: {{attemptsRemaining}}",
				"codeLabel": "Код сопряжения",
				"codeDescription": "Введите 8-символьный код из окна сопряжения Motrix.",
				"codeInvalid": "Введите 8-символьный код из окна сопряжения.",
				"dialogTitle": "Ввести код сопряжения",
				"dismissPrompt": "Ввести позже и продолжить просмотр",
				"enterCode": "Ввести код сопряжения",
				"expiresIn": "Истекает через {{time}}",
				"pairButton": "Сопряжение",
				"pickerHelp": "Найдено несколько экземпляров Motrix. Выберите один для сопряжения.",
				"rescan": "Повторить поиск",
				"noCandidates": "Экземпляры Motrix не найдены.",
				"candidatesLabel": "Обнаруженные экземпляры Motrix",
				"candidatePort": "Порт {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "неизвестная версия",
				"choose": "Выбрать",
				"backoffTitle": "Слишком много попыток сопряжения",
				"backoffBody": "Повторите попытку в {{time}}.",
				"retryIn": "Повторить через {{seconds}} с",
				"permissionMissingTitle": "Требуется разрешение",
				"permissionMissingBody": "Разрешите доступ к localhost для поиска Motrix на этом компьютере.",
				"grantPermission": "Предоставить разрешение",
				"degradedTitle": "Motrix подключён",
				"degradedBody": "Вы можете пользоваться Motrix как обычно. Это соединение прошло только базовую проверку. Для более надёжной защиты обновите Motrix и выполните сопряжение заново.",
				"recoveryExhaustedTitle": "Не удалось переподключиться автоматически",
				"recoveryExhaustedBody": "Ни одно сохранённое сопряжение Motrix не сработало. Нажмите «Подключиться» для повторного сопряжения."
			}
		},
		errors: { "connection": {
			"generic": "Не удалось подключиться. Повторите.",
			"backoffLocked": "Слишком много попыток сопряжения. Повторите позже.",
			"staleAttempt": "Начата более новая попытка подключения.",
			"aborted": "Сопряжение отменено.",
			"deadlineExceeded": "Время ожидания истекло. Повторите.",
			"runsExhausted": "Слишком много неверных кодов. Начните сопряжение заново, чтобы получить новый код.",
			"invalidCode": "Неверный формат кода. Проверьте окно Motrix.",
			"missingNonce": "Motrix не предоставил место для сопряжения. Убедитесь, что Motrix запущен, и повторите.",
			"unsupportedBrowser": "Этот браузер не поддерживает сопряжение.",
			"ticketPreparationFailed": "Не удалось подготовить сопряжение. Повторите.",
			"protocolViolation": "Motrix отправил неожиданный ответ. Повторите.",
			"unsupportedVersion": "Расширение и Motrix используют разные версии протокола. Обновите оба и повторите.",
			"backendUpgradeRequired": "Эта версия Motrix слишком стара для безопасного сопряжения. Обновите Motrix и повторите.",
			"extensionUpgradeRequired": "Эта версия расширения слишком стара для данного Motrix. Обновите расширение Motrix и повторите.",
			"unsupportedRemote": "Аутентифицированный Motrix — не тот App или Server, который выбран для подключения. Проверьте адрес подключения и повторите.",
			"remoteDiscoveryUnavailable": "Не удалось связаться с удалённым Motrix Server. Проверьте адрес, службу прослушивания и сеть; для WSS также проверьте сертификат и обратный прокси.",
			"remotePairingUnavailable": "Удалённый Motrix Server не смог открыть защищённый сеанс сопряжения. Повторите попытку чуть позже.",
			"remoteTransportUnavailable": "Не удалось подключиться к удалённому Motrix Server. Проверьте адрес, службу прослушивания, DNS и сеть; для WSS также проверьте сертификат и обратный прокси. Браузер не может определить точную причину сбоя.",
			"peerRejected": "Motrix отклонил сопряжение.",
			"peerBusy": "Motrix обрабатывает слишком много запросов сопряжения. Повторите попытку чуть позже.",
			"securityCheckFailed": "Соединение не прошло проверку безопасности и было остановлено.",
			"peerNotAuthentic": "Другая сторона не смогла подтвердить, что это ваш Motrix. Соединение остановлено.",
			"credentialPhaseFailed": "Не удалось сохранить сопряжение. Попробуйте выполнить его заново.",
			"internalError": "В расширении произошла ошибка. Повторите.",
			"authFailed": "Motrix не распознал это сопряжение. Возможно, оно отозвано — выполните сопряжение заново.",
			"serverMacMismatch": "Ответ не прошёл проверку, поэтому соединение остановлено. Возможно, это не ваш Motrix.",
			"channelClosed": "Соединение закрыто. Подключитесь заново, чтобы продолжить.",
			"channelUnavailable": "Motrix сейчас недоступен. Убедитесь, что он запущен."
		} }
	} },
	th: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: เชื่อมต่อแล้ว",
			"disconnected": "Motrix: ยังไม่ได้เชื่อมต่อ",
			"connecting": "Motrix: กำลังเชื่อมต่อ…",
			"downloading": "Motrix: กำลังดาวน์โหลด",
			"denied": "Motrix: การจับคู่ถูกปฏิเสธ — เปิดเพื่อจับคู่ใหม่",
			"error": "Motrix: ส่งต่อไม่สำเร็จ — คลิกเพื่อดูรายละเอียด"
		} },
		contextMenu: {
			"downloadWithMotrix": "ดาวน์โหลดด้วย Motrix",
			"pairThenDownload": "จับคู่ Motrix แล้วดาวน์โหลด"
		},
		notify: {
			"browserFallbackBody": "Motrix ไม่พร้อมใช้งาน เบราว์เซอร์จะดาวน์โหลดแทน",
			"browserFallbackTitle": "กำลังดาวน์โหลดในเบราว์เซอร์",
			"downloadComplete": "ดาวน์โหลดเสร็จแล้ว",
			"downloadFailed": "ดาวน์โหลดไม่สำเร็จ",
			"handedToMotrix": "ส่งไปยัง Motrix แล้ว",
			"notConnectedBody": "จับคู่ Motrix เพื่อให้จัดการการดาวน์โหลด",
			"notConnectedTitle": "ยังไม่ได้เชื่อมต่อ Motrix",
			"notReachableBody": "จับคู่ Motrix แล้วลองดาวน์โหลดอีกครั้ง",
			"notReachableTitle": "ไม่สามารถติดต่อ Motrix ได้",
			"pairNudgeBody": "เปิด Motrix เพื่อจับคู่ให้เสร็จสิ้น",
			"pairNudgeTitle": "จับคู่ Motrix",
			"pairRevokedBody": "Motrix เพิกถอนการจับคู่ของเบราว์เซอร์นี้แล้ว",
			"pairRevokedTitle": "เพิกถอนการจับคู่แล้ว",
			"sensitiveSkippedBody": "ให้เบราว์เซอร์ดาวน์โหลดจากเว็บไซต์ที่มีข้อมูลอ่อนไหว",
			"sensitiveSkippedTitle": "ข้ามแล้ว",
			"submitFailedBody": "กำลังดาวน์โหลดใหม่ในเบราว์เซอร์",
			"submitFailedTitle": "ส่งไปยัง Motrix ไม่สำเร็จ"
		},
		options: /* @__PURE__ */ JSON.parse("{\"diagnostics\":{\"adapters\":\"อะแดปเตอร์\",\"extensionId\":\"รหัสส่วนขยาย\",\"logLevel\":\"ระดับบันทึกเหตุการณ์\",\"logLevels\":{\"silent\":\"ไม่บันทึก\",\"error\":\"ข้อผิดพลาด\",\"warn\":\"คำเตือน\",\"info\":\"ข้อมูล\",\"debug\":\"ดีบัก\"},\"noneRegistered\":\"ยังไม่มีรายการที่ลงทะเบียน\",\"title\":\"การวินิจฉัย\",\"version\":\"เวอร์ชัน\"},\"endpoint\":{\"activate\":\"ใช้\",\"activateAria\":\"ใช้ {{name}}\",\"connection\":{\"bootstrapping\":\"กำลังเริ่มต้น\",\"connected\":\"เชื่อมต่อแล้ว\",\"connecting\":\"กำลังเชื่อมต่อ\",\"denied\":\"ถูกปฏิเสธ\",\"disconnected\":\"ไม่ได้เชื่อมต่อ\",\"handshaking\":\"กำลังอนุญาต\",\"awaiting-code\":\"กำลังรอรหัส\"},\"currentDescription\":\"เลือก App หรือ Server สำหรับการดาวน์โหลด งาน และทรัพยากรที่ตรวจพบในหน้าเว็บ\",\"currentTitle\":\"แบ็กเอนด์ Motrix\",\"listLabel\":\"แบ็กเอนด์ Motrix ที่พร้อมใช้งาน\",\"localDescription\":\"คอมพิวเตอร์เครื่องนี้ที่ค้นพบผ่าน Motrix App\",\"localName\":\"Motrix App\",\"selectLabel\":\"ส่งการดาวน์โหลดไปยัง\"},\"language\":{\"label\":\"ภาษา\",\"system\":\"ตามระบบ\"},\"notifications\":{\"title\":\"การแจ้งเตือนของระบบ\",\"masterLabel\":\"เปิดการแจ้งเตือนของระบบ\",\"masterAria\":\"เปิดการแจ้งเตือนของระบบ\",\"confirmLabel\":\"สำเร็จ / การยืนยัน\",\"confirmDesc\":\"ส่งไปยัง Motrix แล้ว, ดาวน์โหลดเสร็จแล้ว\",\"errorLabel\":\"ความล้มเหลว / ข้อผิดพลาด\",\"errorDesc\":\"ส่งไม่สำเร็จ, ติดต่อไม่ได้, ดาวน์โหลดไม่สำเร็จ\",\"reminderLabel\":\"การเตือน\",\"reminderDesc\":\"คำขอจับคู่, การเพิกถอนการจับคู่, เว็บไซต์ที่ข้าม\"},\"pairing\":{\"backendTitle\":\"กำลังจับคู่ {{name}}\",\"forget\":\"ลืมการจับคู่\",\"loading\":\"กำลังโหลดสถานะการจับคู่…\",\"localHelp\":\"คลิกจับคู่เพื่อค้นหา Motrix บนคอมพิวเตอร์เครื่องนี้ แล้วป้อนรหัสจับคู่\",\"localTitle\":\"จับคู่ผ่าน Motrix App\",\"remoteTitle\":\"จับคู่กับ Motrix Server\",\"remoteHelp\":\"คลิกจับคู่ ยืนยันคำขอในหน้าจัดการ Server แล้วป้อนรหัสที่แสดงที่นี่ รองรับทั้งปลายทาง WS และ WSS โดยแนะนำให้ใช้ WSS\",\"serverRequiredTitle\":\"ต้องใช้ Motrix Server\",\"serverRequiredHelp\":\"Firefox สำหรับ Android เชื่อมต่อผ่าน Motrix Server เพิ่ม Server ด้านบนแล้วเลือกเพื่อจับคู่\",\"remoteConsentTitle\":\"การดาวน์โหลดระยะไกล\",\"remoteConsentBody\":\"การดาวน์โหลดระยะไกลจะส่ง URL เป้าหมาย, URL และชื่อหน้าเว็บต้นทาง, ชื่อไฟล์, รายการที่เลือก และคำสั่งควบคุมงานไปยัง Server นี้ คุกกี้และส่วนหัวคำขอจะไม่ถูกส่งจนกว่าจะเปิดใช้งานแยกต่างหาก\",\"remoteConsentOffline\":\"สิทธิ์ข้อมูลผูกกับ Server ที่ยืนยันตัวตนแล้ว โปรดเชื่อมต่อก่อนเปลี่ยนสิทธิ์\",\"remoteHeadersLabel\":\"ส่งส่วนหัวคำขอ\",\"remoteHeadersHelp\":\"อนุญาตส่วนหัวที่ได้จากหน้าเว็บ เช่น Referer และส่วนหัวการเล่นสื่อ ส่วนหัวการยืนยันตัวตนยังต้องใช้สิทธิ์ข้อมูลรับรองด้านล่าง\",\"remoteCredentialsLabel\":\"ส่งคุกกี้และข้อมูลยืนยันตัวตน\",\"remoteCredentialsHelp\":\"อนุญาตคุกกี้และส่วนหัวข้อมูลรับรองสำหรับ Server นี้เท่านั้น เปิดใช้เฉพาะ Server ที่คุณควบคุม\",\"notPaired\":\"ยังไม่ได้จับคู่\",\"paired\":\"จับคู่กับ Motrix แล้ว\",\"pairedHelp\":\"เก็บข้อมูลรับรอง MBP1 ที่ยืนยันแล้วไว้สำหรับแบ็กเอนด์นี้ สถานะการเชื่อมต่อปัจจุบันจะแสดงแยกต่างหาก\",\"pairedTitle\":\"การจับคู่พร้อมใช้งาน\",\"reconnect\":\"เชื่อมต่อใหม่\",\"scopedHelp\":\"ความเชื่อถือและข้อมูลรับรองการจับคู่แยกกันสำหรับแต่ละแบ็กเอนด์ การเปลี่ยนแบ็กเอนด์จะไม่ใช้ความเชื่อถือของแบ็กเอนด์อื่น\",\"pair\":\"จับคู่\",\"pairDialogTitle\":\"จับคู่กับ Motrix\"},\"servers\":{\"add\":\"เพิ่มเซิร์ฟเวอร์\",\"addTitle\":\"เพิ่ม Motrix Server\",\"current\":\"ปัจจุบัน\",\"delete\":\"ลบเซิร์ฟเวอร์\",\"deleteActiveDescription\":\"ลบ {{name}} พร้อมข้อมูลรับรองการจับคู่และความยินยอมที่เก็บไว้ในเครื่องหรือไม่? แบ็กเอนด์ปัจจุบันจะกลับไปเป็น Motrix App โดยไม่เชื่อมต่อหรือเปิดแอป\",\"deleteActiveServerOnlyDescription\":\"ลบ {{name}} พร้อมข้อมูลรับรองการจับคู่และความยินยอมที่เก็บไว้ในเครื่องหรือไม่? คุณต้องเพิ่มหรือเลือก Motrix Server อื่นก่อนดาวน์โหลด\",\"deleteAria\":\"ลบ {{name}}\",\"deleteDescription\":\"ลบ {{name}} พร้อมข้อมูลรับรองการจับคู่และความยินยอมที่เก็บไว้ในเครื่องหรือไม่? การดำเนินการนี้ไม่เพิกถอนสิ่งใดบนเซิร์ฟเวอร์\",\"deleteTitle\":\"ลบ Motrix Server หรือไม่?\",\"description\":\"บันทึกที่อยู่ Motrix Server หลายรายการและสลับใช้งานจากการตั้งค่าหรือป๊อปอัป\",\"dialogDescription\":\"ตั้งชื่อที่จดจำง่ายให้แบ็กเอนด์นี้และป้อน URL ฐานของ WebSocket\",\"editAria\":\"แก้ไข {{name}}\",\"editTitle\":\"แก้ไข Motrix Server\",\"emptyDescription\":\"เพิ่มเซิร์ฟเวอร์เพื่อเชื่อมต่อกับ Motrix นอกคอมพิวเตอร์เครื่องนี้\",\"emptyTitle\":\"ยังไม่มี Motrix Server\",\"footer\":\"การเปลี่ยนที่อยู่เซิร์ฟเวอร์ต้องจับคู่ใหม่ ข้อมูลการจับคู่จะไม่ถูกแชร์ระหว่างที่อยู่\",\"nameLabel\":\"ชื่อเซิร์ฟเวอร์\",\"namePlaceholder\":\"เซิร์ฟเวอร์ที่บ้าน\",\"nameRequired\":\"ต้องระบุชื่อเซิร์ฟเวอร์\",\"save\":\"บันทึกเซิร์ฟเวอร์\",\"statusAuthority\":\"ที่อยู่เซิร์ฟเวอร์: {{value}}\",\"statusRuntime\":\"เวอร์ชัน Motrix: {{name}} {{version}}\",\"statusTitle\":\"ข้อมูลเซิร์ฟเวอร์\",\"statusTransportSecure\":\"ความปลอดภัยการเชื่อมต่อ: ใช้ WSS และ TLS ตรวจสอบตัวตนเซิร์ฟเวอร์\",\"statusTransportPlain\":\"ความปลอดภัยการเชื่อมต่อ: เข้ารหัสแล้ว แต่ WS ไม่สามารถตรวจสอบตัวตนเซิร์ฟเวอร์และอาจเปิดเผยข้อมูลการเชื่อมต่อ แนะนำให้ใช้ WSS\",\"title\":\"เซิร์ฟเวอร์ Motrix\",\"urlDescription\":\"ใช้ URL ฐาน ws:// หรือ wss:// พาธที่ระบุเพิ่มเติมจะถูกเก็บไว้ตามเดิมเป็นคำนำหน้าของพร็อกซีย้อนกลับ แนะนำให้ใช้ WSS\",\"urlDuplicate\":\"ที่อยู่ Motrix Server นี้บันทึกไว้แล้ว\",\"urlInvalid\":\"ป้อน URL ฐาน ws:// หรือ wss:// ที่ถูกต้อง โดยไม่มีช่องว่าง ข้อมูลรับรอง คิวรี หรือแฟรกเมนต์\",\"urlLabel\":\"URL ของ WebSocket\",\"urlPlaceholder\":\"ws(s)://host[:port][/base-path]\",\"transportWarningTitle\":\"การเชื่อมต่อนี้ไม่ได้ใช้ WSS\",\"transportWarningBody\":\"เนื้อหาที่รับส่งกับ Motrix ยังคงเข้ารหัส แต่ WS ไม่สามารถตรวจสอบตัวตนเซิร์ฟเวอร์และอาจเปิดเผยข้อมูลการเชื่อมต่อ ใช้ WSS หาก NAS ของคุณรองรับ\",\"urlRequired\":\"ต้องระบุ URL ของ WebSocket\"},\"takeover\":{\"consentBody\":\"Motrix จะรับคุกกี้เข้าสู่ระบบของเว็บไซต์เพื่อดาวน์โหลดไฟล์ การดาวน์โหลดจากเว็บไซต์ที่มีข้อมูลอ่อนไหวยังคงอยู่ในเบราว์เซอร์\",\"consentCancel\":\"ยกเลิก\",\"consentConfirm\":\"เปิดใช้งาน\",\"consentDialogLabel\":\"ส่งการดาวน์โหลดไปยัง Motrix หรือไม่?\",\"denylistLabel\":\"รายการยกเว้น (หนึ่งโฮสต์ต่อบรรทัด — ให้เบราว์เซอร์จัดการเสมอ)\",\"enableAria\":\"เปิดการรับช่วงดาวน์โหลด\",\"enableLabel\":\"ส่งการดาวน์โหลดที่เข้าเงื่อนไขไปยัง Motrix\",\"loading\":\"กำลังโหลดการตั้งค่ารับช่วงดาวน์โหลด…\",\"minSizeLabel\":\"ขนาดขั้นต่ำ (MB)\",\"minSizePlaceholder\":\"0 = ทั้งหมด\",\"thresholdInvalid\":\"ขนาดขั้นต่ำต้องเป็นตัวเลขที่ไม่ติดลบ\",\"save\":\"บันทึก\",\"saved\":\"บันทึกแล้ว\",\"title\":\"รับช่วงดาวน์โหลด\",\"remoteUnavailable\":\"การรับช่วงอัตโนมัติในขณะนี้ต้องใช้ Motrix App ในเครื่อง การดาวน์โหลดระยะไกลและสิทธิ์ส่วนหัวหรือคุกกี้จะไม่เปิดใช้คุณสมบัตินี้ คุณยังส่งการดาวน์โหลดไปยัง Server นี้ด้วยตนเองหรือจากเมนูคลิกขวาได้\",\"availabilityUnknown\":\"ยังรับช่วงดาวน์โหลดไม่ได้จนกว่าจะตรวจสอบแบ็กเอนด์ที่เลือกได้\",\"remoteUnavailableShort\":\"เฉพาะ App ในเครื่อง การส่งผ่านคลิกขวาใช้กับ Server ได้\"},\"tabs\":{\"general\":\"ทั่วไป\",\"download\":\"การดาวน์โหลด\",\"integration\":\"การผสานรวม\",\"help\":\"ช่วยเหลือ\"},\"common\":{\"apply\":\"นำไปใช้\",\"cancel\":\"ยกเลิก\",\"loadError\":\"โหลดการตั้งค่าไม่ได้เนื่องจากกระบวนการเบื้องหลังของส่วนขยายเริ่มทำงานไม่สำเร็จ โหลดส่วนขยายใหม่แล้วลองอีกครั้ง\",\"saved\":\"บันทึกแล้ว\",\"saving\":\"กำลังบันทึก…\",\"saveError\":\"บันทึกไม่สำเร็จ\"},\"appearance\":{\"title\":\"รูปลักษณ์\",\"theme\":{\"label\":\"ธีม\",\"system\":\"ตามระบบ\",\"light\":\"สว่าง\",\"dark\":\"มืด\"}},\"help\":{\"title\":\"ความช่วยเหลือและการสนับสนุน\",\"description\":\"ดูคู่มือ ความช่วยเหลือ และข้อมูลวินิจฉัยส่วนขยาย\",\"reportBug\":\"รายงานปัญหา\",\"reportBugDescription\":\"เปิด issue บน GitHub หรือส่งข้อเสนอแนะ\",\"issues\":\"GitHub Issues\",\"docs\":\"เอกสาร\",\"docsDescription\":\"อ่านคู่มือการตั้งค่า การจับคู่ การรับช่วงดาวน์โหลด และการแก้ปัญหา\",\"copyDiagnostics\":\"คัดลอกข้อมูลวินิจฉัย\",\"copied\":\"คัดลอกแล้ว\",\"diagnostics\":\"การวินิจฉัย\",\"diagnosticsDescription\":\"ปรับการบันทึกเหตุการณ์และคัดลอกข้อมูลที่มีประโยชน์ในการแก้ปัญหา\"},\"about\":{\"subtitle\":\"ดาวน์โหลดไฟล์จากเว็บด้วย Motrix\",\"website\":\"เว็บไซต์ทางการ\"},\"title\":\"การตั้งค่าส่วนขยาย Motrix\"}"),
		popup: /* @__PURE__ */ JSON.parse("{\"backend\":{\"app\":\"Motrix App\",\"appDescription\":\"คอมพิวเตอร์เครื่องนี้\",\"choose\":\"เลือกแบ็กเอนด์ Motrix\",\"configureServer\":\"จัดการ Motrix Server\",\"notConfigured\":\"ยังไม่ได้ตั้งค่า\",\"server\":\"Motrix Server\",\"version\":\"v{{version}}\"},\"controlPanel\":{\"engineState\":\"เอนจิน: {{state}}\",\"noDownloads\":\"ไม่มีการดาวน์โหลด\",\"pause\":\"หยุดชั่วคราว\",\"remove\":\"นำออก\",\"resume\":\"ทำต่อ\",\"statsSummary\":\"กำลังทำงาน {{active}} · รอ {{waiting}}\"},\"dashboard\":{\"activity\":\"กิจกรรม\",\"resources\":\"ทรัพยากร\",\"showResources\":\"แสดงทรัพยากรจากหน้านี้\",\"showTasks\":\"แสดงงานที่กำลังทำงาน\",\"title\":\"ภาพรวมการถ่ายโอน\"},\"loading\":\"กำลังโหลด…\",\"quickSettings\":{\"fullSettings\":\"ตั้งค่าทั้งหมด\",\"fullSettingsDescription\":\"ทั่วไป การดาวน์โหลด แบ็กเอนด์ และความช่วยเหลือ\",\"loadError\":\"โหลดการตั้งค่าด่วนไม่ได้\",\"notificationsDescription\":\"ควบคุมการแจ้งเตือนของระบบจากส่วนขยาย\",\"retry\":\"ลองอีกครั้ง\",\"saveError\":\"บันทึกการตั้งค่าไม่ได้ ลองอีกครั้ง\",\"takeoverDescription\":\"ส่งการดาวน์โหลดของเบราว์เซอร์ไปยังแบ็กเอนด์ Motrix ปัจจุบัน\"},\"quickAdd\":{\"title\":\"งานใหม่\",\"description\":\"วางลิงก์ HTTP, HTTPS หรือ magnet\",\"inputLabel\":\"ที่อยู่ดาวน์โหลด\",\"placeholder\":\"https://example.com/file.zip\",\"cancel\":\"ยกเลิก\",\"add\":\"เพิ่ม\",\"submitting\":\"กำลังเพิ่ม…\",\"error\":{\"empty\":\"ป้อนที่อยู่ดาวน์โหลด\",\"unsupported\":\"รองรับเฉพาะลิงก์ HTTP, HTTPS หรือ magnet\",\"invalid\":\"ที่อยู่ดาวน์โหลดไม่ถูกต้อง\",\"submitFailed\":\"เพิ่มงานไม่ได้ โปรดลองอีกครั้ง\"}},\"reconnect\":\"เชื่อมต่อ\",\"settings\":\"เปิดการตั้งค่า\",\"sniffer\":{\"clearFilters\":\"ล้างตัวกรอง\",\"detected\":\"{{count}} รายการ\",\"downloadCount\":\"ดาวน์โหลด {{count}} รายการ\",\"downloadSelected\":\"ดาวน์โหลดรายการที่เลือก\",\"downloadedResource\":\"ส่ง {{name}} แล้ว\",\"downloadingResource\":\"กำลังดาวน์โหลด {{name}}\",\"emptyDescription\":\"เล่นสื่อแล้วลองอีกครั้ง\",\"emptyFilter\":\"ไม่มีทรัพยากรตรงตัวกรอง\",\"emptyTitle\":\"ไม่พบสื่อ\",\"filteredCount\":\"รูปภาพ {{matched}} / {{total}} รูป\",\"filters\":{\"all\":\"ทั้งหมด\",\"audio\":\"เสียง\",\"image\":\"ภาพ\",\"video\":\"วิดีโอ\"},\"imageFilters\":{\"activeCount\":\"ใช้ตัวกรอง {{count}} รายการ\",\"dimensions\":\"มิติและขนาดไฟล์\",\"done\":\"เสร็จสิ้น\",\"fields\":{\"height\":\"ความสูง\",\"size\":\"ขนาด\",\"width\":\"ความกว้าง\"},\"formatOptionLabel\":\"กรองรูปภาพ {{format}}\",\"formats\":\"รูปแบบภาพ\",\"operatorLabel\":\"เปรียบเทียบ {{label}}\",\"reset\":\"รีเซ็ต\",\"result\":\"{{matched}} / {{total}}\",\"sizeUnitLabel\":\"หน่วยขนาดไฟล์\",\"title\":\"ตัวกรองด่วน\",\"trigger\":\"กรอง\",\"valueLabel\":\"ค่า {{label}}\"},\"imageCount\":\"{{count}} รูป\",\"noImageMatches\":\"ไม่มีรูปภาพที่ตรงกัน\",\"pageAction\":{\"bilibili\":\"ส่งวิดีโอ bilibili นี้\",\"youtube\":\"ส่งวิดีโอ YouTube นี้\"},\"pageSubmitted\":\"ส่งวิดีโอไปยัง Motrix แล้ว {{taskId}}\",\"pageResources\":\"ทรัพยากร\",\"quickDownloadResource\":\"ดาวน์โหลด {{name}} แบบด่วน\",\"connectToSubmit\":\"เชื่อมต่อกับ Motrix เพื่อส่งทรัพยากร\",\"scan\":\"สแกนอีกครั้ง\",\"scanning\":\"กำลังสแกน…\",\"selectAll\":\"เลือกทั้งหมด\",\"selected\":\"เลือกแล้ว {{count}} รายการ\",\"selectResource\":\"เลือก {{name}}\",\"sourceHost\":\"แหล่งที่มา: {{host}}\",\"sendResource\":\"ส่ง {{name}} ไปยัง Motrix\",\"sent\":\"ส่งแล้ว\",\"sending\":\"กำลังส่ง\",\"submitFailed\":\"ส่งทรัพยากรไม่ได้ โปรดลองอีกครั้ง\",\"title\":\"ค้นหาทรัพยากร\",\"unavailableDescription\":\"เปลี่ยนหน้าหรือลองอีกครั้งภายหลัง\",\"unavailableTitle\":\"สแกนหน้านี้ไม่ได้\",\"unsupported\":\"ต้องใช้ ffmpeg\",\"unsupportedReason\":\"แบ็กเอนด์ที่เลือกไม่สามารถส่งทรัพยากร {{kind}} ได้ เนื่องจากไม่มีการรองรับ ffmpeg\",\"unsupportedSelectionReason\":\"แบ็กเอนด์ที่เลือกไม่สามารถส่งทรัพยากรที่เลือกอย่างน้อยหนึ่งประเภทได้\",\"unsupportedResource\":\"ส่ง {{name}} ไม่ได้ {{reason}}\"},\"speed\":{\"download\":\"ดาวน์โหลด\",\"upload\":\"อัปโหลด\"},\"status\":{\"bootstrapping\":\"กำลังค้นหา Motrix…\",\"connected\":\"เชื่อมต่อแล้ว\",\"connecting\":\"กำลังเชื่อมต่อ…\",\"denied\":\"การจับคู่ถูกปฏิเสธ\",\"disconnected\":\"ไม่ได้เชื่อมต่อ\",\"handshaking\":\"กำลังเจรจาการเชื่อมต่อ\",\"awaiting-code\":\"กำลังรอรหัสจับคู่…\"},\"tabs\":{\"settings\":\"ตั้งค่า\",\"sniffer\":\"ทรัพยากร\",\"tasks\":\"งาน\"},\"takeover\":{\"aria\":\"สลับการรับช่วงดาวน์โหลด\",\"label\":\"รับช่วง\"},\"tasks\":{\"actions\":\"การดำเนินการสำหรับ {{name}}\",\"openFolder\":\"เปิดโฟลเดอร์ที่มีไฟล์ใน Motrix\",\"openFolderError\":\"เปิดโฟลเดอร์งานไม่ได้ โปรดลองอีกครั้ง\",\"openFolderMetadataPending\":\"รอข้อมูลเมตาของงานก่อนเปิดโฟลเดอร์\",\"openFolderTask\":\"เปิดโฟลเดอร์ที่มี {{name}}\",\"openFolderUnsupported\":\"อัปเดต Motrix เพื่อเปิดโฟลเดอร์\",\"pauseTask\":\"หยุด {{name}} ชั่วคราว\",\"removeTask\":\"นำ {{name}} ออก\",\"removeConfirmTitle\":\"นำงานออกหรือไม่?\",\"removeConfirmDescription\":\"“{{name}}” จะถูกนำออกจากรายการดาวน์โหลด\",\"removeDeleteFilesLabel\":\"ลบไฟล์ที่ดาวน์โหลดแล้ว\",\"removeConfirmAction\":\"นำออก\",\"resumeTask\":\"ทำ {{name}} ต่อ\",\"bytes\":\"{{done}} จาก {{total}}\",\"disconnectedDescription\":\"เชื่อมต่อเพื่อดูงาน\",\"disconnectedTitle\":\"Motrix ออฟไลน์\",\"empty\":{\"active\":\"ไม่มีงานกำลังทำงาน\",\"failed\":\"ไม่มีงานล้มเหลว\",\"recent\":\"ไม่มีงานเสร็จแล้ว\"},\"filters\":{\"active\":\"กำลังทำงาน\",\"failed\":\"ล้มเหลว\",\"recent\":\"เสร็จแล้ว\"},\"loading\":\"กำลังโหลดงาน\",\"status\":{\"completed\":\"เสร็จแล้ว\",\"downloading\":\"กำลังดาวน์โหลด\",\"error\":\"ล้มเหลว\",\"fetching_metadata\":\"กำลังรับข้อมูลเมตา\",\"finalizing\":\"กำลังดำเนินการขั้นสุดท้าย\",\"paused\":\"หยุดชั่วคราว\",\"queued\":\"อยู่ในคิว\",\"seeding\":\"กำลังปล่อยไฟล์\"},\"title\":\"งาน\"},\"pairing\":{\"attemptOf\":\"ครั้งที่ {{run}} จาก {{maxRuns}}\",\"attemptsRemaining\":\"เหลือ {{attemptsRemaining}} ครั้ง\",\"codeLabel\":\"รหัสจับคู่\",\"codeDescription\":\"ป้อนรหัส 8 อักขระจากหน้าต่างจับคู่ Motrix\",\"codeInvalid\":\"ป้อนรหัส 8 อักขระจากหน้าต่างจับคู่\",\"dialogTitle\":\"ป้อนรหัสจับคู่\",\"dismissPrompt\":\"ป้อนภายหลังและท่องเว็บต่อ\",\"enterCode\":\"ป้อนรหัสจับคู่\",\"expiresIn\":\"หมดอายุใน {{time}}\",\"pairButton\":\"จับคู่\",\"pickerHelp\":\"พบ Motrix หลายอินสแตนซ์ เลือกหนึ่งรายการเพื่อจับคู่\",\"rescan\":\"ค้นหาใหม่\",\"noCandidates\":\"ไม่พบอินสแตนซ์ Motrix\",\"candidatesLabel\":\"อินสแตนซ์ Motrix ที่ค้นพบ\",\"candidatePort\":\"พอร์ต {{port}}\",\"candidateDetail\":\"{{instanceId}} · v{{appVersion}}\",\"unknownVersion\":\"ไม่ทราบเวอร์ชัน\",\"choose\":\"เลือก\",\"backoffTitle\":\"พยายามจับคู่มากเกินไป\",\"backoffBody\":\"ลองอีกครั้งเวลา {{time}}\",\"retryIn\":\"ลองอีกครั้งใน {{seconds}} วินาที\",\"permissionMissingTitle\":\"ต้องได้รับสิทธิ์\",\"permissionMissingBody\":\"อนุญาตให้เข้าถึง localhost เพื่อค้นหา Motrix บนคอมพิวเตอร์เครื่องนี้\",\"grantPermission\":\"ให้สิทธิ์\",\"degradedTitle\":\"เชื่อมต่อ Motrix แล้ว\",\"degradedBody\":\"คุณใช้ Motrix ได้ตามปกติ การเชื่อมต่อนี้มีเพียงการตรวจสอบขั้นพื้นฐาน เพื่อการป้องกันที่ดียิ่งขึ้น ให้อัปเดต Motrix และจับคู่ใหม่\",\"recoveryExhaustedTitle\":\"เชื่อมต่อใหม่โดยอัตโนมัติไม่ได้\",\"recoveryExhaustedBody\":\"การจับคู่ Motrix ที่บันทึกไว้ทั้งหมดใช้ไม่ได้ กดเชื่อมต่อเพื่อจับคู่ใหม่\"}}"),
		errors: { "connection": {
			"generic": "เชื่อมต่อไม่สำเร็จ โปรดลองอีกครั้ง",
			"backoffLocked": "พยายามจับคู่มากเกินไป โปรดลองอีกครั้งภายหลัง",
			"staleAttempt": "มีการพยายามเชื่อมต่อครั้งใหม่เข้ามาแทนที่",
			"aborted": "ยกเลิกการจับคู่แล้ว",
			"deadlineExceeded": "หมดเวลาการลอง โปรดลองอีกครั้ง",
			"runsExhausted": "ป้อนรหัสผิดมากเกินไป เริ่มจับคู่ใหม่เพื่อรับรหัสใหม่",
			"invalidCode": "รูปแบบรหัสไม่ถูกต้อง ตรวจสอบกล่องโต้ตอบของ Motrix",
			"missingNonce": "Motrix ไม่ได้จัดสรรช่องสำหรับจับคู่ ตรวจสอบว่า Motrix ทำงานอยู่แล้วลองอีกครั้ง",
			"unsupportedBrowser": "เบราว์เซอร์นี้ไม่รองรับการจับคู่",
			"ticketPreparationFailed": "เตรียมการจับคู่ไม่ได้ โปรดลองอีกครั้ง",
			"protocolViolation": "Motrix ส่งการตอบกลับที่ไม่คาดคิด โปรดลองอีกครั้ง",
			"unsupportedVersion": "ส่วนขยายนี้กับ Motrix ใช้โปรโตคอลคนละเวอร์ชัน อัปเดตทั้งสองแล้วลองอีกครั้ง",
			"backendUpgradeRequired": "Motrix เวอร์ชันนี้เก่าเกินไปสำหรับการจับคู่ที่ปลอดภัย อัปเดต Motrix แล้วลองอีกครั้ง",
			"extensionUpgradeRequired": "ส่วนขยายเวอร์ชันนี้เก่าเกินไปสำหรับ Motrix นี้ อัปเดตส่วนขยาย Motrix แล้วลองอีกครั้ง",
			"unsupportedRemote": "Motrix ที่ยืนยันตัวตนแล้วไม่ใช่ App หรือ Server ที่เลือกสำหรับการเชื่อมต่อนี้ ตรวจสอบปลายทางแล้วลองอีกครั้ง",
			"remoteDiscoveryUnavailable": "ติดต่อ Motrix Server ระยะไกลไม่ได้ ตรวจสอบที่อยู่ บริการรับการเชื่อมต่อ และเครือข่าย สำหรับ WSS ให้ตรวจสอบใบรับรองและพร็อกซีย้อนกลับด้วย",
			"remotePairingUnavailable": "Motrix Server ระยะไกลเปิดเซสชันจับคู่ที่ปลอดภัยไม่ได้ โปรดลองอีกครั้งในอีกสักครู่",
			"remoteTransportUnavailable": "เชื่อมต่อ Motrix Server ระยะไกลไม่สำเร็จ ตรวจสอบที่อยู่ บริการรับการเชื่อมต่อ DNS และเครือข่าย สำหรับ WSS ให้ตรวจสอบใบรับรองและพร็อกซีย้อนกลับด้วย เบราว์เซอร์ไม่สามารถระบุได้ว่าส่วนใดล้มเหลว",
			"peerRejected": "Motrix ปฏิเสธการจับคู่",
			"peerBusy": "Motrix กำลังจัดการคำขอจับคู่มากเกินไป โปรดลองอีกครั้งในอีกสักครู่",
			"securityCheckFailed": "การเชื่อมต่อไม่ผ่านการตรวจสอบความปลอดภัยและถูกหยุดแล้ว",
			"peerNotAuthentic": "อีกฝ่ายพิสูจน์ไม่ได้ว่าเป็น Motrix ของคุณ การเชื่อมต่อจึงถูกหยุด",
			"credentialPhaseFailed": "บันทึกการจับคู่ไม่ได้ โปรดลองจับคู่ใหม่",
			"internalError": "เกิดปัญหาในส่วนขยาย โปรดลองอีกครั้ง",
			"authFailed": "Motrix ไม่รู้จักการจับคู่นี้ อาจถูกเพิกถอนแล้ว โปรดลองจับคู่ใหม่",
			"serverMacMismatch": "การตอบกลับไม่ผ่านการตรวจสอบจึงหยุดการเชื่อมต่อ อีกฝ่ายอาจไม่ใช่ Motrix ของคุณ",
			"channelClosed": "ปิดการเชื่อมต่อแล้ว เชื่อมต่อใหม่เพื่อดำเนินการต่อ",
			"channelUnavailable": "ขณะนี้ติดต่อ Motrix ไม่ได้ ตรวจสอบว่าโปรแกรมทำงานอยู่"
		} }
	} },
	tr: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: bağlı",
			"disconnected": "Motrix: bağlı değil",
			"connecting": "Motrix: bağlanıyor…",
			"downloading": "Motrix: indiriliyor",
			"denied": "Motrix: eşleştirme reddedildi — yeniden eşleştirmek için açın",
			"error": "Motrix: aktarım başarısız — ayrıntılar için tıklayın"
		} },
		contextMenu: {
			"downloadWithMotrix": "Motrix ile indir",
			"pairThenDownload": "Motrix’i eşleştir, ardından indir"
		},
		notify: {
			"browserFallbackBody": "Motrix kullanılamıyor. İndirme tarayıcıda yapılacak.",
			"browserFallbackTitle": "Tarayıcıda indiriliyor",
			"downloadComplete": "İndirme tamamlandı",
			"downloadFailed": "İndirme başarısız",
			"handedToMotrix": "Motrix’e gönderildi",
			"notConnectedBody": "İndirmeleri devralması için Motrix’i eşleştirin.",
			"notConnectedTitle": "Motrix bağlı değil",
			"notReachableBody": "Motrix’i eşleştirip indirmeyi yeniden deneyin.",
			"notReachableTitle": "Motrix’e ulaşılamıyor",
			"pairNudgeBody": "Eşleştirmeyi tamamlamak için Motrix’i açın.",
			"pairNudgeTitle": "Motrix’i eşleştir",
			"pairRevokedBody": "Motrix bu tarayıcının eşleştirmesini iptal etti.",
			"pairRevokedTitle": "Eşleştirme iptal edildi",
			"sensitiveSkippedBody": "Hassas sitenin indirmesi tarayıcıya bırakıldı.",
			"sensitiveSkippedTitle": "Atlandı",
			"submitFailedBody": "Tarayıcıda yeniden indiriliyor.",
			"submitFailedTitle": "Motrix’e gönderilemedi"
		},
		options: {
			"diagnostics": {
				"adapters": "Bağdaştırıcılar",
				"extensionId": "Uzantı kimliği",
				"logLevel": "Günlük düzeyi",
				"logLevels": {
					"silent": "Kayıt yok",
					"error": "Hata",
					"warn": "Uyarı",
					"info": "Bilgi",
					"debug": "Hata ayıklama"
				},
				"noneRegistered": "Henüz kayıtlı değil",
				"title": "Tanılama",
				"version": "Sürüm"
			},
			"endpoint": {
				"activate": "Kullan",
				"activateAria": "{{name}} kullan",
				"connection": {
					"bootstrapping": "Başlatılıyor",
					"connected": "Bağlı",
					"connecting": "Bağlanıyor",
					"denied": "Reddedildi",
					"disconnected": "Bağlı değil",
					"handshaking": "Yetkilendiriliyor",
					"awaiting-code": "Kod bekleniyor"
				},
				"currentDescription": "İndirmeler, görevler ve sayfada algılanan kaynaklar için bir App veya Server seçin.",
				"currentTitle": "Motrix arka uçları",
				"listLabel": "Kullanılabilir Motrix arka uçları",
				"localDescription": "Motrix App ile bulunan bu bilgisayar",
				"localName": "Motrix App",
				"selectLabel": "İndirmelerin gönderileceği yer"
			},
			"language": {
				"label": "Dil",
				"system": "Sistemi izle"
			},
			"notifications": {
				"title": "Sistem bildirimleri",
				"masterLabel": "Sistem bildirimlerini etkinleştir",
				"masterAria": "Sistem bildirimlerini etkinleştir",
				"confirmLabel": "Başarı / onaylar",
				"confirmDesc": "Motrix’e gönderildi, indirme tamamlandı",
				"errorLabel": "Başarısızlık / hatalar",
				"errorDesc": "Gönderim başarısız, ulaşılamıyor, indirme başarısız",
				"reminderLabel": "Hatırlatmalar",
				"reminderDesc": "Eşleştirme istekleri, iptal edilen eşleştirmeler, atlanan siteler"
			},
			"pairing": {
				"backendTitle": "{{name}} eşleştiriliyor",
				"forget": "Eşleştirmeyi unut",
				"loading": "Eşleştirme durumu yükleniyor…",
				"localHelp": "Bu bilgisayardaki Motrix’i bulmak için Eşleştir’e tıklayın ve eşleştirme kodunu girin.",
				"localTitle": "Motrix App üzerinden eşleştir",
				"remoteTitle": "Motrix Server ile eşleştir",
				"remoteHelp": "Eşleştir’e tıklayın, Server yönetim arayüzünde isteği onaylayın ve gösterilen kodu buraya girin. WS ve WSS uç noktaları desteklenir; WSS önerilir.",
				"serverRequiredTitle": "Motrix Server gerekli",
				"serverRequiredHelp": "Android için Firefox, Motrix Server üzerinden bağlanır. Yukarıdan bir Server ekleyip eşleştirmek için seçin.",
				"remoteConsentTitle": "Uzak indirmeler",
				"remoteConsentBody": "Uzak indirmeler hedef URL’yi, kaynak sayfanın URL’sini ve başlığını, dosya adını, seçimi ve görev komutlarını bu Server’a gönderir. Çerezler ve istek üstbilgileri ayrı olarak etkinleştirilmedikçe gönderilmez.",
				"remoteConsentOffline": "Veri izinleri, kimliği doğrulanmış Server’a bağlıdır. Değiştirmeden önce bağlanın.",
				"remoteHeadersLabel": "İstek üstbilgilerini gönder",
				"remoteHeadersHelp": "Referer ve medya oynatma üstbilgileri gibi sayfadan alınan üstbilgilere izin verir. Kimlik doğrulama üstbilgileri için aşağıdaki kimlik bilgisi izni yine gereklidir.",
				"remoteCredentialsLabel": "Çerezleri ve kimlik doğrulama bilgilerini gönder",
				"remoteCredentialsHelp": "Çerezlere ve kimlik bilgisi üstbilgilerine yalnızca bu Server için izin verir. Yalnızca kontrol ettiğiniz bir Server için etkinleştirin.",
				"notPaired": "Eşleştirilmedi",
				"paired": "Motrix ile eşleştirildi",
				"pairedHelp": "Bu arka uç için onaylanmış bir MBP1 kimlik bilgisi saklanır. Güncel bağlantı durumu ayrı gösterilir.",
				"pairedTitle": "Eşleştirme hazır",
				"reconnect": "Yeniden bağlan",
				"scopedHelp": "Eşleştirme güveni ve kimlik bilgileri her arka uç için ayrıdır. Arka uç değiştirildiğinde diğer arka ucun güveni asla kullanılmaz.",
				"pair": "Eşleştir",
				"pairDialogTitle": "Motrix ile eşleştir"
			},
			"servers": {
				"add": "Sunucu ekle",
				"addTitle": "Motrix Server ekle",
				"current": "Geçerli",
				"delete": "Sunucuyu sil",
				"deleteActiveDescription": "{{name}} ve yerel olarak saklanan eşleştirme kimlik bilgileri ile onayları silinsin mi? Geçerli arka uç Motrix App’e döner ancak uygulamaya bağlanılmaz ve uygulama başlatılmaz.",
				"deleteActiveServerOnlyDescription": "{{name}} ve yerel olarak saklanan eşleştirme kimlik bilgileri ile onayları silinsin mi? İndirmeden önce başka bir Motrix Server eklemeniz veya seçmeniz gerekir.",
				"deleteAria": "{{name}} sil",
				"deleteDescription": "{{name}} ve yerel olarak saklanan eşleştirme kimlik bilgileri ile onayları silinsin mi? Bu işlem sunucuda hiçbir şeyi iptal etmez.",
				"deleteTitle": "Motrix Server silinsin mi?",
				"description": "Birden fazla Motrix Server adresi kaydedin ve seçeneklerden veya açılır pencereden aralarında geçiş yapın.",
				"dialogDescription": "Bu arka uca tanınabilir bir ad verin ve WebSocket temel URL’sini girin.",
				"editAria": "{{name}} düzenle",
				"editTitle": "Motrix Server’ı düzenle",
				"emptyDescription": "Bu bilgisayarın dışındaki Motrix’e bağlanmak için sunucu ekleyin.",
				"emptyTitle": "Henüz Motrix Server yok",
				"footer": "Sunucu adresi değiştiğinde yeniden eşleştirme gerekir. Eşleştirme bilgileri adresler arasında asla paylaşılmaz.",
				"nameLabel": "Sunucu adı",
				"namePlaceholder": "Ev sunucusu",
				"nameRequired": "Sunucu adı gerekli",
				"save": "Sunucuyu kaydet",
				"statusAuthority": "Sunucu adresi: {{value}}",
				"statusRuntime": "Motrix sürümü: {{name}} {{version}}",
				"statusTitle": "Sunucu bilgileri",
				"statusTransportSecure": "Bağlantı güvenliği: WSS kullanılıyor ve TLS sunucu kimliğini doğruluyor",
				"statusTransportPlain": "Bağlantı güvenliği: şifreli, ancak WS sunucu kimliğini doğrulayamaz ve bağlantı bilgilerini açığa çıkarabilir. WSS önerilir",
				"title": "Motrix sunucuları",
				"urlDescription": "ws:// veya wss:// temel URL’si kullanın. İsteğe bağlı yol, ters vekil öneki olarak aynen korunur; WSS önerilir.",
				"urlDuplicate": "Bu Motrix Server adresi zaten kayıtlı",
				"urlInvalid": "Boşluk, kimlik bilgisi, sorgu veya parça içermeyen geçerli bir ws:// veya wss:// temel URL’si girin",
				"urlLabel": "WebSocket URL’si",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Bu bağlantı WSS kullanmıyor",
				"transportWarningBody": "Motrix ile paylaşılan içerik şifreli kalır, ancak WS sunucu kimliğini doğrulayamaz ve bağlantı bilgilerini açığa çıkarabilir. NAS cihazınız destekliyorsa WSS kullanın.",
				"urlRequired": "WebSocket URL’si gerekli"
			},
			"takeover": {
				"consentBody": "Motrix, dosyaları indirmek için sitenin oturum çerezlerini alır. Hassas sitelerin indirmeleri tarayıcıda kalır.",
				"consentCancel": "İptal",
				"consentConfirm": "Etkinleştir",
				"consentDialogLabel": "İndirmeler Motrix’e gönderilsin mi?",
				"denylistLabel": "Dışlama listesi (her satıra bir ana makine — daima tarayıcıya bırakılır)",
				"enableAria": "Devralmayı etkinleştir",
				"enableLabel": "Uygun indirmeleri Motrix’e gönder",
				"loading": "Devralma ayarları yükleniyor…",
				"minSizeLabel": "En küçük boyut (MB)",
				"minSizePlaceholder": "0 = tümü",
				"thresholdInvalid": "En küçük boyut negatif olmayan bir sayı olmalıdır",
				"save": "Kaydet",
				"saved": "Kaydedildi",
				"title": "İndirmeleri devralma",
				"remoteUnavailable": "Otomatik devralma şu anda yerel Motrix App gerektirir. Uzak indirmeler ve üstbilgi veya çerez izinleri bu özelliği etkinleştirmez. Bu Server’a elle veya sağ tık menüsünden indirme gönderebilirsiniz.",
				"availabilityUnknown": "Seçili arka uç kontrol edilene kadar devralma kullanılamaz.",
				"remoteUnavailableShort": "Yalnızca yerel App. Sağ tıkla gönderim Server ile de çalışır."
			},
			"tabs": {
				"general": "Genel",
				"download": "İndirmeler",
				"integration": "Entegrasyon",
				"help": "Yardım"
			},
			"common": {
				"apply": "Uygula",
				"cancel": "İptal",
				"loadError": "Uzantının arka plan işlemi başlatılamadığı için ayarlar yüklenemedi. Uzantıyı yeniden yükleyip tekrar deneyin.",
				"saved": "Kaydedildi",
				"saving": "Kaydediliyor…",
				"saveError": "Kaydedilemedi"
			},
			"appearance": {
				"title": "Görünüm",
				"theme": {
					"label": "Tema",
					"system": "Sistemi izle",
					"light": "Açık",
					"dark": "Koyu"
				}
			},
			"help": {
				"title": "Yardım ve destek",
				"description": "Kılavuz, destek ve uzantı tanılama bilgilerini inceleyin.",
				"reportBug": "Sorun bildir",
				"reportBugDescription": "GitHub’da bir sorun kaydı açın veya geri bildirim paylaşın.",
				"issues": "GitHub Issues",
				"docs": "Belgeler",
				"docsDescription": "Kurulum, eşleştirme, indirmeleri devralma ve sorun giderme kılavuzlarını okuyun.",
				"copyDiagnostics": "Tanılama bilgilerini kopyala",
				"copied": "Kopyalandı",
				"diagnostics": "Tanılama",
				"diagnosticsDescription": "Günlük kaydını ayarlayın ve sorun gidermeye yardımcı bilgileri kopyalayın."
			},
			"about": {
				"subtitle": "Motrix ile web’den dosya indirin",
				"website": "Resmî web sitesi"
			},
			"title": "Motrix Uzantısı Ayarları"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Bu bilgisayar",
				"choose": "Motrix arka ucunu seç",
				"configureServer": "Motrix Server’ları yönet",
				"notConfigured": "Yapılandırılmadı",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "motor: {{state}}",
				"noDownloads": "İndirme yok",
				"pause": "Duraklat",
				"remove": "Kaldır",
				"resume": "Sürdür",
				"statsSummary": "Etkin: {{active}} · Bekleyen: {{waiting}}"
			},
			"dashboard": {
				"activity": "Etkinlik",
				"resources": "Kaynaklar",
				"showResources": "Bu sayfanın kaynaklarını göster",
				"showTasks": "Etkin görevleri göster",
				"title": "Aktarım özeti"
			},
			"loading": "Yükleniyor…",
			"quickSettings": {
				"fullSettings": "Tüm ayarlar",
				"fullSettingsDescription": "Genel, indirmeler, arka uç ve yardım",
				"loadError": "Hızlı ayarlar yüklenemedi.",
				"notificationsDescription": "Uzantının sistem bildirimlerini yönet",
				"retry": "Yeniden dene",
				"saveError": "Ayar kaydedilemedi. Tekrar deneyin.",
				"takeoverDescription": "Tarayıcı indirmelerini mevcut Motrix arka ucuna gönder"
			},
			"quickAdd": {
				"title": "Yeni görev",
				"description": "HTTP, HTTPS veya magnet bağlantısı yapıştırın.",
				"inputLabel": "İndirme adresi",
				"placeholder": "https://example.com/file.zip",
				"cancel": "İptal",
				"add": "Ekle",
				"submitting": "Ekleniyor…",
				"error": {
					"empty": "Bir indirme adresi girin.",
					"unsupported": "Yalnızca HTTP, HTTPS veya magnet bağlantıları desteklenir.",
					"invalid": "İndirme adresi geçersiz.",
					"submitFailed": "Görev eklenemedi. Tekrar deneyin."
				}
			},
			"reconnect": "Bağlan",
			"settings": "Ayarları aç",
			"sniffer": {
				"clearFilters": "Filtreleri temizle",
				"detected": "{{count}} öğe",
				"downloadCount": "{{count}} öğeyi indir",
				"downloadSelected": "Seçilenleri indir",
				"downloadedResource": "{{name}} gönderildi",
				"downloadingResource": "{{name}} indiriliyor",
				"emptyDescription": "Medyayı oynatıp tekrar deneyin.",
				"emptyFilter": "Eşleşen kaynak yok",
				"emptyTitle": "Medya bulunamadı",
				"filteredCount": "{{matched}} / {{total}} görsel",
				"filters": {
					"all": "Tümü",
					"audio": "Ses",
					"image": "Görseller",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "{{count}} etkin filtre",
					"dimensions": "Boyutlar ve dosya boyutu",
					"done": "Bitti",
					"fields": {
						"height": "Yükseklik",
						"size": "Boyut",
						"width": "Genişlik"
					},
					"formatOptionLabel": "{{format}} görsellerini filtrele",
					"formats": "Görsel biçimi",
					"operatorLabel": "{{label}} karşılaştırması",
					"reset": "Sıfırla",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Dosya boyutu birimi",
					"title": "Hızlı filtreler",
					"trigger": "Filtrele",
					"valueLabel": "{{label}} değeri"
				},
				"imageCount": "{{count}} görsel",
				"noImageMatches": "Eşleşen görsel yok",
				"pageAction": {
					"bilibili": "Bu bilibili videosunu gönder",
					"youtube": "Bu YouTube videosunu gönder"
				},
				"pageSubmitted": "Video Motrix’e gönderildi {{taskId}}",
				"pageResources": "Kaynaklar",
				"quickDownloadResource": "{{name}} hızlı indir",
				"connectToSubmit": "Kaynak göndermek için Motrix’e bağlanın.",
				"scan": "Yeniden tara",
				"scanning": "Taranıyor…",
				"selectAll": "Tümünü seç",
				"selected": "{{count}} seçildi",
				"selectResource": "{{name}} seç",
				"sourceHost": "Kaynak: {{host}}",
				"sendResource": "{{name}} öğesini Motrix’e gönder",
				"sent": "Gönderildi",
				"sending": "Gönderiliyor",
				"submitFailed": "Kaynak gönderilemedi. Tekrar deneyin.",
				"title": "Kaynak algılama",
				"unavailableDescription": "Sayfayı değiştirin veya sonra tekrar deneyin.",
				"unavailableTitle": "Bu sayfa taranamıyor",
				"unsupported": "ffmpeg gerekli",
				"unsupportedReason": "ffmpeg desteği olmadığından seçili arka uç {{kind}} kaynaklarını gönderemez.",
				"unsupportedSelectionReason": "Seçili arka uç, seçilen kaynak türlerinden birini veya birkaçını gönderemez.",
				"unsupportedResource": "{{name}} gönderilemiyor. {{reason}}"
			},
			"speed": {
				"download": "İndirme",
				"upload": "Yükleme"
			},
			"status": {
				"bootstrapping": "Motrix aranıyor…",
				"connected": "Bağlı",
				"connecting": "Bağlanıyor…",
				"denied": "Eşleştirme reddedildi",
				"disconnected": "Bağlı değil",
				"handshaking": "El sıkışma sürüyor",
				"awaiting-code": "Eşleştirme kodu bekleniyor…"
			},
			"tabs": {
				"settings": "Ayarlar",
				"sniffer": "Kaynaklar",
				"tasks": "Görevler"
			},
			"takeover": {
				"aria": "İndirmeleri devralmayı aç/kapat",
				"label": "Devralma"
			},
			"tasks": {
				"actions": "{{name}} işlemleri",
				"openFolder": "İçeren klasörü Motrix’te aç",
				"openFolderError": "Görev klasörü açılamadı. Tekrar deneyin.",
				"openFolderMetadataPending": "Klasörü açmadan önce görev meta verilerini bekleyin",
				"openFolderTask": "{{name}} öğesini içeren klasörü aç",
				"openFolderUnsupported": "Klasörleri açmak için Motrix’i güncelleyin",
				"pauseTask": "{{name}} duraklat",
				"removeTask": "{{name}} kaldır",
				"removeConfirmTitle": "Görev kaldırılsın mı?",
				"removeConfirmDescription": "“{{name}}” indirme listesinden kaldırılacak.",
				"removeDeleteFilesLabel": "İndirilen dosyaları sil",
				"removeConfirmAction": "Kaldır",
				"resumeTask": "{{name}} sürdür",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "Görevleri görmek için bağlanın.",
				"disconnectedTitle": "Motrix çevrimdışı",
				"empty": {
					"active": "Etkin görev yok",
					"failed": "Başarısız görev yok",
					"recent": "Biten görev yok"
				},
				"filters": {
					"active": "Etkin",
					"failed": "Başarısız",
					"recent": "Bitenler"
				},
				"loading": "Görevler yükleniyor",
				"status": {
					"completed": "Tamamlandı",
					"downloading": "İndiriliyor",
					"error": "Başarısız",
					"fetching_metadata": "Meta veriler alınıyor",
					"finalizing": "Sonlandırılıyor",
					"paused": "Duraklatıldı",
					"queued": "Sırada",
					"seeding": "Paylaşılıyor"
				},
				"title": "Görevler"
			},
			"pairing": {
				"attemptOf": "Deneme {{run}} / {{maxRuns}}",
				"attemptsRemaining": "{{attemptsRemaining}} deneme kaldı",
				"codeLabel": "Eşleştirme kodu",
				"codeDescription": "Motrix eşleştirme penceresindeki 8 karakterli kodu girin.",
				"codeInvalid": "Eşleştirme penceresindeki 8 karakterli kodu girin.",
				"dialogTitle": "Eşleştirme kodunu gir",
				"dismissPrompt": "Sonra gir ve gezinmeye devam et",
				"enterCode": "Eşleştirme kodunu gir",
				"expiresIn": "{{time}} sonra sona erer",
				"pairButton": "Eşleştir",
				"pickerHelp": "Birden fazla Motrix örneği bulundu. Eşleştirilecek olanı seçin.",
				"rescan": "Yeniden ara",
				"noCandidates": "Motrix örneği bulunamadı.",
				"candidatesLabel": "Bulunan Motrix örnekleri",
				"candidatePort": "Bağlantı noktası {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "bilinmeyen sürüm",
				"choose": "Seç",
				"backoffTitle": "Çok fazla eşleştirme denemesi",
				"backoffBody": "{{time}} zamanında tekrar deneyin.",
				"retryIn": "{{seconds}} sn sonra yeniden dene",
				"permissionMissingTitle": "İzin gerekli",
				"permissionMissingBody": "Bu bilgisayardaki Motrix’i bulmak için localhost erişimine izin verin.",
				"grantPermission": "İzin ver",
				"degradedTitle": "Motrix bağlı",
				"degradedBody": "Motrix’i normal şekilde kullanabilirsiniz. Bu bağlantı yalnızca temel doğrulamaya sahiptir. Daha güçlü koruma için Motrix’i güncelleyip yeniden eşleştirin.",
				"recoveryExhaustedTitle": "Otomatik olarak yeniden bağlanılamadı",
				"recoveryExhaustedBody": "Kayıtlı Motrix eşleştirmelerinin hiçbiri çalışmadı. Yeniden eşleştirmek için Bağlan’a basın."
			}
		},
		errors: { "connection": {
			"generic": "Bağlantı başarısız. Tekrar deneyin.",
			"backoffLocked": "Çok fazla eşleştirme denemesi. Daha sonra tekrar deneyin.",
			"staleAttempt": "Daha yeni bir bağlantı denemesi devraldı.",
			"aborted": "Eşleştirme iptal edildi.",
			"deadlineExceeded": "Deneme zaman aşımına uğradı. Tekrar deneyin.",
			"runsExhausted": "Çok fazla yanlış kod girildi. Yeni bir kod almak için eşleştirmeyi yeniden başlatın.",
			"invalidCode": "Kod beklenen biçimde değil. Motrix penceresini kontrol edin.",
			"missingNonce": "Motrix bir eşleştirme yuvası sunmadı. Motrix’in çalıştığından emin olup tekrar deneyin.",
			"unsupportedBrowser": "Bu tarayıcıda eşleştirme desteklenmiyor.",
			"ticketPreparationFailed": "Eşleştirme hazırlanamadı. Tekrar deneyin.",
			"protocolViolation": "Motrix beklenmeyen bir yanıt gönderdi. Tekrar deneyin.",
			"unsupportedVersion": "Bu uzantı ve Motrix farklı protokol sürümleri kullanıyor. İkisini de güncelleyip tekrar deneyin.",
			"backendUpgradeRequired": "Bu Motrix sürümü güvenli eşleştirme için çok eski. Motrix’i güncelleyip tekrar deneyin.",
			"extensionUpgradeRequired": "Bu uzantı sürümü bu Motrix için çok eski. Motrix uzantısını güncelleyip tekrar deneyin.",
			"unsupportedRemote": "Kimliği doğrulanan Motrix, bu bağlantı için seçilen App veya Server değil. Uç noktayı kontrol edip tekrar deneyin.",
			"remoteDiscoveryUnavailable": "Uzak Motrix Server’a ulaşılamadı. Adresi, dinleme hizmetini ve ağı kontrol edin; WSS için sertifikayı ve ters vekili de kontrol edin.",
			"remotePairingUnavailable": "Uzak Motrix Server güvenli bir eşleştirme oturumu açamadı. Biraz sonra tekrar deneyin.",
			"remoteTransportUnavailable": "Uzak Motrix Server bağlantısı başarısız. Adresi, dinleme hizmetini, DNS’i ve ağı kontrol edin; WSS için sertifikayı ve ters vekili de kontrol edin. Tarayıcı hangisinin başarısız olduğunu belirleyemez.",
			"peerRejected": "Motrix eşleştirmeyi reddetti.",
			"peerBusy": "Motrix çok fazla eşleştirme isteği işliyor. Biraz sonra tekrar deneyin.",
			"securityCheckFailed": "Bağlantı güvenlik kontrolünden geçemedi ve durduruldu.",
			"peerNotAuthentic": "Karşı taraf sizin Motrix’iniz olduğunu kanıtlayamadı. Bağlantı durduruldu.",
			"credentialPhaseFailed": "Eşleştirme kaydedilemedi. Yeniden eşleştirmeyi deneyin.",
			"internalError": "Uzantıda bir hata oluştu. Tekrar deneyin.",
			"authFailed": "Motrix bu eşleştirmeyi tanımadı. İptal edilmiş olabilir; yeniden eşleştirin.",
			"serverMacMismatch": "Yanıt doğrulanamadığı için bağlantı durduruldu. Sizin Motrix’iniz olmayabilir.",
			"channelClosed": "Bağlantı kapatıldı. Devam etmek için yeniden bağlanın.",
			"channelUnavailable": "Şu anda Motrix’e ulaşılamıyor. Çalıştığından emin olun."
		} }
	} },
	vi: { translation: {
		badge: { "tooltip": {
			"connected": "Motrix: đã kết nối",
			"disconnected": "Motrix: chưa kết nối",
			"connecting": "Motrix: đang kết nối…",
			"downloading": "Motrix: đang tải xuống",
			"denied": "Motrix: ghép đôi bị từ chối — mở để ghép đôi lại",
			"error": "Motrix: chuyển giao thất bại — nhấp để xem chi tiết"
		} },
		contextMenu: {
			"downloadWithMotrix": "Tải xuống bằng Motrix",
			"pairThenDownload": "Ghép đôi Motrix rồi tải xuống"
		},
		notify: {
			"browserFallbackBody": "Motrix không khả dụng. Trình duyệt sẽ tải xuống thay thế.",
			"browserFallbackTitle": "Đang tải bằng trình duyệt",
			"downloadComplete": "Tải xuống hoàn tất",
			"downloadFailed": "Tải xuống thất bại",
			"handedToMotrix": "Đã gửi tới Motrix",
			"notConnectedBody": "Ghép đôi Motrix để tiếp quản tải xuống.",
			"notConnectedTitle": "Motrix chưa kết nối",
			"notReachableBody": "Ghép đôi Motrix rồi thử tải xuống lại.",
			"notReachableTitle": "Không thể truy cập Motrix",
			"pairNudgeBody": "Mở Motrix để hoàn tất ghép đôi.",
			"pairNudgeTitle": "Ghép đôi Motrix",
			"pairRevokedBody": "Motrix đã thu hồi ghép đôi của trình duyệt này.",
			"pairRevokedTitle": "Đã thu hồi ghép đôi",
			"sensitiveSkippedBody": "Nội dung từ trang nhạy cảm được tải bằng trình duyệt.",
			"sensitiveSkippedTitle": "Đã bỏ qua",
			"submitFailedBody": "Đang tải lại bằng trình duyệt.",
			"submitFailedTitle": "Gửi tới Motrix thất bại"
		},
		options: {
			"diagnostics": {
				"adapters": "Bộ điều hợp",
				"extensionId": "ID tiện ích",
				"logLevel": "Mức ghi nhật ký",
				"logLevels": {
					"silent": "Không ghi",
					"error": "Lỗi",
					"warn": "Cảnh báo",
					"info": "Thông tin",
					"debug": "Gỡ lỗi"
				},
				"noneRegistered": "Chưa đăng ký bộ nào",
				"title": "Chẩn đoán",
				"version": "Phiên bản"
			},
			"endpoint": {
				"activate": "Sử dụng",
				"activateAria": "Sử dụng {{name}}",
				"connection": {
					"bootstrapping": "Đang khởi động",
					"connected": "Đã kết nối",
					"connecting": "Đang kết nối",
					"denied": "Bị từ chối",
					"disconnected": "Đã ngắt kết nối",
					"handshaking": "Đang cấp quyền",
					"awaiting-code": "Đang chờ mã"
				},
				"currentDescription": "Chọn một App hoặc Server cho lượt tải xuống, tác vụ và tài nguyên được phát hiện trên trang.",
				"currentTitle": "Dịch vụ Motrix",
				"listLabel": "Dịch vụ Motrix khả dụng",
				"localDescription": "Máy tính này, được tìm thấy qua Motrix App",
				"localName": "Motrix App",
				"selectLabel": "Gửi lượt tải xuống tới"
			},
			"language": {
				"label": "Ngôn ngữ",
				"system": "Theo hệ thống"
			},
			"notifications": {
				"title": "Thông báo hệ thống",
				"masterLabel": "Bật thông báo hệ thống",
				"masterAria": "Bật thông báo hệ thống",
				"confirmLabel": "Thành công / xác nhận",
				"confirmDesc": "Đã gửi tới Motrix, tải xuống hoàn tất",
				"errorLabel": "Thất bại / lỗi",
				"errorDesc": "Gửi thất bại, không thể truy cập, tải xuống thất bại",
				"reminderLabel": "Lời nhắc",
				"reminderDesc": "Yêu cầu ghép đôi, ghép đôi bị thu hồi, trang bị bỏ qua"
			},
			"pairing": {
				"backendTitle": "Đang ghép đôi {{name}}",
				"forget": "Quên ghép đôi",
				"loading": "Đang tải trạng thái ghép đôi…",
				"localHelp": "Nhấp Ghép đôi để tìm Motrix trên máy tính này rồi nhập mã ghép đôi.",
				"localTitle": "Ghép đôi qua Motrix App",
				"remoteTitle": "Ghép đôi với Motrix Server",
				"remoteHelp": "Nhấp Ghép đôi, xác nhận yêu cầu trong giao diện quản trị Server rồi nhập mã hiển thị vào đây. Hỗ trợ cả điểm cuối WS và WSS; nên dùng WSS.",
				"serverRequiredTitle": "Cần có Motrix Server",
				"serverRequiredHelp": "Firefox cho Android kết nối qua Motrix Server. Thêm Server ở trên rồi chọn để ghép đôi.",
				"remoteConsentTitle": "Tải xuống từ xa",
				"remoteConsentBody": "Tải xuống từ xa gửi URL đích, URL và tiêu đề trang nguồn, tên tệp, nội dung được chọn và lệnh điều khiển tác vụ tới Server này. Cookie và tiêu đề yêu cầu chỉ được gửi khi bật riêng.",
				"remoteConsentOffline": "Quyền dữ liệu gắn với Server đã xác thực. Hãy kết nối trước khi thay đổi.",
				"remoteHeadersLabel": "Gửi tiêu đề yêu cầu",
				"remoteHeadersHelp": "Cho phép các tiêu đề lấy từ trang như Referer và tiêu đề phát nội dung đa phương tiện. Tiêu đề xác thực vẫn cần quyền thông tin xác thực bên dưới.",
				"remoteCredentialsLabel": "Gửi cookie và thông tin xác thực",
				"remoteCredentialsHelp": "Chỉ cho phép cookie và tiêu đề chứa thông tin xác thực đối với Server này. Chỉ bật cho Server do bạn kiểm soát.",
				"notPaired": "Chưa ghép đôi",
				"paired": "Đã ghép đôi với Motrix",
				"pairedHelp": "Thông tin xác thực MBP1 đã xác nhận được lưu cho dịch vụ này. Trạng thái kết nối hiện tại được hiển thị riêng.",
				"pairedTitle": "Ghép đôi sẵn sàng",
				"reconnect": "Kết nối lại",
				"scopedHelp": "Độ tin cậy và thông tin xác thực ghép đôi được tách riêng cho từng dịch vụ. Chuyển dịch vụ không sử dụng lại độ tin cậy của dịch vụ khác.",
				"pair": "Ghép đôi",
				"pairDialogTitle": "Ghép đôi với Motrix"
			},
			"servers": {
				"add": "Thêm máy chủ",
				"addTitle": "Thêm Motrix Server",
				"current": "Hiện tại",
				"delete": "Xóa máy chủ",
				"deleteActiveDescription": "Xóa {{name}} cùng thông tin xác thực ghép đôi và chấp thuận được lưu cục bộ? Dịch vụ hiện tại sẽ chuyển về Motrix App nhưng không kết nối hay khởi chạy ứng dụng.",
				"deleteActiveServerOnlyDescription": "Xóa {{name}} cùng thông tin xác thực ghép đôi và chấp thuận được lưu cục bộ? Bạn cần thêm hoặc chọn Motrix Server khác trước khi tải xuống.",
				"deleteAria": "Xóa {{name}}",
				"deleteDescription": "Xóa {{name}} cùng thông tin xác thực ghép đôi và chấp thuận được lưu cục bộ? Thao tác này không thu hồi bất kỳ mục nào trên máy chủ.",
				"deleteTitle": "Xóa Motrix Server?",
				"description": "Lưu nhiều địa chỉ Motrix Server và chuyển đổi trong phần cài đặt hoặc cửa sổ bật lên.",
				"dialogDescription": "Đặt tên dễ nhận biết cho dịch vụ này và nhập URL cơ sở WebSocket.",
				"editAria": "Sửa {{name}}",
				"editTitle": "Sửa Motrix Server",
				"emptyDescription": "Thêm máy chủ để kết nối tới Motrix ngoài máy tính này.",
				"emptyTitle": "Chưa có Motrix Server",
				"footer": "Thay đổi địa chỉ máy chủ yêu cầu ghép đôi lại. Thông tin ghép đôi không bao giờ được chia sẻ giữa các địa chỉ.",
				"nameLabel": "Tên máy chủ",
				"namePlaceholder": "Máy chủ tại nhà",
				"nameRequired": "Cần nhập tên máy chủ",
				"save": "Lưu máy chủ",
				"statusAuthority": "Địa chỉ máy chủ: {{value}}",
				"statusRuntime": "Phiên bản Motrix: {{name}} {{version}}",
				"statusTitle": "Thông tin máy chủ",
				"statusTransportSecure": "Bảo mật kết nối: đang dùng WSS và TLS xác minh danh tính máy chủ",
				"statusTransportPlain": "Bảo mật kết nối: được mã hóa, nhưng WS không xác minh được danh tính máy chủ và có thể làm lộ thông tin kết nối. Nên dùng WSS",
				"title": "Máy chủ Motrix",
				"urlDescription": "Dùng URL cơ sở ws:// hoặc wss://. Đường dẫn tùy chọn được giữ nguyên làm tiền tố proxy ngược; nên dùng WSS.",
				"urlDuplicate": "Địa chỉ Motrix Server này đã được lưu",
				"urlInvalid": "Nhập URL cơ sở ws:// hoặc wss:// hợp lệ, không chứa khoảng trắng, thông tin xác thực, truy vấn hay đoạn định danh",
				"urlLabel": "URL WebSocket",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "Kết nối này không dùng WSS",
				"transportWarningBody": "Nội dung trao đổi với Motrix vẫn được mã hóa, nhưng WS không xác minh được danh tính máy chủ và có thể làm lộ thông tin kết nối. Hãy dùng WSS nếu NAS hỗ trợ.",
				"urlRequired": "Cần nhập URL WebSocket"
			},
			"takeover": {
				"consentBody": "Motrix nhận cookie đăng nhập của trang để tải tệp. Tải xuống từ trang nhạy cảm vẫn do trình duyệt xử lý.",
				"consentCancel": "Hủy",
				"consentConfirm": "Bật",
				"consentDialogLabel": "Gửi lượt tải xuống tới Motrix?",
				"denylistLabel": "Danh sách loại trừ (mỗi dòng một máy chủ — luôn để trình duyệt xử lý)",
				"enableAria": "Bật tiếp quản",
				"enableLabel": "Gửi các lượt tải xuống phù hợp tới Motrix",
				"loading": "Đang tải cài đặt tiếp quản…",
				"minSizeLabel": "Kích thước tối thiểu (MB)",
				"minSizePlaceholder": "0 = tất cả",
				"thresholdInvalid": "Kích thước tối thiểu phải là số không âm",
				"save": "Lưu",
				"saved": "Đã lưu",
				"title": "Tiếp quản tải xuống",
				"remoteUnavailable": "Tiếp quản tự động hiện yêu cầu Motrix App cục bộ. Tải xuống từ xa và quyền tiêu đề hoặc cookie không bật tính năng này. Bạn vẫn có thể gửi lượt tải xuống tới Server này theo cách thủ công hoặc qua menu chuột phải.",
				"availabilityUnknown": "Chưa thể tiếp quản cho đến khi kiểm tra được dịch vụ đã chọn.",
				"remoteUnavailableShort": "Chỉ App cục bộ. Gửi qua chuột phải vẫn dùng được với Server."
			},
			"tabs": {
				"general": "Chung",
				"download": "Tải xuống",
				"integration": "Tích hợp",
				"help": "Trợ giúp"
			},
			"common": {
				"apply": "Áp dụng",
				"cancel": "Hủy",
				"loadError": "Không thể tải cài đặt vì tiến trình nền của tiện ích không khởi động được. Hãy tải lại tiện ích và thử lại.",
				"saved": "Đã lưu",
				"saving": "Đang lưu…",
				"saveError": "Lưu thất bại"
			},
			"appearance": {
				"title": "Giao diện",
				"theme": {
					"label": "Chủ đề",
					"system": "Theo hệ thống",
					"light": "Sáng",
					"dark": "Tối"
				}
			},
			"help": {
				"title": "Trợ giúp và hỗ trợ",
				"description": "Xem hướng dẫn, hỗ trợ và chẩn đoán tiện ích.",
				"reportBug": "Báo cáo sự cố",
				"reportBugDescription": "Mở một issue trên GitHub hoặc gửi phản hồi.",
				"issues": "GitHub Issues",
				"docs": "Tài liệu",
				"docsDescription": "Đọc hướng dẫn thiết lập, ghép đôi, tiếp quản tải xuống và khắc phục sự cố.",
				"copyDiagnostics": "Sao chép chẩn đoán",
				"copied": "Đã sao chép",
				"diagnostics": "Chẩn đoán",
				"diagnosticsDescription": "Điều chỉnh nhật ký và sao chép thông tin hữu ích để khắc phục sự cố."
			},
			"about": {
				"subtitle": "Tải tệp từ web bằng Motrix",
				"website": "Trang web chính thức"
			},
			"title": "Cài đặt tiện ích Motrix"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "Máy tính này",
				"choose": "Chọn dịch vụ Motrix",
				"configureServer": "Quản lý Motrix Server",
				"notConfigured": "Chưa cấu hình",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "bộ máy: {{state}}",
				"noDownloads": "Không có lượt tải xuống",
				"pause": "Tạm dừng",
				"remove": "Gỡ bỏ",
				"resume": "Tiếp tục",
				"statsSummary": "Đang chạy: {{active}} · Đang chờ: {{waiting}}"
			},
			"dashboard": {
				"activity": "Hoạt động",
				"resources": "Tài nguyên",
				"showResources": "Hiện tài nguyên của trang này",
				"showTasks": "Hiện tác vụ đang chạy",
				"title": "Tổng quan truyền dữ liệu"
			},
			"loading": "Đang tải…",
			"quickSettings": {
				"fullSettings": "Tất cả cài đặt",
				"fullSettingsDescription": "Chung, tải xuống, dịch vụ và trợ giúp",
				"loadError": "Không thể tải cài đặt nhanh.",
				"notificationsDescription": "Quản lý thông báo hệ thống từ tiện ích",
				"retry": "Thử lại",
				"saveError": "Không lưu được cài đặt. Thử lại.",
				"takeoverDescription": "Gửi tải xuống từ trình duyệt tới dịch vụ Motrix hiện tại"
			},
			"quickAdd": {
				"title": "Tác vụ mới",
				"description": "Dán liên kết HTTP, HTTPS hoặc magnet.",
				"inputLabel": "Địa chỉ tải xuống",
				"placeholder": "https://example.com/file.zip",
				"cancel": "Hủy",
				"add": "Thêm",
				"submitting": "Đang thêm…",
				"error": {
					"empty": "Nhập địa chỉ tải xuống.",
					"unsupported": "Chỉ hỗ trợ liên kết HTTP, HTTPS hoặc magnet.",
					"invalid": "Địa chỉ tải xuống không hợp lệ.",
					"submitFailed": "Không thể thêm tác vụ. Hãy thử lại."
				}
			},
			"reconnect": "Kết nối",
			"settings": "Mở cài đặt",
			"sniffer": {
				"clearFilters": "Xóa bộ lọc",
				"detected": "{{count}} mục",
				"downloadCount": "Tải xuống {{count}} mục",
				"downloadSelected": "Tải mục đã chọn",
				"downloadedResource": "Đã gửi {{name}}",
				"downloadingResource": "Đang tải {{name}}",
				"emptyDescription": "Phát nội dung đa phương tiện rồi thử lại.",
				"emptyFilter": "Không có tài nguyên phù hợp",
				"emptyTitle": "Không thấy nội dung đa phương tiện",
				"filteredCount": "{{matched}} / {{total}} hình ảnh",
				"filters": {
					"all": "Tất cả",
					"audio": "Âm thanh",
					"image": "Ảnh",
					"video": "Video"
				},
				"imageFilters": {
					"activeCount": "{{count}} bộ lọc đang bật",
					"dimensions": "Kích thước và dung lượng",
					"done": "Xong",
					"fields": {
						"height": "Cao",
						"size": "Dung lượng",
						"width": "Rộng"
					},
					"formatOptionLabel": "Lọc ảnh {{format}}",
					"formats": "Định dạng ảnh",
					"operatorLabel": "So sánh {{label}}",
					"reset": "Đặt lại",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "Đơn vị dung lượng tệp",
					"title": "Bộ lọc nhanh",
					"trigger": "Lọc",
					"valueLabel": "Giá trị {{label}}"
				},
				"imageCount": "{{count}} hình ảnh",
				"noImageMatches": "Không có hình ảnh phù hợp",
				"pageAction": {
					"bilibili": "Gửi video bilibili này",
					"youtube": "Gửi video YouTube này"
				},
				"pageSubmitted": "Đã gửi video tới Motrix {{taskId}}",
				"pageResources": "Tài nguyên",
				"quickDownloadResource": "Tải nhanh {{name}}",
				"connectToSubmit": "Kết nối tới Motrix để gửi tài nguyên.",
				"scan": "Quét lại",
				"scanning": "Đang quét…",
				"selectAll": "Chọn tất cả",
				"selected": "Đã chọn {{count}} mục",
				"selectResource": "Chọn {{name}}",
				"sourceHost": "Nguồn: {{host}}",
				"sendResource": "Gửi {{name}} tới Motrix",
				"sent": "Đã gửi",
				"sending": "Đang gửi",
				"submitFailed": "Không thể gửi tài nguyên. Hãy thử lại.",
				"title": "Dò tài nguyên",
				"unavailableDescription": "Chuyển trang hoặc thử lại sau.",
				"unavailableTitle": "Không thể quét trang này",
				"unsupported": "Cần có ffmpeg",
				"unsupportedReason": "Dịch vụ đã chọn không thể gửi tài nguyên {{kind}} vì không có hỗ trợ ffmpeg.",
				"unsupportedSelectionReason": "Dịch vụ đã chọn không thể gửi một hoặc nhiều loại tài nguyên đã chọn.",
				"unsupportedResource": "Không thể gửi {{name}}. {{reason}}"
			},
			"speed": {
				"download": "Tải xuống",
				"upload": "Tải lên"
			},
			"status": {
				"bootstrapping": "Đang tìm Motrix…",
				"connected": "Đã kết nối",
				"connecting": "Đang kết nối…",
				"denied": "Ghép đôi bị từ chối",
				"disconnected": "Đã ngắt kết nối",
				"handshaking": "Đang bắt tay kết nối",
				"awaiting-code": "Đang chờ mã ghép đôi…"
			},
			"tabs": {
				"settings": "Cài đặt",
				"sniffer": "Tài nguyên",
				"tasks": "Tác vụ"
			},
			"takeover": {
				"aria": "Bật/tắt tiếp quản tải xuống",
				"label": "Tiếp quản"
			},
			"tasks": {
				"actions": "Thao tác cho {{name}}",
				"openFolder": "Mở thư mục chứa tệp trong Motrix",
				"openFolderError": "Không thể mở thư mục tác vụ. Hãy thử lại.",
				"openFolderMetadataPending": "Chờ siêu dữ liệu tác vụ trước khi mở thư mục",
				"openFolderTask": "Mở thư mục chứa {{name}}",
				"openFolderUnsupported": "Cập nhật Motrix để mở thư mục",
				"pauseTask": "Tạm dừng {{name}}",
				"removeTask": "Gỡ bỏ {{name}}",
				"removeConfirmTitle": "Gỡ bỏ tác vụ?",
				"removeConfirmDescription": "“{{name}}” sẽ bị gỡ khỏi danh sách tải xuống.",
				"removeDeleteFilesLabel": "Xóa các tệp đã tải xuống",
				"removeConfirmAction": "Gỡ bỏ",
				"resumeTask": "Tiếp tục {{name}}",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "Kết nối để xem tác vụ.",
				"disconnectedTitle": "Motrix đang ngoại tuyến",
				"empty": {
					"active": "Không có tác vụ đang chạy",
					"failed": "Không có tác vụ thất bại",
					"recent": "Không có tác vụ hoàn tất"
				},
				"filters": {
					"active": "Đang chạy",
					"failed": "Thất bại",
					"recent": "Hoàn tất"
				},
				"loading": "Đang tải tác vụ",
				"status": {
					"completed": "Hoàn tất",
					"downloading": "Đang tải xuống",
					"error": "Thất bại",
					"fetching_metadata": "Đang lấy siêu dữ liệu",
					"finalizing": "Đang hoàn tất",
					"paused": "Đã tạm dừng",
					"queued": "Trong hàng đợi",
					"seeding": "Đang chia sẻ"
				},
				"title": "Tác vụ"
			},
			"pairing": {
				"attemptOf": "Lần thử {{run}} / {{maxRuns}}",
				"attemptsRemaining": "Còn {{attemptsRemaining}} lần thử",
				"codeLabel": "Mã ghép đôi",
				"codeDescription": "Nhập mã 8 ký tự trong hộp thoại ghép đôi Motrix.",
				"codeInvalid": "Nhập mã 8 ký tự trong hộp thoại ghép đôi.",
				"dialogTitle": "Nhập mã ghép đôi",
				"dismissPrompt": "Nhập sau và duyệt web tiếp",
				"enterCode": "Nhập mã ghép đôi",
				"expiresIn": "Hết hạn sau {{time}}",
				"pairButton": "Ghép đôi",
				"pickerHelp": "Tìm thấy nhiều phiên bản Motrix đang chạy. Chọn một phiên bản để ghép đôi.",
				"rescan": "Tìm lại",
				"noCandidates": "Không tìm thấy phiên bản Motrix đang chạy.",
				"candidatesLabel": "Các phiên bản Motrix được phát hiện",
				"candidatePort": "Cổng {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "không rõ phiên bản",
				"choose": "Chọn",
				"backoffTitle": "Quá nhiều lần thử ghép đôi",
				"backoffBody": "Thử lại lúc {{time}}.",
				"retryIn": "Thử lại sau {{seconds}} giây",
				"permissionMissingTitle": "Cần cấp quyền",
				"permissionMissingBody": "Cho phép truy cập localhost để tìm Motrix trên máy tính này.",
				"grantPermission": "Cấp quyền",
				"degradedTitle": "Motrix đã kết nối",
				"degradedBody": "Bạn có thể dùng Motrix bình thường. Kết nối này chỉ có xác minh cơ bản. Để được bảo vệ tốt hơn, hãy cập nhật Motrix và ghép đôi lại.",
				"recoveryExhaustedTitle": "Không thể tự động kết nối lại",
				"recoveryExhaustedBody": "Không có ghép đôi Motrix đã lưu nào hoạt động. Nhấn Kết nối để ghép đôi lại."
			}
		},
		errors: { "connection": {
			"generic": "Kết nối thất bại. Hãy thử lại.",
			"backoffLocked": "Quá nhiều lần thử ghép đôi. Hãy thử lại sau.",
			"staleAttempt": "Một lần thử kết nối mới hơn đã thay thế lần này.",
			"aborted": "Đã hủy ghép đôi.",
			"deadlineExceeded": "Lần thử đã hết thời gian chờ. Hãy thử lại.",
			"runsExhausted": "Nhập sai mã quá nhiều lần. Bắt đầu ghép đôi lại để lấy mã mới.",
			"invalidCode": "Mã không đúng định dạng. Hãy kiểm tra hộp thoại Motrix.",
			"missingNonce": "Motrix không cung cấp phiên ghép đôi. Đảm bảo Motrix đang chạy rồi thử lại.",
			"unsupportedBrowser": "Trình duyệt này không hỗ trợ ghép đôi.",
			"ticketPreparationFailed": "Không thể chuẩn bị ghép đôi. Hãy thử lại.",
			"protocolViolation": "Motrix gửi phản hồi không mong đợi. Hãy thử lại.",
			"unsupportedVersion": "Tiện ích này và Motrix dùng phiên bản giao thức khác nhau. Hãy cập nhật cả hai rồi thử lại.",
			"backendUpgradeRequired": "Phiên bản Motrix này quá cũ để ghép đôi an toàn. Hãy cập nhật Motrix rồi thử lại.",
			"extensionUpgradeRequired": "Phiên bản tiện ích này quá cũ so với Motrix này. Hãy cập nhật tiện ích Motrix rồi thử lại.",
			"unsupportedRemote": "Motrix đã xác thực không phải App hoặc Server được chọn cho kết nối này. Kiểm tra điểm cuối rồi thử lại.",
			"remoteDiscoveryUnavailable": "Không thể truy cập Motrix Server từ xa. Kiểm tra địa chỉ, dịch vụ lắng nghe và mạng; với WSS, kiểm tra cả chứng chỉ và proxy ngược.",
			"remotePairingUnavailable": "Motrix Server từ xa không thể mở phiên ghép đôi an toàn. Hãy thử lại sau ít phút.",
			"remoteTransportUnavailable": "Kết nối Motrix Server từ xa thất bại. Kiểm tra địa chỉ, dịch vụ lắng nghe, DNS và mạng; với WSS, kiểm tra cả chứng chỉ và proxy ngược. Trình duyệt không xác định được thành phần nào gặp lỗi.",
			"peerRejected": "Motrix đã từ chối ghép đôi.",
			"peerBusy": "Motrix đang xử lý quá nhiều yêu cầu ghép đôi. Hãy thử lại sau ít phút.",
			"securityCheckFailed": "Kết nối không vượt qua kiểm tra bảo mật và đã bị dừng.",
			"peerNotAuthentic": "Đầu bên kia không chứng minh được đó là Motrix của bạn. Kết nối đã bị dừng.",
			"credentialPhaseFailed": "Không thể lưu ghép đôi. Hãy thử ghép đôi lại.",
			"internalError": "Tiện ích gặp lỗi. Hãy thử lại.",
			"authFailed": "Motrix không nhận ra ghép đôi này. Có thể nó đã bị thu hồi — hãy ghép đôi lại.",
			"serverMacMismatch": "Phản hồi không vượt qua xác minh nên kết nối đã bị dừng. Đó có thể không phải Motrix của bạn.",
			"channelClosed": "Kết nối đã đóng. Kết nối lại để tiếp tục.",
			"channelUnavailable": "Hiện không thể truy cập Motrix. Đảm bảo ứng dụng đang chạy."
		} }
	} },
	"zh-TW": { translation: {
		badge: { "tooltip": {
			"connected": "Motrix：已連線",
			"disconnected": "Motrix：未連線",
			"connecting": "Motrix：連線中…",
			"downloading": "Motrix：下載中",
			"denied": "Motrix：配對遭拒，請開啟並重新配對",
			"error": "Motrix：交接失敗，點選以查看詳情"
		} },
		contextMenu: {
			"downloadWithMotrix": "使用 Motrix 下載",
			"pairThenDownload": "配對 Motrix 後下載"
		},
		notify: {
			"browserFallbackBody": "Motrix 無法使用，將改由瀏覽器下載。",
			"browserFallbackTitle": "正在使用瀏覽器下載",
			"downloadComplete": "下載完成",
			"downloadFailed": "下載失敗",
			"handedToMotrix": "已傳送至 Motrix",
			"notConnectedBody": "配對 Motrix 以接管下載。",
			"notConnectedTitle": "Motrix 尚未連線",
			"notReachableBody": "請先配對 Motrix，再重試下載。",
			"notReachableTitle": "無法連線至 Motrix",
			"pairNudgeBody": "請開啟 Motrix 以完成配對。",
			"pairNudgeTitle": "配對 Motrix",
			"pairRevokedBody": "Motrix 已撤銷此瀏覽器的配對。",
			"pairRevokedTitle": "配對已撤銷",
			"sensitiveSkippedBody": "敏感網站的下載交由瀏覽器處理。",
			"sensitiveSkippedTitle": "已略過",
			"submitFailedBody": "正在使用瀏覽器重新下載。",
			"submitFailedTitle": "傳送至 Motrix 失敗"
		},
		options: {
			"diagnostics": {
				"adapters": "介接器",
				"extensionId": "擴充功能 ID",
				"logLevel": "記錄層級",
				"logLevels": {
					"silent": "不記錄",
					"error": "錯誤",
					"warn": "警告",
					"info": "資訊",
					"debug": "偵錯"
				},
				"noneRegistered": "尚未註冊任何介接器",
				"title": "診斷",
				"version": "版本"
			},
			"endpoint": {
				"activate": "使用",
				"activateAria": "使用 {{name}}",
				"connection": {
					"bootstrapping": "啟動中",
					"connected": "已連線",
					"connecting": "連線中",
					"denied": "已拒絕",
					"disconnected": "未連線",
					"handshaking": "授權中",
					"awaiting-code": "等待驗證碼"
				},
				"currentDescription": "選擇用於下載、任務與網頁資源偵測的 App 或 Server。",
				"currentTitle": "Motrix 後端",
				"listLabel": "可用 Motrix 後端",
				"localDescription": "透過 Motrix App 偵測到的這台電腦",
				"localName": "Motrix App",
				"selectLabel": "下載傳送至"
			},
			"language": {
				"label": "語言",
				"system": "跟隨系統"
			},
			"notifications": {
				"title": "系統通知",
				"masterLabel": "啟用系統通知",
				"masterAria": "啟用系統通知",
				"confirmLabel": "成功／確認",
				"confirmDesc": "已傳送至 Motrix、下載完成",
				"errorLabel": "失敗／錯誤",
				"errorDesc": "傳送失敗、無法連線、下載失敗",
				"reminderLabel": "提醒",
				"reminderDesc": "配對提示、配對撤銷、略過網站"
			},
			"pairing": {
				"backendTitle": "正在配對 {{name}}",
				"forget": "忘記配對",
				"loading": "載入配對狀態…",
				"localHelp": "點選「配對」以尋找這台電腦上的 Motrix，並輸入配對碼。",
				"localTitle": "透過 Motrix App 配對",
				"remoteTitle": "與 Motrix Server 配對",
				"remoteHelp": "點選「配對」，在 Server 管理介面中確認要求，再於此處輸入顯示的配對碼。支援 WS 與 WSS 端點，建議使用 WSS。",
				"serverRequiredTitle": "需要 Motrix Server",
				"serverRequiredHelp": "Android 版 Firefox 透過 Motrix Server 連線。請先在上方新增 Server，再選取以進行配對。",
				"remoteConsentTitle": "遠端下載",
				"remoteConsentBody": "遠端下載會將目標網址、來源頁面網址與標題、檔案名稱、選取內容及任務控制指令傳送至此 Server。Cookie 與請求標頭須另行啟用才會傳送。",
				"remoteConsentOffline": "資料權限綁定於已驗證的 Server。請先連線再變更權限。",
				"remoteHeadersLabel": "傳送請求標頭",
				"remoteHeadersHelp": "允許傳送來自網頁的標頭，例如 Referer 和媒體播放標頭。驗證標頭仍需下方的憑證權限。",
				"remoteCredentialsLabel": "傳送 Cookie 與驗證資訊",
				"remoteCredentialsHelp": "僅允許向此 Server 傳送 Cookie 與憑證標頭。請只對您自行管理的 Server 啟用。",
				"notPaired": "尚未配對",
				"paired": "已與 Motrix 配對",
				"pairedHelp": "此後端已儲存確認完成的 MBP1 憑證。目前的連線狀態另行顯示。",
				"pairedTitle": "配對已就緒",
				"reconnect": "重新連線",
				"scopedHelp": "各後端的配對信任與憑證彼此獨立。切換後端不會沿用其他後端的信任。",
				"pair": "配對",
				"pairDialogTitle": "與 Motrix 配對"
			},
			"servers": {
				"add": "新增伺服器",
				"addTitle": "新增 Motrix Server",
				"current": "目前使用",
				"delete": "刪除伺服器",
				"deleteActiveDescription": "要刪除 {{name}} 及其儲存在本機的配對憑證與同意設定嗎？目前後端將切回 Motrix App，但不會連線或啟動它。",
				"deleteActiveServerOnlyDescription": "要刪除 {{name}} 及其儲存在本機的配對憑證與同意設定嗎？下載前，您需要新增或選取另一個 Motrix Server。",
				"deleteAria": "刪除 {{name}}",
				"deleteDescription": "要刪除 {{name}} 及其儲存在本機的配對憑證與同意設定嗎？這不會撤銷伺服器端的任何資料或權限。",
				"deleteTitle": "要刪除 Motrix Server 嗎？",
				"description": "儲存多個 Motrix Server 位址，並從設定或彈出視窗切換。",
				"dialogDescription": "為此後端取一個容易辨識的名稱，並輸入其 WebSocket 基底網址。",
				"editAria": "編輯 {{name}}",
				"editTitle": "編輯 Motrix Server",
				"emptyDescription": "新增伺服器以連線至其他電腦上的 Motrix。",
				"emptyTitle": "尚無 Motrix Server",
				"footer": "變更伺服器位址後需要重新配對。配對資訊不會在不同位址間共用。",
				"nameLabel": "伺服器名稱",
				"namePlaceholder": "家用伺服器",
				"nameRequired": "請輸入伺服器名稱",
				"save": "儲存伺服器",
				"statusAuthority": "伺服器位址：{{value}}",
				"statusRuntime": "Motrix 版本：{{name}} {{version}}",
				"statusTitle": "伺服器資訊",
				"statusTransportSecure": "連線安全性：使用 WSS，並透過 TLS 驗證伺服器身分",
				"statusTransportPlain": "連線安全性：已加密，但 WS 無法驗證伺服器身分，且可能暴露連線資訊。建議使用 WSS",
				"title": "Motrix 伺服器",
				"urlDescription": "請使用 ws:// 或 wss:// 基底網址。選填的路徑會原樣保留為反向代理前綴；建議使用 WSS。",
				"urlDuplicate": "此 Motrix Server 位址已儲存",
				"urlInvalid": "請輸入有效的 ws:// 或 wss:// 基底網址，不可包含空白、憑證、查詢參數或片段識別碼",
				"urlLabel": "WebSocket 網址",
				"urlPlaceholder": "ws(s)://host[:port][/base-path]",
				"transportWarningTitle": "此連線未使用 WSS",
				"transportWarningBody": "與 Motrix 交換的內容仍會加密，但 WS 無法驗證伺服器身分，且可能暴露連線資訊。如果 NAS 支援，請使用 WSS。",
				"urlRequired": "請輸入 WebSocket 網址"
			},
			"takeover": {
				"consentBody": "Motrix 會接收網站的登入 Cookie 以下載檔案。敏感網站的下載仍由瀏覽器處理。",
				"consentCancel": "取消",
				"consentConfirm": "啟用",
				"consentDialogLabel": "要將下載傳送至 Motrix 嗎？",
				"denylistLabel": "排除清單（每行一個主機名稱，一律交由瀏覽器處理）",
				"enableAria": "啟用下載接管",
				"enableLabel": "將符合條件的下載傳送至 Motrix",
				"loading": "載入接管設定…",
				"minSizeLabel": "最小大小（MB）",
				"minSizePlaceholder": "0 = 全部",
				"thresholdInvalid": "最小大小必須為非負數",
				"save": "儲存",
				"saved": "已儲存",
				"title": "下載接管",
				"remoteUnavailable": "自動接管目前需要本機 Motrix App。遠端下載及標頭或 Cookie 權限不會啟用自動接管。您仍可手動或透過右鍵選單將下載傳送至此 Server。",
				"availabilityUnknown": "在能夠檢查所選後端之前，無法使用接管功能。",
				"remoteUnavailableShort": "僅限本機 App。Server 可使用右鍵傳送。"
			},
			"tabs": {
				"general": "一般",
				"download": "下載",
				"integration": "整合",
				"help": "說明"
			},
			"common": {
				"apply": "套用",
				"cancel": "取消",
				"loadError": "擴充功能的背景程序未能啟動，因此無法載入設定。請重新載入擴充功能後重試。",
				"saved": "已儲存",
				"saving": "正在儲存…",
				"saveError": "儲存失敗"
			},
			"appearance": {
				"title": "外觀",
				"theme": {
					"label": "佈景主題",
					"system": "跟隨系統",
					"light": "淺色",
					"dark": "深色"
				}
			},
			"help": {
				"title": "說明與支援",
				"description": "瀏覽指南、取得支援、查看擴充功能診斷資訊。",
				"reportBug": "回報問題",
				"reportBugDescription": "在 GitHub 建立議題或提供意見回饋。",
				"issues": "GitHub Issues",
				"docs": "使用文件",
				"docsDescription": "閱讀設定、配對、下載接管與疑難排解指南。",
				"copyDiagnostics": "複製診斷資訊",
				"copied": "已複製",
				"diagnostics": "診斷",
				"diagnosticsDescription": "調整記錄設定，並複製有助於疑難排解的資訊。"
			},
			"about": {
				"subtitle": "使用 Motrix 下載網頁中的檔案",
				"website": "官方網站"
			},
			"title": "Motrix 擴充功能設定"
		},
		popup: {
			"backend": {
				"app": "Motrix App",
				"appDescription": "這台電腦",
				"choose": "選擇 Motrix 後端",
				"configureServer": "管理 Motrix Server",
				"notConfigured": "尚未設定",
				"server": "Motrix Server",
				"version": "v{{version}}"
			},
			"controlPanel": {
				"engineState": "引擎：{{state}}",
				"noDownloads": "沒有下載項目",
				"pause": "暫停",
				"remove": "移除",
				"resume": "繼續",
				"statsSummary": "進行中 {{active}} · 等待中 {{waiting}}"
			},
			"dashboard": {
				"activity": "動態",
				"resources": "資源",
				"showResources": "顯示此頁面的資源",
				"showTasks": "顯示進行中的任務",
				"title": "傳輸概覽"
			},
			"loading": "載入中…",
			"quickSettings": {
				"fullSettings": "完整設定",
				"fullSettingsDescription": "一般、下載、後端與說明",
				"loadError": "無法載入快速設定。",
				"notificationsDescription": "控制擴充功能的系統通知",
				"retry": "重試",
				"saveError": "設定儲存失敗，請重試。",
				"takeoverDescription": "將瀏覽器下載傳送至目前的 Motrix 後端"
			},
			"quickAdd": {
				"title": "新增任務",
				"description": "貼上 HTTP、HTTPS 或磁力連結。",
				"inputLabel": "下載網址",
				"placeholder": "https://example.com/file.zip",
				"cancel": "取消",
				"add": "新增",
				"submitting": "正在新增…",
				"error": {
					"empty": "請輸入下載網址。",
					"unsupported": "僅支援 HTTP、HTTPS 或磁力連結。",
					"invalid": "下載網址無效。",
					"submitFailed": "無法新增任務，請重試。"
				}
			},
			"reconnect": "連線",
			"settings": "開啟設定",
			"sniffer": {
				"clearFilters": "清除篩選條件",
				"detected": "{{count}} 個項目",
				"downloadCount": "下載 {{count}} 個項目",
				"downloadSelected": "下載所選項目",
				"downloadedResource": "已傳送 {{name}}",
				"downloadingResource": "正在下載 {{name}}",
				"emptyDescription": "播放媒體後重試。",
				"emptyFilter": "無符合條件的資源",
				"emptyTitle": "找不到媒體",
				"filteredCount": "{{matched}} / {{total}} 張圖片",
				"filters": {
					"all": "全部",
					"audio": "音訊",
					"image": "圖片",
					"video": "影片"
				},
				"imageFilters": {
					"activeCount": "已啟用 {{count}} 個篩選條件",
					"dimensions": "尺寸與大小",
					"done": "完成",
					"fields": {
						"height": "高度",
						"size": "大小",
						"width": "寬度"
					},
					"formatOptionLabel": "篩選 {{format}} 圖片",
					"formats": "圖片格式",
					"operatorLabel": "{{label}}比較條件",
					"reset": "重設",
					"result": "{{matched}} / {{total}}",
					"sizeUnitLabel": "檔案大小單位",
					"title": "快速篩選",
					"trigger": "篩選",
					"valueLabel": "{{label}}數值"
				},
				"imageCount": "{{count}} 張圖片",
				"noImageMatches": "沒有符合條件的圖片",
				"pageAction": {
					"bilibili": "傳送此 bilibili 影片",
					"youtube": "傳送此 YouTube 影片"
				},
				"pageSubmitted": "影片已傳送至 Motrix {{taskId}}",
				"pageResources": "網頁資源",
				"quickDownloadResource": "快速下載 {{name}}",
				"connectToSubmit": "連線至 Motrix 以傳送資源。",
				"scan": "重新掃描",
				"scanning": "正在掃描…",
				"selectAll": "全選",
				"selected": "已選取 {{count}} 個項目",
				"selectResource": "選取 {{name}}",
				"sourceHost": "來源：{{host}}",
				"sendResource": "將 {{name}} 傳送至 Motrix",
				"sent": "已傳送",
				"sending": "傳送中",
				"submitFailed": "無法傳送資源，請重試。",
				"title": "資源偵測",
				"unavailableDescription": "請切換頁面或稍後再試。",
				"unavailableTitle": "無法掃描此頁面",
				"unsupported": "需要 ffmpeg",
				"unsupportedReason": "所選後端不支援 ffmpeg，無法傳送 {{kind}} 資源。",
				"unsupportedSelectionReason": "所選後端無法傳送一或多種已選取的資源類型。",
				"unsupportedResource": "無法傳送 {{name}}。{{reason}}"
			},
			"speed": {
				"download": "下載",
				"upload": "上傳"
			},
			"status": {
				"bootstrapping": "正在尋找 Motrix…",
				"connected": "已連線",
				"connecting": "連線中…",
				"denied": "配對遭拒",
				"disconnected": "未連線",
				"handshaking": "交握中",
				"awaiting-code": "正在等待配對碼…"
			},
			"tabs": {
				"settings": "設定",
				"sniffer": "資源",
				"tasks": "任務"
			},
			"takeover": {
				"aria": "切換下載接管",
				"label": "接管"
			},
			"tasks": {
				"actions": "{{name}} 的操作",
				"openFolder": "在 Motrix 開啟所在資料夾",
				"openFolderError": "無法開啟任務資料夾，請重試。",
				"openFolderMetadataPending": "取得任務中繼資料後再開啟資料夾",
				"openFolderTask": "開啟 {{name}} 所在的資料夾",
				"openFolderUnsupported": "請更新 Motrix 以開啟資料夾",
				"pauseTask": "暫停 {{name}}",
				"removeTask": "移除 {{name}}",
				"removeConfirmTitle": "要移除任務嗎？",
				"removeConfirmDescription": "「{{name}}」將從下載清單中移除。",
				"removeDeleteFilesLabel": "刪除已下載的檔案",
				"removeConfirmAction": "移除",
				"resumeTask": "繼續 {{name}}",
				"bytes": "{{done}} / {{total}}",
				"disconnectedDescription": "連線後即可查看任務。",
				"disconnectedTitle": "Motrix 已離線",
				"empty": {
					"active": "無進行中的任務",
					"failed": "無失敗任務",
					"recent": "無已完成任務"
				},
				"filters": {
					"active": "進行中",
					"failed": "失敗",
					"recent": "已完成"
				},
				"loading": "正在載入任務",
				"status": {
					"completed": "已完成",
					"downloading": "下載中",
					"error": "失敗",
					"fetching_metadata": "正在取得中繼資料",
					"finalizing": "正在完成處理",
					"paused": "已暫停",
					"queued": "排隊中",
					"seeding": "做種中"
				},
				"title": "任務"
			},
			"pairing": {
				"attemptOf": "第 {{run}} / {{maxRuns}} 次嘗試",
				"attemptsRemaining": "還可嘗試 {{attemptsRemaining}} 次",
				"codeLabel": "配對碼",
				"codeDescription": "輸入 Motrix 配對對話方塊中的 8 字元配對碼。",
				"codeInvalid": "輸入配對對話方塊中的 8 字元配對碼。",
				"dialogTitle": "輸入配對碼",
				"dismissPrompt": "稍後輸入，繼續瀏覽",
				"enterCode": "輸入配對碼",
				"expiresIn": "將於 {{time}} 後到期",
				"pairButton": "配對",
				"pickerHelp": "找到多個 Motrix 執行個體，請選擇要配對的項目。",
				"rescan": "重新搜尋",
				"noCandidates": "找不到 Motrix 執行個體。",
				"candidatesLabel": "偵測到的 Motrix 執行個體",
				"candidatePort": "連接埠 {{port}}",
				"candidateDetail": "{{instanceId}} · v{{appVersion}}",
				"unknownVersion": "未知版本",
				"choose": "選擇",
				"backoffTitle": "配對嘗試次數過多",
				"backoffBody": "請於 {{time}} 再試。",
				"retryIn": "{{seconds}} 秒後重試",
				"permissionMissingTitle": "需要權限",
				"permissionMissingBody": "請允許存取 localhost，以尋找這台電腦上的 Motrix。",
				"grantPermission": "授予權限",
				"degradedTitle": "Motrix 已連線",
				"degradedBody": "您可以正常使用 Motrix。此連線僅通過基本驗證。如需更完善的保護，請更新 Motrix 並重新配對。",
				"recoveryExhaustedTitle": "無法自動重新連線",
				"recoveryExhaustedBody": "已儲存的 Motrix 配對皆無法使用。請按「連線」以重新配對。"
			}
		},
		errors: { "connection": {
			"generic": "連線失敗，請重試。",
			"backoffLocked": "配對嘗試次數過多，請稍後再試。",
			"staleAttempt": "已由較新的連線嘗試接手。",
			"aborted": "配對已取消。",
			"deadlineExceeded": "嘗試逾時，請重試。",
			"runsExhausted": "輸入錯誤配對碼的次數過多，請重新配對以取得新配對碼。",
			"invalidCode": "配對碼格式不符，請查看 Motrix 對話方塊。",
			"missingNonce": "Motrix 未提供配對名額。請確認 Motrix 正在執行後重試。",
			"unsupportedBrowser": "此瀏覽器不支援配對。",
			"ticketPreparationFailed": "無法準備配對，請重試。",
			"protocolViolation": "Motrix 傳回非預期的回應，請重試。",
			"unsupportedVersion": "此擴充功能與 Motrix 使用不同的通訊協定版本。請更新兩者後重試。",
			"backendUpgradeRequired": "此 Motrix 版本過舊，無法安全配對。請更新 Motrix 後重試。",
			"extensionUpgradeRequired": "此擴充功能版本過舊，無法搭配目前的 Motrix。請更新 Motrix 擴充功能後重試。",
			"unsupportedRemote": "通過驗證的 Motrix 並非此次連線所選的 App 或 Server。請檢查端點後重試。",
			"remoteDiscoveryUnavailable": "無法連線至遠端 Motrix Server。請檢查位址、監聽服務與網路；使用 WSS 時，也請檢查憑證與反向代理。",
			"remotePairingUnavailable": "遠端 Motrix Server 無法建立安全的配對工作階段，請稍後再試。",
			"remoteTransportUnavailable": "遠端 Motrix Server 連線失敗。請檢查位址、監聽服務、DNS 與網路；使用 WSS 時，也請檢查憑證與反向代理。瀏覽器無法判斷是哪個環節失敗。",
			"peerRejected": "Motrix 拒絕了配對。",
			"peerBusy": "Motrix 正在處理過多配對要求，請稍後再試。",
			"securityCheckFailed": "連線未通過安全檢查，已停止。",
			"peerNotAuthentic": "對方無法證明是您的 Motrix，連線已停止。",
			"credentialPhaseFailed": "無法儲存配對，請重新配對。",
			"internalError": "擴充功能發生錯誤，請重試。",
			"authFailed": "Motrix 無法辨識此配對，可能已遭撤銷。請重新配對。",
			"serverMacMismatch": "回應未通過驗證，連線已停止。對方可能不是您的 Motrix。",
			"channelClosed": "連線已關閉，請重新連線以繼續。",
			"channelUnavailable": "目前無法連線至 Motrix，請確認它正在執行。"
		} }
	} }
};
function resolveDefaultLocale() {
	return resolveLocale(extensionBrowser.i18n.getUILanguage());
}
instance.use(initReactI18next).init({
	resources,
	lng: resolveDefaultLocale(),
	fallbackLng: "en-US",
	interpolation: { escapeValue: false }
});
/** Apply the stored override (or browser default). Call once per runtime on load. */
async function initI18n() {
	const target = await getLocaleOverride() ?? resolveDefaultLocale();
	if (instance.language !== target) await instance.changeLanguage(target);
}
//#endregion
//#region src/background/mbp1/pairing-code.ts
/**
* MBP1 pairing-code format and local normalization (bridge-pairing-protocol.md
* §7.1). The code is the PAKE password: it MUST never travel over any
* network channel and MUST never be logged (§7.1, §11). Everything in this
* module runs before any network traffic, so a string that fails validation
* here never consumes an attempt.
*/
/** Crockford base32 (32 symbols; excludes I, L, O, U). */
var CROCKFORD_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
/** Visually confusable letters folded onto their Crockford digit lookalikes. */
var CONFUSABLE_MAP = /* @__PURE__ */ new Map([
	["O", "0"],
	["I", "1"],
	["L", "1"]
]);
/**
* Normalize user-entered pairing-code text: strip ASCII hyphens and spaces,
* uppercase, map O→0/I→1/L→1, then require exactly 8 Crockford symbols.
* Returns `null` (never throws) on any validation failure.
*/
/**
* Entry-time cleanup for code inputs (§7.1): drops separators, whitespace,
* and clipboard noise so a display-form paste (`XXXX-XXXX`) fills an input
* cleanly. Deliberately NOT the full normalization — confusable folding
* (O→0, I→1, L→1) and casing stay out so pasted and typed characters render
* identically before submit; `normalizePairingCode` below owns the rest.
*/
function sanitizePairingCodeInput(raw) {
	return raw.replace(/[^0-9a-zA-Z]/g, "");
}
function normalizePairingCode(input) {
	const upper = input.replace(/[- ]/g, "").toUpperCase();
	let mapped = "";
	for (const char of upper) mapped += CONFUSABLE_MAP.get(char) ?? char;
	if (mapped.length !== 8) return null;
	for (const char of mapped) if (!CROCKFORD_ALPHABET.includes(char)) return null;
	return mapped;
}
//#endregion
//#region src/shared/platformCapabilities.ts
/**
* Native Messaging is available in desktop Firefox and Chromium browsers,
* but Firefox for Android intentionally omits the API. Remote Motrix Server
* connections do not depend on it and remain supported on Android.
*/
function hasNativeMessagingSupport() {
	return typeof extensionBrowser.runtime?.connectNative === "function";
}
//#endregion
export { MessageBus as $, magnetDisplayName as A, backendAuthorityKey as B, unknown as C, hostOf as D, TAKEOVER_DEFAULT as E, resolveActiveEndpoint as F, b64uDecode as G, normalizeRemoteEndpoint as H, resolveEndpointById as I, enc as J, b64uEncode as K, createOperationQueue as L, EndpointConfigStore as M, LOCAL_ENDPOINT_ID as N, hostSuffixMatch as O, STORAGE_KEY as P, utf8 as Q, LOCAL_BACKEND_AUTHORITY as R, string as S, QUALITY_SENTINEL as T, parseRemoteEndpoint as U, createRemoteBackendAuthority as V, assertAscii as W, encU64BE as X, encU32BE as Y, timingSafeEqualBytes as Z, number as _, resolveDefaultLocale as a, instance as at, record as b, setLocaleOverride as c, _enum as d, send as et, array as f, literal as g, httpUrl as h, initI18n as i, getDefaults as it, supportsAutomaticTakeover as j, isMagnetUrl as k, LOCALE_NAMES as l, discriminatedUnion as m, normalizePairingCode as n, isErrorResponse as nt, LOCALE_KEY as o, __commonJSMin as ot, boolean as p, concatBytes as q, sanitizePairingCodeInput as r, getI18n as rt, getLocaleOverride as s, __toESM as st, hasNativeMessagingSupport as t, MEDIA_SUBMIT_ERROR as tt, SUPPORTED_LOCALES as u, object as v, MIB as w, strictObject as x, preprocess as y, assertBackendAuthority as z };

//# sourceMappingURL=platformCapabilities-BhYiGJPy.js.map