import { a as mediaCategory, l as shouldExcludeHost, r as inferMediaMimeType, t as classifyMediaUrl, u as isWebStoreBuild } from "./media-oiN-I4sB.js";
//#region src/content/mediaBodySniffer.ts
/**
* Body inspection is deliberately small and bounded. A content script must not
* turn a large streaming response into an in-memory copy just to discover a
* manifest URL.
*/
var MEDIA_BODY_LIMITS = {
	maxBytes: 262144,
	maxChunks: 64,
	maxJsonDepth: 6,
	maxJsonNodes: 2e3,
	maxCandidates: 100,
	maxStringLength: 32768
};
function bareContentType(contentType) {
	return contentType?.split(";", 1)[0]?.trim().toLowerCase() ?? "";
}
function resolveHttpUrl(value, baseUrl) {
	const trimmed = value.trim();
	if (!trimmed || trimmed.length > MEDIA_BODY_LIMITS.maxStringLength) return null;
	try {
		const parsed = new URL(trimmed, baseUrl);
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
		parsed.hash = "";
		return parsed.toString();
	} catch {
		return null;
	}
}
function playlistUrls(body, baseUrl) {
	const urls = [];
	let expectsVariantUri = false;
	for (const rawLine of body.split(/\r?\n/)) {
		if (urls.length >= MEDIA_BODY_LIMITS.maxCandidates) break;
		const line = rawLine.trim();
		if (!line) continue;
		if (line.startsWith("#")) {
			if (/^#EXT-X-STREAM-INF(?::|$)/i.test(line)) expectsVariantUri = true;
			if (/^#EXT-X-(?:MEDIA|I-FRAME-STREAM-INF)(?::|$)/i.test(line)) {
				const uri = /(?:^|,)URI=(?:"([^"]+)"|([^,]+))/i.exec(line);
				const url = resolveHttpUrl(uri?.[1] ?? uri?.[2] ?? "", baseUrl);
				if (url) urls.push({
					url,
					forceHls: true
				});
			}
			continue;
		}
		const url = resolveHttpUrl(line, baseUrl);
		const forceHls = expectsVariantUri;
		expectsVariantUri = false;
		if (!url) continue;
		const kind = classifyMediaUrl(url);
		if (forceHls || kind === "hls") urls.push({
			url,
			forceHls: true
		});
		else if (kind === "dash") urls.push({
			url,
			forceHls: false
		});
	}
	return urls;
}
function jsonMediaUrls(value, baseUrl) {
	const urls = [];
	const seen = /* @__PURE__ */ new Set();
	let visitedNodes = 0;
	const visit = (node, depth) => {
		if (depth > MEDIA_BODY_LIMITS.maxJsonDepth || visitedNodes >= MEDIA_BODY_LIMITS.maxJsonNodes || urls.length >= MEDIA_BODY_LIMITS.maxCandidates) return;
		visitedNodes += 1;
		if (typeof node === "string") {
			const url = resolveHttpUrl(node, baseUrl);
			if (!url || seen.has(url) || classifyMediaUrl(url) === null) return;
			seen.add(url);
			urls.push(url);
			return;
		}
		if (Array.isArray(node)) {
			for (const item of node) visit(item, depth + 1);
			return;
		}
		if (typeof node !== "object" || node === null) return;
		for (const child of Object.values(node)) {
			visit(child, depth + 1);
			if (visitedNodes >= MEDIA_BODY_LIMITS.maxJsonNodes || urls.length >= MEDIA_BODY_LIMITS.maxCandidates) break;
		}
	};
	visit(value, 0);
	return urls;
}
/** Inspect an already-bounded response body for manifests and media URLs. */
function inspectMediaBodyText(body, responseUrl, contentType) {
	if (body.length === 0 || body.length > MEDIA_BODY_LIMITS.maxBytes) return [];
	const trimmed = body.trimStart();
	const type = bareContentType(contentType);
	const candidates = [];
	const seen = /* @__PURE__ */ new Set();
	const add = (value, candidateType, evidence) => {
		if (candidates.length >= MEDIA_BODY_LIMITS.maxCandidates) return;
		const url = resolveHttpUrl(value, responseUrl);
		if (!url || seen.has(url)) return;
		seen.add(url);
		candidates.push({
			url,
			...candidateType ? { contentType: candidateType } : {},
			evidence: [evidence]
		});
	};
	if (trimmed.startsWith("#EXTM3U")) {
		add(responseUrl, "application/vnd.apple.mpegurl", "body-hls");
		for (const candidate of playlistUrls(body, responseUrl)) add(candidate.url, candidate.forceHls ? "application/vnd.apple.mpegurl" : inferMediaMimeType(candidate.url) ?? void 0, "body-hls");
	}
	if (/^(?:<\?xml[^>]*>\s*)?<MPD\b/i.test(trimmed)) add(responseUrl, "application/dash+xml", "body-dash");
	if (type === "application/json" || type.endsWith("+json") || trimmed.startsWith("{") || trimmed.startsWith("[")) try {
		const parsed = JSON.parse(body);
		for (const url of jsonMediaUrls(parsed, responseUrl)) add(url, inferMediaMimeType(url) ?? void 0, "body-json");
	} catch {}
	return candidates;
}
function declaredBodyLength(response) {
	const raw = response.headers.get("content-length");
	if (!raw) return null;
	const value = Number.parseInt(raw, 10);
	return Number.isSafeInteger(value) && value >= 0 ? value : null;
}
/**
* Read a cloned fetch response without ever consuming the response returned to
* the page. Oversized or over-fragmented clones are cancelled and discarded.
*/
async function readBoundedResponseText(response, onBytesRead) {
	const declaredLength = declaredBodyLength(response);
	if (declaredLength !== null && declaredLength > MEDIA_BODY_LIMITS.maxBytes) return null;
	if (!response.body) try {
		const text = await response.text();
		const byteLength = new TextEncoder().encode(text).byteLength;
		if (byteLength > MEDIA_BODY_LIMITS.maxBytes) return null;
		onBytesRead?.(byteLength);
		return text;
	} catch {
		return null;
	}
	const reader = response.body.getReader();
	const chunks = [];
	let byteLength = 0;
	let chunkCount = 0;
	try {
		for (;;) {
			const next = await reader.read();
			if (next.done) break;
			chunkCount += 1;
			byteLength += next.value.byteLength;
			if (chunkCount > MEDIA_BODY_LIMITS.maxChunks || byteLength > MEDIA_BODY_LIMITS.maxBytes) {
				reader.cancel().catch(() => void 0);
				return null;
			}
			chunks.push(next.value);
		}
	} catch {
		reader.cancel().catch(() => void 0);
		return null;
	}
	const combined = new Uint8Array(byteLength);
	let offset = 0;
	for (const chunk of chunks) {
		combined.set(chunk, offset);
		offset += chunk.byteLength;
	}
	onBytesRead?.(byteLength);
	return new TextDecoder().decode(combined);
}
async function inspectFetchResponseBody(response, fallbackUrl, onBytesRead) {
	let clone;
	try {
		clone = response.clone();
	} catch {
		return [];
	}
	const text = await readBoundedResponseText(clone, onBytesRead);
	if (text === null) return [];
	return inspectMediaBodyText(text, response.url || fallbackUrl, response.headers.get("content-type") ?? void 0);
}
//#endregion
//#region src/content/mediaSniffer.ts
var MAX_REPORT_ITEMS = 100;
var MAX_DOM_MEDIA_ELEMENTS = 1200;
var MAX_DOM_STYLE_ELEMENTS = 400;
var MAX_DOM_CANDIDATES = 2e3;
var MAX_RESOURCE_KEYS = 4096;
var MAX_BODY_INSPECTIONS_PER_SECOND = 8;
var MAX_BODY_BYTES_PER_SECOND = 524288;
var MAX_CONCURRENT_BODY_INSPECTIONS = 2;
var MAX_MUTATION_ROOTS = 200;
var MUTATION_BATCH_MS = 120;
var MUTATION_WORK_WINDOW_MS = 1e3;
var MAX_MUTATION_FLUSHES_PER_WINDOW = 4;
var MAX_MUTATION_ROOT_WORK_PER_WINDOW = 400;
var MAX_CANDIDATE_URL_LENGTH = 32768;
var MAX_SRCSET_LENGTH = 65536;
var MAX_SRCSET_CANDIDATES = 32;
var MIN_IMAGE_EDGE = 48;
var MIN_IMAGE_AREA = 4096;
var MAX_TEXT_METADATA = 512;
var LAZY_URL_ATTRIBUTES = [
	"data-src",
	"data-original",
	"data-lazy-src",
	"data-url",
	"data-flickity-lazyload",
	"data-splide-lazy",
	"data-bg",
	"data-background-image",
	"data-thumb",
	"data-image"
];
var LAZY_SRCSET_ATTRIBUTES = ["data-srcset", "data-lazy-srcset"];
var DOM_MEDIA_SELECTOR = [
	"video",
	"audio",
	"img",
	"video source",
	"audio source",
	"picture source",
	"input[type=\"image\"]",
	"meta[property^=\"og:image\"]",
	"meta[property^=\"og:video\"]",
	"meta[property^=\"og:audio\"]",
	"meta[name^=\"twitter:image\"]",
	"meta[name^=\"twitter:player:stream\"]",
	"meta[itemprop=\"image\"]",
	"meta[itemprop=\"thumbnailUrl\"]",
	"meta[itemprop=\"contentUrl\"]",
	"link[rel~=\"image_src\"]",
	"link[rel~=\"preload\"][as=\"image\"]",
	"link[rel~=\"preload\"][as=\"video\"]",
	"link[rel~=\"preload\"][as=\"audio\"]",
	...LAZY_URL_ATTRIBUTES.map((attribute) => `[${attribute}]`),
	...LAZY_SRCSET_ATTRIBUTES.map((attribute) => `[${attribute}]`)
].join(",");
var DOM_STYLE_SELECTOR = "[style], [class], [id]";
var STREAM_SEGMENT_RE = /\.(?:ts|m4s|cmfv|cmfa)(?:$|[?#])|\/(?:seg(?:ment)?|frag(?:ment)?|chunk)[-_./]?\d+[^/]*(?:$|[?#])/i;
var resourceKey = (entry) => {
	const resource = entry;
	return [
		resource.name,
		resource.startTime,
		resource.duration,
		resource.initiatorType
	].join("\n");
};
function positiveInteger(value) {
	return typeof value === "number" && Number.isFinite(value) && value > 0 ? Math.round(value) : void 0;
}
function boundedText(value) {
	return [...(value ?? "").slice(0, MAX_TEXT_METADATA * 2)].map((character) => {
		const code = character.charCodeAt(0);
		return code <= 31 || code === 127 ? " " : character;
	}).join("").trim().slice(0, MAX_TEXT_METADATA) || void 0;
}
function isSvg(url, mimeType) {
	return mimeType?.split(";", 1)[0]?.trim().toLowerCase() === "image/svg+xml" || /\.svgz?(?:$|[?#])/i.test(url);
}
function isSmallDecorativeImage(category, width, height) {
	if (category !== "image" || width === void 0 || height === void 0) return false;
	return width < MIN_IMAGE_EDGE || height < MIN_IMAGE_EDGE || width * height < MIN_IMAGE_AREA;
}
function mergeMedia(existing, incoming) {
	const evidence = [.../* @__PURE__ */ new Set([...existing.evidence ?? [], ...incoming.evidence ?? []])].slice(0, 8);
	if (evidence.length > 0) existing.evidence = evidence;
	if (!existing.alt && incoming.alt) existing.alt = incoming.alt;
	if (!existing.suggestedFilename && incoming.suggestedFilename) existing.suggestedFilename = incoming.suggestedFilename;
	if (existing.mimeType?.endsWith("/*") && incoming.mimeType) existing.mimeType = incoming.mimeType;
	if (incoming.width !== void 0 && incoming.width > (existing.width ?? 0)) existing.width = incoming.width;
	if (incoming.height !== void 0 && incoming.height > (existing.height ?? 0)) existing.height = incoming.height;
	if (incoming.sizeBytes !== void 0 && incoming.sizeBytes > (existing.sizeBytes ?? 0)) existing.sizeBytes = incoming.sizeBytes;
	if (incoming.previewable === false) existing.previewable = false;
}
function collectFromUrls(urls, ctx) {
	const items = /* @__PURE__ */ new Map();
	for (const candidate of urls) {
		let resolvedUrl;
		let hostname;
		try {
			let parsed;
			try {
				parsed = new URL(candidate.url);
			} catch {
				parsed = new URL(candidate.url, ctx.pageUrl);
			}
			if (parsed.protocol !== "http:" && parsed.protocol !== "https:") continue;
			parsed.hash = "";
			resolvedUrl = parsed.toString();
			hostname = parsed.hostname;
		} catch {
			continue;
		}
		if (STREAM_SEGMENT_RE.test(resolvedUrl)) continue;
		if (shouldExcludeHost(hostname, ctx.webStore)) continue;
		const kind = classifyMediaUrl(resolvedUrl, candidate.contentType);
		if (!kind) continue;
		const mimeType = inferMediaMimeType(resolvedUrl, candidate.contentType) ?? void 0;
		const category = candidate.category ?? mediaCategory({
			kind,
			url: resolvedUrl,
			...mimeType ? { mimeType } : {}
		});
		const width = positiveInteger(candidate.width);
		const height = positiveInteger(candidate.height);
		if (isSmallDecorativeImage(category, width, height)) continue;
		const previewable = category === "image" ? candidate.previewable !== false && !isSvg(resolvedUrl, mimeType) : void 0;
		const alt = boundedText(candidate.alt);
		const suggestedFilename = boundedText(candidate.suggestedFilename);
		const sizeBytes = positiveInteger(candidate.sizeBytes);
		const item = {
			kind,
			url: resolvedUrl,
			pageUrl: ctx.pageUrl,
			pageTitle: ctx.pageTitle,
			detectedAt: ctx.now,
			category,
			...mimeType ? { mimeType } : {},
			...width ? { width } : {},
			...height ? { height } : {},
			...alt ? { alt } : {},
			...suggestedFilename ? { suggestedFilename } : {},
			...sizeBytes ? { sizeBytes } : {},
			...previewable !== void 0 ? { previewable } : {},
			...candidate.evidence && candidate.evidence.length > 0 ? { evidence: [...new Set(candidate.evidence)].slice(0, 8) } : {}
		};
		const existing = items.get(resolvedUrl);
		if (existing) mergeMedia(existing, item);
		else items.set(resolvedUrl, item);
	}
	return [...items.values()];
}
function srcsetCandidates(srcset, elementSize = {}) {
	if (!srcset) return [];
	return srcset.slice(0, MAX_SRCSET_LENGTH).split(",").map((candidate) => {
		const [url = "", descriptor = ""] = candidate.trim().split(/\s+/, 2);
		if (!url) return null;
		const widthMatch = /^(\d+)w$/i.exec(descriptor);
		const width = positiveInteger(widthMatch?.[1] ? Number.parseInt(widthMatch[1], 10) : void 0);
		const height = width && elementSize.width && elementSize.height ? positiveInteger(width * elementSize.height / elementSize.width) : void 0;
		return {
			url,
			...width ? { width } : {},
			...height ? { height } : {}
		};
	}).filter((candidate) => candidate !== null).slice(0, MAX_SRCSET_CANDIDATES);
}
function lazyAttributeUrls(value) {
	if (!value) return [];
	const embedded = cssUrls(value);
	return embedded.length > 0 ? embedded : [value];
}
function elementDimensions(element) {
	const media = element;
	const width = positiveInteger(media.naturalWidth || media.videoWidth || media.width);
	const height = positiveInteger(media.naturalHeight || media.videoHeight || media.height);
	return {
		...width ? { width } : {},
		...height ? { height } : {}
	};
}
function addElementCandidate(candidates, url, options) {
	const value = url?.trim();
	if (!value || value.length > MAX_CANDIDATE_URL_LENGTH || candidates.length >= MAX_DOM_CANDIDATES) return;
	candidates.push({
		url: value,
		...options
	});
}
function sourceContext(element) {
	const explicitType = boundedText(element.getAttribute("type"));
	const picture = element.closest("picture");
	const audio = element.closest("audio");
	const video = element.closest("video");
	if (picture) return {
		category: "image",
		contentType: explicitType ?? "image/*",
		evidence: ["picture", "source"]
	};
	if (audio) return {
		category: "audio",
		contentType: explicitType ?? "audio/*",
		evidence: ["audio", "source"]
	};
	if (video) return {
		category: "video",
		contentType: explicitType ?? "video/*",
		evidence: ["video", "source"]
	};
	return { evidence: ["source"] };
}
function metaCategory(element) {
	const key = `${element.getAttribute("property") ?? ""} ${element.getAttribute("name") ?? ""} ${element.getAttribute("itemprop") ?? ""}`.toLowerCase();
	if (key.includes("audio")) return "audio";
	if (key.includes("video") || key.includes("player")) return "video";
	if (key.includes("image") || key.includes("thumbnail")) return "image";
}
function collectElementMedia(element, candidates) {
	const tag = element.tagName.toLowerCase();
	const dimensions = elementDimensions(element);
	if (tag === "img") {
		const image = element;
		const base = {
			category: "image",
			contentType: "image/*",
			alt: image.alt,
			...dimensions
		};
		addElementCandidate(candidates, image.currentSrc, {
			...base,
			evidence: ["img", "current-src"]
		});
		addElementCandidate(candidates, element.getAttribute("src"), {
			...base,
			evidence: ["img"]
		});
		for (const source of srcsetCandidates(element.getAttribute("srcset"), dimensions)) addElementCandidate(candidates, source.url, {
			category: "image",
			contentType: "image/*",
			alt: image.alt,
			...source.width ? { width: source.width } : {},
			...source.height ? { height: source.height } : {},
			evidence: ["img", "srcset"]
		});
		for (const attribute of LAZY_URL_ATTRIBUTES) for (const url of lazyAttributeUrls(element.getAttribute(attribute))) addElementCandidate(candidates, url, {
			...base,
			evidence: ["img", "lazy"]
		});
		for (const attribute of LAZY_SRCSET_ATTRIBUTES) for (const source of srcsetCandidates(element.getAttribute(attribute), dimensions)) addElementCandidate(candidates, source.url, {
			category: "image",
			contentType: "image/*",
			alt: image.alt,
			...source.width ? { width: source.width } : {},
			...source.height ? { height: source.height } : {},
			evidence: [
				"img",
				"srcset",
				"lazy"
			]
		});
		return;
	}
	if (tag === "video" || tag === "audio") {
		const media = element;
		const category = tag;
		const contentType = `${category}/*`;
		addElementCandidate(candidates, media.currentSrc, {
			category,
			contentType,
			...dimensions,
			evidence: [category, "current-src"]
		});
		addElementCandidate(candidates, element.getAttribute("src"), {
			category,
			contentType,
			...dimensions,
			evidence: [category]
		});
		for (const attribute of LAZY_URL_ATTRIBUTES) for (const url of lazyAttributeUrls(element.getAttribute(attribute))) addElementCandidate(candidates, url, {
			category,
			contentType,
			...dimensions,
			evidence: [category, "lazy"]
		});
		if (tag === "video") addElementCandidate(candidates, element.getAttribute("poster"), {
			category: "image",
			contentType: "image/*",
			...dimensions,
			evidence: ["video", "poster"]
		});
		return;
	}
	if (tag === "source") {
		const context = sourceContext(element);
		const dimensionElement = element.closest("picture")?.querySelector("img") ?? element.parentElement;
		const parentDimensions = dimensionElement ? elementDimensions(dimensionElement) : {};
		addElementCandidate(candidates, element.getAttribute("src"), {
			...context,
			...parentDimensions
		});
		for (const attribute of LAZY_URL_ATTRIBUTES) for (const url of lazyAttributeUrls(element.getAttribute(attribute))) addElementCandidate(candidates, url, {
			...context,
			...parentDimensions,
			evidence: [...context.evidence, "lazy"]
		});
		for (const attribute of ["srcset", ...LAZY_SRCSET_ATTRIBUTES]) for (const source of srcsetCandidates(element.getAttribute(attribute), parentDimensions)) addElementCandidate(candidates, source.url, {
			...context,
			...source.width ? { width: source.width } : {},
			...source.height ? { height: source.height } : {},
			evidence: [
				...context.evidence,
				"srcset",
				...attribute !== "srcset" ? ["lazy"] : []
			]
		});
		return;
	}
	if (tag === "input" && element.getAttribute("type")?.toLowerCase() === "image") {
		const alt = element.getAttribute("alt") ?? void 0;
		addElementCandidate(candidates, element.getAttribute("src"), {
			category: "image",
			contentType: "image/*",
			...alt ? { alt } : {},
			...dimensions,
			evidence: ["input-image"]
		});
		return;
	}
	if (tag === "meta") {
		const category = metaCategory(element);
		addElementCandidate(candidates, element.getAttribute("content"), {
			...category ? {
				category,
				contentType: `${category}/*`
			} : {},
			evidence: ["meta"]
		});
		return;
	}
	if (tag === "link") {
		const category = element.getAttribute("as");
		const suggestedFilename = element.getAttribute("download") ?? void 0;
		addElementCandidate(candidates, element.getAttribute("href"), {
			...category === "image" || category === "video" || category === "audio" ? {
				category,
				contentType: `${category}/*`
			} : {
				category: "image",
				contentType: "image/*"
			},
			...suggestedFilename ? { suggestedFilename } : {},
			evidence: ["link"]
		});
		return;
	}
	for (const attribute of LAZY_URL_ATTRIBUTES) for (const url of lazyAttributeUrls(element.getAttribute(attribute))) addElementCandidate(candidates, url, {
		category: "image",
		contentType: "image/*",
		...dimensions,
		evidence: ["lazy"]
	});
	for (const attribute of LAZY_SRCSET_ATTRIBUTES) for (const source of srcsetCandidates(element.getAttribute(attribute), dimensions)) addElementCandidate(candidates, source.url, {
		category: "image",
		contentType: "image/*",
		...source.width ? { width: source.width } : {},
		...source.height ? { height: source.height } : {},
		evidence: ["srcset", "lazy"]
	});
}
function cssUrls(value) {
	if (!value || value === "none") return [];
	const urls = [];
	const pattern = /url\(\s*(?:(["'])(.*?)\1|([^)]*?))\s*\)/gi;
	for (;;) {
		const match = pattern.exec(value);
		if (!match) break;
		const url = (match[2] ?? match[3] ?? "").trim();
		if (url) urls.push(url);
		if (urls.length >= MAX_SRCSET_CANDIDATES) break;
	}
	return urls;
}
function collectCssMedia(element, candidates) {
	let dimensions = elementDimensions(element);
	if (dimensions.width === void 0 || dimensions.height === void 0) try {
		const rect = element.getBoundingClientRect();
		const width = positiveInteger(rect.width);
		const height = positiveInteger(rect.height);
		dimensions = {
			...width ? { width } : {},
			...height ? { height } : {}
		};
	} catch {}
	const readStyle = (pseudo) => {
		try {
			return window.getComputedStyle(element, pseudo);
		} catch {
			return null;
		}
	};
	const style = readStyle();
	for (const url of cssUrls(style?.backgroundImage)) addElementCandidate(candidates, url, {
		category: "image",
		contentType: "image/*",
		...dimensions,
		evidence: ["css-background"]
	});
	for (const pseudo of ["::before", "::after"]) {
		const pseudoStyle = readStyle(pseudo);
		for (const value of [pseudoStyle?.backgroundImage, pseudoStyle?.content]) for (const url of cssUrls(value)) addElementCandidate(candidates, url, {
			category: "image",
			contentType: "image/*",
			...dimensions,
			evidence: ["css-pseudo"]
		});
	}
}
function elementsInRoots(roots, selector, limit) {
	const elements = /* @__PURE__ */ new Set();
	for (const root of roots) {
		if (root instanceof Element && root.matches(selector)) elements.add(root);
		for (const element of root.querySelectorAll(selector)) {
			elements.add(element);
			if (elements.size >= limit) return [...elements];
		}
	}
	return [...elements];
}
function collectDomCandidates(roots = [document]) {
	const candidates = [];
	for (const element of elementsInRoots(roots, DOM_MEDIA_SELECTOR, MAX_DOM_MEDIA_ELEMENTS)) collectElementMedia(element, candidates);
	for (const element of elementsInRoots(roots, DOM_STYLE_SELECTOR, MAX_DOM_STYLE_ELEMENTS)) collectCssMedia(element, candidates);
	return candidates;
}
function fetchRequestUrl(input) {
	if (typeof input === "string") return input;
	if (input instanceof URL) return input.toString();
	return input.url;
}
function responseSize(headers) {
	const raw = headers.get("content-length");
	if (!raw) return void 0;
	const value = Number.parseInt(raw, 10);
	return Number.isSafeInteger(value) && value > 0 ? value : void 0;
}
function shouldInspectBody(url, contentType) {
	const type = contentType?.split(";", 1)[0]?.trim().toLowerCase() ?? "";
	const kind = classifyMediaUrl(url, contentType);
	return kind === "hls" || kind === "dash" || type === "application/json" || type.endsWith("+json") || type === "application/xml" || type === "text/xml" || type === "text/plain" || type === "application/octet-stream";
}
/**
* Install continuous, backend-independent media discovery for one document.
* The caller decides whether reports go directly to extension messaging
* (an isolated-world fallback) or through the MAIN/isolated relay.
*/
function installSniffer(report, initialCtx, resolveContext) {
	const webStore = isWebStoreBuild();
	let currentCtx = initialCtx;
	let active = true;
	const deferBodyInspection = globalThis.queueMicrotask.bind(globalThis);
	const resourcePageByKey = /* @__PURE__ */ new Map();
	const resourcePageByEntry = /* @__PURE__ */ new WeakMap();
	let bodyInspectionTokens = MAX_BODY_INSPECTIONS_PER_SECOND;
	let bodyByteTokens = MAX_BODY_BYTES_PER_SECOND;
	let bodyTokensUpdatedAt = Date.now();
	let concurrentBodyInspections = 0;
	const acquireBodyInspection = () => {
		const now = Date.now();
		const elapsed = Math.max(0, now - bodyTokensUpdatedAt);
		if (elapsed > 0) {
			const refillRatio = Math.min(1, elapsed / 1e3);
			bodyInspectionTokens = Math.min(MAX_BODY_INSPECTIONS_PER_SECOND, bodyInspectionTokens + MAX_BODY_INSPECTIONS_PER_SECOND * refillRatio);
			bodyByteTokens = Math.min(MAX_BODY_BYTES_PER_SECOND, bodyByteTokens + MAX_BODY_BYTES_PER_SECOND * refillRatio);
			bodyTokensUpdatedAt = now;
		}
		const reservedBytes = MEDIA_BODY_LIMITS.maxBytes;
		if (!active || concurrentBodyInspections >= MAX_CONCURRENT_BODY_INSPECTIONS || bodyInspectionTokens < 1 || bodyByteTokens < reservedBytes) return null;
		bodyInspectionTokens -= 1;
		bodyByteTokens -= reservedBytes;
		concurrentBodyInspections += 1;
		let released = false;
		return (actualBytes) => {
			if (released) return;
			released = true;
			concurrentBodyInspections = Math.max(0, concurrentBodyInspections - 1);
			if (actualBytes !== void 0) {
				const consumedBytes = Math.min(reservedBytes, Math.max(0, actualBytes));
				bodyByteTokens = Math.min(MAX_BODY_BYTES_PER_SECOND, bodyByteTokens + reservedBytes - consumedBytes);
			}
		};
	};
	const getCurrentContext = () => {
		try {
			return resolveContext?.() ?? currentCtx;
		} catch {
			return currentCtx;
		}
	};
	const reportUrls = (entries, ctx = getCurrentContext()) => {
		if (!active || entries.length === 0) return;
		try {
			const items = collectFromUrls(entries, {
				...ctx,
				now: Date.now(),
				webStore
			});
			for (let offset = 0; offset < items.length; offset += MAX_REPORT_ITEMS) try {
				report(items.slice(offset, offset + MAX_REPORT_ITEMS));
			} catch {}
		} catch {}
	};
	const push = (url, contentType, evidence, sizeBytes) => reportUrls([{
		url,
		...contentType ? { contentType } : {},
		...sizeBytes ? { sizeBytes } : {},
		evidence: [evidence]
	}]);
	const origFetch = window.fetch;
	const wrappedFetch = function(...args) {
		return Reflect.apply(origFetch, this, args).then((response) => {
			if (!active) return response;
			try {
				const requestUrl = fetchRequestUrl(args[0]);
				const responseUrl = response.url || requestUrl;
				const contentType = response.headers.get("content-type") ?? void 0;
				const sizeBytes = responseSize(response.headers);
				push(responseUrl, contentType, "fetch", sizeBytes);
				if (shouldInspectBody(responseUrl, contentType) && (sizeBytes === void 0 || sizeBytes <= MEDIA_BODY_LIMITS.maxBytes)) {
					const release = acquireBodyInspection();
					if (!release) return response;
					let inspectedBytes;
					inspectFetchResponseBody(response, requestUrl, (byteLength) => {
						inspectedBytes = byteLength;
					}).then((candidates) => {
						reportUrls(candidates.map((candidate) => ({
							...candidate,
							evidence: [...candidate.evidence, "fetch"]
						})));
					}).catch(() => void 0).finally(() => release(inspectedBytes));
				}
			} catch {}
			return response;
		});
	};
	window.fetch = wrappedFetch;
	const origOpen = XMLHttpRequest.prototype.open;
	const xhrUrls = /* @__PURE__ */ new WeakMap();
	const observedXhrs = /* @__PURE__ */ new WeakSet();
	const wrappedOpen = function(method, url, ...rest) {
		const result = Reflect.apply(origOpen, this, [
			method,
			url,
			...rest
		]);
		try {
			xhrUrls.set(this, String(url));
			if (!observedXhrs.has(this)) {
				observedXhrs.add(this);
				this.addEventListener("load", () => {
					if (!active) return;
					try {
						let contentType;
						let sizeBytes;
						contentType = this.getResponseHeader("content-type") ?? void 0;
						const length = this.getResponseHeader("content-length");
						const parsed = length ? Number.parseInt(length, 10) : NaN;
						if (Number.isSafeInteger(parsed) && parsed > 0) sizeBytes = parsed;
						const responseUrl = this.responseURL || xhrUrls.get(this) || "";
						push(responseUrl, contentType, "xhr", sizeBytes);
						if (!shouldInspectBody(responseUrl, contentType) || sizeBytes !== void 0 && sizeBytes > MEDIA_BODY_LIMITS.maxBytes) return;
						deferBodyInspection(() => {
							if (!active) return;
							const release = acquireBodyInspection();
							if (!release) return;
							let inspectedBytes;
							try {
								const responseType = this.responseType;
								if (responseType === "" || responseType === "text") {
									const body = this.responseText;
									if (typeof body !== "string") return;
									inspectedBytes = new TextEncoder().encode(body).byteLength;
									if (body.length <= MEDIA_BODY_LIMITS.maxBytes && inspectedBytes <= MEDIA_BODY_LIMITS.maxBytes) reportUrls(inspectMediaBodyText(body, responseUrl, contentType).map((candidate) => ({
										...candidate,
										evidence: [...candidate.evidence, "xhr"]
									})));
								}
							} catch {} finally {
								release(inspectedBytes);
							}
						});
					} catch {}
				});
			}
		} catch {}
		return result;
	};
	XMLHttpRequest.prototype.open = wrappedOpen;
	const rememberResourceOwner = (entry, key, pageUrl) => {
		resourcePageByEntry.set(entry, pageUrl);
		resourcePageByKey.delete(key);
		resourcePageByKey.set(key, pageUrl);
		while (resourcePageByKey.size > MAX_RESOURCE_KEYS) {
			const oldestKey = resourcePageByKey.keys().next().value;
			if (typeof oldestKey !== "string") break;
			resourcePageByKey.delete(oldestKey);
		}
	};
	const resourceOwner = (entry, key) => {
		const owner = resourcePageByEntry.get(entry) ?? resourcePageByKey.get(key);
		if (owner !== void 0) rememberResourceOwner(entry, key, owner);
		return owner;
	};
	const harvestPerformance = (entries, ctx, repeatedScan) => {
		const harvested = [];
		for (const entry of entries.slice(-2e3)) {
			const resource = entry;
			if (typeof resource.name !== "string" || resource.name.length === 0) continue;
			const key = resourceKey(entry);
			const owningPage = resourceOwner(entry, key);
			if (owningPage === void 0) rememberResourceOwner(entry, key, ctx.pageUrl);
			else if (owningPage !== ctx.pageUrl) continue;
			else if (!repeatedScan) continue;
			const sizeBytes = positiveInteger(resource.decodedBodySize);
			harvested.push({
				url: resource.name,
				...sizeBytes ? { sizeBytes } : {},
				evidence: ["performance"]
			});
		}
		reportUrls(harvested, ctx);
	};
	let performanceObserver = null;
	if (typeof PerformanceObserver !== "undefined") try {
		performanceObserver = new PerformanceObserver((list) => {
			harvestPerformance(list.getEntries(), getCurrentContext(), false);
		});
		performanceObserver.observe({
			type: "resource",
			buffered: true
		});
	} catch {
		performanceObserver = null;
	}
	const pendingRoots = /* @__PURE__ */ new Set();
	let mutationTimer;
	let mutationWindowStartedAt = Date.now();
	let mutationFlushes = 0;
	let mutationRootWork = 0;
	const resetMutationWindowIfNeeded = () => {
		if (Date.now() - mutationWindowStartedAt < MUTATION_WORK_WINDOW_MS) return;
		mutationWindowStartedAt = Date.now();
		mutationFlushes = 0;
		mutationRootWork = 0;
	};
	function scheduleMutationFlush(delay = MUTATION_BATCH_MS) {
		if (!active || mutationTimer !== void 0 || pendingRoots.size === 0) return;
		mutationTimer = window.setTimeout(flushMutations, delay);
	}
	function flushMutations() {
		mutationTimer = void 0;
		if (!active || pendingRoots.size === 0) return;
		resetMutationWindowIfNeeded();
		const remainingRootWork = MAX_MUTATION_ROOT_WORK_PER_WINDOW - mutationRootWork;
		if (mutationFlushes >= MAX_MUTATION_FLUSHES_PER_WINDOW || remainingRootWork <= 0) {
			scheduleMutationFlush(Math.max(1, MUTATION_WORK_WINDOW_MS - (Date.now() - mutationWindowStartedAt)));
			return;
		}
		const roots = [...pendingRoots].slice(0, remainingRootWork);
		for (const root of roots) pendingRoots.delete(root);
		mutationFlushes += 1;
		mutationRootWork += roots.length;
		try {
			reportUrls(collectDomCandidates(roots));
		} catch {}
		if (pendingRoots.size > 0) scheduleMutationFlush();
	}
	const addPendingRoot = (root) => {
		for (const existing of pendingRoots) {
			if (existing === root || existing.contains(root)) return;
			if (root.contains(existing)) pendingRoots.delete(existing);
		}
		if (pendingRoots.size < MAX_MUTATION_ROOTS) pendingRoots.add(root);
	};
	const scheduleRoots = (roots) => {
		if (!active) return;
		for (const root of roots) addPendingRoot(root);
		scheduleMutationFlush();
	};
	let mutationObserver = null;
	if (typeof MutationObserver !== "undefined") {
		mutationObserver = new MutationObserver((records) => {
			const roots = [];
			for (const record of records) {
				if (record.target instanceof Element) roots.push(record.target);
				for (const node of record.addedNodes) if (node instanceof Element) roots.push(node);
				if (roots.length >= MAX_MUTATION_ROOTS) break;
			}
			scheduleRoots(roots);
		});
		mutationObserver.observe(document, {
			subtree: true,
			childList: true,
			attributes: true,
			attributeFilter: [
				"src",
				"srcset",
				"poster",
				"content",
				"href",
				"style",
				"class",
				...LAZY_URL_ATTRIBUTES,
				...LAZY_SRCSET_ATTRIBUTES
			]
		});
	}
	const onResourceLoad = (event) => {
		if (!(event.target instanceof Element)) return;
		if (event.target instanceof HTMLLinkElement && event.target.relList.contains("stylesheet") && document.documentElement) {
			scheduleRoots([document.documentElement]);
			return;
		}
		scheduleRoots([event.target]);
	};
	const onDocumentReady = () => {
		if (document.documentElement) scheduleRoots([document.documentElement]);
	};
	document.addEventListener("load", onResourceLoad, true);
	document.addEventListener("DOMContentLoaded", onDocumentReady);
	window.addEventListener("load", onDocumentReady);
	const scan = (nextCtx = getCurrentContext()) => {
		if (nextCtx.pageUrl !== currentCtx.pageUrl) {
			resourcePageByKey.clear();
			pendingRoots.clear();
			if (mutationTimer !== void 0) {
				window.clearTimeout(mutationTimer);
				mutationTimer = void 0;
			}
			mutationWindowStartedAt = Date.now();
			mutationFlushes = 0;
			mutationRootWork = 0;
		}
		currentCtx = nextCtx;
		try {
			reportUrls(collectDomCandidates(), nextCtx);
		} catch {}
		try {
			harvestPerformance(performance.getEntriesByType("resource"), nextCtx, true);
		} catch {}
	};
	scan(initialCtx);
	return {
		scan,
		uninstall: () => {
			active = false;
			mutationObserver?.disconnect();
			performanceObserver?.disconnect();
			document.removeEventListener("load", onResourceLoad, true);
			document.removeEventListener("DOMContentLoaded", onDocumentReady);
			window.removeEventListener("load", onDocumentReady);
			if (mutationTimer !== void 0) window.clearTimeout(mutationTimer);
			if (window.fetch === wrappedFetch) window.fetch = origFetch;
			if (XMLHttpRequest.prototype.open === wrappedOpen) XMLHttpRequest.prototype.open = origOpen;
		}
	};
}
//#endregion
export { installSniffer as t };

//# sourceMappingURL=mediaSniffer-lZsBbi9G.js.map