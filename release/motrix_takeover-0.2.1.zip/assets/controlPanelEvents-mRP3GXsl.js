import { h as httpUrl } from "./platformCapabilities-BhYiGJPy.js";
var FALLBACK_HTTP_FILENAME = "download";
var FALLBACK_MAGNET_FILENAME = "magnet-download";
var ManualTaskHttpUrl = httpUrl();
/**
* Parse user-pasted input without consulting tabs, cookies, or browser state.
* Keeping this pure lets the popup validate with the same rules enforced by
* the background handler.
*/
function parseManualTaskInput(raw) {
	if (typeof raw !== "string" || raw.trim().length === 0) return {
		ok: false,
		reason: "empty"
	};
	const input = raw.trim();
	let url;
	try {
		url = new URL(input);
	} catch {
		return {
			ok: false,
			reason: "invalid"
		};
	}
	if (url.protocol === "http:" || url.protocol === "https:") {
		if (!ManualTaskHttpUrl.safeParse(url.href).success) return {
			ok: false,
			reason: "invalid"
		};
		return {
			ok: true,
			value: {
				kind: "direct",
				url: url.href,
				suggestedFilename: filenameFromHttpUrl(url)
			}
		};
	}
	if (url.protocol === "magnet:" && url.href.startsWith("magnet:?")) {
		if (!url.searchParams.getAll("xt").some((value) => value.trim() !== "")) return {
			ok: false,
			reason: "invalid"
		};
		return {
			ok: true,
			value: {
				kind: "magnet",
				uri: url.href,
				suggestedFilename: sanitizeFilename(url.searchParams.get("dn") ?? "", FALLBACK_MAGNET_FILENAME)
			}
		};
	}
	return {
		ok: false,
		reason: "unsupported"
	};
}
function filenameFromHttpUrl(url) {
	const encodedSegment = url.pathname.split("/").at(-1) ?? "";
	let segment = encodedSegment;
	try {
		segment = decodeURIComponent(encodedSegment);
	} catch {}
	return sanitizeFilename(segment, FALLBACK_HTTP_FILENAME);
}
/** Characters forbidden or troublesome on Windows, macOS, and Linux. */
var UNSAFE_FILENAME_CHARS = /[<>:"/\\|?*\x00-\x1f\x7f]/g;
/** Invisible direction overrides can disguise an executable suffix. */
var BIDI_FILENAME_CONTROLS = /[\u202a-\u202e\u2066-\u2069]/g;
var WINDOWS_DEVICE_NAME = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
function sanitizeFilename(value, fallback) {
	const safeFallback = fallback.normalize("NFC").replace(BIDI_FILENAME_CONTROLS, "").replace(UNSAFE_FILENAME_CHARS, "_").trim().replace(/[. ]+$/g, "") || "download";
	let safe = value.normalize("NFC").replace(BIDI_FILENAME_CONTROLS, "").replace(UNSAFE_FILENAME_CHARS, "_").trim().replace(/[. ]+$/g, "");
	if (safe === "" || safe === "." || safe === "..") safe = safeFallback;
	if (WINDOWS_DEVICE_NAME.test(safe)) safe = `_${safe}`;
	safe = truncateWithoutSplittingSurrogate(safe, 255).trim().replace(/[. ]+$/g, "");
	return safe || safeFallback;
}
/**
* Sanitize a filename and force a trusted canonical extension. The suffix is
* budgeted before truncation so a long Unicode stem can never remove it or be
* cut between a surrogate pair.
*/
function sanitizeFilenameWithExtension(value, extension, fallback) {
	const canonicalExtension = extension.normalize("NFC").replace(BIDI_FILENAME_CONTROLS, "").replace(/^\.+/, "").replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 32);
	if (!canonicalExtension) return sanitizeFilename(value, fallback);
	const suffix = `.${canonicalExtension}`;
	const safe = sanitizeFilename(value, fallback);
	const existingExtension = /\.([a-z0-9]{1,16})$/i.exec(safe);
	const rawStem = existingExtension ? safe.slice(0, -existingExtension[0].length) : safe;
	const deduplicatedStem = rawStem.toLowerCase().endsWith(suffix) ? rawStem.slice(0, -suffix.length) : rawStem;
	const fallbackStem = sanitizeFilename(fallback, "download").replace(/\.([a-z0-9]{1,16})$/i, "") || "download";
	return `${truncateWithoutSplittingSurrogate(sanitizeFilename(deduplicatedStem, fallbackStem), Math.max(1, 255 - suffix.length)).trim().replace(/[. ]+$/g, "") || fallbackStem}${suffix}`;
}
function truncateWithoutSplittingSurrogate(value, max) {
	if (value.length <= max) return value;
	let result = value.slice(0, max);
	const last = result.charCodeAt(result.length - 1);
	if (last >= 55296 && last <= 56319) result = result.slice(0, -1);
	return result;
}
//#endregion
//#region src/shared/controlPanelEvents.ts
/**
* One-way background event used to wake an open popup when the paired MDXP
* session sees its active task set change. The popup still reconciles through
* `task/list`: WS task pushes are session-scoped and therefore cannot be the
* authoritative list of tasks created directly in Motrix.
*/
var CONTROL_PANEL_ACTIVITY_EVENT = "event.controlPanelActivity";
function isControlPanelActivityEvent(value) {
	return typeof value === "object" && value !== null && "kind" in value && value.kind === "event.controlPanelActivity";
}
//#endregion
export { sanitizeFilenameWithExtension as a, sanitizeFilename as i, isControlPanelActivityEvent as n, parseManualTaskInput as r, CONTROL_PANEL_ACTIVITY_EVENT as t };

//# sourceMappingURL=controlPanelEvents-mRP3GXsl.js.map