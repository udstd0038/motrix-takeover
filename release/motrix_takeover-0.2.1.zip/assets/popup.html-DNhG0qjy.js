import { et as send, i as initI18n, j as supportsAutomaticTakeover, nt as isErrorResponse, st as __toESM, t as hasNativeMessagingSupport } from "./platformCapabilities-BhYiGJPy.js";
import { $ as usePositioner, $n as dispatchClickWithModifiers, $t as fastComponent, A as SelectTrigger, At as useSyncedFloatingRootContext, B as useOpenMethodTriggerProps, Bt as FloatingTreeStore, C as AlertTitle, Cn as useCompositeListItem, Cr as ChevronRight, Ct as setPopupOpenState, D as SelectContent, Dn as cancelOpen, Dr as require_client, Dt as usePopupRootStore, E as Select, En as createChangeEventDetails, Er as createLucideIcon, Et as usePopupInteractionProps, F as InternalBackdrop, Ft as FloatingNode, Gn as cn, Gt as POPUP_COLLISION_AVOIDANCE, H as Switch, Hn as useControlled, I as isMouseWithinBounds, It as FloatingTree, Jn as EMPTY_ARRAY, Kn as cva, Kt as FocusGuard, L as normalizeScrollOffset, Ln as siblingOpen, Lt as useFloatingNodeId, M as useToolbarRootContext, Mn as imperativeAction, Mt as useDismiss, N as styleDisableScrollbar, Nn as itemPress, Nt as useClick, Or as require_react_dom, Ot as usePopupRootSync, P as useAnchoredPopupScrollLock, Pt as FloatingFocusManager, Qn as useButton, Qt as useTimeout, R as clamp, Rt as useFloatingParentNodeId, S as AlertDescription, Sn as useCompositeItem, Sr as CircleAlert, St as createDefaultInitialFocus, Tn as useId$3, Tr as Check, Tt as useOpenStateTransitions, U as Input, Un as Button, Ut as CLICK_TRIGGER_IDENTIFIER, V as Textarea, Vn as CompositeList, Vt as FloatingPortal, W as Field, Wn as buttonVariants, Wt as DROPDOWN_COLLISION_AVOIDANCE, Xn as NOOP, Y as FieldLabel, Yn as EMPTY_OBJECT, Yt as addEventListener, Z as Separator, Zn as useMergedRefs, Zt as Timeout, _ as AlertDialogFooter, _r as Plus, _t as PopupTriggerMap, an as useDirection, ar as useStableCallback, at as triggerOpenStateMapping, b as Alert, bn as webkit, br as Laptop, c as DialogFooter, cn as useOpenChangeComplete, ct as useListNavigation, d as Spinner, dn as inertValue, dr as isLastTraversableNode, en as fastComponentRef, er as ownerDocument, et as getDisabledMountTransitionStyles, f as AlertDialog, fn as useCSPContext, fr as require_jsx_runtime, ft as useFocus, g as AlertDialogDescription, gn as isOutsideEvent, gr as RefreshCw, gt as popupStoreSelectors, h as AlertDialogContent, hn as getTabbableBeforeElement, hr as Server, ht as createPopupFloatingRootContext, i as Dialog, in as TabsTrigger, ir as useIsoLayoutEffect, it as pressableTriggerOpenStateMapping, j as SelectValue, jn as focusOut, jt as ReactStore, k as SelectItem, kr as require_react, kt as useTriggerDataForwarding, l as DialogHeader, ln as useAnimationsFinished, lt as useHoverReferenceInteraction, m as AlertDialogCancel, mn as getTabbableAfterElement, mr as Trash2, mt as createInitialPopupStoreState, n as connectionErrorKey, nn as TabsContent, nr as formatErrorMessage, o as DialogContent, on as COMPOSITE_KEYS, or as useRefWithInit, ot as safePolygon, p as AlertDialogAction, pn as getNextTabbable, pr as useTranslation, pt as usePopupHandleStore, q as FieldError, qn as useRenderElement, qt as visuallyHidden, r as PairingCodePanel, rn as TabsList, rr as mergeProps, rt as popupTransitionStateMapping, s as DialogDescription, sn as useTransitionStatus, sr as getParentNode, st as useTypeahead, t as initTheme, tn as Tabs, tr as useCompositeRootContext, tt as useAnchorPositioning, u as DialogTitle, un as transitionStatusMapping, ur as isHTMLElement, ut as useHoverFloatingInteraction, v as AlertDialogHeader, vn as contains, vr as Minus, vt as FOCUSABLE_POPUP_PROPS, wn as useBaseUiId, wr as ChevronDown, wt as useImplicitActiveTrigger, xn as mac, xt as attachPreventUnmountOnClose, y as AlertDialogTitle, yn as getTarget, yr as LoaderCircle, yt as PopupHandleAttachment, z as useOpenInteractionType, zn as triggerHover, zt as useFloatingTree } from "./theme-DX7Zessj.js";
import { n as isControlPanelActivityEvent, r as parseManualTaskInput } from "./controlPanelEvents-mRP3GXsl.js";
import { a as mediaCategory, c as readableMediaMetadata, i as isResolvableVideoPage, o as mediaStorageKey, s as mediaTabStorageKey, u as isWebStoreBuild } from "./media-oiN-I4sB.js";
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Activity = createLucideIcon("activity", [["path", {
	d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
	key: "169zse"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CircleCheck = createLucideIcon("circle-check", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["path", {
	d: "m16 9-5.5 5.5L8 12",
	key: "xofnsj"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Download = createLucideIcon("download", [
	["path", {
		d: "M12 15V3",
		key: "m9g1x1"
	}],
	["path", {
		d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",
		key: "ih7n3h"
	}],
	["path", {
		d: "m7 10 5 5 5-5",
		key: "brsn70"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FileArchive = createLucideIcon("file-archive", [
	["path", {
		d: "M13.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v11.5",
		key: "4pqfef"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M8 12v-1",
		key: "1ej8lb"
	}],
	["path", {
		d: "M8 18v-2",
		key: "qcmpov"
	}],
	["path", {
		d: "M8 7V6",
		key: "1nbb54"
	}],
	["circle", {
		cx: "8",
		cy: "20",
		r: "2",
		key: "ckkr5m"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FileDown = createLucideIcon("file-down", [
	["path", {
		d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
		key: "1oefj6"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M12 18v-6",
		key: "17g6i2"
	}],
	["path", {
		d: "m9 15 3 3 3-3",
		key: "1npd3o"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FileHeadphone = createLucideIcon("file-headphone", [
	["path", {
		d: "M4 6.835V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.706.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2h-.343",
		key: "1vfytu"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M2 19a2 2 0 0 1 4 0v1a2 2 0 0 1-4 0v-4a6 6 0 0 1 12 0v4a2 2 0 0 1-4 0v-1a2 2 0 0 1 4 0",
		key: "1etmh7"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FilePlay = createLucideIcon("file-play", [
	["path", {
		d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
		key: "1oefj6"
	}],
	["path", {
		d: "M14 2v5a1 1 0 0 0 1 1h5",
		key: "wfsgrz"
	}],
	["path", {
		d: "M15.033 13.44a.647.647 0 0 1 0 1.12l-4.065 2.352a.645.645 0 0 1-.968-.56v-4.704a.645.645 0 0 1 .967-.56z",
		key: "1tzo1f"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var File = createLucideIcon("file", [["path", {
	d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
	key: "1oefj6"
}], ["path", {
	d: "M14 2v5a1 1 0 0 0 1 1h5",
	key: "wfsgrz"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FolderOpen = createLucideIcon("folder-open", [["path", {
	d: "m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",
	key: "usdka0"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Image = createLucideIcon("image", [
	["rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "3",
		rx: "2",
		ry: "2",
		key: "1m3agn"
	}],
	["circle", {
		cx: "9",
		cy: "9",
		r: "2",
		key: "af1f0g"
	}],
	["path", {
		d: "m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",
		key: "1xmnt7"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Inbox = createLucideIcon("inbox", [["polyline", {
	points: "22 12 16 12 14 15 10 15 8 12 2 12",
	key: "o97t9d"
}], ["path", {
	d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
	key: "oot6mr"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ListTodo = createLucideIcon("list-todo", [
	["path", {
		d: "M13 5h8",
		key: "a7qcls"
	}],
	["path", {
		d: "M13 12h8",
		key: "h98zly"
	}],
	["path", {
		d: "M13 19h8",
		key: "c3s6r1"
	}],
	["path", {
		d: "m3 17 2 2 4-4",
		key: "1jhpwq"
	}],
	["rect", {
		x: "3",
		y: "4",
		width: "6",
		height: "6",
		rx: "1",
		key: "cif1o7"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Magnet = createLucideIcon("magnet", [
	["path", {
		d: "m12 15 4 4",
		key: "lnac28"
	}],
	["path", {
		d: "M2.352 10.648a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.029-6.029a1 1 0 1 1 3 3l-6.029 6.029a1.205 1.205 0 0 0 0 1.704l2.296 2.296a1.205 1.205 0 0 0 1.704 0l6.365-6.367A1 1 0 0 0 8.716 4.282z",
		key: "nlhkjb"
	}],
	["path", {
		d: "m5 8 4 4",
		key: "j6kj7e"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Pause = createLucideIcon("pause", [["rect", {
	x: "14",
	y: "3",
	width: "5",
	height: "18",
	rx: "1",
	key: "kaeet6"
}], ["rect", {
	x: "5",
	y: "3",
	width: "5",
	height: "18",
	rx: "1",
	key: "1wsw3u"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Play = createLucideIcon("play", [["path", {
	d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
	key: "10ikf1"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Radio = createLucideIcon("radio", [
	["path", {
		d: "M16.247 7.761a6 6 0 0 1 0 8.478",
		key: "1fwjs5"
	}],
	["path", {
		d: "M19.075 4.933a10 10 0 0 1 0 14.134",
		key: "ehdyv1"
	}],
	["path", {
		d: "M4.925 19.067a10 10 0 0 1 0-14.134",
		key: "1q22gi"
	}],
	["path", {
		d: "M7.753 16.239a6 6 0 0 1 0-8.478",
		key: "r2q7qm"
	}],
	["circle", {
		cx: "12",
		cy: "12",
		r: "2",
		key: "1c9p78"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ScanSearch = createLucideIcon("scan-search", [
	["path", {
		d: "M3 7V5a2 2 0 0 1 2-2h2",
		key: "aa7l1z"
	}],
	["path", {
		d: "M17 3h2a2 2 0 0 1 2 2v2",
		key: "4qcy5o"
	}],
	["path", {
		d: "M21 17v2a2 2 0 0 1-2 2h-2",
		key: "6vwrx8"
	}],
	["path", {
		d: "M7 21H5a2 2 0 0 1-2-2v-2",
		key: "ioqczr"
	}],
	["circle", {
		cx: "12",
		cy: "12",
		r: "3",
		key: "1v7zrd"
	}],
	["path", {
		d: "m16 16-1.9-1.9",
		key: "1dq9hf"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Send = createLucideIcon("send", [["path", {
	d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
	key: "1ffxy3"
}], ["path", {
	d: "m21.854 2.147-10.94 10.939",
	key: "12cjpa"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Settings = createLucideIcon("settings", [["path", {
	d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
	key: "1i5ecw"
}], ["circle", {
	cx: "12",
	cy: "12",
	r: "3",
	key: "1v7zrd"
}]]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Settings2 = createLucideIcon("settings-2", [
	["path", {
		d: "M14 17H5",
		key: "gfn3mx"
	}],
	["path", {
		d: "M19 7h-9",
		key: "6i9tg"
	}],
	["circle", {
		cx: "17",
		cy: "17",
		r: "3",
		key: "18b49y"
	}],
	["circle", {
		cx: "7",
		cy: "7",
		r: "3",
		key: "dfmy0x"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var SlidersHorizontal = createLucideIcon("sliders-horizontal", [
	["path", {
		d: "M10 5H3",
		key: "1qgfaw"
	}],
	["path", {
		d: "M12 19H3",
		key: "yhmn1j"
	}],
	["path", {
		d: "M14 3v4",
		key: "1sua03"
	}],
	["path", {
		d: "M16 17v4",
		key: "1q0r14"
	}],
	["path", {
		d: "M21 12h-9",
		key: "1o4lsq"
	}],
	["path", {
		d: "M21 19h-5",
		key: "1rlt1p"
	}],
	["path", {
		d: "M21 5h-7",
		key: "1oszz2"
	}],
	["path", {
		d: "M8 10v4",
		key: "tgpxqk"
	}],
	["path", {
		d: "M8 12H3",
		key: "a7s4jb"
	}]
]);
/**
* @license lucide-react v1.38.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var TriangleAlert = createLucideIcon("triangle-alert", [
	["path", {
		d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
		key: "wmoenq"
	}],
	["path", {
		d: "M12 9v4",
		key: "juzpu7"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]);
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var MenuPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuPositionerContext(optional) {
	const context = import_react.useContext(MenuPositionerContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(33));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs
var MenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuRootContext(optional) {
	const context = import_react.useContext(MenuRootContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(36));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs
var ContextMenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useContextMenuRootContext(optional = true) {
	const context = import_react.useContext(ContextMenuRootContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(25));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/item/useMenuItemCommonProps.mjs
/**
* Returns common props shared by all menu item types.
* This hook extracts the shared logic for id, role, tabIndex, onKeyDown,
* onMouseMove, onClick, and onMouseUp handlers.
*/
function useMenuItemCommonProps(params) {
	const { closeOnClick, highlighted, id, nodeId, store, typingRef, itemRef, itemMetadata } = params;
	const { events: menuEvents } = store.useState("floatingTreeRoot");
	const open = store.useState("open");
	const contextMenuContext = useContextMenuRootContext(true);
	const isContextMenu = contextMenuContext !== void 0;
	return import_react.useMemo(() => ({
		id,
		role: "menuitem",
		tabIndex: open && highlighted ? 0 : -1,
		onKeyDown(event) {
			if (event.key === " " && typingRef?.current) event.preventDefault();
		},
		onMouseMove(event) {
			if (!nodeId) return;
			menuEvents.emit("itemhover", {
				nodeId,
				target: event.currentTarget
			});
		},
		onClick(event) {
			if (closeOnClick) menuEvents.emit("close", {
				domEvent: event,
				reason: itemPress
			});
		},
		onMouseUp(event) {
			if (contextMenuContext) {
				const initialCursorPoint = contextMenuContext.initialCursorPointRef.current;
				contextMenuContext.initialCursorPointRef.current = null;
				if (isContextMenu && initialCursorPoint && Math.abs(event.clientX - initialCursorPoint.x) <= 1 && Math.abs(event.clientY - initialCursorPoint.y) <= 1) return;
				if (isContextMenu && !mac && event.button === 2) return;
			}
			if (itemRef.current && store.context.allowMouseUpTriggerRef.current && (!isContextMenu || event.button === 2)) {
				if (itemMetadata.type === "regular-item") dispatchClickWithModifiers(itemRef.current, event, { detail: 1 });
			}
		}
	}), [
		closeOnClick,
		highlighted,
		id,
		menuEvents,
		nodeId,
		open,
		store,
		typingRef,
		itemRef,
		contextMenuContext,
		isContextMenu,
		itemMetadata
	]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/item/useMenuItem.mjs
var REGULAR_ITEM = { type: "regular-item" };
function useMenuItem(params) {
	const { closeOnClick, disabled, highlighted, id, store, typingRef = store.context.typingRef, nativeButton, itemMetadata, nodeId } = params;
	const itemRef = import_react.useRef(null);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		focusableWhenDisabled: true,
		native: nativeButton,
		composite: true
	});
	const commonProps = useMenuItemCommonProps({
		closeOnClick,
		highlighted,
		id,
		nodeId,
		store,
		typingRef,
		itemRef,
		itemMetadata
	});
	const getItemProps = import_react.useCallback((externalProps) => {
		return mergeProps(commonProps, { onMouseEnter() {
			if (itemMetadata.type !== "submenu-trigger") return;
			itemMetadata.setActive();
		} }, externalProps, getButtonProps);
	}, [
		commonProps,
		getButtonProps,
		itemMetadata
	]);
	const mergedRef = useMergedRefs(itemRef, buttonRef);
	return import_react.useMemo(() => ({
		getItemProps,
		itemRef: mergedRef
	}), [getItemProps, mergedRef]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemDataAttributes.mjs
var MenuCheckboxItemDataAttributes = /*#__PURE__*/ function(MenuCheckboxItemDataAttributes) {
	/**
	* Present when the menu checkbox item is checked.
	*/
	MenuCheckboxItemDataAttributes["checked"] = "data-checked";
	/**
	* Present when the menu checkbox item is not checked.
	*/
	MenuCheckboxItemDataAttributes["unchecked"] = "data-unchecked";
	/**
	* Present when the menu checkbox item is disabled.
	*/
	MenuCheckboxItemDataAttributes["disabled"] = "data-disabled";
	/**
	* Present when the menu checkbox item is highlighted.
	*/
	MenuCheckboxItemDataAttributes["highlighted"] = "data-highlighted";
	return MenuCheckboxItemDataAttributes;
}({});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs
var itemMapping = {
	checked(value) {
		if (value) return { [MenuCheckboxItemDataAttributes.checked]: "" };
		return { [MenuCheckboxItemDataAttributes.unchecked]: "" };
	},
	...transitionStatusMapping
};
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs
var MenuGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuGroupRootContext() {
	const context = import_react.useContext(MenuGroupContext);
	if (context === void 0) throw new Error(formatErrorMessage(31));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/group/MenuGroup.mjs
var import_jsx_runtime = require_jsx_runtime();
var MenuGroup = /*#__PURE__*/ import_react.forwardRef(function MenuGroup(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState(void 0);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: {
			role: "group",
			"aria-labelledby": labelId,
			...elementProps
		}
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuGroupContext.Provider, {
		value: setLabelId,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/group-label/MenuGroupLabel.mjs
/**
* An accessible label that is automatically associated with its parent group.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuGroupLabel = /*#__PURE__*/ import_react.forwardRef(function MenuGroupLabel(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const setLabelId = useMenuGroupRootContext();
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [setLabelId, id]);
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: {
			id,
			role: "presentation",
			...elementProps
		}
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/item/MenuItem.mjs
/**
* An individual interactive item in the menu.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuItem = /*#__PURE__*/ import_react.forwardRef(function MenuItem(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = true, style, ...elementProps } = componentProps;
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const menuPositionerContext = useMenuPositionerContext(true);
	const id = useBaseUiId(idProp);
	const { store } = useMenuRootContext();
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp || rootDisabled;
	const highlighted = store.useState("isActive", listItem.index);
	const itemProps = store.useState("itemProps");
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick,
		disabled,
		highlighted,
		id,
		store,
		nativeButton,
		nodeId: menuPositionerContext?.context.nodeId,
		itemMetadata: REGULAR_ITEM
	});
	return useRenderElement("div", componentProps, {
		state: {
			disabled,
			highlighted
		},
		props: [
			itemProps,
			elementProps,
			getItemProps
		],
		ref: [
			itemRef,
			forwardedRef,
			listItem.ref
		]
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/popup/MenuPopup.mjs
/**
* A container for the menu items.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPopup = /*#__PURE__*/ import_react.forwardRef(function MenuPopup(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const { side, align } = useMenuPositionerContext();
	const insideToolbar = useToolbarRootContext(true) != null;
	const open = store.useState("open");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const mounted = store.useState("mounted");
	const instantType = store.useState("instantType");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const parent = store.useState("parent");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const rootId = store.useState("rootId");
	const floatingContext = store.useState("floatingRootContext");
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const closeDelay = store.useState("closeDelay");
	const hoverEnabled = store.useState("hoverEnabled");
	const disabled = store.useState("disabled");
	const openMethod = store.useState("openMethod");
	const isContextMenu = parent.type === "context-menu";
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	import_react.useEffect(() => {
		function handleClose(event) {
			store.setOpen(false, createChangeEventDetails(event.reason, event.domEvent));
		}
		floatingTreeRoot.events.on("close", handleClose);
		return () => {
			floatingTreeRoot.events.off("close", handleClose);
		};
	}, [floatingTreeRoot.events, store]);
	useHoverFloatingInteraction(floatingContext, {
		enabled: hoverEnabled && !disabled && !isContextMenu && parent.type !== "menubar",
		closeDelay
	});
	const setPopupElement = store.useStateSetter("popupElement");
	const state = {
		transitionStatus,
		side,
		align,
		open,
		nested: parent.type === "menu",
		instant: instantType
	};
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		stateAttributesMapping: popupTransitionStateMapping,
		props: [
			popupProps,
			{ onKeyDown(event) {
				if (insideToolbar && COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
			} },
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps,
			{ "data-rootownerid": rootId }
		]
	});
	let returnFocus = parent.type === void 0 || isContextMenu;
	if (activeTriggerElement || parent.type === "menubar" && lastOpenChangeReason !== "outside-press") returnFocus = true;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingContext,
		openInteractionType: openMethod,
		modal: isContextMenu,
		disabled: !mounted,
		returnFocus: finalFocus === void 0 ? returnFocus : finalFocus,
		initialFocus: parent.type !== "menu",
		restoreFocus: true,
		externalTree: parent.type !== "menubar" ? floatingTreeRoot : void 0,
		previousFocusableElement: activeTriggerElement,
		nextFocusableElement: parent.type === void 0 ? store.context.triggerFocusTargetRef : void 0,
		beforeContentFocusGuardRef: parent.type === void 0 ? store.context.beforeContentFocusGuardRef : void 0,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/portal/MenuPortalContext.mjs
var MenuPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuPortalContext() {
	const value = import_react.useContext(MenuPortalContext);
	if (value === void 0) throw new Error(formatErrorMessage(32));
	return value;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/portal/MenuPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPortal = /*#__PURE__*/ import_react.forwardRef(function MenuPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const { store } = useMenuRootContext();
	if (!(store.useState("mounted") || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/positioner/MenuPositioner.mjs
/**
* Positions the menu popup against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPositioner = /*#__PURE__*/ import_react.forwardRef(function MenuPositioner(componentProps, forwardedRef) {
	const { anchor: anchorProp, positionMethod: positionMethodProp = "absolute", className, render, side, align: alignProp, sideOffset: sideOffsetProp = 0, alignOffset: alignOffsetProp = 0, collisionBoundary = "clipping-ancestors", collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance: collisionAvoidanceProp = DROPDOWN_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const keepMounted = useMenuPortalContext();
	const contextMenuContext = useContextMenuRootContext(true);
	const parent = store.useState("parent");
	const floatingRootContext = store.useState("floatingRootContext");
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const mounted = store.useState("mounted");
	const open = store.useState("open");
	const modal = store.useState("modal");
	const openMethod = store.useState("openMethod");
	const triggerElement = store.useState("activeTriggerElement");
	const transitionStatus = store.useState("transitionStatus");
	const positionerElement = store.useState("positionerElement");
	const instantType = store.useState("instantType");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const floatingNodeId = store.useState("floatingNodeId");
	const floatingParentNodeId = store.useState("floatingParentNodeId");
	const domReference = floatingRootContext.useState("domReferenceElement");
	const previousTriggerRef = import_react.useRef(null);
	const runOnceAnimationsFinish = useAnimationsFinished(positionerElement);
	let anchor = anchorProp;
	let sideOffset = sideOffsetProp;
	let alignOffset = alignOffsetProp;
	let align = alignProp;
	let collisionAvoidance = collisionAvoidanceProp;
	if (parent.type === "context-menu") {
		anchor = anchorProp ?? parent.context?.anchor;
		align = align ?? "start";
		if (!side && align !== "center") {
			alignOffset = componentProps.alignOffset ?? 2;
			sideOffset = componentProps.sideOffset ?? -5;
		}
	}
	let computedSide = side;
	let computedAlign = align;
	if (parent.type === "menu") {
		computedSide = computedSide ?? "inline-end";
		computedAlign = computedAlign ?? "start";
		collisionAvoidance = componentProps.collisionAvoidance ?? POPUP_COLLISION_AVOIDANCE;
	} else if (parent.type === "menubar") {
		computedSide = computedSide ?? (parent.context.orientation === "vertical" ? "inline-end" : "bottom");
		computedAlign = computedAlign ?? "start";
	}
	const contextMenu = parent.type === "context-menu";
	const positioner = useAnchorPositioning({
		anchor,
		floatingRootContext,
		positionMethod: contextMenuContext ? "fixed" : positionMethodProp,
		mounted,
		side: computedSide,
		sideOffset,
		align: computedAlign,
		alignOffset,
		arrowPadding: contextMenu ? 0 : arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		nodeId: floatingNodeId,
		keepMounted,
		disableAnchorTracking,
		collisionAvoidance,
		shift: contextMenu ? {
			crossAxis: !("side" in collisionAvoidance && collisionAvoidance.side === "flip"),
			rootBoundary: "layoutViewport"
		} : void 0,
		externalTree: floatingTreeRoot,
		adaptiveOrigin
	});
	import_react.useEffect(() => {
		function onMenuOpenChange(details) {
			if (details.open) {
				if (details.parentNodeId === floatingNodeId) store.set("hoverEnabled", false);
				if (details.nodeId !== floatingNodeId && details.parentNodeId === store.select("floatingParentNodeId")) store.setOpen(false, createChangeEventDetails(siblingOpen));
			}
		}
		floatingTreeRoot.events.on("menuopenchange", onMenuOpenChange);
		return () => {
			floatingTreeRoot.events.off("menuopenchange", onMenuOpenChange);
		};
	}, [
		store,
		floatingTreeRoot.events,
		floatingNodeId
	]);
	import_react.useEffect(() => {
		if (store.select("floatingParentNodeId") == null) return;
		function onParentClose(details) {
			if (details.open || details.nodeId !== store.select("floatingParentNodeId")) return;
			const reason = details.reason ?? "sibling-open";
			store.setOpen(false, createChangeEventDetails(reason));
		}
		floatingTreeRoot.events.on("menuopenchange", onParentClose);
		return () => {
			floatingTreeRoot.events.off("menuopenchange", onParentClose);
		};
	}, [floatingTreeRoot.events, store]);
	const closeTimeout = useTimeout();
	import_react.useEffect(() => {
		if (!open) closeTimeout.clear();
	}, [open, closeTimeout]);
	import_react.useEffect(() => {
		function onItemHover(event) {
			if (!open || event.nodeId !== store.select("floatingParentNodeId")) return;
			if (event.target && triggerElement && triggerElement !== event.target) {
				const delay = store.select("closeDelay");
				if (delay > 0) {
					if (!closeTimeout.isStarted()) closeTimeout.start(delay, () => {
						store.setOpen(false, createChangeEventDetails(siblingOpen));
					});
				} else store.setOpen(false, createChangeEventDetails(siblingOpen));
			} else closeTimeout.clear();
		}
		floatingTreeRoot.events.on("itemhover", onItemHover);
		return () => {
			floatingTreeRoot.events.off("itemhover", onItemHover);
		};
	}, [
		floatingTreeRoot.events,
		open,
		triggerElement,
		store,
		closeTimeout
	]);
	import_react.useEffect(() => {
		const eventDetails = {
			open,
			nodeId: floatingNodeId,
			parentNodeId: floatingParentNodeId,
			reason: store.select("lastOpenChangeReason")
		};
		floatingTreeRoot.events.emit("menuopenchange", eventDetails);
	}, [
		floatingTreeRoot.events,
		open,
		store,
		floatingNodeId,
		floatingParentNodeId
	]);
	useIsoLayoutEffect(() => {
		const currentTrigger = domReference;
		const previousTrigger = previousTriggerRef.current;
		if (currentTrigger) previousTriggerRef.current = currentTrigger;
		if (previousTrigger && currentTrigger && currentTrigger !== previousTrigger) {
			store.set("instantType", void 0);
			const abortController = new AbortController();
			runOnceAnimationsFinish(() => {
				store.set("instantType", "trigger-change");
			}, abortController.signal);
			return () => {
				abortController.abort();
			};
		}
	}, [
		domReference,
		runOnceAnimationsFinish,
		store
	]);
	const state = {
		open,
		side: positioner.side,
		align: positioner.align,
		anchorHidden: positioner.anchorHidden,
		nested: parent.type === "menu",
		instant: instantType
	};
	const menubarModal = parent.type === "menubar" && parent.context.modal;
	useAnchoredPopupScrollLock(open && (menubarModal || modal && lastOpenChangeReason !== "trigger-hover"), openMethod === "touch", positionerElement, triggerElement);
	const element = usePositioner(componentProps, state, {
		styles: positioner.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, store.useStateSetter("positionerElement")],
		hidden: !mounted,
		inert: !open
	});
	const shouldRenderBackdrop = mounted && parent.type !== "menu" && (parent.type !== "menubar" && modal && lastOpenChangeReason !== "trigger-hover" || parent.type === "menubar" && parent.context.modal);
	let backdropCutout = null;
	if (parent.type === "menubar") backdropCutout = parent.context.contentElement;
	else if (parent.type === void 0) backdropCutout = triggerElement;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(MenuPositionerContext.Provider, {
		value: positioner,
		children: [shouldRenderBackdrop && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
			ref: parent.type === "context-menu" || parent.type === "nested-context-menu" ? parent.context.internalBackdropRef : null,
			inert: inertValue(!open),
			cutout: backdropCutout
		}), /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingNode, {
			id: floatingNodeId,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
				elementsRef: store.context.itemDomElements,
				labelsRef: store.context.itemLabels,
				children: element
			})
		})]
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroupContext.mjs
var MenuRadioGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuRadioGroupContext() {
	const context = import_react.useContext(MenuRadioGroupContext);
	if (context === void 0) throw new Error(formatErrorMessage(34));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroup.mjs
/**
* Groups related radio items.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuRadioGroup = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function MenuRadioGroup(componentProps, forwardedRef) {
	const { render, className, value: valueProp, defaultValue, onValueChange: onValueChangeProp, disabled = false, style, "aria-labelledby": ariaLabelledByProp, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState(void 0);
	const [value, setValueUnwrapped] = useControlled({
		controlled: valueProp,
		default: defaultValue,
		name: "MenuRadioGroup"
	});
	const setValue = useStableCallback((newValue, eventDetails) => {
		onValueChangeProp?.(newValue, eventDetails);
		if (eventDetails.isCanceled) return;
		setValueUnwrapped(newValue);
	});
	const element = useRenderElement("div", componentProps, {
		state: { disabled },
		ref: forwardedRef,
		props: {
			role: "group",
			"aria-labelledby": ariaLabelledByProp ?? labelId,
			"aria-disabled": disabled || void 0,
			...elementProps
		}
	});
	const context = import_react.useMemo(() => ({
		value,
		setValue,
		disabled
	}), [
		value,
		setValue,
		disabled
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuGroupContext.Provider, {
		value: setLabelId,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioGroupContext.Provider, {
			value: context,
			children: element
		})
	});
}));
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/radio-item/MenuRadioItemContext.mjs
var MenuRadioItemContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuRadioItemContext() {
	const context = import_react.useContext(MenuRadioItemContext);
	if (context === void 0) throw new Error(formatErrorMessage(35));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/radio-item/MenuRadioItem.mjs
/**
* A menu item that works like a radio button in a given group.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuRadioItem = /*#__PURE__*/ import_react.forwardRef(function MenuRadioItem(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = false, value, style, ...elementProps } = componentProps;
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const menuPositionerContext = useMenuPositionerContext(true);
	const id = useBaseUiId(idProp);
	const { store } = useMenuRootContext();
	const highlighted = store.useState("isActive", listItem.index);
	const itemProps = store.useState("itemProps");
	const { value: selectedValue, setValue: setSelectedValue, disabled: groupDisabled } = useMenuRadioGroupContext();
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp || groupDisabled || rootDisabled;
	const checked = selectedValue === value;
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick,
		disabled,
		highlighted,
		id,
		store,
		nativeButton,
		nodeId: menuPositionerContext?.context.nodeId,
		itemMetadata: REGULAR_ITEM
	});
	const state = import_react.useMemo(() => ({
		disabled,
		highlighted,
		checked
	}), [
		disabled,
		highlighted,
		checked
	]);
	function handleClick(event) {
		const details = createChangeEventDetails(itemPress, event.nativeEvent, void 0, { preventUnmountOnClose: NOOP });
		setSelectedValue(value, details);
	}
	const element = useRenderElement("div", componentProps, {
		state,
		stateAttributesMapping: itemMapping,
		props: [
			itemProps,
			{
				role: "menuitemradio",
				"aria-checked": checked,
				onClick: handleClick
			},
			elementProps,
			getItemProps
		],
		ref: [
			itemRef,
			forwardedRef,
			listItem.ref
		]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioItemContext.Provider, {
		value: state,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/radio-item-indicator/MenuRadioItemIndicator.mjs
/**
* Indicates whether the radio item is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuRadioItemIndicator = /*#__PURE__*/ import_react.forwardRef(function MenuRadioItemIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const item = useMenuRadioItemContext();
	const indicatorRef = import_react.useRef(null);
	const { transitionStatus, mounted, setMounted } = useTransitionStatus(item.checked);
	useOpenChangeComplete({
		open: item.checked,
		ref: indicatorRef,
		onComplete() {
			if (!item.checked) setMounted(false);
		}
	});
	const state = {
		checked: item.checked,
		disabled: item.disabled,
		highlighted: item.highlighted,
		transitionStatus
	};
	return useRenderElement("span", componentProps, {
		state,
		stateAttributesMapping: itemMapping,
		ref: [forwardedRef, indicatorRef],
		props: {
			"aria-hidden": true,
			...elementProps
		},
		enabled: keepMounted || mounted
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menubar/MenubarContext.mjs
var MenubarContext = /*#__PURE__*/ import_react.createContext(null);
function useMenubarContext(optional) {
	const context = import_react.useContext(MenubarContext);
	if (context === null && !optional) throw new Error(formatErrorMessage(5));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/store/MenuStore.mjs
var selectors$1 = {
	...popupStoreSelectors,
	disabled: (state) => state.parent.type === "menubar" ? state.parent.context.disabled || state.disabled : state.disabled,
	modal: (state) => (state.parent.type === void 0 || state.parent.type === "context-menu") && (state.modal ?? true),
	openMethod: (state) => state.openMethod,
	allowMouseEnter: (state) => state.allowMouseEnter,
	highlightItemOnHover: (state) => state.highlightItemOnHover,
	parent: (state) => state.parent,
	rootId: (state) => {
		if (state.parent.type === "menu") return state.parent.store.select("rootId");
		return state.parent.type !== void 0 ? state.parent.context.rootId : state.rootId;
	},
	activeIndex: (state) => state.activeIndex,
	isActive: (state, itemIndex) => state.activeIndex === itemIndex,
	hoverEnabled: (state) => state.hoverEnabled,
	instantType: (state) => state.instantType,
	lastOpenChangeReason: (state) => state.openChangeReason,
	floatingTreeRoot: (state) => {
		if (state.parent.type === "menu") return state.parent.store.select("floatingTreeRoot");
		return state.floatingTreeRoot;
	},
	floatingNodeId: (state) => state.floatingNodeId,
	floatingParentNodeId: (state) => state.floatingParentNodeId,
	itemProps: (state) => state.itemProps,
	closeDelay: (state) => state.closeDelay,
	adaptiveOrigin: (state) => state.adaptiveOrigin,
	keyboardEventRelay: (state) => {
		if (state.keyboardEventRelay) return state.keyboardEventRelay;
		if (state.parent.type === "menu") return state.parent.store.select("keyboardEventRelay");
	}
};
/**
* The store view that detached handle-backed triggers read from. Both the real `MenuStore` and the
* inert fallback store satisfy it, so a trigger can read from whichever store the handle currently
* exposes. Narrowed to the members a trigger actually uses — the trigger-data members plus `setOpen`
* (called by the focus guards) — so the exposed surface can't bypass the open-change pipeline; on
* the detached fallback store every one of these mutations is a no-op.
*/
var MenuStore = class extends ReactStore {
	constructor(initialState) {
		super({
			...createInitialState$1(),
			...initialState
		}, createInitialContext$1(), selectors$1);
		this.unsubscribeParentListener = this.observe("parent", (parent) => {
			this.unsubscribeParentListener?.();
			if (parent.type === "menu") {
				let rootId = parent.store.select("rootId");
				let floatingTreeRoot = parent.store.select("floatingTreeRoot");
				let keyboardEventRelay = parent.store.select("keyboardEventRelay");
				this.unsubscribeParentListener = parent.store.subscribe(() => {
					const nextRootId = parent.store.select("rootId");
					const nextFloatingTreeRoot = parent.store.select("floatingTreeRoot");
					const nextKeyboardEventRelay = parent.store.select("keyboardEventRelay");
					if (rootId === nextRootId && floatingTreeRoot === nextFloatingTreeRoot && keyboardEventRelay === nextKeyboardEventRelay) return;
					rootId = nextRootId;
					floatingTreeRoot = nextFloatingTreeRoot;
					keyboardEventRelay = nextKeyboardEventRelay;
					this.notifyAll();
				});
				this.context.allowMouseUpTriggerRef = parent.store.context.allowMouseUpTriggerRef;
				return;
			}
			if (parent.type !== void 0) this.context.allowMouseUpTriggerRef = parent.context.allowMouseUpTriggerRef;
			this.unsubscribeParentListener = null;
		});
	}
	setOpen(open, eventDetails) {
		this.state.floatingRootContext.context.events.emit("setOpen", {
			open,
			eventDetails
		});
	}
	unsubscribeParentListener = null;
};
function createInitialContext$1() {
	return {
		positionerRef: /*#__PURE__*/ import_react.createRef(),
		popupRef: /*#__PURE__*/ import_react.createRef(),
		typingRef: { current: false },
		itemDomElements: { current: [] },
		itemLabels: { current: [] },
		allowMouseUpTriggerRef: { current: false },
		triggerFocusTargetRef: /*#__PURE__*/ import_react.createRef(),
		beforeContentFocusGuardRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChangeComplete: void 0,
		triggerElements: new PopupTriggerMap()
	};
}
function createInitialState$1() {
	return {
		...createInitialPopupStoreState(),
		disabled: false,
		modal: true,
		openMethod: null,
		allowMouseEnter: false,
		highlightItemOnHover: true,
		parent: { type: void 0 },
		rootId: void 0,
		activeIndex: null,
		hoverEnabled: true,
		instantType: void 0,
		openChangeReason: null,
		floatingTreeRoot: new FloatingTreeStore(),
		floatingNodeId: void 0,
		floatingParentNodeId: null,
		itemProps: EMPTY_OBJECT,
		keyboardEventRelay: void 0,
		closeDelay: 0,
		adaptiveOrigin: void 0
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs
var MenuSubmenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useMenuSubmenuRootContext() {
	return import_react.useContext(MenuSubmenuRootContext);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/root/MenuRoot.mjs
/**
* Groups all parts of the menu.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuRoot = fastComponent(function MenuRoot(props) {
	const { children, open: openProp, onOpenChange, onOpenChangeComplete, defaultOpen = false, disabled: disabledProp = false, modal: modalProp, loopFocus = true, orientation = "vertical", actionsRef, closeParentOnEsc = false, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, highlightItemOnHover = true } = props;
	const contextMenuContext = useContextMenuRootContext(true);
	const parentMenuRootContext = useMenuRootContext(true);
	const menubarContext = useMenubarContext(true);
	const isSubmenu = useMenuSubmenuRootContext();
	const parentFromContext = import_react.useMemo(() => {
		if (isSubmenu && parentMenuRootContext) return {
			type: "menu",
			store: parentMenuRootContext.store
		};
		if (menubarContext) return {
			type: "menubar",
			context: menubarContext
		};
		if (contextMenuContext && !parentMenuRootContext) return {
			type: "context-menu",
			context: contextMenuContext
		};
		return { type: void 0 };
	}, [
		contextMenuContext,
		parentMenuRootContext,
		menubarContext,
		isSubmenu
	]);
	const store = useMenuRootStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp,
		parent: parentFromContext
	});
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const rootId = useId$3();
	const floatingId = useId$3();
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const floatingNodeIdFromContext = useFloatingNodeId(floatingTreeRoot);
	const floatingParentNodeIdFromContext = useFloatingParentNodeId();
	const open = store.useState("open");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const positionerElement = store.useState("positionerElement");
	const hoverEnabled = store.useState("hoverEnabled");
	const disabled = store.useState("disabled");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const parent = store.useState("parent");
	const activeIndex = store.useState("activeIndex");
	const payload = store.useState("payload");
	const floatingParentNodeId = store.useState("floatingParentNodeId");
	const openEventRef = import_react.useRef(null);
	const allowOutsidePressDismissalRef = import_react.useRef(parent.type !== "context-menu");
	const allowOutsidePressDismissalTimeout = useTimeout();
	const allowTouchToCloseRef = import_react.useRef(true);
	const allowTouchToCloseTimeout = useTimeout();
	const nested = floatingParentNodeId != null;
	const { openMethod, triggerProps: interactionTypeProps } = useOpenInteractionType(open);
	store.useSyncedValues({
		disabled: disabledProp,
		highlightItemOnHover,
		modal: parent.type === void 0 ? modalProp : void 0,
		openMethod,
		rootId
	});
	useImplicitActiveTrigger(store);
	const { forceUnmount } = useOpenStateTransitions(open, store, () => {
		store.set("allowMouseEnter", false);
	});
	useIsoLayoutEffect(() => {
		if (contextMenuContext && !parentMenuRootContext) store.update({
			parent: {
				type: "context-menu",
				context: contextMenuContext
			},
			floatingNodeId: floatingNodeIdFromContext,
			floatingParentNodeId: floatingParentNodeIdFromContext
		});
		else if (parentMenuRootContext) store.update({
			floatingNodeId: floatingNodeIdFromContext,
			floatingParentNodeId: floatingParentNodeIdFromContext
		});
	}, [
		contextMenuContext,
		parentMenuRootContext,
		floatingNodeIdFromContext,
		floatingParentNodeIdFromContext,
		store
	]);
	import_react.useEffect(() => {
		if (!open) openEventRef.current = null;
		if (parent.type !== "context-menu") return;
		if (!open) {
			allowOutsidePressDismissalTimeout.clear();
			allowOutsidePressDismissalRef.current = false;
			return;
		}
		allowOutsidePressDismissalTimeout.start(500, () => {
			allowOutsidePressDismissalRef.current = true;
		});
	}, [
		allowOutsidePressDismissalTimeout,
		open,
		parent.type
	]);
	useIsoLayoutEffect(() => {
		if (!open && !hoverEnabled) store.set("hoverEnabled", true);
	}, [
		open,
		hoverEnabled,
		store
	]);
	const setOpen = useStableCallback((nextOpen, eventDetails) => {
		const reason = eventDetails.reason;
		if (!nextOpen && !store.select("open")) return;
		if (open === nextOpen && eventDetails.trigger === activeTriggerElement && lastOpenChangeReason === reason) return;
		const shouldPreventUnmountOnClose = attachPreventUnmountOnClose(eventDetails);
		if (!nextOpen && eventDetails.trigger == null) eventDetails.trigger = activeTriggerElement ?? void 0;
		onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		store.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		const nativeEvent = eventDetails.event;
		if (nextOpen === false && nativeEvent?.type === "click" && nativeEvent.pointerType === "touch" && !allowTouchToCloseRef.current) return;
		if (nextOpen && reason === "trigger-focus") {
			allowTouchToCloseRef.current = false;
			allowTouchToCloseTimeout.start(300, () => {
				allowTouchToCloseRef.current = true;
			});
		} else {
			allowTouchToCloseRef.current = true;
			allowTouchToCloseTimeout.clear();
		}
		const isKeyboardClick = (reason === "trigger-press" || reason === "item-press") && nativeEvent.detail === 0;
		const isDismissClose = !nextOpen && (reason === "escape-key" || reason == null);
		const updatedState = {
			open: nextOpen,
			openChangeReason: reason
		};
		openEventRef.current = eventDetails.event;
		setPopupOpenState(updatedState, nextOpen, eventDetails.trigger, shouldPreventUnmountOnClose());
		store.update(updatedState);
		if (parent.type === "menubar" && (reason === "trigger-focus" || reason === "focus-out" || reason === "trigger-hover" || reason === "list-navigation" || reason === "sibling-open")) store.set("instantType", "group");
		else if (isKeyboardClick || isDismissClose) store.set("instantType", isKeyboardClick ? "click" : "dismiss");
		else store.set("instantType", void 0);
	});
	const floatingRootContext = useSyncedFloatingRootContext({
		popupStore: store,
		floatingId,
		nested: floatingParentNodeIdFromContext != null,
		onOpenChange: setOpen
	});
	const floatingEvents = floatingRootContext.context.events;
	useIsoLayoutEffect(() => {
		const handleSetOpenEvent = ({ open: nextOpen, eventDetails }) => setOpen(nextOpen, eventDetails);
		floatingEvents.on("setOpen", handleSetOpenEvent);
		return () => {
			floatingEvents?.off("setOpen", handleSetOpenEvent);
		};
	}, [floatingEvents, setOpen]);
	const handleImperativeClose = import_react.useCallback(() => {
		store.setOpen(false, createChangeEventDetails(imperativeAction));
	}, [store]);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: handleImperativeClose
	}), [forceUnmount, handleImperativeClose]);
	let ctx;
	if (parent.type === "context-menu") ctx = parent.context;
	import_react.useImperativeHandle(ctx?.positionerRef, () => positionerElement, [positionerElement]);
	import_react.useImperativeHandle(ctx?.actionsRef, () => ({ setOpen }), [setOpen]);
	const dismiss = useDismiss(floatingRootContext, {
		enabled: !disabled,
		bubbles: { escapeKey: closeParentOnEsc && parent.type === "menu" },
		outsidePress() {
			if (parent.type !== "context-menu" || openEventRef.current?.type === "contextmenu") return true;
			return allowOutsidePressDismissalRef.current;
		},
		externalTree: nested ? floatingTreeRoot : void 0
	});
	const direction = useDirection();
	const setActiveIndex = import_react.useCallback((index) => {
		if (store.select("activeIndex") === index) return;
		store.set("activeIndex", index);
	}, [store]);
	const listNavigation$1 = useListNavigation(floatingRootContext, {
		enabled: !disabled,
		listRef: store.context.itemDomElements,
		activeIndex,
		nested: parent.type !== void 0,
		loopFocus,
		orientation,
		parentOrientation: parent.type === "menubar" ? parent.context.orientation : void 0,
		rtl: direction === "rtl",
		disabledIndices: EMPTY_ARRAY,
		onNavigate: setActiveIndex,
		openOnArrowKeyDown: parent.type !== "context-menu",
		externalTree: nested ? floatingTreeRoot : void 0,
		focusItemOnHover: highlightItemOnHover
	});
	const onTyping = import_react.useCallback((nextTyping) => {
		store.context.typingRef.current = nextTyping;
	}, [store]);
	const typeahead = useTypeahead(floatingRootContext, {
		enabled: !disabled,
		listRef: store.context.itemLabels,
		elementsRef: store.context.itemDomElements,
		activeIndex,
		resetMs: 500,
		onMatch: (index) => {
			if (open && index !== activeIndex) store.set("activeIndex", index);
		},
		onTyping
	});
	const activeTriggerProps = import_react.useMemo(() => {
		const mergedProps = mergeProps(typeahead.reference, listNavigation$1.reference, dismiss.reference, { onMouseMove() {
			store.set("allowMouseEnter", true);
		} }, interactionTypeProps);
		mergedProps["aria-haspopup"] = "menu";
		mergedProps["aria-expanded"] = open;
		return mergedProps;
	}, [
		store,
		typeahead.reference,
		listNavigation$1.reference,
		dismiss.reference,
		interactionTypeProps,
		open
	]);
	const inactiveTriggerProps = import_react.useMemo(() => {
		const mergedProps = mergeProps(listNavigation$1.trigger, dismiss.trigger, interactionTypeProps);
		mergedProps["aria-haspopup"] = "menu";
		mergedProps["aria-expanded"] = false;
		return mergedProps;
	}, [
		listNavigation$1.trigger,
		dismiss.trigger,
		interactionTypeProps
	]);
	const popupProps = import_react.useMemo(() => mergeProps(FOCUSABLE_POPUP_PROPS, {
		id: floatingId,
		role: "menu",
		"aria-labelledby": activeTriggerElement?.id,
		onMouseMove() {
			store.set("allowMouseEnter", true);
			if (parent.type === "menu") store.set("hoverEnabled", false);
		},
		onClick() {
			if (store.select("hoverEnabled")) store.set("hoverEnabled", false);
		},
		onKeyDown(event) {
			const relay = store.select("keyboardEventRelay");
			if (relay && !event.isPropagationStopped()) relay(event);
		}
	}, typeahead.floating, listNavigation$1.floating, dismiss.floating), [
		activeTriggerElement,
		floatingId,
		parent.type,
		store,
		typeahead.floating,
		listNavigation$1.floating,
		dismiss.floating
	]);
	const itemProps = listNavigation$1.item ?? EMPTY_OBJECT;
	usePopupInteractionProps(store, {
		floatingRootContext,
		activeTriggerProps,
		inactiveTriggerProps,
		popupProps,
		itemProps
	});
	const context = import_react.useMemo(() => ({
		store,
		parent: parentFromContext
	}), [store, parentFromContext]);
	const content = /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(MenuRootContext.Provider, {
		value: context,
		children: [handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
			handle,
			store
		}), typeof children === "function" ? children({ payload }) : children]
	});
	if (parent.type === void 0 || parent.type === "context-menu") return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingTree, {
		externalTree: floatingTreeRoot,
		children: content
	});
	return content;
});
function useMenuRootStore(initialState) {
	return useRefWithInit(() => new MenuStore(initialState)).current;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/internals/composite/item/CompositeItem.mjs
function CompositeItem(componentProps) {
	const { render, className, style, state = EMPTY_OBJECT, props = EMPTY_ARRAY, refs = EMPTY_ARRAY, metadata, stateAttributesMapping, tag = "div", ...elementProps } = componentProps;
	const { compositeProps, compositeRef } = useCompositeItem({ metadata });
	return useRenderElement(tag, componentProps, {
		state,
		ref: [compositeRef, ...refs],
		props: [
			compositeProps,
			...props,
			elementProps
		],
		stateAttributesMapping
	});
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/utils/findRootOwnerId.mjs
function findRootOwnerId(node) {
	if (isHTMLElement(node) && node.hasAttribute("data-rootownerid")) return node.getAttribute("data-rootownerid");
	if (isLastTraversableNode(node)) return;
	return findRootOwnerId(getParentNode(node));
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/popups/useTriggerFocusGuards.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* Minimal store interface required by the focus guard hook.
* Both PopoverStore and MenuStore satisfy this interface.
*/
/**
* Provides focus guard handlers for popup triggers (Popover, Menu).
*
* When the popup is open, invisible focus guard elements are placed before and after
* the trigger. These handlers close the popup and move focus to the appropriate
* tabbable element when the guards receive focus (i.e. when the user tabs out).
*/
function useTriggerFocusGuards(store, triggerElementRef) {
	const preFocusGuardRef = import_react.useRef(null);
	function handlePreFocusGuardFocus(event) {
		import_react_dom.flushSync(() => {
			store.setOpen(false, createChangeEventDetails(focusOut, event.nativeEvent, event.currentTarget));
		});
		getTabbableBeforeElement(preFocusGuardRef.current)?.focus();
	}
	function handleFocusTargetFocus(event) {
		const positionerElement = store.select("positionerElement");
		if (positionerElement && isOutsideEvent(event, positionerElement)) store.context.beforeContentFocusGuardRef.current?.focus();
		else {
			import_react_dom.flushSync(() => {
				store.setOpen(false, createChangeEventDetails(focusOut, event.nativeEvent, event.currentTarget));
			});
			let nextTabbable = getTabbableAfterElement(store.context.triggerFocusTargetRef.current || triggerElementRef.current);
			while (nextTabbable !== null && contains(positionerElement, nextTabbable)) {
				const prevTabbable = nextTabbable;
				nextTabbable = getNextTabbable(nextTabbable);
				if (nextTabbable === prevTabbable) break;
			}
			nextTabbable?.focus();
		}
	}
	return {
		preFocusGuardRef,
		handlePreFocusGuardFocus,
		handleFocusTargetFocus
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/useMixedToggleClickHandler.mjs
/**
* Returns `click` and `mousedown` handlers that fix the behavior of triggers of popups that are toggled by different events.
* For example, a button that opens a popup on mousedown and closes it on click.
* This hook prevents the popup from closing immediately after the mouse button is released.
*/
function useMixedToggleClickHandler(params) {
	const { enabled = true, mouseDownAction, open } = params;
	const ignoreClickRef = import_react.useRef(false);
	return import_react.useMemo(() => {
		if (!enabled) return EMPTY_OBJECT;
		return {
			onMouseDown: (event) => {
				if (mouseDownAction === "open" && !open || mouseDownAction === "close" && open) {
					ignoreClickRef.current = true;
					ownerDocument(event.currentTarget).addEventListener("click", () => {
						ignoreClickRef.current = false;
					}, { once: true });
				}
			},
			onClick: (event) => {
				if (ignoreClickRef.current) {
					ignoreClickRef.current = false;
					event.preventBaseUIHandler();
				}
			}
		};
	}, [
		enabled,
		mouseDownAction,
		open
	]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/menu/trigger/MenuTrigger.mjs
/**
* A button that opens the menu.
* Renders a `<button>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuTrigger = fastComponentRef(function MenuTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled: disabledProp = false, nativeButton = true, id: idProp, openOnHover: openOnHoverProp, delay = 100, closeDelay = 0, handle, payload, ...elementProps } = componentProps;
	const rootContext = useMenuRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootContext?.store;
	if (!store) throw new Error(formatErrorMessage(85));
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const floatingRootContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const parent = useMenuParent();
	const compositeRootContext = useCompositeRootContext(true);
	const floatingTreeRootFromContext = useFloatingTree();
	const floatingTreeRoot = import_react.useMemo(() => {
		return floatingTreeRootFromContext ?? new FloatingTreeStore();
	}, [floatingTreeRootFromContext]);
	const floatingNodeId = useFloatingNodeId(floatingTreeRoot);
	const floatingParentNodeId = useFloatingParentNodeId();
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		closeDelay,
		parent,
		floatingTreeRoot,
		floatingNodeId,
		floatingParentNodeId,
		keyboardEventRelay: compositeRootContext?.relayKeyboardEvent
	});
	const isInMenubar = parent.type === "menubar";
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp || rootDisabled || isInMenubar && parent.context.disabled;
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	import_react.useEffect(() => {
		if (!isOpenedByThisTrigger && parent.type === void 0) store.context.allowMouseUpTriggerRef.current = false;
	}, [
		store,
		isOpenedByThisTrigger,
		parent.type
	]);
	const triggerRef = import_react.useRef(null);
	const allowMouseUpTriggerTimeout = useTimeout();
	const handleDocumentMouseUp = useStableCallback((mouseEvent) => {
		if (!triggerRef.current) return;
		allowMouseUpTriggerTimeout.clear();
		store.context.allowMouseUpTriggerRef.current = false;
		const mouseUpTarget = mouseEvent.target;
		if (contains(triggerRef.current, mouseUpTarget) || contains(store.select("positionerElement"), mouseUpTarget) || mouseUpTarget === triggerRef.current) return;
		if (mouseUpTarget != null && findRootOwnerId(mouseUpTarget) === store.select("rootId")) return;
		if (isMouseWithinBounds(mouseEvent, triggerRef.current)) return;
		floatingTreeRoot.events.emit("close", {
			domEvent: mouseEvent,
			reason: cancelOpen
		});
	});
	import_react.useEffect(() => {
		if (isOpenedByThisTrigger && store.select("lastOpenChangeReason") === "trigger-hover") ownerDocument(triggerRef.current).addEventListener("mouseup", handleDocumentMouseUp, { once: true });
	}, [
		isOpenedByThisTrigger,
		handleDocumentMouseUp,
		store
	]);
	const parentMenubarHasSubmenuOpen = isInMenubar && parent.context.hasSubmenuOpen;
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		enabled: (openOnHoverProp ?? parentMenubarHasSubmenuOpen) && !disabled && (!isInMenubar || parentMenubarHasSubmenuOpen && !isMountedByThisTrigger),
		handleClose: safePolygon({ blockPointerEvents: !isInMenubar }),
		mouseOnly: true,
		move: false,
		restMs: parent.type === void 0 ? delay : void 0,
		delay: { close: closeDelay },
		triggerElementRef,
		externalTree: floatingTreeRoot,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending"
	});
	const stickIfOpen = useStickIfOpen(isOpenedByThisTrigger, store.select("lastOpenChangeReason"));
	const click = useClick(floatingRootContext, {
		enabled: !disabled,
		event: isOpenedByThisTrigger && isInMenubar ? "click" : "mousedown",
		toggle: true,
		ignoreMouse: false,
		stickIfOpen: parent.type === void 0 ? stickIfOpen : false
	});
	const focus = useFocus(floatingRootContext, { enabled: !disabled && parentMenubarHasSubmenuOpen });
	const mixedToggleHandlers = useMixedToggleClickHandler({
		open: isOpenedByThisTrigger,
		enabled: isInMenubar,
		mouseDownAction: "open"
	});
	const localInteractionProps = import_react.useMemo(() => mergeProps(focus.reference, click.reference), [focus.reference, click.reference]);
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	const { preFocusGuardRef, handlePreFocusGuardFocus, handleFocusTargetFocus } = useTriggerFocusGuards(store, triggerElementRef);
	const state = {
		disabled,
		open: isOpenedByThisTrigger
	};
	const ref = [
		triggerRef,
		forwardedRef,
		buttonRef,
		registerTrigger,
		triggerElementRef
	];
	const props = [
		localInteractionProps,
		hoverProps ?? EMPTY_OBJECT,
		rootTriggerProps,
		{
			"aria-haspopup": "menu",
			"aria-controls": popupId,
			id: thisTriggerId,
			onMouseDown: (event) => {
				if (store.select("open")) return;
				allowMouseUpTriggerTimeout.start(200, () => {
					store.context.allowMouseUpTriggerRef.current = true;
				});
				ownerDocument(event.currentTarget).addEventListener("mouseup", handleDocumentMouseUp, { once: true });
			}
		},
		isInMenubar ? { role: "menuitem" } : {},
		mixedToggleHandlers,
		elementProps,
		getButtonProps
	];
	const element = useRenderElement("button", componentProps, {
		enabled: !isInMenubar,
		stateAttributesMapping: pressableTriggerOpenStateMapping,
		state,
		ref,
		props
	});
	if (isInMenubar) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
		tag: "button",
		render,
		className,
		style,
		state,
		refs: ref,
		props,
		stateAttributesMapping: pressableTriggerOpenStateMapping
	});
	if (isOpenedByThisTrigger) return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: preFocusGuardRef,
			onFocus: handlePreFocusGuardFocus
		}, `${thisTriggerId}-pre-focus-guard`),
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: element }, thisTriggerId),
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: store.context.triggerFocusTargetRef,
			onFocus: handleFocusTargetFocus
		}, `${thisTriggerId}-post-focus-guard`)
	] });
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: element }, thisTriggerId);
});
/**
* Determines whether to ignore clicks after a hover-open.
*/
function useStickIfOpen(open, openReason) {
	const stickIfOpenTimeout = useTimeout();
	const [stickIfOpen, setStickIfOpen] = import_react.useState(false);
	useIsoLayoutEffect(() => {
		if (open && openReason === "trigger-hover") {
			setStickIfOpen(true);
			stickIfOpenTimeout.start(500, () => {
				setStickIfOpen(false);
			});
		} else if (!open) {
			stickIfOpenTimeout.clear();
			setStickIfOpen(false);
		}
	}, [
		open,
		openReason,
		stickIfOpenTimeout
	]);
	return stickIfOpen;
}
function useMenuParent() {
	const menubarContext = useMenubarContext(true);
	return import_react.useMemo(() => {
		if (menubarContext) return {
			type: "menubar",
			context: menubarContext
		};
		return { type: void 0 };
	}, [menubarContext]);
}
//#endregion
//#region src/components/ui/dropdown-menu.tsx
var import_client = require_client();
function DropdownMenu({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRoot, {
		"data-slot": "dropdown-menu",
		...props
	});
}
function DropdownMenuTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuTrigger, {
		"data-slot": "dropdown-menu-trigger",
		...props
	});
}
function DropdownMenuContent({ align = "start", alignOffset = 0, side = "bottom", sideOffset = 4, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPositioner, {
		className: "isolate z-50 outline-none",
		align,
		alignOffset,
		side,
		sideOffset,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuPopup, {
			"data-slot": "dropdown-menu-content",
			className: cn("z-50 max-h-(--available-height) w-(--anchor-width) min-w-32 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-md bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:overflow-hidden data-closed:fade-out-0 data-closed:zoom-out-95", className),
			...props
		})
	}) });
}
function DropdownMenuGroup({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuGroup, {
		"data-slot": "dropdown-menu-group",
		...props
	});
}
function DropdownMenuLabel({ className, inset, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuGroupLabel, {
		"data-slot": "dropdown-menu-label",
		"data-inset": inset,
		className: cn("px-2 py-1.5 text-xs font-medium text-muted-foreground data-inset:pl-8", className),
		...props
	});
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
		"data-slot": "dropdown-menu-item",
		"data-inset": inset,
		"data-variant": variant,
		className: cn("group/dropdown-menu-item relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-8 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[variant=destructive]:*:[svg]:text-destructive", className),
		...props
	});
}
function DropdownMenuRadioGroup({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRadioGroup, {
		"data-slot": "dropdown-menu-radio-group",
		...props
	});
}
function DropdownMenuRadioItem({ className, children, inset, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(MenuRadioItem, {
		"data-slot": "dropdown-menu-radio-item",
		"data-inset": inset,
		className: cn("relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-8 pl-2 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-8 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "pointer-events-none absolute right-2 flex items-center justify-center",
			"data-slot": "dropdown-menu-radio-item-indicator",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuRadioItemIndicator, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}) })
		}), children]
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {
		"data-slot": "dropdown-menu-separator",
		className: cn("-mx-1 my-1 h-px bg-border", className),
		...props
	});
}
//#endregion
//#region src/popup/snapshotEqual.ts
/**
* Compares the JSON-compatible snapshots returned by the extension message
* bus. Message responses are structured clones, so referential equality alone
* cannot tell whether a poll contains new information.
*/
function snapshotEqual(left, right) {
	if (Object.is(left, right)) return true;
	if (left === null || right === null || typeof left !== "object" || typeof right !== "object") return false;
	if (Array.isArray(left) || Array.isArray(right)) {
		if (!Array.isArray(left) || !Array.isArray(right)) return false;
		if (left.length !== right.length) return false;
		return left.every((value, index) => snapshotEqual(value, right[index]));
	}
	const leftRecord = left;
	const rightRecord = right;
	const leftKeys = Object.keys(leftRecord);
	const rightKeys = Object.keys(rightRecord);
	if (leftKeys.length !== rightKeys.length) return false;
	return leftKeys.every((key) => Object.hasOwn(rightRecord, key) && snapshotEqual(leftRecord[key], rightRecord[key]));
}
//#endregion
//#region src/popup/usePopupState.ts
function usePopupState() {
	const [state, setState] = (0, import_react.useState)({
		loading: true,
		connection: null,
		lastError: null,
		lastErrorReason: null,
		endpoint: null,
		server: null,
		backoff: null,
		recoveryExhaustedUnattended: false,
		degraded: false,
		capabilities: { taskReveal: false },
		pairingCode: null
	});
	const [switching, setSwitching] = (0, import_react.useState)(false);
	const stateRef = (0, import_react.useRef)(state);
	const stateVersionRef = (0, import_react.useRef)(0);
	const switchingRef = (0, import_react.useRef)(false);
	stateRef.current = state;
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		send("bg.clearBadgeError", void 0);
		const tick = async () => {
			if (switchingRef.current) return;
			const requestVersion = stateVersionRef.current;
			try {
				const [connection, endpoint] = await Promise.all([send("bg.getState", void 0), send("bg.getEndpointConfig", void 0)]);
				if (isErrorResponse(connection)) throw new Error(connection.error);
				if (isErrorResponse(endpoint)) throw new Error(endpoint.error);
				if (cancelled || switchingRef.current || requestVersion !== stateVersionRef.current) return;
				const nextState = {
					loading: false,
					connection: connection.state,
					lastError: connection.lastError ?? null,
					lastErrorReason: connection.lastErrorReason ?? null,
					endpoint,
					server: connection.server ?? null,
					backoff: connection.backoff ?? null,
					recoveryExhaustedUnattended: connection.recoveryExhaustedUnattended ?? false,
					degraded: connection.degraded ?? false,
					capabilities: { taskReveal: connection.capabilities?.taskReveal === true },
					pairingCode: connection.pairingCode ?? null
				};
				setState((current) => snapshotEqual(current, nextState) ? current : nextState);
			} catch (error) {
				if (cancelled || switchingRef.current || requestVersion !== stateVersionRef.current) return;
				setState((current) => {
					const nextState = {
						...current,
						loading: false,
						connection: "disconnected",
						lastError: error.message,
						lastErrorReason: null,
						server: null,
						capabilities: { taskReveal: false },
						recoveryExhaustedUnattended: false
					};
					return snapshotEqual(current, nextState) ? current : nextState;
				});
			}
		};
		tick();
		const t = setInterval(() => void tick(), 1e3);
		return () => {
			cancelled = true;
			clearInterval(t);
		};
	}, []);
	const reconnect = (0, import_react.useCallback)(async () => {
		const response = await send("bg.reconnect", void 0);
		if (isErrorResponse(response)) throw new Error(response.error);
	}, []);
	const submitPairingCode = (0, import_react.useCallback)(async (code) => {
		const response = await send("bg.submitPairingCode", { code });
		if (isErrorResponse(response)) throw new Error(response.error);
		if (!response.ok) throw new Error(response.error ?? "no pairing code request is pending");
	}, []);
	return {
		state,
		switching,
		reconnect,
		switchEndpoint: (0, import_react.useCallback)(async (endpointId) => {
			const currentEndpoint = stateRef.current.endpoint;
			if (!currentEndpoint || currentEndpoint.activeEndpointId === endpointId) return;
			if (endpointId !== "local" && !currentEndpoint.servers.some((server) => server.id === endpointId)) throw new Error("Motrix Server is not configured");
			switchingRef.current = true;
			stateVersionRef.current += 1;
			setSwitching(true);
			try {
				const activated = await send("bg.activateEndpoint", { endpointId });
				if (isErrorResponse(activated)) throw new Error(activated.error);
				setState((current) => ({
					...current,
					connection: "connecting",
					endpoint: activated.config,
					lastError: null,
					lastErrorReason: null,
					server: null,
					capabilities: { taskReveal: false }
				}));
			} finally {
				switchingRef.current = false;
				setSwitching(false);
			}
		}, []),
		submitPairingCode
	};
}
//#endregion
//#region src/popup/BackendSelector.tsx
var PENDING_STATES = /* @__PURE__ */ new Set([
	"bootstrapping",
	"connecting",
	"handshaking",
	"awaiting-code"
]);
function statusClass(connection) {
	if (connection === "connected") return "bg-connection-online";
	if (connection && PENDING_STATES.has(connection)) return "bg-connection-pending animate-pulse";
	return "bg-connection-offline";
}
function BackendSelector({ connection, endpoint, busy, onEndpointChange, onConfigureServer }) {
	const { t } = useTranslation();
	const localBackendAvailable = hasNativeMessagingSupport();
	const activeEndpointId = endpoint?.activeEndpointId ?? "local";
	const backendName = (endpoint?.servers.find((candidate) => candidate.id === activeEndpointId))?.name ?? t(localBackendAvailable ? "popup.backend.app" : "popup.backend.server");
	const statusLabel = t(`popup.status.${connection ?? "disconnected"}`);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			className: "h-8 w-full min-w-0 justify-start gap-2 rounded-[8px] px-2.5 text-sm shadow-xs",
			title: backendName,
			"aria-label": `${t("popup.backend.choose")}: ${backendName}, ${statusLabel}`,
			disabled: busy
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"aria-hidden": "true",
				className: cn("size-2 shrink-0 rounded-full", statusClass(connection))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 truncate text-left font-normal",
				children: backendName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: statusLabel
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
				className: "size-4 text-muted-foreground",
				"data-icon": "inline-end",
				"aria-hidden": "true"
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "start",
		className: "min-w-60",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioGroup, {
				value: activeEndpointId,
				onValueChange: onEndpointChange,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: t("popup.backend.choose") }),
					localBackendAvailable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem, {
						value: "local",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 flex-1 flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("popup.backend.app") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-xs text-muted-foreground",
								children: t("popup.backend.appDescription")
							})]
						})]
					}),
					endpoint?.servers.map((configuredServer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem, {
						value: configuredServer.id,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Server, { "aria-hidden": "true" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 flex-1 flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: configuredServer.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-xs text-muted-foreground",
								children: configuredServer.url
							})]
						})]
					}, configuredServer.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuGroup, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				onClick: onConfigureServer,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { "aria-hidden": "true" }), t("popup.backend.configureServer")]
			}) })
		]
	})] });
}
//#endregion
//#region src/popup/CompactPopupLayout.tsx
function CompactPopupHeader({ backend, takeoverChecked, takeoverDisabled, takeoverSupported = true, onTakeoverChange, onOpenSettings }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex min-h-8 shrink-0 flex-wrap items-center gap-x-4 gap-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 flex-[1_1_9rem]",
			children: backend
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 max-w-full flex-[1_1_auto] items-center justify-end gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-8 min-w-0 flex-1 items-center justify-end gap-2 text-sm font-normal",
				title: takeoverSupported ? void 0 : t("options.takeover.remoteUnavailable"),
				children: [
					!takeoverSupported && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						id: "popup-takeover-unavailable",
						className: "sr-only",
						children: t("options.takeover.remoteUnavailable")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 [overflow-wrap:anywhere]",
						children: t("popup.takeover.label")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "popup-takeover-switch",
						"data-testid": "takeover-switch",
						checked: takeoverChecked,
						disabled: takeoverDisabled,
						onCheckedChange: onTakeoverChange,
						"aria-label": t("popup.takeover.aria"),
						"aria-describedby": takeoverSupported ? void 0 : "popup-takeover-unavailable"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "icon-sm",
				className: "size-8 shrink-0 text-muted-foreground",
				"aria-label": t("popup.settings"),
				title: t("popup.settings"),
				onClick: onOpenSettings,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
					className: "size-[18px]",
					"aria-hidden": "true"
				})
			})]
		})]
	});
}
function CompactSectionToolbar({ title, controls, action, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-testid": "compact-section-toolbar",
		className: cn("flex min-h-8 shrink-0 flex-wrap items-center gap-x-3 gap-y-2", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "min-w-0 flex-[1_1_auto] text-lg/6 font-medium [overflow-wrap:anywhere]",
			children: title
		}), (controls || action) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 max-w-full flex-[1_1_auto] items-center justify-end gap-3",
			children: [controls && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-w-0 flex-1",
				children: controls
			}), action !== void 0 && action !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-8 shrink-0 items-center justify-center",
				children: action
			}) : null]
		})]
	});
}
function CompactContentCard({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		...props,
		className: cn("mt-3 min-h-48 min-w-0 flex-1 overflow-hidden rounded-[12px] border border-border bg-card shadow-card", className),
		children
	});
}
function PopupBottomNavigation() {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
		"data-testid": "bottom-tabs",
		className: "mx-auto mt-2 grid min-h-9 w-max min-w-0 max-w-full shrink-0 grid-cols-3 items-stretch gap-[3px] rounded-[12px] bg-tab-background p-[3px] group-data-horizontal/tabs:h-auto",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
				value: "tasks",
				"aria-label": t("popup.tabs.tasks"),
				title: t("popup.tabs.tasks"),
				className: "h-auto min-h-[30px] min-w-0 w-full flex-none flex-wrap gap-1 rounded-[8px] px-2 whitespace-normal text-xs font-normal shadow-none group-data-[variant=default]/tabs-list:data-active:shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListTodo, {
					className: "size-3.5",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 [overflow-wrap:anywhere]",
					children: t("popup.tabs.tasks")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
				value: "sniffer",
				"aria-label": t("popup.tabs.sniffer"),
				title: t("popup.tabs.sniffer"),
				className: "h-auto min-h-[30px] min-w-0 w-full flex-none flex-wrap gap-1 rounded-[8px] px-2 whitespace-normal text-xs font-normal shadow-none group-data-[variant=default]/tabs-list:data-active:shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, {
					className: "size-3.5",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 [overflow-wrap:anywhere]",
					children: t("popup.tabs.sniffer")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
				value: "settings",
				"aria-label": t("popup.tabs.settings"),
				title: t("popup.tabs.settings"),
				className: "h-auto min-h-[30px] min-w-0 w-full flex-none flex-wrap gap-1 rounded-[8px] px-2 whitespace-normal text-xs font-normal shadow-none group-data-[variant=default]/tabs-list:data-active:shadow-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
					className: "size-3.5",
					"aria-hidden": "true"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "min-w-0 [overflow-wrap:anywhere]",
					children: t("popup.tabs.settings")
				})]
			})
		]
	});
}
//#endregion
//#region src/background/mbp1/permission-gate.ts
/**
* Loopback host-permission gate for MBP1 candidate probing
* (bridge-pairing-protocol.md §4.1): before the extension fetches
* `http://127.0.0.1:<port>/discovery` on a candidate port, a Manifest V3
* extension needs host permission for that origin, or the fetch is blocked
* regardless of what the page/background script otherwise can do.
*
* **This gate is only a compatibility check today.** `manifest.config.ts` declares
* `host_permissions: ['<all_urls>']` as a *required* permission, granted
* unconditionally at install — and `<all_urls>` already covers
* `http://127.0.0.1/*`. The loopback origin is therefore deliberately not
* repeated in `optional_host_permissions`; browsers omit that redundant
* declaration and may emit a build warning. `<all_urls>` is not being narrowed
* by this module: it is load-bearing for other
* features (download takeover against arbitrary URLs, the `cookies`
* permission, dynamic `scripting` injection), and narrowing it is a separate
* project with its own regression surface.
*
* This gate remains as the check/request seam for a future least-privilege
* migration. Such a migration must add `http://127.0.0.1/*` to
* `optional_host_permissions` and call `requestLoopbackPermission()` directly
* from a user gesture; changing only `host_permissions` would break discovery.
*/
/** `http://127.0.0.1/*` — match patterns carry no port component in either
*  Chrome or Firefox, so this matches every candidate port MBP1 probes
*  (`http://127.0.0.1:<port>/discovery`), not just port 80. */
var LOOPBACK_ORIGINS = { origins: ["http://127.0.0.1/*"] };
/** `true` if the extension currently holds the loopback host permission.
*  `false` — never a rejection — when the Permissions API itself is absent,
*  which is the real remaining reason this can differ from `<all_urls>`'s
*  unconditional grant: older Firefox releases predate `browser.permissions`
*  entirely. */
async function hasLoopbackPermission() {
	if (typeof browser.permissions?.contains !== "function") return false;
	return await browser.permissions.contains(LOOPBACK_ORIGINS);
}
//#endregion
//#region src/components/ui/card.tsx
function Card({ className, size = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card",
		"data-size": size,
		className: cn("group/card flex flex-col gap-(--card-spacing) overflow-hidden rounded-xl bg-card py-(--card-spacing) text-sm text-card-foreground shadow-xs ring-1 ring-foreground/10 [--card-spacing:--spacing(6)] has-[>img:first-child]:pt-0 data-[size=sm]:[--card-spacing:--spacing(4)] *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "card-content",
		className: cn("px-(--card-spacing)", className),
		...props
	});
}
//#endregion
//#region src/popup/ConnectionStatusPanel.tsx
/**
* Seconds until a §7.3 backoff expires, ticking once a second while one is
* active. `0` means "no backoff in force" — the tick stops then, so an idle
* popup holds no timer.
*/
function useBackoffSecondsLeft(retryAtMs) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		if (retryAtMs === null || retryAtMs <= Date.now()) return;
		setNow(Date.now());
		const timer = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(timer);
	}, [retryAtMs]);
	if (retryAtMs === null) return 0;
	return Math.max(0, Math.ceil((retryAtMs - now) / 1e3));
}
/** `hasLoopbackPermission()` is only a compatibility check today — `<all_urls>` is
*  a required, install-time host permission that already covers the
*  loopback origin — so this branch is currently unreachable in production.
*  It remains wired so a future narrowing of `host_permissions` can add the
*  corresponding optional permission flow without discovery failing silently. */
function usePermissionMissing() {
	const [missing, setMissing] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		hasLoopbackPermission().then((granted) => {
			if (!cancelled) setMissing(!granted);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	return missing;
}
var DOT_COLOR = {
	connected: "bg-green-500",
	connecting: "bg-amber-400 animate-pulse",
	bootstrapping: "bg-amber-400 animate-pulse",
	handshaking: "bg-amber-400 animate-pulse",
	"awaiting-code": "bg-amber-400 animate-pulse",
	disconnected: "bg-red-500",
	denied: "bg-red-500"
};
function ConnectionStatusPanel({ state, onReconnect, onShowPairing, actionLabel }) {
	const { t } = useTranslation();
	const permissionMissing = usePermissionMissing();
	const backoffSecondsLeft = useBackoffSecondsLeft(state.backoff?.retryAtMs ?? null);
	const [pendingReconnect, setPendingReconnect] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setPendingReconnect(false);
	}, [state]);
	if (state.loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full items-center justify-center gap-2 text-sm text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
			className: "size-4",
			"aria-hidden": "true"
		}), t("popup.loading")]
	});
	const conn = state.connection ?? "disconnected";
	const isOk = conn === "connected";
	const canShowPairing = state.pairingCode !== null && onShowPairing !== void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "h-full min-w-0 rounded-none border-0 py-0 shadow-none ring-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "flex h-full flex-col justify-center gap-3 px-8 py-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						"data-testid": "status-dot",
						"data-state": conn,
						className: cn("h-2.5 w-2.5 rounded-full", DOT_COLOR[conn] ?? "bg-muted-foreground")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-foreground",
						children: t(`popup.status.${conn}`, { defaultValue: conn })
					})]
				}),
				state.lastError !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
					variant: "destructive",
					title: state.lastError,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t(connectionErrorKey(state.lastErrorReason)) })
				}),
				state.recoveryExhaustedUnattended && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("popup.pairing.recoveryExhaustedTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("popup.pairing.recoveryExhaustedBody") })] }),
				state.backoff && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("popup.pairing.backoffTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("popup.pairing.backoffBody", { time: new Date(state.backoff.retryAtMs).toLocaleTimeString() }) })] }),
				permissionMissing && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("popup.pairing.permissionMissingTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("popup.pairing.permissionMissingBody") })] }),
				isOk && state.degraded && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: t("popup.pairing.degradedTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: t("popup.pairing.degradedBody") })] }),
				!isOk && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					size: "sm",
					disabled: actionLabel === void 0 && !canShowPairing && (pendingReconnect || backoffSecondsLeft > 0),
					onClick: () => {
						if (canShowPairing) {
							onShowPairing();
							return;
						}
						if (actionLabel !== void 0) {
							onReconnect();
							return;
						}
						setPendingReconnect(true);
						onReconnect();
					},
					children: [!canShowPairing && pendingReconnect && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }), canShowPairing ? t("popup.pairing.enterCode") : actionLabel !== void 0 ? actionLabel : backoffSecondsLeft > 0 ? t("popup.pairing.retryIn", { seconds: backoffSecondsLeft }) : t("popup.reconnect")]
				})
			]
		})
	});
}
//#endregion
//#region src/popup/ConnectionPanel.tsx
function ConnectionPanel({ title, state, onReconnect, onShowPairing, actionLabel }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"aria-label": title,
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactSectionToolbar, { title: title || t("popup.tasks.title") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactContentCard, {
			className: "overflow-y-auto [overflow-wrap:anywhere]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectionStatusPanel, {
				state,
				onReconnect,
				...onShowPairing ? { onShowPairing } : {},
				...actionLabel ? { actionLabel } : {}
			})
		})]
	});
}
//#endregion
//#region src/components/ui/empty.tsx
function Empty({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty",
		className: cn("flex w-full min-w-0 flex-1 flex-col items-center justify-center gap-4 rounded-lg border-dashed p-12 text-center text-balance", className),
		...props
	});
}
function EmptyHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty-header",
		className: cn("flex max-w-sm flex-col items-center gap-2", className),
		...props
	});
}
var emptyMediaVariants = cva("mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0", {
	variants: { variant: {
		default: "bg-transparent",
		icon: "flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground [&_svg:not([class*='size-'])]:size-6"
	} },
	defaultVariants: { variant: "default" }
});
function EmptyMedia({ className, variant = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty-icon",
		"data-variant": variant,
		className: cn(emptyMediaVariants({
			variant,
			className
		})),
		...props
	});
}
function EmptyTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty-title",
		className: cn("text-lg font-medium tracking-tight", className),
		...props
	});
}
function EmptyDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty-description",
		className: cn("text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary", className),
		...props
	});
}
function EmptyContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "empty-content",
		className: cn("flex w-full max-w-sm min-w-0 flex-col items-center gap-4 text-sm text-balance", className),
		...props
	});
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/stringifyLocale.mjs
function stringifyLocale(locale) {
	if (Array.isArray(locale)) return locale.map((value) => stringifyLocale(value)).join(",");
	if (locale == null) return "";
	return String(locale);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/formatNumber.mjs
var cache = /* @__PURE__ */ new Map();
function getFormatter(locale, options) {
	const optionsString = JSON.stringify({
		locale: stringifyLocale(locale),
		options
	});
	const cachedFormatter = cache.get(optionsString);
	if (cachedFormatter) return cachedFormatter;
	const formatter = new Intl.NumberFormat(locale, options);
	cache.set(optionsString, formatter);
	return formatter;
}
function formatNumber(value, locale, options) {
	if (value == null) return "";
	return getFormatter(locale, options).format(value);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/valueToPercent.mjs
function valueToPercent(value, min, max) {
	return (value - min) * 100 / (max - min);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/progress/root/ProgressRootContext.mjs
/**
* @internal
*/
var ProgressRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useProgressRootContext() {
	const context = import_react.useContext(ProgressRootContext);
	if (context === void 0) throw new Error(formatErrorMessage(51));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/progress/root/stateAttributesMapping.mjs
var progressStateAttributesMapping = { status(value) {
	return { [`data-${value}`]: "" };
} };
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/progress/root/ProgressRoot.mjs
/**
* Groups all parts of the progress bar and provides the task completion status to screen readers.
* Renders a `<div>` element.
*
* Documentation: [Base UI Progress](https://base-ui.com/react/components/progress)
*/
var ProgressRoot = /*#__PURE__*/ import_react.forwardRef(function ProgressRoot(componentProps, forwardedRef) {
	const { format, getAriaValueText, locale, max = 100, min = 0, value, render, className, children, style, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState();
	let status = "indeterminate";
	let percentageValue = null;
	let clampedValue = null;
	let formattedValue = "";
	let defaultAriaValueText = "indeterminate progress";
	if (value != null && Number.isFinite(value)) {
		const rawPercentage = valueToPercent(value, min, max);
		percentageValue = clamp(Number.isNaN(rawPercentage) ? 0 : rawPercentage, 0, 100);
		clampedValue = clamp(value, min, max);
		status = clampedValue === max ? "complete" : "progressing";
		formattedValue = format ? formatNumber(clampedValue, locale, format) : formatNumber(percentageValue / 100, locale, { style: "percent" });
		defaultAriaValueText = formattedValue;
	}
	const state = import_react.useMemo(() => ({ status }), [status]);
	const defaultProps = {
		"aria-labelledby": labelId,
		"aria-valuemax": max,
		"aria-valuemin": min,
		"aria-valuenow": clampedValue ?? void 0,
		"aria-valuetext": getAriaValueText ? getAriaValueText(formattedValue, value) : defaultAriaValueText,
		role: "progressbar",
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [children, /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
			role: "presentation",
			style: visuallyHidden,
			children: "x"
		})] })
	};
	const contextValue = import_react.useMemo(() => ({
		formattedValue,
		percentageValue,
		setLabelId,
		state,
		value
	}), [
		formattedValue,
		percentageValue,
		setLabelId,
		state,
		value
	]);
	const element = useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [defaultProps, elementProps],
		stateAttributesMapping: progressStateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ProgressRootContext.Provider, {
		value: contextValue,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/progress/track/ProgressTrack.mjs
/**
* Contains the progress bar indicator.
* Renders a `<div>` element.
*
* Documentation: [Base UI Progress](https://base-ui.com/react/components/progress)
*/
var ProgressTrack$1 = /*#__PURE__*/ import_react.forwardRef(function ProgressTrack(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { state } = useProgressRootContext();
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: elementProps,
		stateAttributesMapping: progressStateAttributesMapping
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/progress/indicator/ProgressIndicator.mjs
/**
* Visualizes the completion status of the task.
* Renders a `<div>` element.
*
* Documentation: [Base UI Progress](https://base-ui.com/react/components/progress)
*/
var ProgressIndicator$1 = /*#__PURE__*/ import_react.forwardRef(function ProgressIndicator(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { percentageValue, state } = useProgressRootContext();
	const indicatorStyle = percentageValue == null ? {} : {
		insetInlineStart: 0,
		height: "inherit",
		width: `${percentageValue}%`
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [{ style: indicatorStyle }, elementProps],
		stateAttributesMapping: progressStateAttributesMapping
	});
});
//#endregion
//#region src/components/ui/progress.tsx
function Progress({ className, children, value, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ProgressRoot, {
		value,
		"data-slot": "progress",
		className: cn("flex flex-wrap gap-3", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressTrack, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressIndicator, {}) })]
	});
}
function ProgressTrack({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressTrack$1, {
		className: cn("relative flex h-1.5 w-full items-center overflow-x-hidden rounded-full bg-muted", className),
		"data-slot": "progress-track",
		...props
	});
}
function ProgressIndicator({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressIndicator$1, {
		"data-slot": "progress-indicator",
		className: cn("h-full bg-primary transition-all", className),
		...props
	});
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/root/ScrollAreaRootContext.mjs
var ScrollAreaRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useScrollAreaRootContext() {
	const context = import_react.useContext(ScrollAreaRootContext);
	if (context === void 0) throw new Error(formatErrorMessage(53));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/utils/getOffset.mjs
function getOffset(element, prop, axis) {
	if (!element) return 0;
	const styles = getComputedStyle(element);
	const key = `${prop}${axis === "x" ? "Inline" : "Block"}`;
	const start = parseFloat(styles[`${key}Start`]);
	if (axis === "x" && prop === "margin") return start * 2;
	return start + parseFloat(styles[`${key}End`]);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/root/stateAttributes.mjs
var attr = (name) => (value) => value ? { [name]: "" } : null;
var scrollAreaStateAttributesMapping = {
	hasOverflowX: attr("data-has-overflow-x"),
	hasOverflowY: attr("data-has-overflow-y"),
	overflowXStart: attr("data-overflow-x-start"),
	overflowXEnd: attr("data-overflow-x-end"),
	overflowYStart: attr("data-overflow-y-start"),
	overflowYEnd: attr("data-overflow-y-end"),
	cornerHidden: () => null
};
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/root/ScrollAreaRoot.mjs
var DEFAULT_COORDS = {
	x: 0,
	y: 0
};
var DEFAULT_SIZE = {
	width: 0,
	height: 0
};
var DEFAULT_OVERFLOW_EDGES = {
	xStart: false,
	xEnd: false,
	yStart: false,
	yEnd: false
};
var DEFAULT_HIDDEN_STATE = {
	x: true,
	y: true,
	corner: true
};
/**
* Groups all parts of the scroll area.
* Renders a `<div>` element.
*
* Documentation: [Base UI Scroll Area](https://base-ui.com/react/components/scroll-area)
*/
var ScrollAreaRoot = /*#__PURE__*/ import_react.forwardRef(function ScrollAreaRoot(componentProps, forwardedRef) {
	const { render, className, overflowEdgeThreshold: overflowEdgeThresholdProp, style, ...elementProps } = componentProps;
	const { xStart, xEnd, yStart, yEnd } = normalizeOverflowEdgeThreshold(overflowEdgeThresholdProp);
	const rootId = useBaseUiId();
	const scrollYTimeout = useTimeout();
	const scrollXTimeout = useTimeout();
	const { nonce, disableStyleElements } = useCSPContext();
	const [hovering, setHovering] = import_react.useState(false);
	const [scrollingX, setScrollingX] = import_react.useState(false);
	const [scrollingY, setScrollingY] = import_react.useState(false);
	const [touchModality, setTouchModality] = import_react.useState(false);
	const [hasMeasuredScrollbar, setHasMeasuredScrollbar] = import_react.useState(false);
	const [cornerSize, setCornerSize] = import_react.useState(DEFAULT_SIZE);
	const [thumbSize, setThumbSize] = import_react.useState(DEFAULT_SIZE);
	const [overflowEdges, setOverflowEdges] = import_react.useState(DEFAULT_OVERFLOW_EDGES);
	const [hiddenState, setHiddenState] = import_react.useState(DEFAULT_HIDDEN_STATE);
	const rootRef = import_react.useRef(null);
	const viewportRef = import_react.useRef(null);
	const scrollbarYRef = import_react.useRef(null);
	const scrollbarXRef = import_react.useRef(null);
	const thumbYRef = import_react.useRef(null);
	const thumbXRef = import_react.useRef(null);
	const cornerRef = import_react.useRef(null);
	const activePointerIdRef = import_react.useRef(null);
	const startYRef = import_react.useRef(0);
	const startXRef = import_react.useRef(0);
	const startScrollTopRef = import_react.useRef(0);
	const startScrollLeftRef = import_react.useRef(0);
	const currentOrientationRef = import_react.useRef("vertical");
	const scrollPositionRef = import_react.useRef(DEFAULT_COORDS);
	const savedSnapTypeRef = import_react.useRef(null);
	function startScrolling(vertical) {
		const setScrolling = vertical ? setScrollingY : setScrollingX;
		const timeout = vertical ? scrollYTimeout : scrollXTimeout;
		setScrolling(true);
		timeout.start(500, () => {
			setScrolling(false);
		});
	}
	const handleScroll = useStableCallback((scrollPosition) => {
		const offsetX = scrollPosition.x - scrollPositionRef.current.x;
		const offsetY = scrollPosition.y - scrollPositionRef.current.y;
		scrollPositionRef.current = scrollPosition;
		if (offsetY !== 0) startScrolling(true);
		if (offsetX !== 0) startScrolling(false);
	});
	const disableViewportSnap = useStableCallback(() => {
		const viewportEl = viewportRef.current;
		if (viewportEl && savedSnapTypeRef.current === null) {
			savedSnapTypeRef.current = viewportEl.style.scrollSnapType;
			viewportEl.style.scrollSnapType = "none";
		}
	});
	const handlePointerDown = useStableCallback((event) => {
		if (event.button !== 0) return;
		if (activePointerIdRef.current !== null) {
			if ((currentOrientationRef.current === "vertical" ? thumbYRef.current : thumbXRef.current)?.hasPointerCapture(activePointerIdRef.current)) return;
		}
		activePointerIdRef.current = event.pointerId;
		startYRef.current = event.clientY;
		startXRef.current = event.clientX;
		currentOrientationRef.current = event.currentTarget.getAttribute("data-orientation");
		const viewportEl = viewportRef.current;
		if (viewportEl) {
			startScrollTopRef.current = viewportEl.scrollTop;
			startScrollLeftRef.current = viewportEl.scrollLeft;
			disableViewportSnap();
		}
		(currentOrientationRef.current === "vertical" ? thumbYRef.current : thumbXRef.current)?.setPointerCapture(event.pointerId);
	});
	const handlePointerUp = useStableCallback((event) => {
		if (event.pointerId !== activePointerIdRef.current) return;
		activePointerIdRef.current = null;
		(currentOrientationRef.current === "vertical" ? setScrollingY : setScrollingX)(false);
		if (savedSnapTypeRef.current !== null) {
			if (viewportRef.current) viewportRef.current.style.scrollSnapType = savedSnapTypeRef.current;
			savedSnapTypeRef.current = null;
		}
		const thumb = currentOrientationRef.current === "vertical" ? thumbYRef.current : thumbXRef.current;
		if (thumb?.hasPointerCapture(event.pointerId)) thumb.releasePointerCapture(event.pointerId);
	});
	const handlePointerMove = useStableCallback((event) => {
		if (event.pointerId !== activePointerIdRef.current) return;
		if (event.buttons % 2 === 0) {
			handlePointerUp(event);
			return;
		}
		const viewportEl = viewportRef.current;
		if (!viewportEl) return;
		const vertical = currentOrientationRef.current === "vertical";
		const thumbEl = vertical ? thumbYRef.current : thumbXRef.current;
		const scrollbarEl = vertical ? scrollbarYRef.current : scrollbarXRef.current;
		if (!thumbEl || !scrollbarEl) return;
		const axis = vertical ? "y" : "x";
		const scrollbarOffset = getOffset(scrollbarEl, "padding", axis);
		const thumbOffset = getOffset(thumbEl, "margin", axis);
		const thumbSizePx = vertical ? thumbEl.offsetHeight : thumbEl.offsetWidth;
		const maxThumbOffset = (vertical ? scrollbarEl.offsetHeight : scrollbarEl.offsetWidth) - thumbSizePx - scrollbarOffset - thumbOffset;
		const delta = vertical ? event.clientY - startYRef.current : event.clientX - startXRef.current;
		const scrollRatio = maxThumbOffset <= 0 ? 0 : delta / maxThumbOffset;
		const scrollableSize = vertical ? viewportEl.scrollHeight : viewportEl.scrollWidth;
		const viewportSize = vertical ? viewportEl.clientHeight : viewportEl.clientWidth;
		const nextScroll = (vertical ? startScrollTopRef.current : startScrollLeftRef.current) + scrollRatio * (scrollableSize - viewportSize);
		if (vertical) viewportEl.scrollTop = nextScroll;
		else viewportEl.scrollLeft = nextScroll;
		event.preventDefault();
		startScrolling(vertical);
	});
	function handleTouchModalityChange(event) {
		setTouchModality(event.pointerType === "touch");
	}
	function handlePointerEnterOrMove(event) {
		handleTouchModalityChange(event);
		if (event.pointerType !== "touch") {
			const isTargetRootChild = contains(rootRef.current, event.target);
			setHovering(isTargetRootChild);
		}
	}
	const state = import_react.useMemo(() => ({
		scrolling: scrollingX || scrollingY,
		hasOverflowX: !hiddenState.x,
		hasOverflowY: !hiddenState.y,
		overflowXStart: overflowEdges.xStart,
		overflowXEnd: overflowEdges.xEnd,
		overflowYStart: overflowEdges.yStart,
		overflowYEnd: overflowEdges.yEnd,
		cornerHidden: hiddenState.corner
	}), [
		scrollingX,
		scrollingY,
		hiddenState.x,
		hiddenState.y,
		hiddenState.corner,
		overflowEdges
	]);
	const props = {
		role: "presentation",
		onPointerEnter: handlePointerEnterOrMove,
		onPointerMove: handlePointerEnterOrMove,
		onPointerDown: handleTouchModalityChange,
		onPointerLeave() {
			setHovering(false);
		},
		style: {
			position: "relative",
			["--scroll-area-corner-height"]: `${cornerSize.height}px`,
			["--scroll-area-corner-width"]: `${cornerSize.width}px`
		}
	};
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [forwardedRef, rootRef],
		props: [props, elementProps],
		stateAttributesMapping: scrollAreaStateAttributesMapping
	});
	const contextValue = import_react.useMemo(() => ({
		handlePointerDown,
		handlePointerMove,
		handlePointerUp,
		handleScroll,
		disableViewportSnap,
		cornerSize,
		setCornerSize,
		thumbSize,
		setThumbSize,
		hasMeasuredScrollbar,
		setHasMeasuredScrollbar,
		touchModality,
		cornerRef,
		scrollingX,
		scrollingY,
		hovering,
		setHovering,
		viewportRef,
		scrollbarYRef,
		scrollbarXRef,
		thumbYRef,
		thumbXRef,
		rootId,
		hiddenState,
		setHiddenState,
		overflowEdges,
		setOverflowEdges,
		viewportState: state,
		overflowEdgeThreshold: {
			xStart,
			xEnd,
			yStart,
			yEnd
		}
	}), [
		handlePointerDown,
		handlePointerMove,
		handlePointerUp,
		handleScroll,
		disableViewportSnap,
		cornerSize,
		thumbSize,
		hasMeasuredScrollbar,
		touchModality,
		scrollingX,
		scrollingY,
		hovering,
		rootId,
		hiddenState,
		overflowEdges,
		state,
		xStart,
		xEnd,
		yStart,
		yEnd
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(ScrollAreaRootContext.Provider, {
		value: contextValue,
		children: [!disableStyleElements && styleDisableScrollbar.getElement(nonce), element]
	});
});
function normalizeOverflowEdgeThreshold(threshold) {
	const thresholds = typeof threshold === "number" ? {
		xStart: threshold,
		xEnd: threshold,
		yStart: threshold,
		yEnd: threshold
	} : threshold;
	return {
		xStart: Math.max(0, thresholds?.xStart || 0),
		xEnd: Math.max(0, thresholds?.xEnd || 0),
		yStart: Math.max(0, thresholds?.yStart || 0),
		yEnd: Math.max(0, thresholds?.yEnd || 0)
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/viewport/ScrollAreaViewportContext.mjs
var ScrollAreaViewportContext = /*#__PURE__*/ import_react.createContext(void 0);
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/viewport/ScrollAreaViewport.mjs
var OVERFLOW_EDGE_VARS = [
	"--scroll-area-overflow-x-start",
	"--scroll-area-overflow-x-end",
	"--scroll-area-overflow-y-start",
	"--scroll-area-overflow-y-end"
];
var scrollAreaOverflowVarsRegistered = false;
/**
* Removes inheritance of the scroll area overflow CSS variables, which
* improves rendering performance in complex scroll areas with deep subtrees.
* Instead, each child must manually opt-in to using these properties by
* specifying `inherit`.
* See https://motion.dev/blog/web-animation-performance-tier-list
* under the "Improving CSS variable performance" section.
*/
function removeCSSVariableInheritance() {
	if (scrollAreaOverflowVarsRegistered || webkit) return;
	if (typeof CSS !== "undefined" && "registerProperty" in CSS) OVERFLOW_EDGE_VARS.forEach((name) => {
		try {
			CSS.registerProperty({
				name,
				syntax: "<length>",
				inherits: false,
				initialValue: "0px"
			});
		} catch {}
	});
	scrollAreaOverflowVarsRegistered = true;
}
/**
* The actual scrollable container of the scroll area.
* Renders a `<div>` element.
*
* Documentation: [Base UI Scroll Area](https://base-ui.com/react/components/scroll-area)
*/
var ScrollAreaViewport = /*#__PURE__*/ import_react.forwardRef(function ScrollAreaViewport(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { viewportRef, scrollbarYRef, scrollbarXRef, thumbYRef, thumbXRef, cornerRef, cornerSize, setCornerSize, setThumbSize, rootId, setHiddenState, hiddenState, setHasMeasuredScrollbar, handleScroll, touchModality, setHovering, setOverflowEdges, overflowEdgeThreshold, viewportState } = useScrollAreaRootContext();
	const direction = useDirection();
	const programmaticScrollRef = import_react.useRef(true);
	const lastMeasuredViewportMetricsRef = import_react.useRef([
		NaN,
		NaN,
		NaN,
		NaN
	]);
	const scrollEndTimeout = useTimeout();
	const waitForAnimationsTimeout = useTimeout();
	const computeThumbPosition = useStableCallback(() => {
		const viewportEl = viewportRef.current;
		const scrollbarYEl = scrollbarYRef.current;
		const scrollbarXEl = scrollbarXRef.current;
		const thumbYEl = thumbYRef.current;
		const thumbXEl = thumbXRef.current;
		const cornerEl = cornerRef.current;
		if (!viewportEl) return;
		const scrollableContentHeight = viewportEl.scrollHeight;
		const scrollableContentWidth = viewportEl.scrollWidth;
		const viewportHeight = viewportEl.clientHeight;
		const viewportWidth = viewportEl.clientWidth;
		const scrollTop = viewportEl.scrollTop;
		const scrollLeft = viewportEl.scrollLeft;
		const lastMeasuredViewportMetrics = lastMeasuredViewportMetricsRef.current;
		const isFirstMeasurement = Number.isNaN(lastMeasuredViewportMetrics[0]);
		lastMeasuredViewportMetrics[0] = viewportHeight;
		lastMeasuredViewportMetrics[1] = scrollableContentHeight;
		lastMeasuredViewportMetrics[2] = viewportWidth;
		lastMeasuredViewportMetrics[3] = scrollableContentWidth;
		if (isFirstMeasurement) setHasMeasuredScrollbar(true);
		if (scrollableContentHeight === 0 || scrollableContentWidth === 0) return;
		const nextHiddenState = getHiddenState(viewportEl);
		const scrollbarYHidden = nextHiddenState.y;
		const scrollbarXHidden = nextHiddenState.x;
		const ratioX = viewportWidth / scrollableContentWidth;
		const ratioY = viewportHeight / scrollableContentHeight;
		const maxScrollLeft = Math.max(0, scrollableContentWidth - viewportWidth);
		const maxScrollTop = Math.max(0, scrollableContentHeight - viewportHeight);
		let scrollLeftFromStart = 0;
		let scrollLeftFromEnd = 0;
		if (!scrollbarXHidden) {
			scrollLeftFromStart = normalizeScrollOffset(direction === "rtl" ? -scrollLeft : scrollLeft, maxScrollLeft);
			scrollLeftFromEnd = maxScrollLeft - scrollLeftFromStart;
		}
		const scrollTopFromStart = scrollbarYHidden ? 0 : normalizeScrollOffset(scrollTop, maxScrollTop);
		const scrollTopFromEnd = scrollbarYHidden ? 0 : maxScrollTop - scrollTopFromStart;
		const nextWidth = scrollbarXHidden ? 0 : viewportWidth;
		const nextHeight = scrollbarYHidden ? 0 : viewportHeight;
		let nextCornerWidth = 0;
		let nextCornerHeight = 0;
		if (!scrollbarXHidden && !scrollbarYHidden) {
			nextCornerWidth = scrollbarYEl?.offsetWidth || 0;
			nextCornerHeight = scrollbarXEl?.offsetHeight || 0;
		}
		const cornerNotYetSized = cornerSize.width === 0 && cornerSize.height === 0;
		const cornerWidthOffset = cornerNotYetSized ? nextCornerWidth : 0;
		const cornerHeightOffset = cornerNotYetSized ? nextCornerHeight : 0;
		const scrollbarXOffset = getOffset(scrollbarXEl, "padding", "x");
		const scrollbarYOffset = getOffset(scrollbarYEl, "padding", "y");
		const thumbXOffset = getOffset(thumbXEl, "margin", "x");
		const thumbYOffset = getOffset(thumbYEl, "margin", "y");
		const idealNextWidth = nextWidth - scrollbarXOffset - thumbXOffset;
		const idealNextHeight = nextHeight - scrollbarYOffset - thumbYOffset;
		const maxNextWidth = scrollbarXEl ? Math.min(scrollbarXEl.offsetWidth - cornerWidthOffset, idealNextWidth) : idealNextWidth;
		const maxNextHeight = scrollbarYEl ? Math.min(scrollbarYEl.offsetHeight - cornerHeightOffset, idealNextHeight) : idealNextHeight;
		const clampedNextWidth = Math.max(16, maxNextWidth * ratioX);
		const clampedNextHeight = Math.max(16, maxNextHeight * ratioY);
		setThumbSize((prevSize) => pickState(prevSize, {
			width: clampedNextWidth,
			height: clampedNextHeight
		}));
		if (scrollbarYEl && thumbYEl) {
			const thumbOffsetY = applyOverscrollThumb(thumbYEl, "--scroll-area-thumb-height", scrollTop, maxScrollTop, scrollableContentHeight, clampedNextHeight, scrollbarYEl.offsetHeight - clampedNextHeight - scrollbarYOffset - thumbYOffset);
			thumbYEl.style.transform = `translate3d(0,${thumbOffsetY}px,0)`;
		}
		if (scrollbarXEl && thumbXEl) {
			const maxThumbOffsetX = scrollbarXEl.offsetWidth - clampedNextWidth - scrollbarXOffset - thumbXOffset;
			const offsetX = applyOverscrollThumb(thumbXEl, "--scroll-area-thumb-width", direction === "rtl" ? -scrollLeft : scrollLeft, maxScrollLeft, scrollableContentWidth, clampedNextWidth, maxThumbOffsetX);
			thumbXEl.style.transform = `translate3d(${direction === "rtl" ? -offsetX : offsetX}px,0,0)`;
		}
		const overflowMetricsPx = [
			scrollLeftFromStart,
			scrollLeftFromEnd,
			scrollTopFromStart,
			scrollTopFromEnd
		];
		OVERFLOW_EDGE_VARS.forEach((cssVar, index) => {
			viewportEl.style.setProperty(cssVar, `${overflowMetricsPx[index]}px`);
		});
		if (cornerEl) setCornerSize((prevSize) => pickState(prevSize, {
			width: nextCornerWidth,
			height: nextCornerHeight
		}));
		setHiddenState((prevState) => pickState(prevState, nextHiddenState));
		const nextOverflowEdges = {
			xStart: !scrollbarXHidden && scrollLeftFromStart > overflowEdgeThreshold.xStart,
			xEnd: !scrollbarXHidden && scrollLeftFromEnd > overflowEdgeThreshold.xEnd,
			yStart: !scrollbarYHidden && scrollTopFromStart > overflowEdgeThreshold.yStart,
			yEnd: !scrollbarYHidden && scrollTopFromEnd > overflowEdgeThreshold.yEnd
		};
		setOverflowEdges((prev) => pickState(prev, nextOverflowEdges));
	});
	useIsoLayoutEffect(() => {
		removeCSSVariableInheritance();
	}, []);
	useIsoLayoutEffect(() => {
		queueMicrotask(computeThumbPosition);
	}, [
		computeThumbPosition,
		hiddenState,
		direction,
		overflowEdgeThreshold.xStart,
		overflowEdgeThreshold.xEnd,
		overflowEdgeThreshold.yStart,
		overflowEdgeThreshold.yEnd
	]);
	useIsoLayoutEffect(() => {
		if (viewportRef.current?.matches(":hover")) setHovering(true);
	}, [viewportRef, setHovering]);
	useIsoLayoutEffect(() => {
		const viewport = viewportRef.current;
		if (typeof ResizeObserver === "undefined" || !viewport) return;
		let hasInitialized = false;
		const resizeObserver = new ResizeObserver(() => {
			if (!hasInitialized) {
				hasInitialized = true;
				const lastMeasuredViewportMetrics = lastMeasuredViewportMetricsRef.current;
				if (lastMeasuredViewportMetrics[0] === viewport.clientHeight && lastMeasuredViewportMetrics[1] === viewport.scrollHeight && lastMeasuredViewportMetrics[2] === viewport.clientWidth && lastMeasuredViewportMetrics[3] === viewport.scrollWidth) return;
			}
			computeThumbPosition();
		});
		resizeObserver.observe(viewport);
		waitForAnimationsTimeout.start(0, () => {
			const animations = viewport.getAnimations({ subtree: true });
			if (animations.length === 0) return;
			Promise.allSettled(animations.map((animation) => animation.finished)).then(computeThumbPosition).catch(() => {});
		});
		return () => {
			resizeObserver.disconnect();
			waitForAnimationsTimeout.clear();
		};
	}, [
		computeThumbPosition,
		viewportRef,
		waitForAnimationsTimeout
	]);
	function handleUserInteraction() {
		programmaticScrollRef.current = false;
	}
	const props = {
		role: "presentation",
		...rootId && { "data-id": `${rootId}-viewport` },
		tabIndex: hiddenState.x && hiddenState.y ? -1 : 0,
		className: styleDisableScrollbar.className,
		style: { overflow: "scroll" },
		onScroll() {
			if (!viewportRef.current) return;
			computeThumbPosition();
			if (touchModality || !programmaticScrollRef.current) handleScroll({
				x: viewportRef.current.scrollLeft,
				y: viewportRef.current.scrollTop
			});
			scrollEndTimeout.start(100, () => {
				programmaticScrollRef.current = true;
			});
		},
		onWheel: handleUserInteraction,
		onPointerMove: handleUserInteraction,
		onPointerEnter: handleUserInteraction,
		onKeyDown: handleUserInteraction
	};
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, viewportRef],
		state: viewportState,
		props: [props, elementProps],
		stateAttributesMapping: scrollAreaStateAttributesMapping
	});
	const contextValue = import_react.useMemo(() => ({ computeThumbPosition }), [computeThumbPosition]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ScrollAreaViewportContext.Provider, {
		value: contextValue,
		children: element
	});
});
function getHiddenState(viewport) {
	const y = viewport.clientHeight >= viewport.scrollHeight;
	const x = viewport.clientWidth >= viewport.scrollWidth;
	return {
		y,
		x,
		corner: y || x
	};
}
/**
* Returns `prev` when `next` is shallow-equal to it so setState bails out and
* scroll-frame updates don't rebuild the root context.
*/
function pickState(prev, next) {
	for (const key in next) if (prev[key] !== next[key]) return next;
	return prev;
}
/**
* Sizes the thumb and returns its axis offset. On overscroll (Safari rubber-band only) it shrinks
* against the pinned edge, damped by `content / (content + overscroll)` to match native feedback;
* the size flows through the thumb-size variable so the resting `var(...)` still applies.
*/
function applyOverscrollThumb(thumbEl, sizeVar, scrollFromStart, maxScroll, content, size, maxThumbOffset) {
	const clamped = clamp(scrollFromStart, 0, maxScroll);
	const overscroll = scrollFromStart - clamped;
	const nextSize = Math.max(16, size * content / (content + Math.abs(overscroll)));
	thumbEl.style.setProperty(sizeVar, overscroll ? `${nextSize}px` : "");
	return (maxScroll ? clamped / maxScroll * maxThumbOffset : 0) + (overscroll > 0 ? size - nextSize : 0);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/scrollbar/ScrollAreaScrollbarContext.mjs
var ScrollAreaScrollbarContext = /*#__PURE__*/ import_react.createContext(void 0);
function useScrollAreaScrollbarContext() {
	const context = import_react.useContext(ScrollAreaScrollbarContext);
	if (context === void 0) throw new Error(formatErrorMessage(54));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/scrollbar/ScrollAreaScrollbar.mjs
/**
* A vertical or horizontal scrollbar for the scroll area.
* Renders a `<div>` element.
*
* Documentation: [Base UI Scroll Area](https://base-ui.com/react/components/scroll-area)
*/
var ScrollAreaScrollbar = /*#__PURE__*/ import_react.forwardRef(function ScrollAreaScrollbar(componentProps, forwardedRef) {
	const { render, className, orientation = "vertical", keepMounted = false, style, ...elementProps } = componentProps;
	const { hovering, scrollingX, scrollingY, hiddenState, scrollbarYRef, scrollbarXRef, viewportRef, thumbYRef, thumbXRef, handlePointerDown, handlePointerUp, handleScroll, disableViewportSnap, rootId, thumbSize, hasMeasuredScrollbar, viewportState } = useScrollAreaRootContext();
	const vertical = orientation === "vertical";
	const state = {
		...viewportState,
		hovering,
		scrolling: vertical ? scrollingY : scrollingX,
		orientation
	};
	const direction = useDirection();
	const hideTrackUntilMeasured = !hasMeasuredScrollbar && !keepMounted;
	const isHidden = vertical ? hiddenState.y : hiddenState.x;
	const shouldRender = keepMounted || !isHidden;
	import_react.useEffect(() => {
		if (!shouldRender) return;
		const viewportEl = viewportRef.current;
		const scrollbarEl = vertical ? scrollbarYRef.current : scrollbarXRef.current;
		if (!scrollbarEl) return;
		function handleWheel(event) {
			if (!viewportEl || event.ctrlKey) return;
			const horizontal = !vertical;
			const scrollProperty = horizontal ? "scrollLeft" : "scrollTop";
			const delta = horizontal ? event.deltaX : event.deltaY;
			if (delta === 0) return;
			const maxScroll = horizontal ? viewportEl.scrollWidth - viewportEl.clientWidth : viewportEl.scrollHeight - viewportEl.clientHeight;
			const minScroll = horizontal && direction === "rtl" ? -maxScroll : 0;
			const maxScrollValue = horizontal && direction === "rtl" ? 0 : maxScroll;
			const scrollValue = viewportEl[scrollProperty];
			if (scrollValue <= minScroll && delta < 0 || scrollValue >= maxScrollValue && delta > 0) return;
			event.preventDefault();
			viewportEl[scrollProperty] = Math.min(maxScrollValue, Math.max(minScroll, scrollValue + delta));
			handleScroll({
				x: viewportEl.scrollLeft,
				y: viewportEl.scrollTop
			});
		}
		return addEventListener(scrollbarEl, "wheel", handleWheel, { passive: false });
	}, [
		direction,
		handleScroll,
		vertical,
		scrollbarXRef,
		scrollbarYRef,
		shouldRender,
		viewportRef
	]);
	const props = {
		...rootId && { "data-id": `${rootId}-scrollbar` },
		onPointerDown(event) {
			if (event.button !== 0) return;
			const target = getTarget(event.nativeEvent);
			const thumbEl = vertical ? thumbYRef.current : thumbXRef.current;
			if (thumbEl && contains(thumbEl, target)) return;
			const viewportEl = viewportRef.current;
			if (!viewportEl) return;
			const scrollbarEl = vertical ? scrollbarYRef.current : scrollbarXRef.current;
			if (!thumbEl || !scrollbarEl) return;
			const axis = vertical ? "y" : "x";
			const thumbOffset = getOffset(thumbEl, "margin", axis);
			const scrollbarOffset = getOffset(scrollbarEl, "padding", axis);
			const thumbSizePx = vertical ? thumbEl.offsetHeight : thumbEl.offsetWidth;
			const trackRect = scrollbarEl.getBoundingClientRect();
			const clickPosition = vertical ? event.clientY - trackRect.top - thumbSizePx / 2 - scrollbarOffset + thumbOffset / 2 : event.clientX - trackRect.left - thumbSizePx / 2 - scrollbarOffset + thumbOffset / 2;
			const scrollableSize = vertical ? viewportEl.scrollHeight : viewportEl.scrollWidth;
			const viewportSize = vertical ? viewportEl.clientHeight : viewportEl.clientWidth;
			const maxThumbOffset = (vertical ? scrollbarEl.offsetHeight : scrollbarEl.offsetWidth) - thumbSizePx - scrollbarOffset - thumbOffset;
			if (maxThumbOffset <= 0) return;
			const scrollRatio = clickPosition / maxThumbOffset;
			const maxScrollDistance = scrollableSize - viewportSize;
			disableViewportSnap();
			if (vertical) viewportEl.scrollTop = scrollRatio * maxScrollDistance;
			else if (direction === "rtl") viewportEl.scrollLeft = -(1 - scrollRatio) * maxScrollDistance;
			else viewportEl.scrollLeft = scrollRatio * maxScrollDistance;
			handleScroll({
				x: viewportEl.scrollLeft,
				y: viewportEl.scrollTop
			});
			handlePointerDown(event);
		},
		onPointerUp: handlePointerUp,
		onPointerCancel: handlePointerUp,
		style: {
			position: "absolute",
			touchAction: "none",
			WebkitUserSelect: "none",
			userSelect: "none",
			visibility: hideTrackUntilMeasured ? "hidden" : void 0,
			...vertical ? {
				top: 0,
				bottom: "var(--scroll-area-corner-height)",
				insetInlineEnd: 0,
				["--scroll-area-thumb-height"]: `${thumbSize.height}px`
			} : {
				insetInlineStart: 0,
				insetInlineEnd: "var(--scroll-area-corner-width)",
				bottom: 0,
				["--scroll-area-thumb-width"]: `${thumbSize.width}px`
			}
		}
	};
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, vertical ? scrollbarYRef : scrollbarXRef],
		state,
		props: [props, elementProps],
		stateAttributesMapping: scrollAreaStateAttributesMapping
	});
	if (!shouldRender) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbarContext.Provider, {
		value: orientation,
		children: element
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/thumb/ScrollAreaThumb.mjs
/**
* The draggable part of the scrollbar that indicates the current scroll position.
* Renders a `<div>` element.
*
* Documentation: [Base UI Scroll Area](https://base-ui.com/react/components/scroll-area)
*/
var ScrollAreaThumb = /*#__PURE__*/ import_react.forwardRef(function ScrollAreaThumb(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { thumbYRef, thumbXRef, handlePointerDown, handlePointerMove, handlePointerUp, scrollingX, scrollingY, hasMeasuredScrollbar } = useScrollAreaRootContext();
	const orientation = useScrollAreaScrollbarContext();
	const vertical = orientation === "vertical";
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, vertical ? thumbYRef : thumbXRef],
		state: {
			scrolling: vertical ? scrollingY : scrollingX,
			orientation
		},
		props: [{
			onPointerDown: handlePointerDown,
			onPointerMove: handlePointerMove,
			onPointerUp: handlePointerUp,
			onPointerCancel: handlePointerUp,
			style: {
				visibility: hasMeasuredScrollbar ? void 0 : "hidden",
				...vertical ? { height: "var(--scroll-area-thumb-height)" } : { width: "var(--scroll-area-thumb-width)" }
			}
		}, elementProps]
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/scroll-area/corner/ScrollAreaCorner.mjs
/**
* A small rectangular area that appears at the intersection of horizontal and vertical scrollbars.
* Renders a `<div>` element.
*
* Documentation: [Base UI Scroll Area](https://base-ui.com/react/components/scroll-area)
*/
var ScrollAreaCorner = /*#__PURE__*/ import_react.forwardRef(function ScrollAreaCorner(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { cornerRef, cornerSize, hiddenState } = useScrollAreaRootContext();
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, cornerRef],
		props: [{ style: {
			position: "absolute",
			bottom: 0,
			insetInlineEnd: 0,
			width: cornerSize.width,
			height: cornerSize.height
		} }, elementProps]
	});
	if (hiddenState.corner) return null;
	return element;
});
//#endregion
//#region src/components/ui/scroll-area.tsx
function ScrollArea({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ScrollAreaRoot, {
		"data-slot": "scroll-area",
		className: cn("relative", className),
		...props,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaViewport, {
				"data-slot": "scroll-area-viewport",
				className: "size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaCorner, {})
		]
	});
}
function ScrollBar({ className, orientation = "vertical", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
		"data-slot": "scroll-area-scrollbar",
		"data-orientation": orientation,
		orientation,
		className: cn("flex touch-none p-px transition-colors select-none data-horizontal:h-2.5 data-horizontal:flex-col data-horizontal:border-t data-horizontal:border-t-transparent data-vertical:h-full data-vertical:w-2.5 data-vertical:border-l data-vertical:border-l-transparent", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, {
			"data-slot": "scroll-area-thumb",
			className: "relative flex-1 rounded-full bg-border"
		})
	});
}
//#endregion
//#region src/popup/useQuickAddTask.ts
var QUICK_ADD_TASK_SESSION_KEY = "motrix.quickAddTask.pending.v1";
var MIN_IDEMPOTENCY_KEY_LENGTH$1 = 8;
var MAX_IDEMPOTENCY_KEY_LENGTH$1 = 128;
/**
* `storage.session` is present in supported Chromium builds and recent
* Firefox releases, but the popup must remain usable when it is unavailable
* (preview pages, older browsers, or denied/failed storage access).
*/
function getSessionStorage() {
	try {
		const area = globalThis.chrome?.storage?.session;
		if (typeof area?.get !== "function" || typeof area.set !== "function" || typeof area.remove !== "function") return null;
		return area;
	} catch {
		return null;
	}
}
function normalizePersistedDraft(value) {
	if (typeof value !== "object" || value === null) return null;
	const draft = value;
	if (typeof draft.normalizedInput !== "string" || typeof draft.idempotencyKey !== "string" || draft.idempotencyKey.length < MIN_IDEMPOTENCY_KEY_LENGTH$1 || draft.idempotencyKey.length > MAX_IDEMPOTENCY_KEY_LENGTH$1) return null;
	const parsed = parseManualTaskInput(draft.normalizedInput);
	if (!parsed.ok) return null;
	const normalizedInput = parsed.value.kind === "direct" ? parsed.value.url : parsed.value.uri;
	return normalizedInput === draft.normalizedInput ? {
		normalizedInput,
		idempotencyKey: draft.idempotencyKey
	} : null;
}
var storageMutationQueue = Promise.resolve();
function mutateSessionStorage(mutation) {
	storageMutationQueue = storageMutationQueue.then(async () => {
		const storage = getSessionStorage();
		if (!storage) return;
		try {
			await mutation(storage);
		} catch {}
	});
	return storageMutationQueue;
}
async function loadPersistedDraft() {
	await storageMutationQueue;
	const storage = getSessionStorage();
	if (!storage) return null;
	try {
		return normalizePersistedDraft((await storage.get(QUICK_ADD_TASK_SESSION_KEY))[QUICK_ADD_TASK_SESSION_KEY]);
	} catch {
		return null;
	}
}
function persistDraft(draft) {
	return mutateSessionStorage((storage) => storage.set({ [QUICK_ADD_TASK_SESSION_KEY]: draft }));
}
function clearPersistedDraft() {
	return mutateSessionStorage((storage) => storage.remove(QUICK_ADD_TASK_SESSION_KEY));
}
/**
* Owns one logical manual-task submission.
*
* The idempotency key survives a failed request so a retry cannot create a
* duplicate task. Editing the input starts a new logical submission and thus
* discards that key. Raw background/RPC errors are deliberately collapsed to
* a stable UI error kind.
*/
function useQuickAddTask({ onCreated }) {
	const [input, setInputState] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const inputRef = (0, import_react.useRef)("");
	const idempotencyKeyRef = (0, import_react.useRef)(null);
	const submittingRef = (0, import_react.useRef)(false);
	const mountedRef = (0, import_react.useRef)(true);
	const onCreatedRef = (0, import_react.useRef)(onCreated);
	const inputRevisionRef = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		onCreatedRef.current = onCreated;
	}, [onCreated]);
	(0, import_react.useEffect)(() => {
		mountedRef.current = true;
		return () => {
			mountedRef.current = false;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		const revisionAtStart = inputRevisionRef.current;
		loadPersistedDraft().then((draft) => {
			if (cancelled || !mountedRef.current || !draft || inputRevisionRef.current !== revisionAtStart || inputRef.current !== "") return;
			inputRef.current = draft.normalizedInput;
			idempotencyKeyRef.current = draft.idempotencyKey;
			setInputState(draft.normalizedInput);
		});
		return () => {
			cancelled = true;
		};
	}, []);
	const setInput = (0, import_react.useCallback)((nextInput) => {
		if (nextInput === inputRef.current) return;
		const shouldClearPersistedDraft = inputRef.current === "" || idempotencyKeyRef.current !== null;
		inputRevisionRef.current += 1;
		inputRef.current = nextInput;
		idempotencyKeyRef.current = null;
		if (shouldClearPersistedDraft) clearPersistedDraft();
		if (mountedRef.current) {
			setInputState(nextInput);
			setError(null);
		}
	}, []);
	const reset = (0, import_react.useCallback)(() => {
		inputRevisionRef.current += 1;
		inputRef.current = "";
		idempotencyKeyRef.current = null;
		clearPersistedDraft();
		if (mountedRef.current) {
			setInputState("");
			setError(null);
		}
	}, []);
	return {
		input,
		error,
		submitting,
		setInput,
		submit: (0, import_react.useCallback)(async () => {
			if (submittingRef.current) return null;
			const parsed = parseManualTaskInput(inputRef.current);
			if (!parsed.ok) {
				if (mountedRef.current) setError(parsed.reason);
				return null;
			}
			const idempotencyKey = idempotencyKeyRef.current ?? crypto.randomUUID();
			idempotencyKeyRef.current = idempotencyKey;
			const normalizedInput = parsed.value.kind === "direct" ? parsed.value.url : parsed.value.uri;
			submittingRef.current = true;
			if (mountedRef.current) {
				setSubmitting(true);
				setError(null);
			}
			let taskId;
			try {
				await persistDraft({
					normalizedInput,
					idempotencyKey
				});
				taskId = (await send("bg.createManualTask", {
					input: normalizedInput,
					idempotencyKey
				})).taskId;
			} catch {
				if (mountedRef.current) setError("submitFailed");
				return null;
			} finally {
				submittingRef.current = false;
				if (mountedRef.current) setSubmitting(false);
			}
			inputRef.current = "";
			idempotencyKeyRef.current = null;
			await clearPersistedDraft();
			if (mountedRef.current) {
				setInputState("");
				setError(null);
			}
			try {
				await onCreatedRef.current(taskId);
			} catch {}
			return taskId;
		}, []),
		reset
	};
}
//#endregion
//#region src/popup/QuickAddTaskDialog.tsx
var QUICK_ADD_TASK_I18N_KEYS = {
	title: "popup.quickAdd.title",
	description: "popup.quickAdd.description",
	inputLabel: "popup.quickAdd.inputLabel",
	placeholder: "popup.quickAdd.placeholder",
	cancel: "popup.quickAdd.cancel",
	add: "popup.quickAdd.add",
	submitting: "popup.quickAdd.submitting",
	errors: {
		empty: "popup.quickAdd.error.empty",
		unsupported: "popup.quickAdd.error.unsupported",
		invalid: "popup.quickAdd.error.invalid",
		submitFailed: "popup.quickAdd.error.submitFailed"
	}
};
function QuickAddTaskDialog({ open, onOpenChange, onCreated }) {
	const { t } = useTranslation();
	const onOpenChangeRef = (0, import_react.useRef)(onOpenChange);
	const onCreatedRef = (0, import_react.useRef)(onCreated);
	(0, import_react.useEffect)(() => {
		onOpenChangeRef.current = onOpenChange;
		onCreatedRef.current = onCreated;
	}, [onCreated, onOpenChange]);
	const controller = useQuickAddTask({ onCreated: (0, import_react.useCallback)(async (taskId) => {
		try {
			await onCreatedRef.current(taskId);
		} finally {
			onOpenChangeRef.current(false);
		}
	}, []) });
	const previousOpenRef = (0, import_react.useRef)(open);
	(0, import_react.useEffect)(() => {
		if (previousOpenRef.current && !open) controller.reset();
		previousOpenRef.current = open;
	}, [controller.reset, open]);
	const requestOpenChange = (nextOpen) => {
		if (!nextOpen && controller.submitting) return;
		if (!nextOpen) controller.reset();
		onOpenChange(nextOpen);
	};
	const errorId = controller.error ? "quick-add-task-error" : void 0;
	const describedBy = ["quick-add-task-description", errorId].filter(Boolean).join(" ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: requestOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			className: "max-w-[360px] gap-4 p-5 sm:max-w-[360px]",
			showCloseButton: false,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-4",
				"aria-busy": controller.submitting,
				onSubmit: (event) => {
					event.preventDefault();
					controller.submit();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
						className: "gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t(QUICK_ADD_TASK_I18N_KEYS.title) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
							id: "quick-add-task-description",
							className: "text-xs/5",
							children: t(QUICK_ADD_TASK_I18N_KEYS.description)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						"data-invalid": controller.error !== null,
						className: "gap-1.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "quick-add-task-input",
								className: "sr-only",
								children: t(QUICK_ADD_TASK_I18N_KEYS.inputLabel)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "quick-add-task-input",
								className: "min-h-[88px] max-h-32 resize-none [overflow-wrap:anywhere]",
								rows: 3,
								value: controller.input,
								placeholder: t(QUICK_ADD_TASK_I18N_KEYS.placeholder),
								autoFocus: true,
								autoCapitalize: "off",
								autoComplete: "off",
								spellCheck: false,
								disabled: controller.submitting,
								"aria-invalid": controller.error !== null,
								"aria-describedby": describedBy,
								onChange: (event) => controller.setInput(event.target.value)
							}),
							controller.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, {
								id: errorId,
								"aria-live": "assertive",
								children: t(QUICK_ADD_TASK_I18N_KEYS.errors[controller.error])
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "sr-only",
						role: "status",
						"aria-live": "polite",
						children: controller.submitting ? t(QUICK_ADD_TASK_I18N_KEYS.submitting) : ""
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: controller.submitting,
						onClick: () => requestOpenChange(false),
						children: t(QUICK_ADD_TASK_I18N_KEYS.cancel)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						disabled: controller.submitting || !controller.input.trim(),
						children: [controller.submitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							"data-icon": "inline-start",
							className: "animate-spin",
							"aria-hidden": "true"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
							"data-icon": "inline-start",
							"aria-hidden": "true"
						}), controller.submitting ? t(QUICK_ADD_TASK_I18N_KEYS.submitting) : t(QUICK_ADD_TASK_I18N_KEYS.add)]
					})] })
				]
			})
		})
	});
}
//#endregion
//#region src/popup/ControlPanel.tsx
var TASK_VIEWS = [
	"active",
	"failed",
	"recent"
];
var RESUMABLE = /* @__PURE__ */ new Set(["paused", "error"]);
var PAUSABLE = /* @__PURE__ */ new Set([
	"downloading",
	"fetching_metadata",
	"seeding",
	"queued"
]);
function formatBytes(bytes) {
	if (bytes === null || !Number.isFinite(bytes) || bytes <= 0) return "0 B";
	const units = [
		"B",
		"KB",
		"MB",
		"GB",
		"TB"
	];
	let value = bytes;
	let index = 0;
	while (value >= 1024 && index < units.length - 1) {
		value /= 1024;
		index += 1;
	}
	const precision = index === 0 || value >= 100 ? 0 : 1;
	return `${value.toFixed(precision)} ${units[index] ?? "B"}`;
}
function formatSpeed$1(bytesPerSecond) {
	return `${formatBytes(bytesPerSecond)}/s`;
}
function taskTime(task) {
	return task.finishedAt ?? task.createdAt;
}
function filterTasks(tasks, view) {
	return [...tasks.filter((task) => {
		if (view === "failed") return task.status === "error";
		if (view === "recent") return task.status === "completed";
		return task.status !== "error" && task.status !== "completed";
	})].sort((a, b) => taskTime(b) - taskTime(a));
}
function taskIcon(type, status) {
	if (status === "error") return CircleAlert;
	if (status === "completed") return CircleCheck;
	if (type === "magnet") return Magnet;
	if (type === "bt") return FileArchive;
	return FileDown;
}
function taskIconClassName(status) {
	if (status === "error") return "bg-destructive/[0.08] text-destructive";
	if (status === "completed") return "bg-connection-online/[0.08] text-connection-online";
	if (status === "paused") return "bg-muted text-muted-foreground";
	return "bg-speed-download/[0.07] text-speed-download";
}
var TaskIdentity = (0, import_react.memo)(function TaskIdentity({ name, type, status }) {
	const Icon = taskIcon(type, status);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `absolute top-[17px] left-4 flex size-10 items-center justify-center rounded-[10px] ${taskIconClassName(status)}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5",
			strokeWidth: 1.8,
			"aria-hidden": "true"
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute top-[9px] right-2 left-[72px] truncate text-[13px]/5 font-normal",
		title: name,
		children: name
	})] });
});
var TaskLiveMetrics = (0, import_react.memo)(function TaskLiveMetrics({ name, status, progress, bytesDone, bytesTotal, speedBps, error, secondaryId }) {
	const { t } = useTranslation();
	const progressPercent = Math.round(Math.min(1, Math.max(0, progress)) * 100);
	const statusLabel = t(`popup.tasks.status.${status}`);
	const bytes = t("popup.tasks.bytes", {
		done: formatBytes(bytesDone),
		total: bytesTotal === null ? "—" : formatBytes(bytesTotal)
	});
	const secondary = [
		statusLabel,
		status === "error" ? error : bytes,
		speedBps > 0 ? formatSpeed$1(speedBps) : null
	].filter((part) => Boolean(part)).join(" · ");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		id: secondaryId,
		className: "absolute top-[31px] right-2 left-[72px] truncate text-[11px]/4 text-muted-foreground",
		title: secondary,
		children: secondary
	}), status !== "error" && status !== "completed" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
		value: progressPercent,
		"aria-label": `${name} ${progressPercent}%`,
		className: `absolute top-[55px] right-2 left-[72px] h-1 gap-0 [&_[data-slot=progress-track]]:h-1 [&_[data-slot=progress-track]]:bg-muted ${status === "paused" ? "[&_[data-slot=progress-indicator]]:bg-muted-foreground" : "[&_[data-slot=progress-indicator]]:bg-speed-download"}`
	})] });
});
var TaskActions = (0, import_react.memo)(function TaskActions({ taskId, taskName, status, onPause, onResume, onReveal, onRemove, canRevealTask, revealing }) {
	const { t } = useTranslation();
	const revealReady = canRevealTask && status !== "fetching_metadata";
	const revealLabel = !canRevealTask ? t("popup.tasks.openFolderUnsupported") : status === "fetching_metadata" ? t("popup.tasks.openFolderMetadataPending") : t("popup.tasks.openFolderTask", { name: taskName });
	const revealUnavailable = !revealReady || revealing;
	const transferAction = PAUSABLE.has(status) ? "pause" : RESUMABLE.has(status) ? "resume" : null;
	const transferLabel = transferAction === "pause" ? t("popup.tasks.pauseTask", { name: taskName }) : t("popup.tasks.resumeTask", { name: taskName });
	const TransferIcon = transferAction === "resume" ? Play : Pause;
	const removeLabel = t("popup.tasks.removeTask", { name: taskName });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-testid": `task-actions-${taskId}`,
		className: "absolute top-[23px] right-3 z-10 flex w-[88px] items-center justify-end gap-0.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-xs",
				"data-testid": `task-reveal-${taskId}`,
				"data-task-id": taskId,
				"data-task-action": "reveal",
				className: "size-7 text-muted-foreground aria-disabled:cursor-not-allowed aria-disabled:opacity-50",
				"aria-label": revealLabel,
				"aria-busy": revealing || void 0,
				"aria-disabled": revealUnavailable || void 0,
				title: revealLabel,
				onClick: (event) => {
					event.stopPropagation();
					if (revealUnavailable) return;
					onReveal(taskId);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, {
					className: "size-3.5",
					"aria-hidden": "true"
				})
			}),
			transferAction !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-xs",
				"data-testid": `task-transfer-${taskId}`,
				"data-task-id": taskId,
				"data-task-action": "transfer",
				className: "size-7 text-muted-foreground",
				"aria-label": transferLabel,
				title: transferLabel,
				onClick: (event) => {
					event.stopPropagation();
					if (transferAction === "pause") onPause(taskId);
					else onResume(taskId);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransferIcon, {
					className: "size-3.5",
					"aria-hidden": "true"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-xs",
				"data-task-id": taskId,
				"data-task-action": "remove",
				className: "size-7 text-muted-foreground hover:bg-destructive/10 hover:text-destructive",
				"aria-label": removeLabel,
				title: removeLabel,
				onClick: (event) => {
					event.stopPropagation();
					onRemove(taskId, event.shiftKey);
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
					className: "size-3.5",
					"aria-hidden": "true"
				})
			})
		]
	});
});
function taskRowPropsEqual(previous, next) {
	const a = previous.task;
	const b = next.task;
	return previous.onPause === next.onPause && previous.onResume === next.onResume && previous.onReveal === next.onReveal && previous.onRemove === next.onRemove && previous.canRevealTask === next.canRevealTask && previous.revealing === next.revealing && a.id === b.id && a.name === b.name && a.type === b.type && a.status === b.status && a.progress === b.progress && a.bytesDone === b.bytesDone && a.bytesTotal === b.bytesTotal && a.speedBps === b.speedBps && a.error === b.error;
}
var TaskRow = (0, import_react.memo)(function TaskRow({ task, onPause, onResume, onReveal, onRemove, canRevealTask, revealing }) {
	const { t } = useTranslation();
	const revealReady = canRevealTask && task.status !== "fetching_metadata";
	const secondaryId = `task-secondary-${task.id}`;
	const revealUnavailable = !revealReady || revealing;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		"data-testid": `task-row-${task.id}`,
		className: "relative h-[74px] shrink-0 after:pointer-events-none after:absolute after:inset-x-4 after:bottom-0 after:h-px after:bg-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"data-testid": `task-main-${task.id}`,
				"data-task-id": task.id,
				"data-task-action": "main",
				className: "absolute inset-y-0 right-[108px] left-0 text-left transition-colors hover:bg-muted/30 focus-visible:bg-muted/40 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ring/50 focus-visible:outline-none aria-disabled:pointer-events-none",
				"aria-label": revealReady ? t("popup.tasks.openFolderTask", { name: task.name }) : void 0,
				"aria-describedby": secondaryId,
				"aria-busy": revealing || void 0,
				"aria-disabled": revealUnavailable || void 0,
				"aria-hidden": revealReady ? void 0 : true,
				tabIndex: revealReady ? 0 : -1,
				onClick: () => {
					if (!revealUnavailable) onReveal(task.id);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-y-0 right-[108px] left-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskIdentity, {
					name: task.name,
					type: task.type,
					status: task.status
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskLiveMetrics, {
					name: task.name,
					status: task.status,
					progress: task.progress,
					bytesDone: task.bytesDone,
					bytesTotal: task.bytesTotal,
					speedBps: task.speedBps,
					error: task.error,
					secondaryId
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskActions, {
				taskId: task.id,
				taskName: task.name,
				status: task.status,
				onPause,
				onResume,
				onReveal,
				onRemove,
				canRevealTask,
				revealing
			})
		]
	});
}, taskRowPropsEqual);
function EmptyTasks({ view }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
		role: "status",
		className: "h-full overflow-y-auto px-4 py-6 [overflow-wrap:anywhere]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, {
			className: "w-full min-w-0 gap-2.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, {
				className: "mb-0 text-muted-foreground/55",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, {
					className: "size-7",
					strokeWidth: 1.5,
					"aria-hidden": "true"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
				className: "text-sm leading-5 font-medium tracking-normal text-muted-foreground",
				children: t(`popup.tasks.empty.${view}`)
			})]
		})
	});
}
var ControlPanel = (0, import_react.memo)(function ControlPanel({ connection, controller, canRevealTask = false, onReconnect, notice }) {
	const { t } = useTranslation();
	const [view, setView] = (0, import_react.useState)("active");
	const [quickAddOpen, setQuickAddOpen] = (0, import_react.useState)(false);
	const [actionError, setActionError] = (0, import_react.useState)(null);
	const [taskToRemove, setTaskToRemove] = (0, import_react.useState)(null);
	const [removeDialogOpen, setRemoveDialogOpen] = (0, import_react.useState)(false);
	const [removingTask, setRemovingTask] = (0, import_react.useState)(false);
	const [deleteTaskFiles, setDeleteTaskFiles] = (0, import_react.useState)(false);
	const deleteTaskFilesId = (0, import_react.useId)();
	const [revealingTaskIds, setRevealingTaskIds] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const tasksByView = (0, import_react.useMemo)(() => Object.fromEntries(TASK_VIEWS.map((candidate) => [candidate, filterTasks(controller.tasks, candidate)])), [controller.tasks]);
	const connectionPending = connection === null || connection === "bootstrapping" || connection === "connecting" || connection === "handshaking" || connection === "awaiting-code";
	const runAction = (0, import_react.useCallback)(async (action) => {
		setActionError(null);
		try {
			await action();
		} catch (error) {
			setActionError(error.message);
		}
	}, []);
	const revealTask = (0, import_react.useCallback)(async (taskId) => {
		setActionError(null);
		setRevealingTaskIds((current) => new Set(current).add(taskId));
		try {
			await controller.reveal(taskId);
		} catch {
			setActionError(t("popup.tasks.openFolderError"));
		} finally {
			setRevealingTaskIds((current) => {
				const next = new Set(current);
				next.delete(taskId);
				return next;
			});
		}
	}, [controller.reveal, t]);
	const pauseTask = (0, import_react.useCallback)((taskId) => {
		runAction(() => controller.pause(taskId));
	}, [controller.pause, runAction]);
	const resumeTask = (0, import_react.useCallback)((taskId) => {
		runAction(() => controller.resume(taskId));
	}, [controller.resume, runAction]);
	const removeTask = (0, import_react.useCallback)((taskId, deleteFiles) => {
		const task = controller.tasks.find((candidate) => candidate.id === taskId);
		if (task) {
			setDeleteTaskFiles(deleteFiles);
			setTaskToRemove({
				id: task.id,
				name: task.name
			});
			setRemoveDialogOpen(true);
		}
	}, [controller.tasks]);
	const confirmRemoveTask = (0, import_react.useCallback)(async () => {
		if (taskToRemove === null || removingTask) return;
		setActionError(null);
		setRemovingTask(true);
		try {
			await controller.remove(taskToRemove.id, deleteTaskFiles);
		} catch (error) {
			setActionError(error.message);
		} finally {
			setRemovingTask(false);
			setDeleteTaskFiles(false);
			setRemoveDialogOpen(false);
		}
	}, [
		controller.remove,
		deleteTaskFiles,
		removingTask,
		taskToRemove
	]);
	const filter = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
		className: "h-auto min-h-8 w-full min-w-0 flex-1 flex-wrap items-stretch gap-0 rounded-[10px] bg-tab-background p-0.5 group-data-horizontal/tabs:h-auto",
		children: TASK_VIEWS.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
			value: candidate,
			disabled: controller.loading,
			className: "h-auto min-h-7 w-auto min-w-0 max-w-full flex-auto border-0 px-2 py-1 whitespace-normal [overflow-wrap:anywhere] text-[11px] font-normal shadow-none group-data-[variant=default]/tabs-list:data-active:shadow-xs",
			children: t(`popup.tasks.filters.${candidate}`)
		}, candidate))
	});
	const quickAddAction = connection === "connected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "outline",
		size: "icon-sm",
		className: "size-8 rounded-full",
		"aria-label": t("popup.quickAdd.title"),
		title: t("popup.quickAdd.title"),
		disabled: controller.loading,
		onClick: () => setQuickAddOpen(true),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
			className: "size-4.5",
			"aria-hidden": "true"
		})
	}) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
			value: view,
			onValueChange: (value) => setView(value),
			className: "h-full min-h-0 gap-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactSectionToolbar, {
				title: t("popup.tasks.title"),
				controls: connection === "connected" ? filter : void 0,
				action: quickAddAction
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CompactContentCard, {
				"data-testid": "task-card",
				className: "flex flex-col",
				children: [
					notice !== void 0 && notice !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "shrink-0",
						children: notice
					}) : null,
					(controller.error || actionError) && connection === "connected" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
						variant: "destructive",
						className: "mx-3 mt-3 shrink-0 py-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: actionError ?? controller.error })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1",
						children: connectionPending || connection === "connected" && controller.loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
							className: "h-full overflow-y-auto p-4 [overflow-wrap:anywhere]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, {
								className: "w-full min-w-0 gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, {
									className: "mb-0 text-muted-foreground/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
										className: "size-5",
										"aria-label": t(connectionPending ? "popup.status.connecting" : "popup.tasks.loading")
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
									className: "text-sm leading-5 font-medium tracking-normal text-muted-foreground",
									children: t(connectionPending ? "popup.status.connecting" : "popup.tasks.loading")
								})]
							})
						}) : connection !== "connected" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Empty, {
							className: "h-full gap-2 overflow-y-auto p-3 [overflow-wrap:anywhere]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHeader, {
								className: "w-full min-w-0 gap-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
									className: "text-sm leading-5 font-medium tracking-normal",
									children: t("popup.tasks.disconnectedTitle")
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyContent, {
								className: "gap-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									size: "sm",
									onClick: onReconnect,
									children: t("popup.reconnect")
								})
							})]
						}) : TASK_VIEWS.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
							value: candidate,
							className: "h-full min-h-0 overflow-hidden",
							children: tasksByView[candidate].length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTasks, { view: candidate }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
								className: "h-full w-full",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "flex flex-col",
									children: tasksByView[candidate].map((task) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TaskRow, {
										task,
										onPause: pauseTask,
										onResume: resumeTask,
										onReveal: revealTask,
										onRemove: removeTask,
										canRevealTask,
										revealing: revealingTaskIds.has(task.id)
									}, task.id))
								})
							})
						}, candidate))
					}),
					connection === "connected" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "flex h-11 w-full shrink-0 items-center justify-between px-4 text-xs font-normal text-muted-foreground transition-colors hover:bg-muted/40 hover:text-foreground focus-visible:ring-3 focus-visible:ring-ring/50 focus-visible:outline-none",
						"aria-label": `${t("popup.tasks.filters.recent")} (${tasksByView.recent.length})`,
						"aria-current": view === "recent" ? "page" : void 0,
						onClick: () => setView("recent"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: tasksByView.recent.length
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("popup.tasks.filters.recent") })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
							className: "size-4",
							"aria-hidden": "true"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickAddTaskDialog, {
			open: quickAddOpen,
			onOpenChange: setQuickAddOpen,
			onCreated: async () => {
				setView("active");
				await controller.refresh();
			}
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
			open: removeDialogOpen,
			onOpenChange: (open) => {
				if (!open && !removingTask) {
					setDeleteTaskFiles(false);
					setRemoveDialogOpen(false);
				}
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
				size: "sm",
				className: "max-w-[360px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("popup.tasks.removeConfirmTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("popup.tasks.removeConfirmDescription", { name: taskToRemove?.name ?? "" }) })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						htmlFor: deleteTaskFilesId,
						className: "flex cursor-pointer items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: deleteTaskFilesId,
							type: "checkbox",
							checked: deleteTaskFiles,
							disabled: removingTask,
							onChange: (event) => setDeleteTaskFiles(event.target.checked),
							className: "size-4 accent-primary"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t("popup.tasks.removeDeleteFilesLabel") })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						type: "button",
						disabled: removingTask,
						children: t("options.common.cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogAction, {
						type: "button",
						variant: "destructive",
						disabled: removingTask,
						onClick: () => void confirmRemoveTask(),
						children: [removingTask && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }), t("popup.tasks.removeConfirmAction")]
					})] })
				]
			})
		})
	] });
});
//#endregion
//#region src/popup/DashboardTile.tsx
function DashboardTileContent({ label, value, unit, icon: Icon, iconClassName, decoration }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex min-w-0 items-start justify-between gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 text-[9px]/3 font-medium text-muted-foreground [overflow-wrap:anywhere]",
				children: label
			}), Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				"aria-hidden": "true",
				"data-slot": "dashboard-tile-icon",
				className: cn("size-4 shrink-0", iconClassName),
				strokeWidth: 2
			}) : null]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			"data-slot": "dashboard-tile-value-row",
			className: "flex min-h-[22px] min-w-0 items-baseline gap-0.5 whitespace-nowrap",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"data-slot": "dashboard-tile-value",
				className: "text-[20px] leading-none font-semibold tracking-[-0.01em] tabular-nums",
				children: value
			}), unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				"data-slot": "dashboard-tile-unit",
				className: "shrink-0 text-[8px] leading-none font-normal tracking-normal text-foreground",
				children: unit
			}) : null]
		}),
		decoration
	] });
}
var TILE_CLASS_NAME = "relative row-span-3 grid min-h-20 min-w-0 grid-rows-subgrid gap-y-2 overflow-hidden p-2 pb-4 rounded-[10px] border border-border bg-card text-left shadow-card";
function DashboardTile(props) {
	const { label, value, unit, icon, iconClassName, className, decoration, testId, onClick, ariaLabel } = props;
	const contentProps = {
		label,
		value,
		...unit === void 0 ? {} : { unit },
		...icon === void 0 ? {} : { icon },
		...iconClassName === void 0 ? {} : { iconClassName },
		...decoration === void 0 ? {} : { decoration }
	};
	if (onClick) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"data-testid": testId,
		"aria-label": ariaLabel,
		disabled: props.disabled,
		onClick,
		className: cn(TILE_CLASS_NAME, "outline-none transition-colors hover:bg-muted/30 focus-visible:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50", className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardTileContent, { ...contentProps })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "group",
		"data-testid": testId,
		"aria-label": ariaLabel ?? label,
		className: cn(TILE_CLASS_NAME, className),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardTileContent, { ...contentProps })
	});
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/root/PopoverRootContext.mjs
var PopoverRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function usePopoverRootContext(optional) {
	const context = import_react.useContext(PopoverRootContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(47));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/store/PopoverStore.mjs
var selectors = {
	...popupStoreSelectors,
	disabled: (state) => state.disabled,
	instantType: (state) => state.instantType,
	openMethod: (state) => state.openMethod,
	openChangeReason: (state) => state.openChangeReason,
	modal: (state) => state.modal,
	focusManagerModal: (state) => state.focusManagerModal,
	stickIfOpen: (state) => state.stickIfOpen,
	titleElementId: (state) => state.titleElementId,
	descriptionElementId: (state) => state.descriptionElementId,
	openOnHover: (state) => state.openOnHover,
	closeDelay: (state) => state.closeDelay,
	adaptiveOrigin: (state) => state.adaptiveOrigin
};
/**
* The store view that detached handle-backed triggers read from. Both the real `PopoverStore` and
* the inert fallback store satisfy it, so a trigger can read from whichever store the handle
* currently exposes. Narrowed to the members a trigger actually uses — the trigger-data members plus
* `setOpen` (called by the focus guards) — so the exposed surface can't bypass the open-change
* pipeline; on the detached fallback store every one of these mutations is a no-op.
*/
var PopoverStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		super(createInitialState(initialState, triggerElements, floatingId, nested), createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		const isHover = eventDetails.reason === triggerHover;
		const isKeyboardClick = eventDetails.reason === "trigger-press" && eventDetails.event.detail === 0;
		const isDismissClose = !nextOpen && (eventDetails.reason === "escape-key" || eventDetails.reason == null);
		const shouldPreventUnmountOnClose = attachPreventUnmountOnClose(eventDetails);
		const activeTriggerId = this.select("activeTriggerId");
		if (!nextOpen && eventDetails.reason === "close-press" && eventDetails.trigger == null && activeTriggerId != null) eventDetails.trigger = this.context.triggerElements.getById(activeTriggerId) ?? this.select("activeTriggerElement") ?? void 0;
		this.context.onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		this.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		const changeState = () => {
			const updatedState = {
				open: nextOpen,
				openChangeReason: eventDetails.reason
			};
			setPopupOpenState(updatedState, nextOpen, eventDetails.trigger, shouldPreventUnmountOnClose());
			this.update(updatedState);
		};
		if (isHover) {
			this.set("stickIfOpen", true);
			this.context.stickIfOpenTimeout.start(500, () => {
				this.set("stickIfOpen", false);
			});
			import_react_dom.flushSync(changeState);
		} else changeState();
		let instantType;
		if (isKeyboardClick) instantType = "click";
		else if (isDismissClose) instantType = "dismiss";
		else if (eventDetails.reason === "focus-out") instantType = "focus";
		this.set("instantType", instantType);
	};
};
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	const state = {
		...createInitialPopupStoreState(),
		disabled: false,
		modal: false,
		focusManagerModal: false,
		instantType: void 0,
		openMethod: null,
		openChangeReason: null,
		titleElementId: void 0,
		descriptionElementId: void 0,
		stickIfOpen: true,
		openOnHover: false,
		closeDelay: 0,
		adaptiveOrigin: void 0,
		...initialState
	};
	if (state.open && initialState?.mounted === void 0) state.mounted = true;
	state.floatingRootContext = createPopupFloatingRootContext(triggerElements, floatingId, nested);
	return state;
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChange: void 0,
		onOpenChangeComplete: void 0,
		triggerFocusTargetRef: /*#__PURE__*/ import_react.createRef(),
		beforeContentFocusGuardRef: /*#__PURE__*/ import_react.createRef(),
		stickIfOpenTimeout: new Timeout(),
		triggerElements
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/root/PopoverRoot.mjs
function PopoverRootComponent({ props }) {
	const { children, open: openProp, defaultOpen = false, onOpenChange, onOpenChangeComplete, modal = false, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null } = props;
	const store = usePopoverRootStore(handle, {
		modal,
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp
	});
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	usePopupRootSync(store, open);
	useImplicitActiveTrigger(store);
	const { forceUnmount } = useOpenStateTransitions(open, store, () => {
		store.update({
			stickIfOpen: true,
			openChangeReason: null
		});
	});
	store.useSyncedValues({ modal });
	import_react.useEffect(() => {
		if (!open) store.context.stickIfOpenTimeout.clear();
	}, [store, open]);
	import_react.useImperativeHandle(props.actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PopoverRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopoverInteractions, {
				store,
				modal
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
}
/**
* Groups all parts of the popover.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
function PopoverRoot(props) {
	if (usePopoverRootContext(true)) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopoverRootComponent, { props });
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingTree, { children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopoverRootComponent, { props }) });
}
function usePopoverRootStore(handle, initialState) {
	const store = usePopupRootStore((floatingId, nested) => new PopoverStore(initialState, floatingId, nested));
	import_react.useEffect(() => store.context.stickIfOpenTimeout.disposeEffect(), [store]);
	return store;
}
function PopoverInteractions({ store, modal }) {
	const floatingRootContext = store.useState("floatingRootContext");
	const dismiss = useDismiss(floatingRootContext, { outsidePressEvent: {
		mouse: modal === "trap-focus" ? "sloppy" : "intentional",
		touch: "sloppy"
	} });
	const triggerProps = dismiss.reference;
	const popupProps = dismiss.floating;
	usePopupInteractionProps(store, {
		activeTriggerProps: triggerProps,
		inactiveTriggerProps: triggerProps,
		popupProps
	});
	return null;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/trigger/PopoverTrigger.mjs
/**
* A button that opens the popover.
* Renders a `<button>` element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
var PopoverTrigger$1 = /*#__PURE__*/ import_react.forwardRef(function PopoverTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, handle, payload, openOnHover = false, delay = 300, closeDelay = 0, id: idProp, ...elementProps } = componentProps;
	const rootStore = usePopoverRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootStore;
	if (!store) throw new Error(formatErrorMessage(74));
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const floatingContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		disabled,
		openOnHover,
		closeDelay
	});
	const openReason = store.useState("openChangeReason");
	const stickIfOpen = store.useState("stickIfOpen");
	const openMethod = store.useState("openMethod");
	const focusManagerModal = store.useState("focusManagerModal");
	const hoverProps = useHoverReferenceInteraction(floatingContext, {
		enabled: !disabled && openOnHover && (openMethod !== "touch" || openReason !== "trigger-press"),
		mouseOnly: true,
		move: false,
		handleClose: safePolygon(),
		restMs: delay,
		delay: { close: closeDelay },
		triggerElementRef,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending"
	});
	const click = useClick(floatingContext, { stickIfOpen });
	const interactionTypeProps = useOpenMethodTriggerProps(() => store.select("open"), (interactionType) => {
		store.set("openMethod", interactionType);
	});
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const stateAttributesMapping = { open(value) {
		if (value && openReason === "trigger-press") return pressableTriggerOpenStateMapping.open(value);
		return triggerOpenStateMapping.open(value);
	} };
	const { preFocusGuardRef, handlePreFocusGuardFocus, handleFocusTargetFocus } = useTriggerFocusGuards(store, triggerElementRef);
	const element = useRenderElement("button", componentProps, {
		state: {
			disabled,
			open: isOpenedByThisTrigger
		},
		ref: [
			buttonRef,
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			click.reference,
			hoverProps,
			rootTriggerProps,
			interactionTypeProps,
			{
				[CLICK_TRIGGER_IDENTIFIER]: "",
				id: thisTriggerId,
				"aria-haspopup": "dialog",
				"aria-expanded": isOpenedByThisTrigger,
				"aria-controls": popupId
			},
			elementProps,
			getButtonProps
		],
		stateAttributesMapping
	});
	const keyedElement = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: element }, thisTriggerId);
	if (isMountedByThisTrigger && !focusManagerModal) return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: preFocusGuardRef,
			onFocus: handlePreFocusGuardFocus
		}),
		keyedElement,
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: store.context.triggerFocusTargetRef,
			onFocus: handleFocusTargetFocus
		})
	] });
	return keyedElement;
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/portal/PopoverPortalContext.mjs
var PopoverPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
function usePopoverPortalContext() {
	const value = import_react.useContext(PopoverPortalContext);
	if (value === void 0) throw new Error(formatErrorMessage(45));
	return value;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/portal/PopoverPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
var PopoverPortal = /*#__PURE__*/ import_react.forwardRef(function PopoverPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	if (!(usePopoverRootContext().useState("mounted") || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopoverPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/positioner/PopoverPositionerContext.mjs
var PopoverPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
function usePopoverPositionerContext() {
	const context = import_react.useContext(PopoverPositionerContext);
	if (!context) throw new Error(formatErrorMessage(46));
	return context;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/positioner/PopoverPositioner.mjs
/**
* Positions the popover against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
var PopoverPositioner = /*#__PURE__*/ import_react.forwardRef(function PopoverPositioner(componentProps, forwardedRef) {
	const { render, className, style, anchor, positionMethod, side, align, sideOffset, alignOffset, collisionBoundary = "clipping-ancestors", collisionPadding, arrowPadding, sticky, disableAnchorTracking = false, collisionAvoidance = POPUP_COLLISION_AVOIDANCE, ...elementProps } = componentProps;
	const store = usePopoverRootContext();
	const keepMounted = usePopoverPortalContext();
	const nodeId = useFloatingNodeId();
	const floatingRootContext = store.useState("floatingRootContext");
	const mounted = store.useState("mounted");
	const open = store.useState("open");
	const openReason = store.useState("openChangeReason");
	const triggerElement = store.useState("activeTriggerElement");
	const modal = store.useState("modal");
	const openMethod = store.useState("openMethod");
	const positionerElement = store.useState("positionerElement");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const prevTriggerElementRef = import_react.useRef(null);
	const runOnceAnimationsFinish = useAnimationsFinished(positionerElement);
	const positioning = useAnchorPositioning({
		anchor,
		floatingRootContext,
		positionMethod,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		disableAnchorTracking,
		keepMounted,
		nodeId,
		collisionAvoidance,
		adaptiveOrigin
	});
	const domReference = floatingRootContext.useState("domReferenceElement");
	useIsoLayoutEffect(() => {
		const currentTriggerElement = domReference;
		const prevTriggerElement = prevTriggerElementRef.current;
		if (currentTriggerElement) prevTriggerElementRef.current = currentTriggerElement;
		if (prevTriggerElement && currentTriggerElement && currentTriggerElement !== prevTriggerElement) {
			store.set("instantType", void 0);
			const ac = new AbortController();
			runOnceAnimationsFinish(() => {
				store.set("instantType", "trigger-change");
			}, ac.signal);
			return () => {
				ac.abort();
			};
		}
	}, [
		domReference,
		runOnceAnimationsFinish,
		store
	]);
	const trueModalNonHover = modal === true && openReason !== "trigger-hover";
	useAnchoredPopupScrollLock(open && trueModalNonHover, openMethod === "touch", positionerElement, triggerElement);
	const setPositionerElement = store.useStateSetter("positionerElement");
	const state = {
		open,
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden,
		instant: instantType
	};
	const element = usePositioner(componentProps, state, {
		styles: positioning.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, setPositionerElement],
		hidden: !mounted,
		inert: !open
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PopoverPositionerContext.Provider, {
		value: positioning,
		children: [mounted && trueModalNonHover && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
			inert: inertValue(!open),
			cutout: triggerElement
		}), /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingNode, {
			id: nodeId,
			children: element
		})]
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/utils/closePart.mjs
var ClosePartContext = /*#__PURE__*/ import_react.createContext(void 0);
function useClosePartCount() {
	const [closePartCount, setClosePartCount] = import_react.useState(0);
	const register = useStableCallback(() => {
		setClosePartCount((count) => count + 1);
		return () => {
			setClosePartCount((count) => Math.max(0, count - 1));
		};
	});
	return {
		context: import_react.useMemo(() => ({ register }), [register]),
		hasClosePart: closePartCount > 0
	};
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/popup/PopoverPopup.mjs
/**
* A container for the popover contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
var PopoverPopup = /*#__PURE__*/ import_react.forwardRef(function PopoverPopup(componentProps, forwardedRef) {
	const { render, className, style, initialFocus, finalFocus, ...elementProps } = componentProps;
	const store = usePopoverRootContext();
	const positioner = usePopoverPositionerContext();
	const insideToolbar = useToolbarRootContext(true) != null;
	const { context: closePartContext, hasClosePart } = useClosePartCount();
	const open = store.useState("open");
	const openMethod = store.useState("openMethod");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const titleId = store.useState("titleElementId");
	const descriptionId = store.useState("descriptionElementId");
	const modal = store.useState("modal");
	const mounted = store.useState("mounted");
	const openReason = store.useState("openChangeReason");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const floatingContext = store.useState("floatingRootContext");
	const floatingId = floatingContext.useState("floatingId");
	const disabled = store.useState("disabled");
	const openOnHover = store.useState("openOnHover");
	const closeDelay = store.useState("closeDelay");
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	useHoverFloatingInteraction(floatingContext, {
		enabled: openOnHover && !disabled,
		closeDelay
	});
	const resolvedInitialFocus = initialFocus === void 0 ? createDefaultInitialFocus(store.context.popupRef) : initialFocus;
	const focusManagerModal = modal !== false && hasClosePart;
	store.useSyncedValue("focusManagerModal", focusManagerModal);
	const setPopupElement = store.useStateSetter("popupElement");
	const state = {
		open,
		side: positioner.side,
		align: positioner.align,
		instant: instantType,
		transitionStatus
	};
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		props: [
			popupProps,
			{
				id: floatingId,
				role: "dialog",
				...FOCUSABLE_POPUP_PROPS,
				"aria-labelledby": titleId,
				"aria-describedby": descriptionId,
				onKeyDown(event) {
					if (insideToolbar && COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
				}
			},
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		],
		stateAttributesMapping: popupTransitionStateMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingContext,
		openInteractionType: openMethod,
		modal: focusManagerModal,
		disabled: !mounted || openReason === "trigger-hover",
		initialFocus: resolvedInitialFocus,
		returnFocus: finalFocus,
		restoreFocus: "popup",
		previousFocusableElement: isHTMLElement(activeTriggerElement) ? activeTriggerElement : void 0,
		nextFocusableElement: store.context.triggerFocusTargetRef,
		beforeContentFocusGuardRef: store.context.beforeContentFocusGuardRef,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ClosePartContext.Provider, {
			value: closePartContext,
			children: element
		})
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.7.0_@types_e9c1e83f6bc6140c3efaf3427f2fbf0a/node_modules/@base-ui/react/popover/title/PopoverTitle.mjs
/**
* A heading that labels the popover.
* Renders an `<h2>` element.
*
* Documentation: [Base UI Popover](https://base-ui.com/react/components/popover)
*/
var PopoverTitle$1 = /*#__PURE__*/ import_react.forwardRef(function PopoverTitle(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = usePopoverRootContext();
	const id = useBaseUiId(elementProps.id);
	store.useSyncedValueWithCleanup("titleElementId", id);
	return useRenderElement("h2", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
//#endregion
//#region src/components/ui/popover.tsx
function Popover({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverRoot, {
		"data-slot": "popover",
		...props
	});
}
function PopoverTrigger({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTrigger$1, {
		"data-slot": "popover-trigger",
		...props
	});
}
function PopoverContent({ anchor, className, align = "center", alignOffset = 0, side = "bottom", sideOffset = 4, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPositioner, {
		anchor,
		align,
		alignOffset,
		side,
		sideOffset,
		className: "isolate z-50 outline-none",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverPopup, {
			"data-slot": "popover-content",
			className: cn("z-50 w-72 origin-(--transform-origin) rounded-xl border border-border bg-popover p-4 text-sm text-popover-foreground shadow-sm outline-hidden duration-100 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className),
			...props
		})
	}) });
}
function PopoverHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "popover-header",
		className: cn("flex flex-col gap-1", className),
		...props
	});
}
function PopoverTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTitle$1, {
		"data-slot": "popover-title",
		className: cn("font-medium", className),
		...props
	});
}
//#endregion
//#region src/popup/imageQuickFilters.ts
var FORMAT_ORDER = [
	"JPG",
	"PNG",
	"WEBP",
	"GIF",
	"AVIF",
	"APNG",
	"BMP",
	"ICO",
	"TIFF",
	"HEIC",
	"HEIF",
	"JXL",
	"OTHER"
];
var FORMAT_SET = new Set(FORMAT_ORDER);
var MAX_IMAGE_DIMENSION = 1e5;
var MIME_FORMATS = {
	"image/apng": "APNG",
	"image/avif": "AVIF",
	"image/avif-sequence": "AVIF",
	"image/bmp": "BMP",
	"image/gif": "GIF",
	"image/heic": "HEIC",
	"image/heic-sequence": "HEIC",
	"image/heif": "HEIF",
	"image/heif-sequence": "HEIF",
	"image/jfif": "JPG",
	"image/jpeg": "JPG",
	"image/jpg": "JPG",
	"image/jxl": "JXL",
	"image/pjpeg": "JPG",
	"image/png": "PNG",
	"image/tiff": "TIFF",
	"image/vnd.microsoft.icon": "ICO",
	"image/vnd.mozilla.apng": "APNG",
	"image/webp": "WEBP",
	"image/x-bmp": "BMP",
	"image/x-icon": "ICO",
	"image/x-ms-bmp": "BMP",
	"image/x-png": "PNG"
};
var EXTENSION_FORMATS = {
	apng: "APNG",
	avif: "AVIF",
	bmp: "BMP",
	gif: "GIF",
	heic: "HEIC",
	heif: "HEIF",
	ico: "ICO",
	jfif: "JPG",
	jpe: "JPG",
	jpeg: "JPG",
	jpg: "JPG",
	jxl: "JXL",
	pjp: "JPG",
	pjpeg: "JPG",
	png: "PNG",
	tif: "TIFF",
	tiff: "TIFF",
	webp: "WEBP"
};
function bareMimeType(mimeType) {
	if (typeof mimeType !== "string") return null;
	return mimeType.split(";", 1)[0]?.trim().toLowerCase() || null;
}
function urlExtension(url) {
	if (typeof url !== "string" || url.length === 0) return null;
	let pathname = url;
	try {
		pathname = new URL(url).pathname;
	} catch {
		pathname = url.split(/[?#]/, 1)[0] ?? url;
	}
	return /\.([a-z0-9]+)$/i.exec(pathname)?.[1]?.toLowerCase() ?? null;
}
/** Return a compact, language-independent format label for one image. */
function canonicalImageFormat(media) {
	const mimeType = bareMimeType(media.mimeType);
	if (mimeType) {
		const mimeFormat = MIME_FORMATS[mimeType];
		if (mimeFormat) return mimeFormat;
		if (mimeType.startsWith("image/") && mimeType !== "image/*") return "OTHER";
	}
	const extension = urlExtension(media.url);
	return extension && EXTENSION_FORMATS[extension] || "OTHER";
}
/** Return the formats present in the list using a fixed, non-page-controlled order. */
function availableImageFormats(media) {
	const present = new Set(media.map(canonicalImageFormat));
	return FORMAT_ORDER.filter((format) => present.has(format));
}
function normalizedFormat$1(value) {
	if (typeof value !== "string") return null;
	const normalized = value.trim().toUpperCase();
	const alias = normalized === "JPEG" ? "JPG" : normalized;
	return FORMAT_SET.has(alias) ? alias : null;
}
function maximumForMetric(metric) {
	return metric === "size" ? Number.MAX_SAFE_INTEGER : MAX_IMAGE_DIMENSION;
}
/** Validate a condition coming from form or persisted state without coercion. */
function normalizeImageQuickFilterCondition(condition, metric) {
	if (!condition || typeof condition !== "object" || Array.isArray(condition)) return;
	const { operator, value } = condition;
	if (operator !== "gte" && operator !== "eq" && operator !== "lte") return;
	if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > maximumForMetric(metric)) return;
	return {
		operator,
		value
	};
}
/** Canonicalize formats and remove malformed numeric conditions. */
function normalizeImageQuickFilters(filters) {
	if (!filters || typeof filters !== "object" || Array.isArray(filters)) return { formats: [] };
	const value = filters;
	const seenFormats = /* @__PURE__ */ new Set();
	if (Array.isArray(value.formats)) for (const entry of value.formats) {
		const format = normalizedFormat$1(entry);
		if (format) seenFormats.add(format);
	}
	const formats = FORMAT_ORDER.filter((format) => seenFormats.has(format));
	const width = normalizeImageQuickFilterCondition(value.width, "width");
	const height = normalizeImageQuickFilterCondition(value.height, "height");
	const size = normalizeImageQuickFilterCondition(value.size, "size");
	return {
		formats,
		...width ? { width } : {},
		...height ? { height } : {},
		...size ? { size } : {}
	};
}
function knownMetricValue(value, metric) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 && value <= maximumForMetric(metric) ? value : null;
}
function matchesCondition(actual, condition) {
	if (!condition) return true;
	if (actual === null) return false;
	if (condition.operator === "gte") return actual >= condition.value;
	if (condition.operator === "lte") return actual <= condition.value;
	return actual === condition.value;
}
function matchesImageQuickFilters(media, filters) {
	const normalized = normalizeImageQuickFilters(filters);
	if (normalized.formats.length > 0 && !normalized.formats.includes(canonicalImageFormat(media))) return false;
	return matchesCondition(knownMetricValue(media.width, "width"), normalized.width) && matchesCondition(knownMetricValue(media.height, "height"), normalized.height) && matchesCondition(knownMetricValue(media.sizeBytes, "size"), normalized.size);
}
/** Formats count as one active filter, regardless of how many are selected. */
function countActiveImageQuickFilters(filters) {
	const normalized = normalizeImageQuickFilters(filters);
	return (normalized.formats.length > 0 ? 1 : 0) + Number(Boolean(normalized.width)) + Number(Boolean(normalized.height)) + Number(Boolean(normalized.size));
}
//#endregion
//#region src/popup/ImageQuickFilterPopover.tsx
var OPERATORS = [
	"gte",
	"eq",
	"lte"
];
var OPERATOR_SYMBOLS = {
	gte: "≥",
	eq: "=",
	lte: "≤"
};
var SIZE_MULTIPLIERS = {
	kb: 1024,
	mb: 1048576
};
var SIZE_UNIT_LABELS = {
	kb: "KB",
	mb: "MB"
};
function normalizedFormat(value) {
	const normalized = value.trim().toUpperCase();
	return normalized === "JPEG" ? "JPG" : normalized;
}
function formatOptions(availableFormats, selectedFormats) {
	const seen = /* @__PURE__ */ new Set();
	const formats = [];
	for (const candidate of [...availableFormats, ...selectedFormats]) {
		const normalized = normalizedFormat(candidate);
		if (!normalized || seen.has(normalized)) continue;
		seen.add(normalized);
		formats.push(normalized);
	}
	return formats;
}
function withoutNumericFilter(filters, key) {
	const next = { ...filters };
	delete next[key];
	return next;
}
function finiteNonNegative(value) {
	if (value.trim() === "") return null;
	const parsed = Number(value);
	return Number.isFinite(parsed) && parsed >= 0 ? parsed : NaN;
}
function compactDecimal(value) {
	return String(Number(value.toFixed(6)));
}
function NumericFilterRow({ filterKey, filters, operator, unit, wideUnit = false, unitMultiplier = 1, onOperatorChange, onChange }) {
	const { t } = useTranslation();
	const condition = filters[filterKey];
	const value = condition ? compactDecimal(condition.value / unitMultiplier) : "";
	const label = t(`popup.sniffer.imageFilters.fields.${filterKey}`);
	const updateValue = (rawValue) => {
		const parsed = finiteNonNegative(rawValue);
		if (parsed === null) {
			onChange(withoutNumericFilter(filters, filterKey));
			return;
		}
		if (!Number.isFinite(parsed)) return;
		const convertedValue = parsed * unitMultiplier;
		if (!Number.isSafeInteger(convertedValue)) return;
		onChange({
			...filters,
			[filterKey]: {
				operator,
				value: convertedValue
			}
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("grid items-center gap-1.5", wideUnit ? "grid-cols-[40px_52px_minmax(0,1fr)_58px]" : "grid-cols-[40px_52px_minmax(0,1fr)_24px]"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[11px] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value: operator,
				items: OPERATOR_SYMBOLS,
				onValueChange: (value) => onOperatorChange(value),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					size: "sm",
					className: "w-[52px] px-1.5 py-0 text-[11px] shadow-none data-[size=sm]:h-6",
					"aria-label": t("popup.sniffer.imageFilters.operatorLabel", { label }),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
					align: "start",
					alignItemWithTrigger: false,
					className: "min-w-[52px] shadow-sm",
					children: OPERATORS.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: candidate,
						className: "text-[11px]",
						children: OPERATOR_SYMBOLS[candidate]
					}, candidate))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				type: "number",
				min: 0,
				step: "any",
				inputMode: "decimal",
				value,
				placeholder: "0",
				"aria-label": t("popup.sniffer.imageFilters.valueLabel", { label }),
				className: "h-6 px-2 text-[11px] shadow-none",
				onChange: (event) => updateValue(event.currentTarget.value)
			}),
			typeof unit === "string" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] text-muted-foreground",
				children: unit
			}) : unit
		]
	});
}
function ImageQuickFilterPopover({ filters, availableFormats, matchedCount, totalCount, positionAnchor, onChange, onReset }) {
	const { t } = useTranslation();
	const activeCountDescriptionId = (0, import_react.useId)();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [operators, setOperators] = (0, import_react.useState)({
		width: "gte",
		height: "gte",
		size: "gte"
	});
	const [sizeUnit, setSizeUnit] = (0, import_react.useState)("kb");
	const activeCount = countActiveImageQuickFilters(filters);
	const formats = (0, import_react.useMemo)(() => formatOptions(availableFormats, filters.formats), [availableFormats, filters.formats]);
	const currentOperator = (key) => filters[key]?.operator ?? operators[key];
	const updateOperator = (key, operator) => {
		setOperators((current) => ({
			...current,
			[key]: operator
		}));
		const condition = filters[key];
		if (!condition) return;
		onChange({
			...filters,
			[key]: {
				...condition,
				operator
			}
		});
	};
	const toggleFormat = (format) => {
		const selected = new Set(filters.formats.map(normalizedFormat));
		if (selected.has(format)) selected.delete(format);
		else selected.add(format);
		onChange({
			...filters,
			formats: [...selected]
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverTrigger, {
			type: "button",
			"aria-label": t("popup.sniffer.imageFilters.trigger"),
			"aria-describedby": activeCount > 0 ? activeCountDescriptionId : void 0,
			className: cn(buttonVariants({ variant: activeCount > 0 ? "secondary" : "ghost" }), "relative h-8 gap-1.5 rounded-lg px-2.5 text-xs shadow-none"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, {
					className: "size-3.5",
					"aria-hidden": "true"
				}),
				t("popup.sniffer.imageFilters.trigger"),
				activeCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[10px] leading-4 font-semibold text-primary-foreground",
					"aria-hidden": "true",
					children: activeCount
				}),
				activeCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					id: activeCountDescriptionId,
					className: "sr-only",
					children: t("popup.sniffer.imageFilters.activeCount", { count: activeCount })
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
			anchor: positionAnchor,
			side: "top",
			sideOffset: 8,
			align: "start",
			className: cn("max-w-(--available-width) space-y-2 p-2.5", positionAnchor ? "w-(--anchor-width)" : "w-[368px]"),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverHeader, {
					className: "flex-row items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTitle, {
							className: "text-[13px]/4",
							children: t("popup.sniffer.imageFilters.title")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-[11px] tabular-nums text-muted-foreground",
							"aria-live": "polite",
							children: t("popup.sniffer.imageFilters.result", {
								matched: matchedCount,
								total: totalCount
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "xs",
							variant: "ghost",
							disabled: activeCount === 0,
							onClick: onReset,
							children: t("popup.sniffer.imageFilters.reset")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "xs",
							onClick: () => setOpen(false),
							children: t("popup.sniffer.imageFilters.done")
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					className: "grid grid-cols-[48px_minmax(0,1fr)] items-center gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
							className: "sr-only",
							children: t("popup.sniffer.imageFilters.formats")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							className: "text-[11px] text-muted-foreground",
							children: t("popup.sniffer.imageFilters.formats")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex min-h-6 flex-wrap gap-1",
							children: formats.length > 0 ? formats.map((format) => {
								const selected = filters.formats.map(normalizedFormat).includes(format);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": selected,
									"aria-label": t("popup.sniffer.imageFilters.formatOptionLabel", { format: format.toUpperCase() }),
									className: cn("h-6 rounded-md border px-2 text-[10px] font-medium transition-colors outline-none focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/40", selected ? "border-primary/30 bg-primary/10 text-primary" : "border-border bg-background text-muted-foreground hover:bg-muted hover:text-foreground"),
									onClick: () => toggleFormat(format),
									children: format.toUpperCase()
								}, format);
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted-foreground",
								children: "—"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-1.5",
					"aria-label": t("popup.sniffer.imageFilters.dimensions"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumericFilterRow, {
							filterKey: "width",
							filters,
							operator: currentOperator("width"),
							unit: "px",
							onOperatorChange: (operator) => updateOperator("width", operator),
							onChange
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumericFilterRow, {
							filterKey: "height",
							filters,
							operator: currentOperator("height"),
							unit: "px",
							onOperatorChange: (operator) => updateOperator("height", operator),
							onChange
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumericFilterRow, {
							filterKey: "size",
							filters,
							operator: currentOperator("size"),
							wideUnit: true,
							unitMultiplier: SIZE_MULTIPLIERS[sizeUnit],
							onOperatorChange: (operator) => updateOperator("size", operator),
							onChange,
							unit: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sizeUnit,
								items: SIZE_UNIT_LABELS,
								onValueChange: (value) => setSizeUnit(value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									size: "sm",
									className: "w-[58px] px-1.5 py-0 text-[11px] shadow-none data-[size=sm]:h-6",
									"aria-label": t("popup.sniffer.imageFilters.sizeUnitLabel"),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									align: "end",
									alignItemWithTrigger: false,
									className: "min-w-[58px] shadow-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "kb",
										className: "text-[11px]",
										children: "KB"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "mb",
										className: "text-[11px]",
										children: "MB"
									})]
								})]
							})
						})
					]
				})
			]
		})]
	});
}
//#endregion
//#region src/popup/imagePreview.ts
var MAX_CONCURRENT_PREVIEWS = 3;
var MAX_IMAGE_PREVIEW_CHUNKS = 4096;
var MAX_IMAGE_HEADER_SCAN_BYTES = 524288;
var DEFAULT_THUMBNAIL_SIZE = 72;
var MAX_THUMBNAIL_EDGE = 256;
var RASTER_IMAGE_MIME_TYPES = /* @__PURE__ */ new Set([
	"image/apng",
	"image/avif",
	"image/avif-sequence",
	"image/bmp",
	"image/gif",
	"image/heic",
	"image/heic-sequence",
	"image/heif",
	"image/heif-sequence",
	"image/jpeg",
	"image/jpg",
	"image/jxl",
	"image/pjpeg",
	"image/png",
	"image/tiff",
	"image/vnd.microsoft.icon",
	"image/webp",
	"image/x-icon",
	"image/x-png"
]);
var previewQueue = [];
var activePreviewLoads = 0;
function previewAbortError() {
	return new DOMException("Image preview load was aborted", "AbortError");
}
function throwIfAborted(signal) {
	if (signal?.aborted) throw previewAbortError();
}
function ipv4Octets(hostname) {
	const parts = hostname.split(".");
	if (parts.length !== 4) return null;
	const octets = parts.map((part) => Number(part));
	if (octets.some((octet) => !Number.isInteger(octet) || octet < 0 || octet > 255)) return null;
	return octets;
}
function isPrivateIpv4([first, second]) {
	return first === 0 || first === 10 || first === 127 || first === 169 && second === 254 || first === 172 && second >= 16 && second <= 31 || first === 192 && second === 168;
}
function ipv6Hextets(hostname) {
	const halves = hostname.replace(/^\[|\]$/g, "").toLowerCase().split("::");
	if (halves.length > 2) return null;
	const parseHalf = (half) => {
		if (!half) return [];
		const parts = half.split(":");
		if (parts.some((part) => !/^[0-9a-f]{1,4}$/.test(part))) return null;
		return parts.map((part) => Number.parseInt(part, 16));
	};
	const left = parseHalf(halves[0] ?? "");
	const right = parseHalf(halves[1] ?? "");
	if (!left || !right) return null;
	if (halves.length === 1) return left.length === 8 ? left : null;
	const omitted = 8 - left.length - right.length;
	if (omitted < 1) return null;
	return [
		...left,
		...Array.from({ length: omitted }, () => 0),
		...right
	];
}
function isPrivateIpv6(hextets) {
	if (hextets.length !== 8) return true;
	const first = hextets[0] ?? 0;
	const loopback = hextets.slice(0, 7).every((part) => part === 0) && hextets[7] === 1;
	const unspecified = hextets.every((part) => part === 0);
	const uniqueLocal = (first & 65024) === 64512;
	const linkLocal = (first & 65472) === 65152;
	if (hextets.slice(0, 5).every((part) => part === 0) && (hextets[5] === 0 || hextets[5] === 65535)) {
		const high = hextets[6] ?? 0;
		const low = hextets[7] ?? 0;
		return isPrivateIpv4([
			high >> 8,
			high & 255,
			low >> 8,
			low & 255
		]);
	}
	return loopback || unspecified || uniqueLocal || linkLocal;
}
function assertPublicPreviewHost(parsedUrl) {
	const hostname = parsedUrl.hostname.toLowerCase().replace(/\.$/, "");
	if (hostname === "localhost" || hostname.endsWith(".localhost") || hostname.endsWith(".local")) throw new Error("Image preview host must be public");
	const ipv4 = ipv4Octets(hostname);
	if (ipv4) {
		if (isPrivateIpv4(ipv4)) throw new Error("Image preview host must be public");
		return;
	}
	if (hostname.startsWith("[") && hostname.endsWith("]")) {
		const ipv6 = ipv6Hextets(hostname);
		if (!ipv6 || isPrivateIpv6(ipv6)) throw new Error("Image preview host must be public");
		return;
	}
	if (!hostname.includes(".")) throw new Error("Image preview host must be a public domain");
}
function pumpPreviewQueue() {
	while (activePreviewLoads < MAX_CONCURRENT_PREVIEWS && previewQueue.length > 0) {
		const entry = previewQueue.shift();
		if (!entry) return;
		entry.signal?.removeEventListener("abort", entry.onAbort);
		if (entry.signal?.aborted) {
			entry.reject(previewAbortError());
			continue;
		}
		activePreviewLoads += 1;
		entry.resolve();
	}
}
function acquirePreviewSlot(signal) {
	throwIfAborted(signal);
	return new Promise((resolve, reject) => {
		const entry = {
			signal,
			resolve,
			reject,
			onAbort: () => {
				const index = previewQueue.indexOf(entry);
				if (index < 0) return;
				previewQueue.splice(index, 1);
				signal?.removeEventListener("abort", entry.onAbort);
				reject(previewAbortError());
			}
		};
		signal?.addEventListener("abort", entry.onAbort, { once: true });
		previewQueue.push(entry);
		pumpPreviewQueue();
	});
}
function releasePreviewSlot() {
	activePreviewLoads = Math.max(0, activePreviewLoads - 1);
	pumpPreviewQueue();
}
function rasterMimeType(response) {
	const mimeType = response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase() ?? "";
	if (mimeType === "image/svg+xml" || !RASTER_IMAGE_MIME_TYPES.has(mimeType)) throw new Error("Image preview response is not a supported raster image");
	return mimeType;
}
function declaredResponseBytes(response) {
	const rawLength = response.headers.get("content-length");
	if (!rawLength) return null;
	const length = Number(rawLength);
	return Number.isSafeInteger(length) && length >= 0 ? length : null;
}
function looksLikeSvg(chunks) {
	const prefix = new Uint8Array(Math.min(2048, chunks.reduce((total, chunk) => total + chunk.byteLength, 0)));
	let offset = 0;
	for (const chunk of chunks) {
		if (offset >= prefix.byteLength) break;
		const slice = chunk.subarray(0, prefix.byteLength - offset);
		prefix.set(slice, offset);
		offset += slice.byteLength;
	}
	const text = new TextDecoder().decode(prefix);
	return /^\uFEFF?\s*(?:<\?xml[\s\S]*?\?>\s*)?(?:<!--[\s\S]*?-->\s*)*<svg(?:\s|>)/i.test(text);
}
function uint16(bytes, offset, littleEndian) {
	if (offset < 0 || offset + 2 > bytes.byteLength) return 0;
	return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint16(offset, littleEndian);
}
function uint32(bytes, offset, littleEndian) {
	if (offset < 0 || offset + 4 > bytes.byteLength) return 0;
	return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(offset, littleEndian);
}
function int32(bytes, offset, littleEndian) {
	if (offset < 0 || offset + 4 > bytes.byteLength) return 0;
	return new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getInt32(offset, littleEndian);
}
function matchesBytes(bytes, offset, expected) {
	return expected.every((value, index) => bytes[offset + index] === value);
}
function pngDimensions(bytes, offset = 0) {
	if (offset + 24 > bytes.byteLength || !matchesBytes(bytes, offset, [
		137,
		80,
		78,
		71,
		13,
		10,
		26,
		10
	]) || !matchesBytes(bytes, offset + 12, [
		73,
		72,
		68,
		82
	])) return null;
	return {
		width: uint32(bytes, offset + 16, false),
		height: uint32(bytes, offset + 20, false)
	};
}
function gifDimensions(bytes) {
	if (bytes.byteLength < 10 || !matchesBytes(bytes, 0, [
		71,
		73,
		70,
		56,
		55,
		97
	]) && !matchesBytes(bytes, 0, [
		71,
		73,
		70,
		56,
		57,
		97
	])) return null;
	return {
		width: uint16(bytes, 6, true),
		height: uint16(bytes, 8, true)
	};
}
function jpegDimensions(bytes) {
	if (bytes.byteLength < 4 || bytes[0] !== 255 || bytes[1] !== 216) return null;
	const startOfFrameMarkers = /* @__PURE__ */ new Set([
		192,
		193,
		194,
		195,
		197,
		198,
		199,
		201,
		202,
		203,
		205,
		206,
		207
	]);
	let offset = 2;
	while (offset + 3 < bytes.byteLength) {
		while (offset < bytes.byteLength && bytes[offset] !== 255) offset += 1;
		while (offset < bytes.byteLength && bytes[offset] === 255) offset += 1;
		if (offset >= bytes.byteLength) return null;
		const marker = bytes[offset] ?? 0;
		offset += 1;
		if (marker === 216 || marker === 217 || marker >= 208 && marker <= 215) continue;
		if (offset + 2 > bytes.byteLength) return null;
		const segmentLength = uint16(bytes, offset, false);
		if (segmentLength < 2 || offset + segmentLength > bytes.byteLength) return null;
		if (startOfFrameMarkers.has(marker) && segmentLength >= 7) return {
			width: uint16(bytes, offset + 5, false),
			height: uint16(bytes, offset + 3, false)
		};
		if (marker === 218) return null;
		offset += segmentLength;
	}
	return null;
}
function webpDimensions(bytes) {
	if (bytes.byteLength < 30 || !matchesBytes(bytes, 0, [
		82,
		73,
		70,
		70
	]) || !matchesBytes(bytes, 8, [
		87,
		69,
		66,
		80
	])) return null;
	let offset = 12;
	while (offset + 8 <= bytes.byteLength) {
		const chunkSize = uint32(bytes, offset + 4, true);
		const dataOffset = offset + 8;
		if (chunkSize > bytes.byteLength - dataOffset) return null;
		if (matchesBytes(bytes, offset, [
			86,
			80,
			56,
			88
		]) && chunkSize >= 10) return {
			width: 1 + ((bytes[dataOffset + 4] ?? 0) | (bytes[dataOffset + 5] ?? 0) << 8 | (bytes[dataOffset + 6] ?? 0) << 16),
			height: 1 + ((bytes[dataOffset + 7] ?? 0) | (bytes[dataOffset + 8] ?? 0) << 8 | (bytes[dataOffset + 9] ?? 0) << 16)
		};
		if (matchesBytes(bytes, offset, [
			86,
			80,
			56,
			76
		]) && chunkSize >= 5 && bytes[dataOffset] === 47) {
			const packed = uint32(bytes, dataOffset + 1, true);
			return {
				width: (packed & 16383) + 1,
				height: (packed >>> 14 & 16383) + 1
			};
		}
		if (matchesBytes(bytes, offset, [
			86,
			80,
			56,
			32
		]) && chunkSize >= 10 && matchesBytes(bytes, dataOffset + 3, [
			157,
			1,
			42
		])) return {
			width: uint16(bytes, dataOffset + 6, true) & 16383,
			height: uint16(bytes, dataOffset + 8, true) & 16383
		};
		offset = dataOffset + chunkSize + chunkSize % 2;
	}
	return null;
}
function bmpDimensions(bytes) {
	if (bytes.byteLength < 26 || bytes[0] !== 66 || bytes[1] !== 77) return null;
	const dibSize = uint32(bytes, 14, true);
	if (dibSize === 12) return {
		width: uint16(bytes, 18, true),
		height: uint16(bytes, 20, true)
	};
	if (dibSize < 40) return null;
	return {
		width: Math.abs(int32(bytes, 18, true)),
		height: Math.abs(int32(bytes, 22, true))
	};
}
function icoDimensions(bytes) {
	if (bytes.byteLength < 22 || bytes[0] !== 0 || bytes[1] !== 0 || bytes[2] !== 1 || bytes[3] !== 0) return null;
	const count = Math.min(uint16(bytes, 4, true), 256);
	if (count === 0 || 6 + count * 16 > bytes.byteLength) return null;
	let width = 0;
	let height = 0;
	for (let index = 0; index < count; index += 1) {
		const entryOffset = 6 + index * 16;
		let entryWidth = bytes[entryOffset] || 256;
		let entryHeight = bytes[entryOffset + 1] || 256;
		const payloadBytes = uint32(bytes, entryOffset + 8, true);
		const payloadOffset = uint32(bytes, entryOffset + 12, true);
		if (payloadBytes === 0 || payloadOffset > bytes.byteLength || payloadBytes > bytes.byteLength - payloadOffset) return null;
		const embeddedPng = payloadBytes >= 24 ? pngDimensions(bytes, payloadOffset) : null;
		if (embeddedPng) {
			entryWidth = embeddedPng.width;
			entryHeight = embeddedPng.height;
		} else {
			const dibSize = uint32(bytes, payloadOffset, true);
			if (dibSize === 12 && payloadBytes >= 12) {
				entryWidth = uint16(bytes, payloadOffset + 4, true);
				entryHeight = Math.ceil(uint16(bytes, payloadOffset + 6, true) / 2);
			} else if (dibSize >= 40 && payloadBytes >= 40) {
				entryWidth = Math.abs(int32(bytes, payloadOffset + 4, true));
				entryHeight = Math.ceil(Math.abs(int32(bytes, payloadOffset + 8, true)) / 2);
			} else return null;
		}
		width = Math.max(width, entryWidth);
		height = Math.max(height, entryHeight);
	}
	return {
		width,
		height
	};
}
function tiffDimensions(bytes) {
	if (bytes.byteLength < 16) return null;
	const littleEndian = bytes[0] === 73 && bytes[1] === 73;
	const bigEndian = bytes[0] === 77 && bytes[1] === 77;
	if (!littleEndian && !bigEndian || uint16(bytes, 2, littleEndian) !== 42) return null;
	const ifdOffset = uint32(bytes, 4, littleEndian);
	if (ifdOffset + 2 > bytes.byteLength) return null;
	const entryCount = Math.min(uint16(bytes, ifdOffset, littleEndian), 4096);
	if (ifdOffset + 2 + entryCount * 12 > bytes.byteLength) return null;
	let width = 0;
	let height = 0;
	for (let index = 0; index < entryCount; index += 1) {
		const entryOffset = ifdOffset + 2 + index * 12;
		const tag = uint16(bytes, entryOffset, littleEndian);
		if (tag !== 256 && tag !== 257) continue;
		const type = uint16(bytes, entryOffset + 2, littleEndian);
		if (uint32(bytes, entryOffset + 4, littleEndian) !== 1 || type !== 3 && type !== 4) continue;
		const value = type === 3 ? uint16(bytes, entryOffset + 8, littleEndian) : uint32(bytes, entryOffset + 8, littleEndian);
		if (tag === 256) width = value;
		if (tag === 257) height = value;
	}
	return width > 0 && height > 0 ? {
		width,
		height
	} : null;
}
var ISO_BMFF_RASTER_BRANDS = /* @__PURE__ */ new Set([
	"avif",
	"avis",
	"heic",
	"heix",
	"hevc",
	"hevx",
	"mif1",
	"msf1"
]);
function ascii(bytes, offset, length) {
	if (offset < 0 || offset + length > bytes.byteLength) return "";
	return String.fromCharCode(...bytes.subarray(offset, offset + length));
}
function isoBmffDimensions(bytes) {
	if (bytes.byteLength < 20 || ascii(bytes, 4, 4) !== "ftyp") return null;
	const ftypSize = uint32(bytes, 0, false);
	if (ftypSize < 16 || ftypSize > bytes.byteLength) return null;
	let rasterBrand = ISO_BMFF_RASTER_BRANDS.has(ascii(bytes, 8, 4));
	for (let offset = 16; !rasterBrand && offset + 4 <= ftypSize; offset += 4) rasterBrand = ISO_BMFF_RASTER_BRANDS.has(ascii(bytes, offset, 4));
	if (!rasterBrand) return null;
	let width = 0;
	let height = 0;
	for (let offset = 4; offset + 16 <= bytes.byteLength; offset += 1) {
		if (!matchesBytes(bytes, offset, [
			105,
			115,
			112,
			101
		])) continue;
		const boxSize = uint32(bytes, offset - 4, false);
		if (boxSize < 20 || offset - 4 + boxSize > bytes.byteLength) continue;
		width = Math.max(width, uint32(bytes, offset + 8, false));
		height = Math.max(height, uint32(bytes, offset + 12, false));
	}
	return width > 0 && height > 0 ? {
		width,
		height
	} : null;
}
function imageDimensions(bytes) {
	const header = bytes.subarray(0, MAX_IMAGE_HEADER_SCAN_BYTES);
	return pngDimensions(header) ?? gifDimensions(header) ?? jpegDimensions(header) ?? webpDimensions(header) ?? bmpDimensions(header) ?? icoDimensions(bytes) ?? tiffDimensions(header) ?? isoBmffDimensions(header);
}
function assertSafeDimensions({ width, height }) {
	if (!Number.isInteger(width) || !Number.isInteger(height) || width <= 0 || height <= 0) throw new Error("Image preview has invalid dimensions");
	if (width > 8192 || height > 8192 || width * height > 25165824) throw new Error("Image preview dimensions exceed the safety limit");
}
function combineChunks(chunks) {
	const size = chunks.reduce((total, chunk) => total + chunk.byteLength, 0);
	const combined = new Uint8Array(size);
	let offset = 0;
	for (const chunk of chunks) {
		combined.set(chunk, offset);
		offset += chunk.byteLength;
	}
	return combined;
}
function thumbnailEdge(value) {
	if (!Number.isFinite(value)) return DEFAULT_THUMBNAIL_SIZE;
	return Math.min(MAX_THUMBNAIL_EDGE, Math.max(1, Math.round(value)));
}
function createPreviewObjectUrl(blob, signal) {
	throwIfAborted(signal);
	const objectUrl = URL.createObjectURL(blob);
	if (signal?.aborted) {
		URL.revokeObjectURL(objectUrl);
		throw previewAbortError();
	}
	return objectUrl;
}
async function renderThumbnail(bitmap, width, height) {
	const canvas = new OffscreenCanvas(width, height);
	const context = canvas.getContext("2d");
	if (!context) return null;
	const sourceRatio = bitmap.width / bitmap.height;
	const targetRatio = width / height;
	let sourceX = 0;
	let sourceY = 0;
	let sourceWidth = bitmap.width;
	let sourceHeight = bitmap.height;
	if (sourceRatio > targetRatio) {
		sourceWidth = bitmap.height * targetRatio;
		sourceX = (bitmap.width - sourceWidth) / 2;
	} else if (sourceRatio < targetRatio) {
		sourceHeight = bitmap.width / targetRatio;
		sourceY = (bitmap.height - sourceHeight) / 2;
	}
	context.drawImage(bitmap, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, width, height);
	try {
		const webp = await canvas.convertToBlob({
			type: "image/webp",
			quality: .78
		});
		if (webp.size > 0) return webp;
	} catch {}
	try {
		const png = await canvas.convertToBlob({ type: "image/png" });
		return png.size > 0 ? png : null;
	} catch {
		return null;
	}
}
async function thumbnailOrOriginal(blob, dimensions, options) {
	if (!dimensions) throw new Error("Image preview dimensions could not be verified safely");
	assertSafeDimensions(dimensions);
	if (typeof globalThis.createImageBitmap !== "function" || typeof globalThis.OffscreenCanvas !== "function") return createPreviewObjectUrl(blob, options.signal);
	let bitmap;
	try {
		bitmap = await globalThis.createImageBitmap(blob);
	} catch {
		throwIfAborted(options.signal);
		return createPreviewObjectUrl(blob, options.signal);
	}
	try {
		throwIfAborted(options.signal);
		assertSafeDimensions({
			width: bitmap.width,
			height: bitmap.height
		});
		let thumbnail = null;
		try {
			thumbnail = await renderThumbnail(bitmap, thumbnailEdge(options.width), thumbnailEdge(options.height));
		} catch {}
		throwIfAborted(options.signal);
		return createPreviewObjectUrl(thumbnail ?? blob, options.signal);
	} finally {
		bitmap.close();
	}
}
function readChunk(reader, signal) {
	throwIfAborted(signal);
	if (!signal) return reader.read();
	return new Promise((resolve, reject) => {
		let settled = false;
		const finish = () => {
			if (settled) return false;
			settled = true;
			signal.removeEventListener("abort", onAbort);
			return true;
		};
		const onAbort = () => {
			if (!finish()) return;
			reader.cancel(previewAbortError()).catch(() => void 0);
			reject(previewAbortError());
		};
		signal.addEventListener("abort", onAbort, { once: true });
		reader.read().then((result) => {
			if (finish()) resolve(result);
		}, (error) => {
			if (finish()) reject(error);
		});
	});
}
async function readBoundedImage(response, signal) {
	const declaredBytes = declaredResponseBytes(response);
	if (declaredBytes !== null && declaredBytes > 2097152) {
		await response.body?.cancel().catch(() => void 0);
		throw new Error("Image preview exceeds the size limit");
	}
	if (!response.body) throw new Error("Image preview response has no body");
	const reader = response.body.getReader();
	const chunks = [];
	let totalBytes = 0;
	let chunkCount = 0;
	try {
		while (true) {
			const { done, value } = await readChunk(reader, signal);
			if (done) break;
			if (!value || value.byteLength === 0) continue;
			chunkCount += 1;
			if (chunkCount > MAX_IMAGE_PREVIEW_CHUNKS) throw new Error("Image preview response has too many chunks");
			if (value.byteLength > 262144) throw new Error("Image preview response chunk exceeds the size limit");
			totalBytes += value.byteLength;
			if (totalBytes > 2097152) throw new Error("Image preview exceeds the size limit");
			chunks.push(new Uint8Array(value));
		}
	} catch (error) {
		await reader.cancel(error).catch(() => void 0);
		throw error;
	} finally {
		reader.releaseLock();
	}
	if (totalBytes === 0) throw new Error("Image preview response is empty");
	return chunks;
}
async function loadImagePreview(url, options = {}) {
	const parsedUrl = new URL(url);
	if (parsedUrl.protocol !== "http:" && parsedUrl.protocol !== "https:") throw new Error("Image preview URL must use HTTP or HTTPS");
	if (parsedUrl.username || parsedUrl.password) throw new Error("Image preview URL must not contain credentials");
	assertPublicPreviewHost(parsedUrl);
	if (parsedUrl.protocol !== "https:") throw new Error("Image preview URL must use HTTPS");
	if (/\.svgz?$/i.test(parsedUrl.pathname)) throw new Error("SVG image previews are not allowed");
	await acquirePreviewSlot(options.signal);
	try {
		throwIfAborted(options.signal);
		const requestInit = {
			credentials: "omit",
			redirect: "error",
			referrerPolicy: "no-referrer"
		};
		if (options.signal) requestInit.signal = options.signal;
		const response = await fetch(parsedUrl.href, requestInit);
		throwIfAborted(options.signal);
		if (!response.ok) {
			await response.body?.cancel().catch(() => void 0);
			throw new Error(`Image preview request failed (${response.status})`);
		}
		let mimeType;
		try {
			mimeType = rasterMimeType(response);
		} catch (error) {
			await response.body?.cancel().catch(() => void 0);
			throw error;
		}
		const chunks = await readBoundedImage(response, options.signal);
		if (looksLikeSvg(chunks)) throw new Error("SVG image previews are not allowed");
		throwIfAborted(options.signal);
		const bytes = combineChunks(chunks);
		return await thumbnailOrOriginal(new Blob([bytes], { type: mimeType }), imageDimensions(bytes), options);
	} finally {
		releasePreviewSlot();
	}
}
//#endregion
//#region src/popup/usePageMedia.ts
var PAGE_MEDIA_SUBMISSIONS_SESSION_PREFIX = "motrix.pageMedia.pendingSubmissions.v1:";
var MIN_IDEMPOTENCY_KEY_LENGTH = 8;
var MAX_IDEMPOTENCY_KEY_LENGTH = 128;
function pageMediaSubmissionsSessionKey(scope) {
	return `${PAGE_MEDIA_SUBMISSIONS_SESSION_PREFIX}${scope}`;
}
function sessionStorageArea() {
	try {
		const area = globalThis.chrome?.storage?.session;
		if (typeof area?.get !== "function" || typeof area.set !== "function" || typeof area.remove !== "function") return null;
		return area;
	} catch {
		return null;
	}
}
function isIdempotencyKey(value) {
	return typeof value === "string" && value.length >= MIN_IDEMPOTENCY_KEY_LENGTH && value.length <= MAX_IDEMPOTENCY_KEY_LENGTH;
}
function normalizePendingSubmissions(value) {
	if (typeof value !== "object" || value === null) return { resources: {} };
	const candidate = value;
	const resources = {};
	if (typeof candidate.resources === "object" && candidate.resources !== null) {
		for (const [mediaKey, idempotencyKey] of Object.entries(candidate.resources)) if (isIdempotencyKey(idempotencyKey)) resources[mediaKey] = idempotencyKey;
	}
	return isIdempotencyKey(candidate.page) ? {
		resources,
		page: candidate.page
	} : { resources };
}
var pendingSubmissionStorageQueue = Promise.resolve();
function mutatePendingSubmissions(scope, mutate) {
	pendingSubmissionStorageQueue = pendingSubmissionStorageQueue.then(async () => {
		const storage = sessionStorageArea();
		if (!storage) return;
		const storageKey = pageMediaSubmissionsSessionKey(scope);
		try {
			const current = normalizePendingSubmissions((await storage.get(storageKey))[storageKey]);
			mutate(current);
			if (Object.keys(current.resources).length === 0 && current.page === void 0) await storage.remove(storageKey);
			else await storage.set({ [storageKey]: current });
		} catch {}
	});
	return pendingSubmissionStorageQueue;
}
async function loadPendingSubmissions(scope) {
	await pendingSubmissionStorageQueue;
	const storage = sessionStorageArea();
	if (!storage) return { resources: {} };
	const storageKey = pageMediaSubmissionsSessionKey(scope);
	try {
		return normalizePendingSubmissions((await storage.get(storageKey))[storageKey]);
	} catch {
		return { resources: {} };
	}
}
function rememberResourceSubmission(scope, mediaKey, idempotencyKey) {
	return mutatePendingSubmissions(scope, (current) => {
		current.resources[mediaKey] = idempotencyKey;
	});
}
function clearResourceSubmission(scope, mediaKey, idempotencyKey) {
	return mutatePendingSubmissions(scope, (current) => {
		if (current.resources[mediaKey] === idempotencyKey) delete current.resources[mediaKey];
	});
}
function rememberPageSubmission(scope, idempotencyKey) {
	return mutatePendingSubmissions(scope, (current) => {
		current.page = idempotencyKey;
	});
}
function clearPageSubmission(scope, idempotencyKey) {
	return mutatePendingSubmissions(scope, (current) => {
		if (current.page === idempotencyKey) delete current.page;
	});
}
function popupExtensionApis() {
	const globals = globalThis;
	return {
		tabs: globals.browser?.tabs ?? globals.chrome?.tabs,
		storageChanged: globals.browser?.storage?.onChanged ?? globals.chrome?.storage?.onChanged
	};
}
function usePageMedia(submissionKey = "default") {
	const [media, setMedia] = (0, import_react.useState)([]);
	const [selectionKinds, setKinds] = (0, import_react.useState)(["direct"]);
	const [scanning, setScanning] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [resolvableSite, setResolvableSite] = (0, import_react.useState)(null);
	const scanGeneration = (0, import_react.useRef)(0);
	const liveMediaRevision = (0, import_react.useRef)(0);
	const idempotencyKeys = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const pageIdempotencyKey = (0, import_react.useRef)(null);
	const submissionKeyRef = (0, import_react.useRef)(submissionKey);
	const pendingLoadRef = (0, import_react.useRef)({
		scope: submissionKey,
		promise: null,
		applied: false
	});
	const syncSubmissionKey = (0, import_react.useCallback)(() => {
		if (submissionKeyRef.current === submissionKey) return;
		submissionKeyRef.current = submissionKey;
		idempotencyKeys.current.clear();
		pageIdempotencyKey.current = null;
		pendingLoadRef.current = {
			scope: submissionKey,
			promise: null,
			applied: false
		};
	}, [submissionKey]);
	const hydratePendingKeys = (0, import_react.useCallback)(async (scope) => {
		const load = pendingLoadRef.current;
		if (load.scope !== scope) return;
		load.promise ??= loadPendingSubmissions(scope);
		const persisted = await load.promise;
		if (pendingLoadRef.current !== load || load.applied) return;
		load.applied = true;
		for (const [mediaKey, idempotencyKey] of Object.entries(persisted.resources)) if (!idempotencyKeys.current.has(mediaKey)) idempotencyKeys.current.set(mediaKey, idempotencyKey);
		pageIdempotencyKey.current ??= persisted.page ?? null;
	}, []);
	(0, import_react.useEffect)(() => syncSubmissionKey(), [syncSubmissionKey]);
	(0, import_react.useEffect)(() => {
		const { tabs, storageChanged } = popupExtensionApis();
		let activeTabId = null;
		let cancelled = false;
		const onStorageChanged = (changes, areaName) => {
			if (cancelled || areaName !== "session" || activeTabId === null) return;
			const change = changes[mediaTabStorageKey(activeTabId)];
			if (change === void 0) return;
			if (change.newValue === void 0) {
				liveMediaRevision.current += 1;
				setMedia([]);
				return;
			}
			if (Array.isArray(change.newValue)) {
				liveMediaRevision.current += 1;
				setMedia(change.newValue);
			}
		};
		storageChanged?.addListener(onStorageChanged);
		if (tabs === void 0) return () => {
			cancelled = true;
			storageChanged?.removeListener(onStorageChanged);
		};
		tabs.query({
			active: true,
			currentWindow: true
		}).then(([tab]) => {
			if (cancelled) return;
			activeTabId = typeof tab?.id === "number" ? tab.id : null;
			if (!tab?.url) return;
			const check = isResolvableVideoPage(tab.url, isWebStoreBuild());
			setResolvableSite(check.resolvable ? check.site : null);
		}).catch(() => {});
		return () => {
			cancelled = true;
			storageChanged?.removeListener(onStorageChanged);
		};
	}, []);
	return {
		media,
		selectionKinds,
		scanning,
		error,
		scan: (0, import_react.useCallback)(async () => {
			const generation = ++scanGeneration.current;
			const liveRevisionAtStart = liveMediaRevision.current;
			setScanning(true);
			setError(null);
			try {
				const r = await send("bg.scanActiveTab", void 0);
				if (isErrorResponse(r)) throw new Error(r.error);
				if (!Array.isArray(r.media) || !Array.isArray(r.selectionKinds)) throw new Error("invalid media scan response");
				if (generation !== scanGeneration.current) return;
				if (liveMediaRevision.current === liveRevisionAtStart) setMedia(r.media);
				setKinds(r.selectionKinds);
			} catch (e) {
				if (generation !== scanGeneration.current) return;
				setError(e.message);
			} finally {
				if (generation === scanGeneration.current) setScanning(false);
			}
		}, []),
		download: (0, import_react.useCallback)(async (m) => {
			syncSubmissionKey();
			const scope = submissionKeyRef.current;
			await hydratePendingKeys(scope);
			const mediaKey = mediaStorageKey(m);
			const idempotencyKey = idempotencyKeys.current.get(mediaKey) ?? crypto.randomUUID();
			idempotencyKeys.current.set(mediaKey, idempotencyKey);
			await rememberResourceSubmission(scope, mediaKey, idempotencyKey);
			const r = await send("bg.submitMedia", {
				mediaKey,
				idempotencyKey
			});
			if (isErrorResponse(r)) throw new Error(r.error);
			if (submissionKeyRef.current === scope && idempotencyKeys.current.get(mediaKey) === idempotencyKey) idempotencyKeys.current.delete(mediaKey);
			await clearResourceSubmission(scope, mediaKey, idempotencyKey);
		}, [hydratePendingKeys, syncSubmissionKey]),
		getThumbnail: (0, import_react.useCallback)(async (m) => {
			const r = await send("bg.getMediaThumbnail", { mediaKey: mediaStorageKey(m) });
			if (isErrorResponse(r)) return null;
			return typeof r.dataUrl === "string" ? r.dataUrl : null;
		}, []),
		resolvableSite,
		resolvePageDownload: (0, import_react.useCallback)(async () => {
			syncSubmissionKey();
			const scope = submissionKeyRef.current;
			await hydratePendingKeys(scope);
			const idempotencyKey = pageIdempotencyKey.current ?? crypto.randomUUID();
			pageIdempotencyKey.current = idempotencyKey;
			await rememberPageSubmission(scope, idempotencyKey);
			const r = await send("bg.resolvePageDownload", { idempotencyKey });
			if (isErrorResponse(r)) throw new Error(r.error);
			if (submissionKeyRef.current === scope && pageIdempotencyKey.current === idempotencyKey) pageIdempotencyKey.current = null;
			await clearPageSubmission(scope, idempotencyKey);
			return r;
		}, [hydratePendingKeys, syncSubmissionKey])
	};
}
//#endregion
//#region src/popup/MediaPanel.tsx
var RESOURCE_FILTERS = [
	"all",
	"video",
	"audio",
	"image"
];
var BATCH_CONCURRENCY = 4;
var LOADED_IMAGE_EVIDENCE = /* @__PURE__ */ new Set([
	"network",
	"current-src",
	"performance",
	"fetch",
	"xhr"
]);
function hasLoadedImageEvidence(media) {
	return media.evidence?.some((evidence) => LOADED_IMAGE_EVIDENCE.has(evidence.trim().toLowerCase())) ?? false;
}
function filenameFromUrl(url) {
	try {
		const filename = new URL(url).pathname.split("/").filter(Boolean).at(-1);
		if (!filename) return null;
		try {
			return decodeURIComponent(filename);
		} catch {
			return filename;
		}
	} catch {
		return null;
	}
}
function mediaName(media) {
	return media.suggestedFilename?.trim() || filenameFromUrl(media.url) || media.alt?.trim() || media.pageTitle.trim() || media.url;
}
function mediaHost(media) {
	try {
		return new URL(media.url).host;
	} catch {
		return media.url;
	}
}
function resourceIcon(media) {
	switch (mediaCategory(media)) {
		case "audio": return FileHeadphone;
		case "image": return Image;
		case "video": return FilePlay;
		default: return File;
	}
}
function isSvgMedia(media) {
	if (media.mimeType?.split(";", 1)[0]?.trim().toLowerCase() === "image/svg+xml") return true;
	if (/^data:image\/svg\+xml(?:[;,]|$)/i.test(media.url)) return true;
	try {
		return /\.svgz?$/i.test(new URL(media.url).pathname);
	} catch {
		return /\.svgz?(?:[?#]|$)/i.test(media.url);
	}
}
function mediaDomKey(media) {
	const key = mediaStorageKey(media);
	return key.includes("\0") ? `composite-${encodeURIComponent(key)}` : key;
}
function ResourceMedia({ media, enabled, getThumbnail }) {
	const containerRef = (0, import_react.useRef)(null);
	const [previewFailed, setPreviewFailed] = (0, import_react.useState)(false);
	const [preview, setPreview] = (0, import_react.useState)(null);
	const [nearViewport, setNearViewport] = (0, import_react.useState)(() => typeof IntersectionObserver === "undefined");
	const category = mediaCategory(media);
	const canSamplePage = enabled && category === "image" && media.previewable !== false && !isSvgMedia(media) && !previewFailed;
	const canFetchPublicResource = canSamplePage && hasLoadedImageEvidence(media);
	const previewImage = canSamplePage && preview !== null;
	const Icon = resourceIcon(media);
	(0, import_react.useEffect)(() => {
		if (!canSamplePage) return;
		if (typeof IntersectionObserver === "undefined") {
			setNearViewport(true);
			return;
		}
		const element = containerRef.current;
		if (!element) return;
		const observer = new IntersectionObserver((entries) => {
			if (!entries.some((entry) => entry.isIntersecting)) return;
			setNearViewport(true);
			observer.disconnect();
		}, { rootMargin: "160px 0px" });
		observer.observe(element);
		return () => observer.disconnect();
	}, [canSamplePage]);
	(0, import_react.useEffect)(() => {
		setPreview(null);
		if (!canSamplePage || !nearViewport) return;
		const controller = new AbortController();
		let mounted = true;
		let objectUrl = null;
		(async () => {
			try {
				let pageThumbnail = null;
				try {
					pageThumbnail = await getThumbnail(media);
				} catch {}
				if (!mounted || controller.signal.aborted) return;
				if (typeof pageThumbnail === "string" && pageThumbnail.length <= 49152 && /^data:image\/(?:webp|png|jpeg);base64,/i.test(pageThumbnail)) {
					setPreview({
						url: pageThumbnail,
						ownedObjectUrl: false
					});
					return;
				}
				if (!canFetchPublicResource) return;
				const loadedUrl = await loadImagePreview(media.url, {
					signal: controller.signal,
					width: 72,
					height: 72
				});
				objectUrl = loadedUrl;
				if (!mounted || controller.signal.aborted) {
					URL.revokeObjectURL(loadedUrl);
					objectUrl = null;
					return;
				}
				setPreview({
					url: loadedUrl,
					ownedObjectUrl: true
				});
			} catch (error) {
				if (!mounted || error.name === "AbortError") return;
				setPreviewFailed(true);
			}
		})();
		return () => {
			mounted = false;
			controller.abort();
			if (objectUrl) {
				URL.revokeObjectURL(objectUrl);
				objectUrl = null;
			}
		};
	}, [
		canFetchPublicResource,
		canSamplePage,
		getThumbnail,
		media,
		nearViewport
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref: containerRef,
		"data-testid": `resource-thumbnail-${mediaDomKey(media)}`,
		"data-preview": previewImage ? "image" : "fallback",
		"data-preview-source": preview ? preview.ownedObjectUrl ? "network" : "page" : "none",
		className: "flex size-11 shrink-0 items-center justify-center overflow-hidden rounded-[10px] bg-speed-download/[0.07] text-speed-download",
		children: previewImage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: preview.url,
			alt: "",
			"aria-hidden": "true",
			loading: "lazy",
			decoding: "async",
			className: "size-11 object-cover",
			onError: () => setPreviewFailed(true)
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-4",
			"aria-hidden": "true"
		})
	});
}
function positiveMetric(value) {
	return Number.isFinite(value) && (value ?? 0) > 0 ? value : 0;
}
function visibleResources(media, filter) {
	const decorated = media.map((item, index) => ({
		item,
		index
	}));
	const filtered = filter === "all" ? decorated : decorated.filter(({ item }) => mediaCategory(item) === filter);
	if (filter === "image") filtered.sort((left, right) => {
		const leftArea = positiveMetric(left.item.width) * positiveMetric(left.item.height);
		return positiveMetric(right.item.width) * positiveMetric(right.item.height) - leftArea || positiveMetric(right.item.sizeBytes) - positiveMetric(left.item.sizeBytes) || positiveMetric(right.item.detectedAt) - positiveMetric(left.item.detectedAt) || left.index - right.index;
	});
	else if (filter === "all") {
		const priority = {
			video: 0,
			audio: 1,
			image: 2
		};
		filtered.sort((left, right) => priority[mediaCategory(left.item)] - priority[mediaCategory(right.item)] || left.index - right.index);
	}
	return filtered.map(({ item }) => item);
}
function SelectionCheckbox({ checked, indeterminate = false, disabled, label, describedBy, onChange, compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("relative flex shrink-0 cursor-pointer items-center justify-center rounded-md outline-none has-focus-visible:ring-2 has-focus-visible:ring-ring/50 has-disabled:cursor-default has-disabled:opacity-50", compact ? "size-6" : "size-7"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			ref: (element) => {
				if (element) element.indeterminate = indeterminate;
			},
			disabled,
			"aria-label": label,
			"aria-describedby": describedBy,
			onChange,
			className: "sr-only"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			className: cn("flex items-center justify-center border transition-colors", compact ? "size-4 rounded-[4px]" : "size-[18px] rounded-[5px]", checked || indeterminate ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background text-transparent"),
			children: indeterminate ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
				className: compact ? "size-2.5" : "size-3",
				strokeWidth: 2.5
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
				className: compact ? "size-2.5" : "size-3",
				strokeWidth: 2.5
			})
		})]
	});
}
function ResourceRow({ media, supported, connected, previewEnabled, selected, state, error, getThumbnail, onSelect, onDownload }) {
	const { t } = useTranslation();
	const disabledDescriptionId = (0, import_react.useId)();
	const hostDescriptionId = (0, import_react.useId)();
	const name = mediaName(media);
	const host = mediaHost(media);
	const metadata = readableMediaMetadata(media);
	const unsupportedReason = t("popup.sniffer.unsupportedReason", { kind: media.kind.toUpperCase() });
	const disabledReason = !connected ? t("popup.sniffer.connectToSubmit") : !supported ? unsupportedReason : null;
	const actionLabel = disabledReason ? t("popup.sniffer.unsupportedResource", {
		name,
		reason: disabledReason
	}) : supported ? state === "sending" ? t("popup.sniffer.downloadingResource", { name }) : state === "sent" ? t("popup.sniffer.downloadedResource", { name }) : t("popup.sniffer.quickDownloadResource", { name }) : t("popup.sniffer.unsupportedResource", {
		name,
		reason: unsupportedReason
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		"data-testid": `resource-row-${mediaDomKey(media)}`,
		className: "relative flex h-[68px] shrink-0 items-center transition-colors after:absolute after:inset-x-4 after:bottom-0 after:h-px after:bg-border last:after:hidden hover:bg-muted/40 focus-within:bg-muted/40",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 items-center gap-2 pr-1.5 pl-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectionCheckbox, {
						checked: selected,
						disabled: state === "sending",
						label: t("popup.sniffer.selectResource", { name }),
						describedBy: hostDescriptionId,
						onChange: onSelect
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResourceMedia, {
						media,
						enabled: previewEnabled,
						getThumbnail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs font-medium",
								title: `${name} — ${host}`,
								children: name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block truncate text-[10px] text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: host }),
									(error || metadata) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-hidden": "true",
										children: " · "
									}),
									error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-destructive",
										children: error
									}) : metadata && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: metadata })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								id: hostDescriptionId,
								className: "sr-only",
								children: t("popup.sniffer.sourceHost", { host })
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-sm",
				className: cn("mr-3 size-8 shrink-0 rounded-lg text-muted-foreground hover:bg-speed-download/[0.1] hover:text-speed-download", state === "sent" && "bg-primary/10 text-primary hover:bg-primary/15 hover:text-primary"),
				disabled: !supported || !connected || state !== "idle",
				title: disabledReason ?? host,
				"aria-label": actionLabel,
				"aria-describedby": disabledReason ? disabledDescriptionId : hostDescriptionId,
				onClick: onDownload,
				children: state === "sending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
					className: "size-4 animate-spin",
					"aria-hidden": "true"
				}) : state === "sent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					className: "size-4",
					"aria-hidden": "true"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
					className: "size-4",
					"aria-hidden": "true"
				})
			}),
			disabledReason && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: disabledDescriptionId,
				className: "sr-only",
				children: disabledReason
			})
		]
	});
}
function ResolvablePageAction({ site, connected, onResolve }) {
	const { t } = useTranslation();
	const disabledDescriptionId = (0, import_react.useId)();
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [taskId, setTaskId] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const disconnectedReason = t("popup.sniffer.connectToSubmit");
	const submit = async () => {
		setSubmitting(true);
		setTaskId(null);
		setError(null);
		try {
			const result = await onResolve();
			setTaskId(result.taskId);
		} catch {
			setError(t("popup.sniffer.submitFailed"));
		} finally {
			setSubmitting(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-11 shrink-0 items-center gap-2 border-b border-border px-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				size: "xs",
				variant: "secondary",
				disabled: !connected || submitting || taskId !== null,
				title: !connected ? disconnectedReason : void 0,
				"aria-describedby": !connected ? disabledDescriptionId : void 0,
				onClick: () => void submit(),
				children: [submitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { "data-icon": "inline-start" }) : taskId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
					"data-icon": "inline-start",
					"aria-hidden": "true"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
					"data-icon": "inline-start",
					"aria-hidden": "true"
				}), t(`popup.sniffer.pageAction.${site}`)]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("min-w-0 flex-1 truncate text-right text-[10px]", error ? "text-destructive" : "text-muted-foreground"),
				children: error ?? (taskId ? t("popup.sniffer.pageSubmitted", { taskId }) : null)
			}),
			!connected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: disabledDescriptionId,
				className: "sr-only",
				children: disconnectedReason
			})
		]
	});
}
var MediaPanel = (0, import_react.memo)(function MediaPanel({ active = false, connected = true, submissionKey = "default", onMediaCountChange }) {
	const { t } = useTranslation();
	const autoScanned = (0, import_react.useRef)(false);
	const submissionKeyRef = (0, import_react.useRef)(submissionKey);
	const capabilityRefreshPending = (0, import_react.useRef)(false);
	const inFlight = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const quickFilterAnchorRef = (0, import_react.useRef)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [imageQuickFilters, setImageQuickFilters] = (0, import_react.useState)(() => ({ formats: [] }));
	const [selected, setSelected] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const [submitStates, setSubmitStates] = (0, import_react.useState)({});
	const [submitErrors, setSubmitErrors] = (0, import_react.useState)({});
	const [batchSubmitting, setBatchSubmitting] = (0, import_react.useState)(false);
	const { media, selectionKinds, scanning, error, scan, download, getThumbnail, resolvableSite, resolvePageDownload } = usePageMedia(submissionKey);
	(0, import_react.useEffect)(() => {
		if (submissionKeyRef.current !== submissionKey) {
			submissionKeyRef.current = submissionKey;
			inFlight.current.clear();
			setSubmitStates({});
			setSubmitErrors({});
			if (autoScanned.current) capabilityRefreshPending.current = true;
		}
		if (!autoScanned.current) {
			autoScanned.current = true;
			capabilityRefreshPending.current = !connected;
			scan();
			return;
		}
		if (!active) {
			if (!connected) capabilityRefreshPending.current = true;
			return;
		}
		if (!connected) {
			capabilityRefreshPending.current = true;
			return;
		}
		if (!capabilityRefreshPending.current) return;
		capabilityRefreshPending.current = false;
		scan();
	}, [
		active,
		connected,
		scan,
		submissionKey
	]);
	(0, import_react.useEffect)(() => {
		if (connected) return;
		inFlight.current.clear();
		setSubmitStates({});
		setSubmitErrors({});
	}, [connected]);
	(0, import_react.useEffect)(() => {
		onMediaCountChange?.(media.length);
	}, [media.length, onMediaCountChange]);
	(0, import_react.useEffect)(() => {
		const currentKeys = new Set(media.map((item) => mediaStorageKey(item)));
		setSelected((current) => {
			const next = new Set([...current].filter((key) => currentKeys.has(key)));
			return next.size === current.size ? current : next;
		});
		inFlight.current.forEach((_token, key) => {
			if (!currentKeys.has(key)) inFlight.current.delete(key);
		});
		setSubmitStates((current) => Object.fromEntries(Object.entries(current).filter(([key]) => currentKeys.has(key))));
		setSubmitErrors((current) => Object.fromEntries(Object.entries(current).filter(([key]) => currentKeys.has(key))));
	}, [media]);
	const allImageMedia = (0, import_react.useMemo)(() => media.filter((item) => mediaCategory(item) === "image"), [media]);
	const availableFormats = (0, import_react.useMemo)(() => availableImageFormats(allImageMedia), [allImageMedia]);
	const activeImageFilterCount = countActiveImageQuickFilters(imageQuickFilters);
	const visibleMedia = (0, import_react.useMemo)(() => {
		const resources = visibleResources(media, filter);
		return filter === "image" ? resources.filter((item) => matchesImageQuickFilters(item, imageQuickFilters)) : resources;
	}, [
		filter,
		imageQuickFilters,
		media
	]);
	const selectableVisible = visibleMedia;
	const allVisibleSelected = selectableVisible.length > 0 && selectableVisible.every((item) => selected.has(mediaStorageKey(item)));
	const someVisibleSelected = selectableVisible.some((item) => selected.has(mediaStorageKey(item)));
	const selectedMedia = media.filter((item) => selected.has(mediaStorageKey(item)));
	const selectedUnsupported = selectedMedia.some((item) => !selectionKinds.includes(item.kind));
	const toggleSelected = (key) => {
		setSelected((current) => {
			const next = new Set(current);
			if (next.has(key)) next.delete(key);
			else next.add(key);
			return next;
		});
	};
	const toggleAllVisible = () => {
		setSelected((current) => {
			const next = new Set(current);
			for (const item of selectableVisible) {
				const key = mediaStorageKey(item);
				if (allVisibleSelected) next.delete(key);
				else next.add(key);
			}
			return next;
		});
	};
	const submitOne = (0, import_react.useCallback)(async (item) => {
		if (!connected) return false;
		if (!selectionKinds.includes(item.kind)) return false;
		const key = mediaStorageKey(item);
		if (inFlight.current.has(key)) return false;
		const requestToken = Symbol(key);
		inFlight.current.set(key, requestToken);
		setSubmitErrors((current) => ({
			...current,
			[key]: ""
		}));
		setSubmitStates((current) => ({
			...current,
			[key]: "sending"
		}));
		try {
			await download(item);
			if (inFlight.current.get(key) !== requestToken) return false;
			setSubmitStates((current) => ({
				...current,
				[key]: "sent"
			}));
			setSelected((current) => {
				const next = new Set(current);
				next.delete(key);
				return next;
			});
			return true;
		} catch {
			if (inFlight.current.get(key) !== requestToken) return false;
			setSubmitStates((current) => ({
				...current,
				[key]: "idle"
			}));
			setSubmitErrors((current) => ({
				...current,
				[key]: t("popup.sniffer.submitFailed")
			}));
			return false;
		} finally {
			if (inFlight.current.get(key) === requestToken) inFlight.current.delete(key);
		}
	}, [
		connected,
		download,
		selectionKinds,
		t
	]);
	const submitSelected = async () => {
		if (batchSubmitting || !connected || selectedUnsupported || selectedMedia.length === 0) return;
		setBatchSubmitting(true);
		let cursor = 0;
		const worker = async () => {
			while (cursor < selectedMedia.length) {
				const item = selectedMedia[cursor];
				cursor += 1;
				if (item) await submitOne(item);
			}
		};
		try {
			await Promise.all(Array.from({ length: Math.min(BATCH_CONCURRENCY, selectedMedia.length) }, worker));
		} finally {
			setBatchSubmitting(false);
		}
	};
	const scanLabel = scanning ? t("popup.sniffer.scanning") : t("popup.sniffer.scan");
	const hasMedia = media.length > 0;
	const controls = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tabs, {
		value: filter,
		onValueChange: (value) => setFilter(value),
		className: "block min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsList, {
			className: "h-auto min-h-8 w-full min-w-0 flex-wrap items-stretch gap-0 rounded-[10px] bg-tab-background p-0.5 group-data-horizontal/tabs:h-auto",
			children: RESOURCE_FILTERS.map((candidate) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: candidate,
				className: "h-auto min-h-7 min-w-0 max-w-full flex-auto rounded-[8px] border-0 px-2 py-1 whitespace-normal text-[11px] [overflow-wrap:anywhere] font-normal shadow-none group-data-[variant=default]/tabs-list:data-active:shadow-xs",
				children: t(`popup.sniffer.filters.${candidate}`)
			}, candidate))
		})
	});
	const scanAction = error && !hasMedia ? void 0 : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "outline",
		size: "icon-sm",
		className: "size-8 rounded-full",
		"aria-label": scanLabel,
		title: scanLabel,
		disabled: scanning,
		onClick: () => void scan(),
		children: scanning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { "aria-hidden": "true" })
	});
	const batchDisabledReason = !connected ? t("popup.sniffer.connectToSubmit") : selectedUnsupported ? t("popup.sniffer.unsupportedSelectionReason") : null;
	const batchDescriptionId = (0, import_react.useId)();
	const footerCount = filter === "image" && activeImageFilterCount > 0 ? t("popup.sniffer.filteredCount", {
		matched: visibleMedia.length,
		total: allImageMedia.length
	}) : filter === "image" ? t("popup.sniffer.imageCount", { count: visibleMedia.length }) : t("popup.sniffer.detected", { count: visibleMedia.length });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex h-full min-h-0 min-w-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactSectionToolbar, {
			title: t("popup.sniffer.pageResources"),
			controls,
			action: scanAction
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CompactContentCard, {
			"data-testid": "media-panel-card",
			className: "flex flex-col",
			children: [resolvableSite && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResolvablePageAction, {
				site: resolvableSite,
				connected,
				onResolve: resolvePageDownload
			}, `${submissionKey}:${connected ? "online" : "offline"}`), error && !hasMedia ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				className: "min-h-0 flex-1 gap-2 overflow-y-auto p-3 [overflow-wrap:anywhere]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, {
					className: "w-full min-w-0 gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
						className: "text-sm",
						children: t("popup.sniffer.unavailableTitle")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyDescription, {
						className: "text-xs/normal",
						children: t("popup.sniffer.unavailableDescription")
					})]
				})
			}) : scanning && !hasMedia ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				className: "min-h-0 flex-1 gap-2 overflow-y-auto p-3 [overflow-wrap:anywhere]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(EmptyHeader, {
					className: "w-full min-w-0 gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyMedia, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "size-5" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
						className: "text-sm",
						children: t("popup.sniffer.scanning")
					})]
				})
			}) : !hasMedia ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, {
				className: "min-h-0 flex-1 gap-2 overflow-y-auto p-3 [overflow-wrap:anywhere]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyHeader, {
					className: "w-full min-w-0 gap-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyTitle, {
						className: "text-sm",
						children: t("popup.sniffer.emptyTitle")
					})
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "min-h-0 flex-1",
				children: visibleMedia.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex min-h-0 flex-col",
					children: visibleMedia.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResourceRow, {
						media: item,
						supported: selectionKinds.includes(item.kind),
						connected,
						previewEnabled: active,
						selected: selected.has(mediaStorageKey(item)),
						state: submitStates[mediaStorageKey(item)] ?? "idle",
						error: submitErrors[mediaStorageKey(item)] || null,
						getThumbnail,
						onSelect: () => toggleSelected(mediaStorageKey(item)),
						onDownload: () => void submitOne(item)
					}, mediaStorageKey(item)))
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-full flex-col items-center justify-center gap-1.5 p-3 text-center text-xs [overflow-wrap:anywhere] text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: filter === "image" && activeImageFilterCount > 0 ? t("popup.sniffer.noImageMatches") : t("popup.sniffer.emptyFilter") }), filter === "image" && activeImageFilterCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						size: "xs",
						variant: "ghost",
						onClick: () => setImageQuickFilters({ formats: [] }),
						children: t("popup.sniffer.clearFilters")
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				"data-testid": "media-panel-footer",
				className: "relative flex min-h-11 shrink-0 flex-wrap items-center gap-1.5 border-t border-border px-3 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						ref: quickFilterAnchorRef,
						"aria-hidden": "true",
						className: "pointer-events-none absolute -top-px bottom-0 inset-x-[7px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-h-7 min-w-0 max-w-full items-center gap-1 text-[11px] [overflow-wrap:anywhere] text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectionCheckbox, {
							checked: allVisibleSelected,
							indeterminate: someVisibleSelected && !allVisibleSelected,
							disabled: selectableVisible.length === 0,
							label: t("popup.sniffer.selectAll"),
							onChange: toggleAllVisible,
							compact: true
						}), t("popup.sniffer.selectAll")]
					}),
					filter === "image" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageQuickFilterPopover, {
						filters: imageQuickFilters,
						availableFormats,
						matchedCount: visibleMedia.length,
						totalCount: allImageMedia.length,
						positionAnchor: quickFilterAnchorRef,
						onChange: setImageQuickFilters,
						onReset: () => setImageQuickFilters({ formats: [] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 flex-1 truncate text-[11px] tabular-nums text-muted-foreground",
						title: footerCount,
						"aria-live": "polite",
						children: footerCount
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						size: "xs",
						className: "h-auto min-h-6 max-w-full whitespace-normal [overflow-wrap:anywhere]",
						"aria-label": t("popup.sniffer.downloadSelected"),
						disabled: batchSubmitting || selectedMedia.length === 0 || batchDisabledReason !== null,
						title: batchDisabledReason ?? void 0,
						"aria-describedby": batchDisabledReason ? batchDescriptionId : void 0,
						onClick: () => void submitSelected(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							"data-icon": "inline-start",
							"aria-hidden": "true"
						}), t("popup.sniffer.downloadCount", { count: selected.size })]
					}),
					batchDisabledReason && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						id: batchDescriptionId,
						className: "sr-only",
						children: batchDisabledReason
					})
				]
			})] })]
		})]
	});
});
//#endregion
//#region src/popup/PairingPromptDialog.tsx
function PairingPromptDialog({ prompt, error, submitting, onSubmit, onDismiss }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open) onDismiss();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[520px] max-w-[360px] gap-4 overflow-y-auto p-5 sm:max-w-[360px]",
			showCloseButton: false,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: t("popup.pairing.dialogTitle") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "text-xs/5",
						children: t("popup.pairing.codeDescription")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairingCodePanel, {
					onSubmit,
					run: prompt.run,
					maxRuns: prompt.maxRuns,
					attemptsRemaining: prompt.attemptsRemaining,
					deadlineMs: prompt.deadlineMs,
					disabled: submitting
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
					variant: "destructive",
					className: "py-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: error })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "sm",
					className: "mx-auto -mb-1",
					onClick: onDismiss,
					children: t("popup.pairing.dismissPrompt")
				})
			]
		})
	});
}
//#endregion
//#region src/popup/QuickSettingsPanel.tsx
var QUICK_SETTINGS_I18N_KEYS = {
	title: "popup.tabs.settings",
	takeoverDescription: "popup.quickSettings.takeoverDescription",
	notificationsDescription: "popup.quickSettings.notificationsDescription",
	fullSettings: "popup.quickSettings.fullSettings",
	fullSettingsDescription: "popup.quickSettings.fullSettingsDescription",
	loadError: "popup.quickSettings.loadError",
	saveError: "popup.quickSettings.saveError",
	retry: "popup.quickSettings.retry"
};
/** A compact, label-driven switch row shared by every popup quick setting. */
function QuickSettingRow({ id, title, description, checked, disabled = false, onCheckedChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-slot": "quick-setting-row",
		"data-disabled": disabled ? "true" : void 0,
		className: "flex min-h-[55px] shrink-0 items-center justify-between gap-3 px-3 py-2 transition-colors hover:bg-muted/30 data-[disabled=true]:opacity-55",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				id: `${id}-label`,
				htmlFor: id,
				className: cn("block text-xs/4 [overflow-wrap:anywhere] font-medium", disabled ? "cursor-not-allowed" : "cursor-pointer"),
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				id: `${id}-description`,
				className: "block whitespace-normal text-[10px]/4 [overflow-wrap:anywhere] text-muted-foreground",
				title: description,
				children: description
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			id,
			checked,
			disabled,
			onCheckedChange,
			"aria-labelledby": `${id}-label`,
			"aria-describedby": `${id}-description`
		})]
	});
}
var QuickSettingsPanel = (0, import_react.memo)(function QuickSettingsPanel({ controller, onOpenFullSettings, className }) {
	const { t } = useTranslation();
	const { takeover, notifications } = controller;
	const unavailable = takeover === null || notifications === null;
	const controlsDisabled = controller.loading || controller.saving;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("mt-4 flex h-full min-h-0 flex-col", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactSectionToolbar, { title: t(QUICK_SETTINGS_I18N_KEYS.title) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactContentCard, {
				"data-testid": "quick-settings-card",
				className: "overflow-y-auto",
				children: unavailable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full flex-col items-center justify-center gap-3 px-6 text-center",
					children: controller.loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
						className: "size-5 text-muted-foreground",
						"aria-label": t("popup.loading")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: t("popup.loading")
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-xs text-muted-foreground",
						children: t(QUICK_SETTINGS_I18N_KEYS.loadError)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => void controller.reload(),
						children: t(QUICK_SETTINGS_I18N_KEYS.retry)
					})] })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "divide-y divide-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingRow, {
							id: "quick-takeover-switch",
							title: t("options.takeover.enableLabel"),
							description: t(controller.takeoverSupported ? QUICK_SETTINGS_I18N_KEYS.takeoverDescription : "options.takeover.remoteUnavailableShort"),
							checked: controller.takeoverSupported && takeover.enabled,
							disabled: controlsDisabled || !controller.takeoverSupported,
							onCheckedChange: (checked) => void controller.requestTakeoverEnabled(checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingRow, {
							id: "quick-notifications-master-switch",
							title: t("options.notifications.masterLabel"),
							description: t(QUICK_SETTINGS_I18N_KEYS.notificationsDescription),
							checked: notifications.master,
							disabled: controlsDisabled,
							onCheckedChange: (checked) => void controller.setNotification("master", checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingRow, {
							id: "quick-notifications-confirm-switch",
							title: t("options.notifications.confirmLabel"),
							description: t("options.notifications.confirmDesc"),
							checked: notifications.confirm,
							disabled: controlsDisabled || !notifications.master,
							onCheckedChange: (checked) => void controller.setNotification("confirm", checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingRow, {
							id: "quick-notifications-error-switch",
							title: t("options.notifications.errorLabel"),
							description: t("options.notifications.errorDesc"),
							checked: notifications.error,
							disabled: controlsDisabled || !notifications.master,
							onCheckedChange: (checked) => void controller.setNotification("error", checked)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingRow, {
							id: "quick-notifications-reminder-switch",
							title: t("options.notifications.reminderLabel"),
							description: t("options.notifications.reminderDesc"),
							checked: notifications.reminder,
							disabled: controlsDisabled || !notifications.master,
							onCheckedChange: (checked) => void controller.setNotification("reminder", checked)
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					"data-testid": "full-settings-row",
					type: "button",
					variant: "ghost",
					className: "h-auto min-h-[63px] w-full justify-start whitespace-normal rounded-none border-x-0 border-t border-b-0 border-border px-3 py-2 text-left hover:bg-muted/40",
					onClick: onOpenFullSettings,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, {
							className: "size-4 text-muted-foreground",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block text-xs/4 font-medium",
								children: t(QUICK_SETTINGS_I18N_KEYS.fullSettings)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block whitespace-normal text-[10px]/4 [overflow-wrap:anywhere] font-normal text-muted-foreground",
								children: t(QUICK_SETTINGS_I18N_KEYS.fullSettingsDescription)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
							className: "size-4 text-muted-foreground",
							"aria-hidden": "true"
						})
					]
				})] })
			}),
			controller.error?.operation === "save" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-1 shrink-0 px-1 [overflow-wrap:anywhere] text-[10px]/4 text-destructive",
				children: t(QUICK_SETTINGS_I18N_KEYS.saveError)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
				open: controller.consentRequired && controller.takeoverSupported,
				onOpenChange: (open) => {
					if (!open) controller.cancelTakeoverConsent();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, {
					size: "sm",
					className: "max-w-[360px]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: t("options.takeover.consentDialogLabel") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: t("options.takeover.consentBody") })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
						type: "button",
						className: "min-w-0",
						disabled: controller.saving,
						children: t("options.takeover.consentCancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogAction, {
						type: "button",
						className: "min-w-0",
						disabled: controller.saving,
						onClick: () => void controller.confirmTakeoverConsent(),
						children: t("options.takeover.consentConfirm")
					})] })]
				})
			})
		]
	});
});
//#endregion
//#region src/popup/SpeedTile.tsx
var SPEED_UNITS = [
	"B/s",
	"KB/s",
	"MB/s",
	"GB/s",
	"TB/s",
	"PB/s"
];
var ACCENT_CLASS = {
	upload: {
		band: "bg-speed-upload/[0.12]",
		line: "bg-speed-upload"
	},
	download: {
		band: "bg-speed-download/[0.12]",
		line: "bg-speed-download"
	}
};
function formatSpeed(bytesPerSecond) {
	if (!Number.isFinite(bytesPerSecond) || bytesPerSecond < 1) return {
		number: "0",
		unit: "B/s"
	};
	let value = bytesPerSecond;
	let unitIndex = 0;
	while (value >= 1024 && unitIndex < SPEED_UNITS.length - 1) {
		value /= 1024;
		unitIndex += 1;
	}
	return {
		number: unitIndex === 0 ? Math.floor(value).toString() : value >= 100 ? Math.round(value).toString() : value.toFixed(1),
		unit: SPEED_UNITS[unitIndex] ?? "B/s"
	};
}
function SpeedTile({ kind, label, bytesPerSecond, className }) {
	const speed = formatSpeed(bytesPerSecond);
	const accent = ACCENT_CLASS[kind];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardTile, {
		label,
		value: speed.number,
		unit: speed.unit,
		...className === void 0 ? {} : { className },
		decoration: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			className: cn("pointer-events-none absolute inset-x-0 bottom-0 h-2", accent.band)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-hidden": "true",
			className: cn("pointer-events-none absolute inset-x-0 bottom-2 h-px", accent.line)
		})] })
	});
}
//#endregion
//#region src/popup/useControlPanel.ts
var ACTIVE_POLL_MS = 1500;
var IDLE_POLL_MS = 1e4;
var ENGINE_POLL_MS = 3e4;
var ACTIVE_TASK_STATUSES = /* @__PURE__ */ new Set([
	"queued",
	"fetching_metadata",
	"downloading",
	"seeding",
	"finalizing"
]);
function emptyState(scopeKey, active) {
	return {
		tasks: [],
		stats: null,
		engine: null,
		loading: active,
		error: null,
		scopeKey,
		activityError: null,
		engineError: null
	};
}
function retainEqualTasks(current, incoming) {
	if (snapshotEqual(current, incoming)) return current;
	const currentById = new Map(current.map((task) => [task.id, task]));
	return incoming.map((task) => {
		const previous = currentById.get(task.id);
		return previous && snapshotEqual(previous, task) ? previous : task;
	});
}
function hasActiveTasks(tasks) {
	return tasks.some((task) => ACTIVE_TASK_STATUSES.has(task.status));
}
/**
* Reconciles the bridge control-plane while `active`.
*
* Task + stats refresh quickly only while work can change on screen, then
* back off when idle. Engine status has its own slow loop. Activity pushes
* from the paired session wake the task loop immediately, while an idle poll
* remains as the source of truth for tasks added directly in Motrix.
*/
function useControlPanel(active, scopeKey = "default") {
	const [state, setState] = (0, import_react.useState)(() => emptyState(scopeKey, active));
	const activeRef = (0, import_react.useRef)(active);
	const scopeRef = (0, import_react.useRef)(scopeKey);
	activeRef.current = active;
	scopeRef.current = scopeKey;
	const refreshActivitySnapshot = (0, import_react.useCallback)(async (requestScope) => {
		if (!activeRef.current) return null;
		try {
			const [list, stats] = await Promise.all([send("bg.taskList", {}), send("bg.statsGet", {})]);
			if (isErrorResponse(list)) throw new Error(list.error);
			if (isErrorResponse(stats)) throw new Error(stats.error);
			if (!activeRef.current || scopeRef.current !== requestScope) return null;
			const nextHasActiveTasks = hasActiveTasks(list.tasks);
			setState((current) => {
				const scopedCurrent = current.scopeKey === requestScope ? current : emptyState(requestScope, true);
				const tasks = retainEqualTasks(scopedCurrent.tasks, list.tasks);
				const nextStats = snapshotEqual(scopedCurrent.stats, stats) ? scopedCurrent.stats : stats;
				if (scopedCurrent.tasks === tasks && scopedCurrent.stats === nextStats && !scopedCurrent.loading && scopedCurrent.activityError === null) return scopedCurrent;
				return {
					...scopedCurrent,
					activityError: null,
					error: scopedCurrent.engineError,
					loading: false,
					stats: nextStats,
					tasks
				};
			});
			return nextHasActiveTasks;
		} catch (e) {
			if (!activeRef.current || scopeRef.current !== requestScope) return null;
			setState((current) => {
				const error = e.message;
				const scopedCurrent = current.scopeKey === requestScope ? current : emptyState(requestScope, true);
				if (!scopedCurrent.loading && scopedCurrent.activityError === error) return scopedCurrent;
				return {
					...scopedCurrent,
					activityError: error,
					loading: false,
					error
				};
			});
			return null;
		}
	}, []);
	const refreshEngineSnapshot = (0, import_react.useCallback)(async (requestScope) => {
		if (!activeRef.current) return;
		try {
			const engine = await send("bg.engineStatus", {});
			if (isErrorResponse(engine)) throw new Error(engine.error);
			if (!activeRef.current || scopeRef.current !== requestScope) return;
			setState((current) => {
				const scopedCurrent = current.scopeKey === requestScope ? current : emptyState(requestScope, true);
				const nextEngine = snapshotEqual(scopedCurrent.engine, engine) ? scopedCurrent.engine : engine;
				if (scopedCurrent.engine === nextEngine && scopedCurrent.engineError === null) return scopedCurrent;
				return {
					...scopedCurrent,
					engine: nextEngine,
					engineError: null,
					error: scopedCurrent.activityError
				};
			});
		} catch (e) {
			if (!activeRef.current || scopeRef.current !== requestScope) return;
			setState((current) => {
				const error = e.message;
				const scopedCurrent = current.scopeKey === requestScope ? current : emptyState(requestScope, true);
				if (scopedCurrent.engineError === error) return scopedCurrent;
				return {
					...scopedCurrent,
					engineError: error,
					error: scopedCurrent.activityError ?? error
				};
			});
		}
	}, []);
	const requestActivityRefreshRef = (0, import_react.useRef)(async () => void 0);
	const refresh = (0, import_react.useCallback)(() => requestActivityRefreshRef.current(), []);
	(0, import_react.useEffect)(() => {
		setState(emptyState(scopeKey, active));
		if (!active) {
			requestActivityRefreshRef.current = async () => void 0;
			return;
		}
		let disposed = false;
		let fastPolling = false;
		let activityTimer = null;
		let engineTimer = null;
		let activityRequested = false;
		let activityRunner = null;
		const clearActivityTimer = () => {
			if (activityTimer !== null) clearTimeout(activityTimer);
			activityTimer = null;
		};
		const scheduleActivityRefresh = () => {
			clearActivityTimer();
			if (disposed) return;
			activityTimer = setTimeout(() => void requestActivityRefresh(), fastPolling ? ACTIVE_POLL_MS : IDLE_POLL_MS);
		};
		const requestActivityRefresh = async () => {
			if (disposed) return;
			activityRequested = true;
			clearActivityTimer();
			if (activityRunner === null) activityRunner = (async () => {
				while (activityRequested && !disposed) {
					activityRequested = false;
					const nextFastPolling = await refreshActivitySnapshot(scopeKey);
					if (nextFastPolling !== null) fastPolling = nextFastPolling;
				}
			})().finally(() => {
				activityRunner = null;
				scheduleActivityRefresh();
			});
			await activityRunner;
			if (activityRequested && !disposed) await requestActivityRefresh();
		};
		const pollEngine = async () => {
			await refreshEngineSnapshot(scopeKey);
			if (disposed) return;
			engineTimer = setTimeout(() => void pollEngine(), ENGINE_POLL_MS);
		};
		const handleRuntimeMessage = (message) => {
			if (isControlPanelActivityEvent(message)) requestActivityRefresh();
		};
		requestActivityRefreshRef.current = requestActivityRefresh;
		browser.runtime.onMessage.addListener(handleRuntimeMessage);
		requestActivityRefresh();
		pollEngine();
		return () => {
			disposed = true;
			clearActivityTimer();
			if (engineTimer !== null) clearTimeout(engineTimer);
			browser.runtime.onMessage.removeListener(handleRuntimeMessage);
			if (requestActivityRefreshRef.current === requestActivityRefresh) requestActivityRefreshRef.current = async () => void 0;
		};
	}, [
		active,
		refreshActivitySnapshot,
		refreshEngineSnapshot,
		scopeKey
	]);
	const action = (0, import_react.useCallback)(async (kind, taskId, deleteFiles) => {
		const res = await send(kind, kind === "bg.taskRemove" ? {
			taskId,
			deleteFiles
		} : { taskId });
		if (isErrorResponse(res)) throw new Error(res.error);
		await refresh();
	}, [refresh]);
	const pause = (0, import_react.useCallback)((taskId) => action("bg.taskPause", taskId), [action]);
	const resume = (0, import_react.useCallback)((taskId) => action("bg.taskResume", taskId), [action]);
	const reveal = (0, import_react.useCallback)(async (taskId) => {
		const response = await send("bg.taskReveal", { taskId });
		if (isErrorResponse(response)) throw new Error(response.error);
	}, []);
	const remove = (0, import_react.useCallback)((taskId, deleteFiles) => action("bg.taskRemove", taskId, deleteFiles), [action]);
	const inactiveState = (0, import_react.useMemo)(() => emptyState(scopeKey, active), [active, scopeKey]);
	const visibleState = active && state.scopeKey === scopeKey ? state : inactiveState;
	return (0, import_react.useMemo)(() => ({
		...visibleState,
		refresh,
		pause,
		resume,
		reveal,
		remove
	}), [
		pause,
		refresh,
		remove,
		resume,
		reveal,
		visibleState
	]);
}
//#endregion
//#region src/popup/useQuickSettings.ts
function errorMessage(error) {
	return error instanceof Error ? error.message : String(error);
}
/**
* Loads and persists the two real background-owned configs used by the popup's
* quick settings. Mutations always spread the last full config so fields that
* are only editable on the Options page are not reset by a quick toggle.
*/
function useQuickSettings(takeoverSupported = true) {
	const [takeover, setTakeover] = (0, import_react.useState)(null);
	const [notifications, setNotifications] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [consentRequired, setConsentRequired] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!takeoverSupported) setConsentRequired(false);
	}, [takeoverSupported]);
	const mountedRef = (0, import_react.useRef)(true);
	const loadGenerationRef = (0, import_react.useRef)(0);
	const savingRef = (0, import_react.useRef)(false);
	const takeoverRef = (0, import_react.useRef)(null);
	const notificationsRef = (0, import_react.useRef)(null);
	const reload = (0, import_react.useCallback)(async () => {
		const generation = ++loadGenerationRef.current;
		if (mountedRef.current) {
			setLoading(true);
			setError(null);
		}
		try {
			const [nextTakeover, nextNotifications] = await Promise.all([send("bg.getTakeoverConfig", void 0), send("bg.getNotificationsConfig", void 0)]);
			if (!mountedRef.current || generation !== loadGenerationRef.current) return;
			takeoverRef.current = nextTakeover;
			notificationsRef.current = nextNotifications;
			setTakeover(nextTakeover);
			setNotifications(nextNotifications);
			setConsentRequired(false);
		} catch (loadError) {
			if (!mountedRef.current || generation !== loadGenerationRef.current) return;
			setError({
				operation: "load",
				message: errorMessage(loadError)
			});
		} finally {
			if (mountedRef.current && generation === loadGenerationRef.current) setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		mountedRef.current = true;
		reload();
		return () => {
			mountedRef.current = false;
			loadGenerationRef.current += 1;
		};
	}, [reload]);
	const persistTakeover = (0, import_react.useCallback)(async (next) => {
		const previous = takeoverRef.current;
		if (previous === null || savingRef.current) return false;
		savingRef.current = true;
		takeoverRef.current = next;
		if (mountedRef.current) {
			setSaving(true);
			setError(null);
			setTakeover(next);
		}
		try {
			await send("bg.setTakeoverConfig", next);
			return true;
		} catch (saveError) {
			const shouldRollback = takeoverRef.current === next;
			if (shouldRollback) takeoverRef.current = previous;
			if (mountedRef.current) {
				if (shouldRollback) setTakeover(previous);
				setError({
					operation: "save",
					message: errorMessage(saveError)
				});
			}
			return false;
		} finally {
			savingRef.current = false;
			if (mountedRef.current) setSaving(false);
		}
	}, []);
	const persistNotifications = (0, import_react.useCallback)(async (next) => {
		const previous = notificationsRef.current;
		if (previous === null || savingRef.current) return false;
		savingRef.current = true;
		notificationsRef.current = next;
		if (mountedRef.current) {
			setSaving(true);
			setError(null);
			setNotifications(next);
		}
		try {
			await send("bg.setNotificationsConfig", next);
			return true;
		} catch (saveError) {
			const shouldRollback = notificationsRef.current === next;
			if (shouldRollback) notificationsRef.current = previous;
			if (mountedRef.current) {
				if (shouldRollback) setNotifications(previous);
				setError({
					operation: "save",
					message: errorMessage(saveError)
				});
			}
			return false;
		} finally {
			savingRef.current = false;
			if (mountedRef.current) setSaving(false);
		}
	}, []);
	const requestTakeoverEnabled = (0, import_react.useCallback)(async (enabled) => {
		const current = takeoverRef.current;
		if (!takeoverSupported) return;
		if (current === null || current.enabled === enabled) return;
		if (enabled && current.consentAckVersion < 1) {
			if (mountedRef.current) setConsentRequired(true);
			return;
		}
		if (!enabled && mountedRef.current) setConsentRequired(false);
		await persistTakeover({
			...current,
			enabled
		});
	}, [persistTakeover, takeoverSupported]);
	const confirmTakeoverConsent = (0, import_react.useCallback)(async () => {
		const current = takeoverRef.current;
		if (!takeoverSupported || current === null) return;
		if (await persistTakeover({
			...current,
			enabled: true,
			consentAckVersion: Math.max(current.consentAckVersion, 1)
		}) && mountedRef.current) setConsentRequired(false);
	}, [persistTakeover, takeoverSupported]);
	const cancelTakeoverConsent = (0, import_react.useCallback)(() => {
		if (mountedRef.current) setConsentRequired(false);
	}, []);
	const setNotification = (0, import_react.useCallback)(async (setting, enabled) => {
		const current = notificationsRef.current;
		if (current === null || current[setting] === enabled) return;
		await persistNotifications({
			...current,
			[setting]: enabled
		});
	}, [persistNotifications]);
	return (0, import_react.useMemo)(() => ({
		takeoverSupported,
		takeover,
		notifications,
		loading,
		saving,
		error,
		consentRequired,
		reload,
		requestTakeoverEnabled,
		confirmTakeoverConsent,
		cancelTakeoverConsent,
		setNotification
	}), [
		cancelTakeoverConsent,
		confirmTakeoverConsent,
		consentRequired,
		error,
		loading,
		notifications,
		reload,
		requestTakeoverEnabled,
		saving,
		setNotification,
		takeover,
		takeoverSupported
	]);
}
//#endregion
//#region src/popup/App.tsx
function CompactConnectionNotice({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "status",
		className: "flex h-8 items-center gap-2 border-b border-amber-500/20 bg-amber-500/[0.07] px-3 text-[10px]/4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
			className: "size-3.5 shrink-0 text-amber-600",
			"aria-hidden": "true"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate",
			children: text
		})]
	});
}
var PopupHeaderSection = (0, import_react.memo)(function PopupHeaderSection({ connection, endpoint, switching, takeoverChecked, takeoverDisabled, takeoverSupported, onEndpointChange, onTakeoverChange, onOpenSettings }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactPopupHeader, {
		backend: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackendSelector, {
			connection,
			endpoint,
			busy: switching,
			onEndpointChange,
			onConfigureServer: onOpenSettings
		}),
		takeoverChecked,
		takeoverDisabled,
		takeoverSupported,
		onTakeoverChange,
		onOpenSettings
	});
});
var PopupDashboard = (0, import_react.memo)(function PopupDashboard({ uploadSpeed, downloadSpeed, activeTaskCount, resourceCount, onShowTasks, onShowResources }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		"data-testid": "dashboard-tiles",
		"aria-label": t("popup.dashboard.title"),
		className: "mt-4 grid min-h-20 shrink-0 grid-cols-4 grid-rows-[auto_auto_1fr] gap-x-4 gap-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedTile, {
				kind: "upload",
				label: t("popup.speed.upload"),
				bytesPerSecond: uploadSpeed
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SpeedTile, {
				kind: "download",
				label: t("popup.speed.download"),
				bytesPerSecond: downloadSpeed
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardTile, {
				testId: "tile-activity",
				label: t("popup.dashboard.activity"),
				value: activeTaskCount,
				icon: Activity,
				iconClassName: "text-connection-online",
				ariaLabel: t("popup.dashboard.showTasks"),
				onClick: onShowTasks
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardTile, {
				testId: "tile-resources",
				label: t("popup.dashboard.resources"),
				value: resourceCount,
				icon: ScanSearch,
				iconClassName: "text-speed-download",
				ariaLabel: t("popup.dashboard.showResources"),
				onClick: onShowResources
			})
		]
	});
});
var PopupContent = (0, import_react.memo)(function PopupContent({ tab, onTabChange, connected, state, statusState, taskController, notice, needsServer, onReconnect, onOpenOptions, onShowPairing, backendKey, onMediaCountChange, quickSettings }) {
	const { t } = useTranslation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
		value: tab,
		onValueChange: (value) => onTabChange(value),
		className: "mt-4 min-h-0 flex-1 gap-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "tasks",
				className: "min-h-0 min-w-0 overflow-x-hidden overflow-y-auto",
				children: connected && !state.loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlPanel, {
					connection: state.connection,
					controller: taskController,
					canRevealTask: state.capabilities.taskReveal,
					onReconnect,
					notice
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectionPanel, {
					title: t("popup.tasks.title"),
					state: statusState,
					onReconnect: needsServer ? onOpenOptions : onReconnect,
					...needsServer ? { actionLabel: t("popup.backend.configureServer") } : { onShowPairing }
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "sniffer",
				keepMounted: true,
				className: "min-h-0 min-w-0 overflow-x-hidden overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaPanel, {
					active: tab === "sniffer",
					connected: connected && !state.loading,
					submissionKey: backendKey,
					onMediaCountChange
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
				value: "settings",
				className: "min-h-0 min-w-0 overflow-x-hidden overflow-y-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuickSettingsPanel, {
					controller: quickSettings,
					onOpenFullSettings: onOpenOptions,
					className: "mt-0"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopupBottomNavigation, {})
		]
	});
});
function App() {
	const { t } = useTranslation();
	const { state, switching, reconnect, switchEndpoint, submitPairingCode } = usePopupState();
	const quickSettings = useQuickSettings(!switching && supportsAutomaticTakeover(state.endpoint));
	const [tab, setTab] = (0, import_react.useState)("tasks");
	const [resourceCount, setResourceCount] = (0, import_react.useState)(0);
	const [endpointError, setEndpointError] = (0, import_react.useState)(null);
	const [pairingCodeError, setPairingCodeError] = (0, import_react.useState)(null);
	const [submittingCode, setSubmittingCode] = (0, import_react.useState)(false);
	const [dismissedPairingDeadlineMs, setDismissedPairingDeadlineMs] = (0, import_react.useState)(null);
	const connected = state.connection === "connected";
	const needsServer = !hasNativeMessagingSupport() && (state.endpoint?.activeEndpointId ?? "local") === "local";
	const statusState = (0, import_react.useMemo)(() => endpointError === null ? state : {
		...state,
		lastError: endpointError,
		lastErrorReason: null
	}, [endpointError, state]);
	const backendKey = state.endpoint?.activeEndpointId ?? "unresolved";
	const controller = useControlPanel(connected, backendKey);
	const taskController = (0, import_react.useMemo)(() => ({
		tasks: controller.tasks,
		loading: controller.loading,
		error: controller.error,
		refresh: controller.refresh,
		pause: controller.pause,
		resume: controller.resume,
		reveal: controller.reveal,
		remove: controller.remove
	}), [
		controller.error,
		controller.loading,
		controller.pause,
		controller.refresh,
		controller.remove,
		controller.resume,
		controller.reveal,
		controller.tasks
	]);
	const activeTaskCount = controller.stats === null ? controller.tasks.filter((task) => task.status !== "completed" && task.status !== "error").length : controller.stats.activeTasks + controller.stats.waitingTasks;
	const openOptions = (0, import_react.useCallback)(() => {
		browser.runtime.openOptionsPage();
	}, []);
	const changeEndpoint = (0, import_react.useCallback)(async (endpointId) => {
		setEndpointError(null);
		try {
			await switchEndpoint(endpointId);
		} catch (error) {
			setEndpointError(error.message);
		}
	}, [switchEndpoint]);
	const handleSubmitCode = (0, import_react.useCallback)(async (code) => {
		setPairingCodeError(null);
		setSubmittingCode(true);
		try {
			await submitPairingCode(code);
		} catch {
			setPairingCodeError(t("errors.connection.generic"));
		} finally {
			setSubmittingCode(false);
		}
	}, [submitPairingCode, t]);
	const handleTakeoverChange = (0, import_react.useCallback)((checked) => {
		if (checked && quickSettings.takeover !== null && quickSettings.takeover.consentAckVersion < 1) setTab("settings");
		quickSettings.requestTakeoverEnabled(checked);
	}, [quickSettings.requestTakeoverEnabled, quickSettings.takeover]);
	const connectedNotice = (0, import_react.useMemo)(() => state.degraded ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactConnectionNotice, { text: t("popup.pairing.degradedBody") }) : statusState.lastError !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CompactConnectionNotice, { text: t(connectionErrorKey(statusState.lastErrorReason)) }) : void 0, [
		state.degraded,
		statusState.lastError,
		statusState.lastErrorReason,
		t
	]);
	const reconnectPopup = (0, import_react.useCallback)(() => void reconnect(), [reconnect]);
	const showPairing = (0, import_react.useCallback)(() => setDismissedPairingDeadlineMs(null), []);
	const showTasks = (0, import_react.useCallback)(() => setTab("tasks"), []);
	const showResources = (0, import_react.useCallback)(() => setTab("sniffer"), []);
	const changeTab = (0, import_react.useCallback)((nextTab) => setTab(nextTab), []);
	const pairingPrompt = tab === "tasks" && state.pairingCode !== null && dismissedPairingDeadlineMs !== state.pairingCode.deadlineMs ? state.pairingCode : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		"data-testid": "compact-popup",
		className: "box-border flex h-[600px] w-[400px] flex-col overflow-hidden bg-background p-4 font-sans text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopupHeaderSection, {
				connection: state.loading ? "connecting" : state.connection,
				endpoint: state.endpoint,
				switching,
				takeoverChecked: quickSettings.takeoverSupported && (quickSettings.takeover?.enabled ?? false),
				takeoverDisabled: quickSettings.loading || quickSettings.saving || !quickSettings.takeoverSupported,
				takeoverSupported: quickSettings.takeoverSupported,
				onEndpointChange: changeEndpoint,
				onTakeoverChange: handleTakeoverChange,
				onOpenSettings: openOptions
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopupDashboard, {
				uploadSpeed: controller.stats?.totalUploadSpeed ?? 0,
				downloadSpeed: controller.stats?.totalDownloadSpeed ?? 0,
				activeTaskCount,
				resourceCount,
				onShowTasks: showTasks,
				onShowResources: showResources
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopupContent, {
				tab,
				onTabChange: changeTab,
				connected,
				state,
				statusState,
				taskController,
				notice: connectedNotice,
				needsServer,
				onReconnect: reconnectPopup,
				onOpenOptions: openOptions,
				onShowPairing: showPairing,
				backendKey,
				onMediaCountChange: setResourceCount,
				quickSettings
			}),
			pairingPrompt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PairingPromptDialog, {
				prompt: pairingPrompt,
				error: pairingCodeError,
				submitting: submittingCode,
				onSubmit: (code) => void handleSubmitCode(code),
				onDismiss: () => setDismissedPairingDeadlineMs(pairingPrompt.deadlineMs)
			})
		]
	});
}
//#endregion
//#region src/popup/index.tsx
initTheme();
var root = document.getElementById("root");
initI18n().then(() => {
	if (root) (0, import_client.createRoot)(root).render(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(App, {}));
});
//#endregion

//# sourceMappingURL=popup.html-DNhG0qjy.js.map