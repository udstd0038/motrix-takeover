import { $ as MessageBus, A as magnetDisplayName, B as backendAuthorityKey, C as unknown, D as hostOf, E as TAKEOVER_DEFAULT, F as resolveActiveEndpoint, G as b64uDecode, H as normalizeRemoteEndpoint, I as resolveEndpointById, J as enc, K as b64uEncode, L as createOperationQueue, M as EndpointConfigStore, N as LOCAL_ENDPOINT_ID, O as hostSuffixMatch, Q as utf8, R as LOCAL_BACKEND_AUTHORITY, S as string, T as QUALITY_SENTINEL, V as createRemoteBackendAuthority, W as assertAscii, X as encU64BE, Y as encU32BE, Z as timingSafeEqualBytes, _ as number, at as instance, b as record, d as _enum, f as array, g as literal, h as httpUrl$2, i as initI18n, j as supportsAutomaticTakeover, k as isMagnetUrl, m as discriminatedUnion, n as normalizePairingCode, ot as __commonJSMin, p as boolean, q as concatBytes$2, t as hasNativeMessagingSupport, tt as MEDIA_SUBMIT_ERROR, v as object, x as strictObject, y as preprocess, z as assertBackendAuthority } from "./platformCapabilities-BhYiGJPy.js";
import { a as parseLogLevel, c as isSeverityEnabled, i as getLogLevel, n as LOG_LEVEL_KEY, r as LOG_LEVEL_RANK, s as NOTIFICATIONS_DEFAULT, t as DEFAULT_LOG_LEVEL } from "./logLevel-DcvbLdwE.js";
import { a as sanitizeFilenameWithExtension, i as sanitizeFilename, r as parseManualTaskInput, t as CONTROL_PANEL_ACTIVITY_EVENT } from "./controlPanelEvents-mRP3GXsl.js";
import { a as mediaCategory, i as isResolvableVideoPage, l as shouldExcludeHost, n as extensionForMediaMimeType, o as mediaStorageKey, r as inferMediaMimeType, s as mediaTabStorageKey, t as classifyMediaUrl, u as isWebStoreBuild } from "./media-oiN-I4sB.js";
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/is.js
var require_is = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.boolean = boolean;
	exports.string = string;
	exports.number = number;
	exports.error = error;
	exports.func = func;
	exports.array = array;
	exports.stringArray = stringArray;
	function boolean(value) {
		return value === true || value === false;
	}
	function string(value) {
		return typeof value === "string" || value instanceof String;
	}
	function number(value) {
		return typeof value === "number" || value instanceof Number;
	}
	function error(value) {
		return value instanceof Error;
	}
	function func(value) {
		return typeof value === "function";
	}
	function array(value) {
		return Array.isArray(value);
	}
	function stringArray(value) {
		return array(value) && value.every((elem) => string(elem));
	}
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/messages.js
var require_messages = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || (function() {
		var ownKeys = function(o) {
			ownKeys = Object.getOwnPropertyNames || function(o) {
				var ar = [];
				for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
				return ar;
			};
			return ownKeys(o);
		};
		return function(mod) {
			if (mod && mod.__esModule) return mod;
			var result = {};
			if (mod != null) {
				for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
			}
			__setModuleDefault(result, mod);
			return result;
		};
	})();
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Message = exports.NotificationType9 = exports.NotificationType8 = exports.NotificationType7 = exports.NotificationType6 = exports.NotificationType5 = exports.NotificationType4 = exports.NotificationType3 = exports.NotificationType2 = exports.NotificationType1 = exports.NotificationType0 = exports.NotificationType = exports.RequestType9 = exports.RequestType8 = exports.RequestType7 = exports.RequestType6 = exports.RequestType5 = exports.RequestType4 = exports.RequestType3 = exports.RequestType2 = exports.RequestType1 = exports.RequestType = exports.RequestType0 = exports.AbstractMessageSignature = exports.ParameterStructures = exports.ResponseError = exports.ErrorCodes = void 0;
	var is = __importStar(require_is());
	/**
	* Predefined error codes.
	*/
	var ErrorCodes;
	(function(ErrorCodes) {
		ErrorCodes.ParseError = -32700;
		ErrorCodes.InvalidRequest = -32600;
		ErrorCodes.MethodNotFound = -32601;
		ErrorCodes.InvalidParams = -32602;
		ErrorCodes.InternalError = -32603;
		/**
		* This is the start range of JSON RPC reserved error codes.
		* It doesn't denote a real error code. No application error codes should
		* be defined between the start and end range. For backwards
		* compatibility the `ServerNotInitialized` and the `UnknownErrorCode`
		* are left in the range.
		*
		* @since 3.16.0
		*/
		ErrorCodes.jsonrpcReservedErrorRangeStart = -32099;
		/** @deprecated use  jsonrpcReservedErrorRangeStart */
		ErrorCodes.serverErrorStart = -32099;
		/**
		* An error occurred when write a message to the transport layer.
		*/
		ErrorCodes.MessageWriteError = -32099;
		/**
		* An error occurred when reading a message from the transport layer.
		*/
		ErrorCodes.MessageReadError = -32098;
		/**
		* The connection got disposed or lost and all pending responses got
		* rejected.
		*/
		ErrorCodes.PendingResponseRejected = -32097;
		/**
		* The connection is inactive and a use of it failed.
		*/
		ErrorCodes.ConnectionInactive = -32096;
		/**
		* Error code indicating that a server received a notification or
		* request before the server has received the `initialize` request.
		*/
		ErrorCodes.ServerNotInitialized = -32002;
		ErrorCodes.UnknownErrorCode = -32001;
		/**
		* This is the end range of JSON RPC reserved error codes.
		* It doesn't denote a real error code.
		*
		* @since 3.16.0
		*/
		ErrorCodes.jsonrpcReservedErrorRangeEnd = -32e3;
		/** @deprecated use  jsonrpcReservedErrorRangeEnd */
		ErrorCodes.serverErrorEnd = -32e3;
	})(ErrorCodes || (exports.ErrorCodes = ErrorCodes = {}));
	exports.ResponseError = class ResponseError extends Error {
		code;
		data;
		constructor(code, message, data) {
			super(message);
			this.code = is.number(code) ? code : ErrorCodes.UnknownErrorCode;
			this.data = data;
			Object.setPrototypeOf(this, ResponseError.prototype);
		}
		toJson() {
			const result = {
				code: this.code,
				message: this.message
			};
			if (this.data !== void 0) result.data = this.data;
			return result;
		}
	};
	var ParameterStructures = class ParameterStructures {
		kind;
		/**
		* The parameter structure is automatically inferred on the number of parameters
		* and the parameter type in case of a single param.
		*/
		static auto = new ParameterStructures("auto");
		/**
		* Forces `byPosition` parameter structure. This is useful if you have a single
		* parameter which has a literal type.
		*/
		static byPosition = new ParameterStructures("byPosition");
		/**
		* Forces `byName` parameter structure. This is only useful when having a single
		* parameter. The library will report errors if used with a different number of
		* parameters.
		*/
		static byName = new ParameterStructures("byName");
		constructor(kind) {
			this.kind = kind;
		}
		static is(value) {
			return value === ParameterStructures.auto || value === ParameterStructures.byName || value === ParameterStructures.byPosition;
		}
		toString() {
			return this.kind;
		}
	};
	exports.ParameterStructures = ParameterStructures;
	/**
	* An abstract implementation of a MessageType.
	*/
	var AbstractMessageSignature = class {
		method;
		numberOfParams;
		constructor(method, numberOfParams) {
			this.method = method;
			this.numberOfParams = numberOfParams;
		}
		get parameterStructures() {
			return ParameterStructures.auto;
		}
	};
	exports.AbstractMessageSignature = AbstractMessageSignature;
	/**
	* Classes to type request response pairs
	*/
	var RequestType0 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 0);
		}
	};
	exports.RequestType0 = RequestType0;
	var RequestType = class extends AbstractMessageSignature {
		_parameterStructures;
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method, _parameterStructures = ParameterStructures.auto) {
			super(method, 1);
			this._parameterStructures = _parameterStructures;
		}
		get parameterStructures() {
			return this._parameterStructures;
		}
	};
	exports.RequestType = RequestType;
	var RequestType1 = class extends AbstractMessageSignature {
		_parameterStructures;
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method, _parameterStructures = ParameterStructures.auto) {
			super(method, 1);
			this._parameterStructures = _parameterStructures;
		}
		get parameterStructures() {
			return this._parameterStructures;
		}
	};
	exports.RequestType1 = RequestType1;
	var RequestType2 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 2);
		}
	};
	exports.RequestType2 = RequestType2;
	var RequestType3 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 3);
		}
	};
	exports.RequestType3 = RequestType3;
	var RequestType4 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 4);
		}
	};
	exports.RequestType4 = RequestType4;
	var RequestType5 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 5);
		}
	};
	exports.RequestType5 = RequestType5;
	var RequestType6 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 6);
		}
	};
	exports.RequestType6 = RequestType6;
	var RequestType7 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 7);
		}
	};
	exports.RequestType7 = RequestType7;
	var RequestType8 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 8);
		}
	};
	exports.RequestType8 = RequestType8;
	var RequestType9 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 9);
		}
	};
	exports.RequestType9 = RequestType9;
	var NotificationType = class extends AbstractMessageSignature {
		_parameterStructures;
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method, _parameterStructures = ParameterStructures.auto) {
			super(method, 1);
			this._parameterStructures = _parameterStructures;
		}
		get parameterStructures() {
			return this._parameterStructures;
		}
	};
	exports.NotificationType = NotificationType;
	var NotificationType0 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 0);
		}
	};
	exports.NotificationType0 = NotificationType0;
	var NotificationType1 = class extends AbstractMessageSignature {
		_parameterStructures;
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method, _parameterStructures = ParameterStructures.auto) {
			super(method, 1);
			this._parameterStructures = _parameterStructures;
		}
		get parameterStructures() {
			return this._parameterStructures;
		}
	};
	exports.NotificationType1 = NotificationType1;
	var NotificationType2 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 2);
		}
	};
	exports.NotificationType2 = NotificationType2;
	var NotificationType3 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 3);
		}
	};
	exports.NotificationType3 = NotificationType3;
	var NotificationType4 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 4);
		}
	};
	exports.NotificationType4 = NotificationType4;
	var NotificationType5 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 5);
		}
	};
	exports.NotificationType5 = NotificationType5;
	var NotificationType6 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 6);
		}
	};
	exports.NotificationType6 = NotificationType6;
	var NotificationType7 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 7);
		}
	};
	exports.NotificationType7 = NotificationType7;
	var NotificationType8 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 8);
		}
	};
	exports.NotificationType8 = NotificationType8;
	var NotificationType9 = class extends AbstractMessageSignature {
		/**
		* Clients must not use this property. It is here to ensure correct typing.
		*/
		_;
		constructor(method) {
			super(method, 9);
		}
	};
	exports.NotificationType9 = NotificationType9;
	var Message;
	(function(Message) {
		/**
		* Tests if the given message is a request message
		*/
		function isRequest(message) {
			const candidate = message;
			return candidate && is.string(candidate.method) && (is.string(candidate.id) || is.number(candidate.id));
		}
		Message.isRequest = isRequest;
		/**
		* Tests if the given message is a notification message
		*/
		function isNotification(message) {
			const candidate = message;
			return candidate && is.string(candidate.method) && message.id === void 0;
		}
		Message.isNotification = isNotification;
		/**
		* Tests if the given message is a response message
		*/
		function isResponse(message) {
			const candidate = message;
			return candidate && (candidate.result !== void 0 || !!candidate.error) && (is.string(candidate.id) || is.number(candidate.id) || candidate.id === null);
		}
		Message.isResponse = isResponse;
	})(Message || (exports.Message = Message = {}));
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/linkedMap.js
var require_linkedMap = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.LRUCache = exports.LinkedMap = exports.Touch = void 0;
	var Touch;
	(function(Touch) {
		Touch.None = 0;
		Touch.First = 1;
		Touch.AsOld = Touch.First;
		Touch.Last = 2;
		Touch.AsNew = Touch.Last;
	})(Touch || (exports.Touch = Touch = {}));
	var LinkedMap = class {
		[Symbol.toStringTag] = "LinkedMap";
		_map;
		_head;
		_tail;
		_size;
		_state;
		constructor() {
			this._map = /* @__PURE__ */ new Map();
			this._head = void 0;
			this._tail = void 0;
			this._size = 0;
			this._state = 0;
		}
		clear() {
			this._map.clear();
			this._head = void 0;
			this._tail = void 0;
			this._size = 0;
			this._state++;
		}
		isEmpty() {
			return !this._head && !this._tail;
		}
		get size() {
			return this._size;
		}
		get first() {
			return this._head?.value;
		}
		get last() {
			return this._tail?.value;
		}
		before(key) {
			const item = this._map.get(key);
			return item ? item.previous?.value : void 0;
		}
		after(key) {
			const item = this._map.get(key);
			return item ? item.next?.value : void 0;
		}
		has(key) {
			return this._map.has(key);
		}
		get(key, touch = Touch.None) {
			const item = this._map.get(key);
			if (!item) return;
			if (touch !== Touch.None) this.touch(item, touch);
			return item.value;
		}
		set(key, value, touch = Touch.None) {
			let item = this._map.get(key);
			if (item) {
				item.value = value;
				if (touch !== Touch.None) this.touch(item, touch);
			} else {
				item = {
					key,
					value,
					next: void 0,
					previous: void 0
				};
				switch (touch) {
					case Touch.None:
						this.addItemLast(item);
						break;
					case Touch.First:
						this.addItemFirst(item);
						break;
					case Touch.Last:
						this.addItemLast(item);
						break;
					default: this.addItemLast(item);
				}
				this._map.set(key, item);
				this._size++;
			}
			return this;
		}
		delete(key) {
			return !!this.remove(key);
		}
		remove(key) {
			const item = this._map.get(key);
			if (!item) return;
			this._map.delete(key);
			this.removeItem(item);
			this._size--;
			return item.value;
		}
		shift() {
			if (!this._head && !this._tail) return;
			if (!this._head || !this._tail) throw new Error("Invalid list");
			const item = this._head;
			this._map.delete(item.key);
			this.removeItem(item);
			this._size--;
			return item.value;
		}
		forEach(callbackfn, thisArg) {
			const state = this._state;
			let current = this._head;
			while (current) {
				if (thisArg) callbackfn.bind(thisArg)(current.value, current.key, this);
				else callbackfn(current.value, current.key, this);
				if (this._state !== state) throw new Error(`LinkedMap got modified during iteration.`);
				current = current.next;
			}
		}
		keys() {
			const state = this._state;
			let current = this._head;
			const iterator = {
				[Symbol.iterator]: () => {
					return iterator;
				},
				next: () => {
					if (this._state !== state) throw new Error(`LinkedMap got modified during iteration.`);
					if (current) {
						const result = {
							value: current.key,
							done: false
						};
						current = current.next;
						return result;
					} else return {
						value: void 0,
						done: true
					};
				}
			};
			return iterator;
		}
		values() {
			const state = this._state;
			let current = this._head;
			const iterator = {
				[Symbol.iterator]: () => {
					return iterator;
				},
				next: () => {
					if (this._state !== state) throw new Error(`LinkedMap got modified during iteration.`);
					if (current) {
						const result = {
							value: current.value,
							done: false
						};
						current = current.next;
						return result;
					} else return {
						value: void 0,
						done: true
					};
				}
			};
			return iterator;
		}
		entries() {
			const state = this._state;
			let current = this._head;
			const iterator = {
				[Symbol.iterator]: () => {
					return iterator;
				},
				next: () => {
					if (this._state !== state) throw new Error(`LinkedMap got modified during iteration.`);
					if (current) {
						const result = {
							value: [current.key, current.value],
							done: false
						};
						current = current.next;
						return result;
					} else return {
						value: void 0,
						done: true
					};
				}
			};
			return iterator;
		}
		[Symbol.iterator]() {
			return this.entries();
		}
		trimOld(newSize) {
			if (newSize >= this.size) return;
			if (newSize === 0) {
				this.clear();
				return;
			}
			let current = this._head;
			let currentSize = this.size;
			while (current && currentSize > newSize) {
				this._map.delete(current.key);
				current = current.next;
				currentSize--;
			}
			this._head = current;
			this._size = currentSize;
			if (current) current.previous = void 0;
			this._state++;
		}
		addItemFirst(item) {
			if (!this._head && !this._tail) this._tail = item;
			else if (!this._head) throw new Error("Invalid list");
			else {
				item.next = this._head;
				this._head.previous = item;
			}
			this._head = item;
			this._state++;
		}
		addItemLast(item) {
			if (!this._head && !this._tail) this._head = item;
			else if (!this._tail) throw new Error("Invalid list");
			else {
				item.previous = this._tail;
				this._tail.next = item;
			}
			this._tail = item;
			this._state++;
		}
		removeItem(item) {
			if (item === this._head && item === this._tail) {
				this._head = void 0;
				this._tail = void 0;
			} else if (item === this._head) {
				if (!item.next) throw new Error("Invalid list");
				item.next.previous = void 0;
				this._head = item.next;
			} else if (item === this._tail) {
				if (!item.previous) throw new Error("Invalid list");
				item.previous.next = void 0;
				this._tail = item.previous;
			} else {
				const next = item.next;
				const previous = item.previous;
				if (!next || !previous) throw new Error("Invalid list");
				next.previous = previous;
				previous.next = next;
			}
			item.next = void 0;
			item.previous = void 0;
			this._state++;
		}
		touch(item, touch) {
			if (!this._head || !this._tail) throw new Error("Invalid list");
			if (touch !== Touch.First && touch !== Touch.Last) return;
			if (touch === Touch.First) {
				if (item === this._head) return;
				const next = item.next;
				const previous = item.previous;
				if (item === this._tail) {
					previous.next = void 0;
					this._tail = previous;
				} else {
					next.previous = previous;
					previous.next = next;
				}
				item.previous = void 0;
				item.next = this._head;
				this._head.previous = item;
				this._head = item;
				this._state++;
			} else if (touch === Touch.Last) {
				if (item === this._tail) return;
				const next = item.next;
				const previous = item.previous;
				if (item === this._head) {
					next.previous = void 0;
					this._head = next;
				} else {
					next.previous = previous;
					previous.next = next;
				}
				item.next = void 0;
				item.previous = this._tail;
				this._tail.next = item;
				this._tail = item;
				this._state++;
			}
		}
		toJSON() {
			const data = [];
			this.forEach((value, key) => {
				data.push([key, value]);
			});
			return data;
		}
		fromJSON(data) {
			this.clear();
			for (const [key, value] of data) this.set(key, value);
		}
	};
	exports.LinkedMap = LinkedMap;
	var LRUCache = class extends LinkedMap {
		_limit;
		_ratio;
		constructor(limit, ratio = 1) {
			super();
			this._limit = limit;
			this._ratio = Math.min(Math.max(0, ratio), 1);
		}
		get limit() {
			return this._limit;
		}
		set limit(limit) {
			this._limit = limit;
			this.checkTrim();
		}
		get ratio() {
			return this._ratio;
		}
		set ratio(ratio) {
			this._ratio = Math.min(Math.max(0, ratio), 1);
			this.checkTrim();
		}
		get(key, touch = Touch.AsNew) {
			return super.get(key, touch);
		}
		peek(key) {
			return super.get(key, Touch.None);
		}
		set(key, value) {
			super.set(key, value, Touch.Last);
			this.checkTrim();
			return this;
		}
		checkTrim() {
			if (this.size > this._limit) this.trimOld(Math.round(this._limit * this._ratio));
		}
	};
	exports.LRUCache = LRUCache;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/disposable.js
var require_disposable = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Disposable = void 0;
	var Disposable;
	(function(Disposable) {
		function create(func) {
			return { dispose: func };
		}
		Disposable.create = create;
	})(Disposable || (exports.Disposable = Disposable = {}));
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/ral.js
var require_ral = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var _ral;
	function RAL() {
		if (_ral === void 0) throw new Error(`No runtime abstraction layer installed`);
		return _ral;
	}
	(function(RAL) {
		function install(ral) {
			if (ral === void 0) throw new Error(`No runtime abstraction layer provided`);
			_ral = ral;
		}
		RAL.install = install;
	})(RAL || (RAL = {}));
	exports.default = RAL;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/events.js
var require_events = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Emitter = exports.Event = void 0;
	var ral_1 = __importDefault(require_ral());
	var Event;
	(function(Event) {
		const _disposable = { dispose() {} };
		Event.None = function() {
			return _disposable;
		};
	})(Event || (exports.Event = Event = {}));
	var CallbackList = class {
		_callbacks;
		_contexts;
		add(callback, context = null, bucket) {
			if (!this._callbacks) {
				this._callbacks = [];
				this._contexts = [];
			}
			this._callbacks.push(callback);
			this._contexts.push(context);
			if (Array.isArray(bucket)) bucket.push({ dispose: () => this.remove(callback, context) });
		}
		remove(callback, context = null) {
			if (!this._callbacks) return;
			let foundCallbackWithDifferentContext = false;
			for (let i = 0, len = this._callbacks.length; i < len; i++) if (this._callbacks[i] === callback) {
				if (this._contexts[i] === context) {
					this._callbacks.splice(i, 1);
					this._contexts.splice(i, 1);
					return;
				} else foundCallbackWithDifferentContext = true;
			}
			if (foundCallbackWithDifferentContext) throw new Error("When adding a listener with a context, you should remove it with the same context");
		}
		invoke(...args) {
			if (!this._callbacks) return [];
			const ret = [], callbacks = this._callbacks.slice(0), contexts = this._contexts.slice(0);
			for (let i = 0, len = callbacks.length; i < len; i++) try {
				ret.push(callbacks[i].apply(contexts[i], args));
			} catch (e) {
				(0, ral_1.default)().console.error(e);
			}
			return ret;
		}
		isEmpty() {
			return !this._callbacks || this._callbacks.length === 0;
		}
		dispose() {
			this._callbacks = void 0;
			this._contexts = void 0;
		}
	};
	exports.Emitter = class Emitter {
		_options;
		static _noop = function() {};
		_event;
		_callbacks;
		constructor(_options) {
			this._options = _options;
		}
		/**
		* For the public to allow to subscribe
		* to events from this Emitter
		*/
		get event() {
			if (!this._event) this._event = (listener, thisArgs, disposables) => {
				if (!this._callbacks) this._callbacks = new CallbackList();
				if (this._options && this._options.onFirstListenerAdd && this._callbacks.isEmpty()) this._options.onFirstListenerAdd(this);
				this._callbacks.add(listener, thisArgs);
				const result = { dispose: () => {
					if (!this._callbacks) return;
					this._callbacks.remove(listener, thisArgs);
					result.dispose = Emitter._noop;
					if (this._options && this._options.onLastListenerRemove && this._callbacks.isEmpty()) this._options.onLastListenerRemove(this);
				} };
				if (Array.isArray(disposables)) disposables.push(result);
				return result;
			};
			return this._event;
		}
		/**
		* To be kept private to fire an event to
		* subscribers
		*/
		fire(event) {
			if (this._callbacks) this._callbacks.invoke.call(this._callbacks, event);
		}
		dispose() {
			if (this._callbacks) {
				this._callbacks.dispose();
				this._callbacks = void 0;
			}
		}
	};
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/cancellation.js
var require_cancellation = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || (function() {
		var ownKeys = function(o) {
			ownKeys = Object.getOwnPropertyNames || function(o) {
				var ar = [];
				for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
				return ar;
			};
			return ownKeys(o);
		};
		return function(mod) {
			if (mod && mod.__esModule) return mod;
			var result = {};
			if (mod != null) {
				for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
			}
			__setModuleDefault(result, mod);
			return result;
		};
	})();
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.CancellationTokenSource = exports.CancellationToken = void 0;
	var ral_1 = __importDefault(require_ral());
	var Is = __importStar(require_is());
	var events_1 = require_events();
	var CancellationToken;
	(function(CancellationToken) {
		CancellationToken.None = Object.freeze({
			isCancellationRequested: false,
			onCancellationRequested: events_1.Event.None
		});
		CancellationToken.Cancelled = Object.freeze({
			isCancellationRequested: true,
			onCancellationRequested: events_1.Event.None
		});
		function is(value) {
			const candidate = value;
			return candidate && (candidate === CancellationToken.None || candidate === CancellationToken.Cancelled || Is.boolean(candidate.isCancellationRequested) && !!candidate.onCancellationRequested);
		}
		CancellationToken.is = is;
	})(CancellationToken || (exports.CancellationToken = CancellationToken = {}));
	var shortcutEvent = Object.freeze(function(callback, context) {
		const handle = (0, ral_1.default)().timer.setTimeout(callback.bind(context), 0);
		return { dispose() {
			handle.dispose();
		} };
	});
	var MutableToken = class {
		_isCancelled = false;
		_emitter;
		cancel() {
			if (!this._isCancelled) {
				this._isCancelled = true;
				if (this._emitter) {
					this._emitter.fire(void 0);
					this.dispose();
				}
			}
		}
		get isCancellationRequested() {
			return this._isCancelled;
		}
		get onCancellationRequested() {
			if (this._isCancelled) return shortcutEvent;
			if (!this._emitter) this._emitter = new events_1.Emitter();
			return this._emitter.event;
		}
		dispose() {
			if (this._emitter) {
				this._emitter.dispose();
				this._emitter = void 0;
			}
		}
	};
	var CancellationTokenSource = class {
		_token;
		get token() {
			if (!this._token) this._token = new MutableToken();
			return this._token;
		}
		cancel() {
			if (!this._token) this._token = CancellationToken.Cancelled;
			else this._token.cancel();
		}
		dispose() {
			if (!this._token) this._token = CancellationToken.None;
			else if (this._token instanceof MutableToken) this._token.dispose();
		}
	};
	exports.CancellationTokenSource = CancellationTokenSource;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/sharedArrayCancellation.js
var require_sharedArrayCancellation = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.SharedArrayReceiverStrategy = exports.SharedArraySenderStrategy = void 0;
	var cancellation_1 = require_cancellation();
	var CancellationState;
	(function(CancellationState) {
		CancellationState.Continue = 0;
		CancellationState.Cancelled = 1;
	})(CancellationState || (CancellationState = {}));
	var SharedArraySenderStrategy = class {
		buffers;
		constructor() {
			this.buffers = /* @__PURE__ */ new Map();
		}
		enableCancellation(request) {
			if (request.id === null) return;
			const buffer = new SharedArrayBuffer(4);
			const data = new Int32Array(buffer, 0, 1);
			data[0] = CancellationState.Continue;
			this.buffers.set(request.id, buffer);
			request.$cancellationData = buffer;
		}
		async sendCancellation(_conn, id) {
			const buffer = this.buffers.get(id);
			if (buffer === void 0) return;
			const data = new Int32Array(buffer, 0, 1);
			Atomics.store(data, 0, CancellationState.Cancelled);
		}
		cleanup(id) {
			this.buffers.delete(id);
		}
		dispose() {
			this.buffers.clear();
		}
	};
	exports.SharedArraySenderStrategy = SharedArraySenderStrategy;
	var SharedArrayBufferCancellationToken = class {
		data;
		constructor(buffer) {
			this.data = new Int32Array(buffer, 0, 1);
		}
		get isCancellationRequested() {
			return Atomics.load(this.data, 0) === CancellationState.Cancelled;
		}
		get onCancellationRequested() {
			throw new Error(`Cancellation over SharedArrayBuffer doesn't support cancellation events`);
		}
	};
	var SharedArrayBufferCancellationTokenSource = class {
		token;
		constructor(buffer) {
			this.token = new SharedArrayBufferCancellationToken(buffer);
		}
		cancel() {}
		dispose() {}
	};
	var SharedArrayReceiverStrategy = class {
		kind = "request";
		createCancellationTokenSource(request) {
			const buffer = request.$cancellationData;
			if (buffer === void 0) return new cancellation_1.CancellationTokenSource();
			return new SharedArrayBufferCancellationTokenSource(buffer);
		}
	};
	exports.SharedArrayReceiverStrategy = SharedArrayReceiverStrategy;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/semaphore.js
var require_semaphore = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.Semaphore = void 0;
	var ral_1 = __importDefault(require_ral());
	var Semaphore = class {
		_capacity;
		_active;
		_waiting;
		constructor(capacity = 1) {
			if (capacity <= 0) throw new Error("Capacity must be greater than 0");
			this._capacity = capacity;
			this._active = 0;
			this._waiting = [];
		}
		lock(thunk) {
			return new Promise((resolve, reject) => {
				this._waiting.push({
					thunk,
					resolve,
					reject
				});
				this.runNext();
			});
		}
		get active() {
			return this._active;
		}
		runNext() {
			if (this._waiting.length === 0 || this._active === this._capacity) return;
			(0, ral_1.default)().timer.setImmediate(() => this.doRunNext());
		}
		doRunNext() {
			if (this._waiting.length === 0 || this._active === this._capacity) return;
			const next = this._waiting.shift();
			this._active++;
			if (this._active > this._capacity) throw new Error(`Too many thunks active`);
			try {
				const result = next.thunk();
				if (result instanceof Promise) result.then((value) => {
					this._active--;
					next.resolve(value);
					this.runNext();
				}, (err) => {
					this._active--;
					next.reject(err);
					this.runNext();
				});
				else {
					this._active--;
					next.resolve(result);
					this.runNext();
				}
			} catch (err) {
				this._active--;
				next.reject(err);
				this.runNext();
			}
		}
	};
	exports.Semaphore = Semaphore;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/messageReader.js
var require_messageReader = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || (function() {
		var ownKeys = function(o) {
			ownKeys = Object.getOwnPropertyNames || function(o) {
				var ar = [];
				for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
				return ar;
			};
			return ownKeys(o);
		};
		return function(mod) {
			if (mod && mod.__esModule) return mod;
			var result = {};
			if (mod != null) {
				for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
			}
			__setModuleDefault(result, mod);
			return result;
		};
	})();
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ReadableStreamMessageReader = exports.AbstractMessageReader = exports.MessageReader = void 0;
	var ral_1 = __importDefault(require_ral());
	var Is = __importStar(require_is());
	var events_1 = require_events();
	var semaphore_1 = require_semaphore();
	var MessageReader;
	(function(MessageReader) {
		function is(value) {
			const candidate = value;
			return candidate && Is.func(candidate.listen) && Is.func(candidate.dispose) && Is.func(candidate.onError) && Is.func(candidate.onClose) && Is.func(candidate.onPartialMessage);
		}
		MessageReader.is = is;
	})(MessageReader || (exports.MessageReader = MessageReader = {}));
	var AbstractMessageReader = class {
		errorEmitter;
		closeEmitter;
		partialMessageEmitter;
		constructor() {
			this.errorEmitter = new events_1.Emitter();
			this.closeEmitter = new events_1.Emitter();
			this.partialMessageEmitter = new events_1.Emitter();
		}
		dispose() {
			this.errorEmitter.dispose();
			this.closeEmitter.dispose();
			this.partialMessageEmitter.dispose();
		}
		get onError() {
			return this.errorEmitter.event;
		}
		fireError(error) {
			this.errorEmitter.fire(this.asError(error));
		}
		get onClose() {
			return this.closeEmitter.event;
		}
		fireClose() {
			this.closeEmitter.fire(void 0);
		}
		get onPartialMessage() {
			return this.partialMessageEmitter.event;
		}
		firePartialMessage(info) {
			this.partialMessageEmitter.fire(info);
		}
		asError(error) {
			if (error instanceof Error) return error;
			else return /* @__PURE__ */ new Error(`Reader received error. Reason: ${Is.string(error.message) ? error.message : "unknown"}`);
		}
	};
	exports.AbstractMessageReader = AbstractMessageReader;
	var ResolvedMessageReaderOptions;
	(function(ResolvedMessageReaderOptions) {
		function fromOptions(options) {
			let charset;
			let contentDecoder;
			const contentDecoders = /* @__PURE__ */ new Map();
			let contentTypeDecoder;
			const contentTypeDecoders = /* @__PURE__ */ new Map();
			if (options === void 0 || typeof options === "string") charset = options ?? "utf-8";
			else {
				charset = options.charset ?? "utf-8";
				if (options.contentDecoder !== void 0) {
					contentDecoder = options.contentDecoder;
					contentDecoders.set(contentDecoder.name, contentDecoder);
				}
				if (options.contentDecoders !== void 0) for (const decoder of options.contentDecoders) contentDecoders.set(decoder.name, decoder);
				if (options.contentTypeDecoder !== void 0) {
					contentTypeDecoder = options.contentTypeDecoder;
					contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
				}
				if (options.contentTypeDecoders !== void 0) for (const decoder of options.contentTypeDecoders) contentTypeDecoders.set(decoder.name, decoder);
			}
			if (contentTypeDecoder === void 0) {
				contentTypeDecoder = (0, ral_1.default)().applicationJson.decoder;
				contentTypeDecoders.set(contentTypeDecoder.name, contentTypeDecoder);
			}
			return {
				charset,
				contentDecoder,
				contentDecoders,
				contentTypeDecoder,
				contentTypeDecoders
			};
		}
		ResolvedMessageReaderOptions.fromOptions = fromOptions;
	})(ResolvedMessageReaderOptions || (ResolvedMessageReaderOptions = {}));
	var ReadableStreamMessageReader = class extends AbstractMessageReader {
		readable;
		options;
		callback;
		nextMessageLength;
		messageToken;
		buffer;
		partialMessageTimer;
		_partialMessageTimeout;
		readSemaphore;
		constructor(readable, options) {
			super();
			this.readable = readable;
			this.options = ResolvedMessageReaderOptions.fromOptions(options);
			this.buffer = (0, ral_1.default)().messageBuffer.create(this.options.charset);
			this._partialMessageTimeout = 1e4;
			this.nextMessageLength = -1;
			this.messageToken = 0;
			this.readSemaphore = new semaphore_1.Semaphore(1);
		}
		set partialMessageTimeout(timeout) {
			this._partialMessageTimeout = timeout;
		}
		get partialMessageTimeout() {
			return this._partialMessageTimeout;
		}
		listen(callback) {
			this.nextMessageLength = -1;
			this.messageToken = 0;
			this.partialMessageTimer = void 0;
			this.callback = callback;
			const result = this.readable.onData((data) => {
				this.onData(data);
			});
			this.readable.onError((error) => this.fireError(error));
			this.readable.onClose(() => this.fireClose());
			return result;
		}
		onData(data) {
			try {
				this.buffer.append(data);
				while (true) {
					if (this.nextMessageLength === -1) {
						const headers = this.buffer.tryReadHeaders(true);
						if (!headers) return;
						const contentLength = headers.get("content-length");
						if (!contentLength) {
							this.fireError(/* @__PURE__ */ new Error(`Header must provide a Content-Length property.\n${JSON.stringify(Object.fromEntries(headers))}`));
							return;
						}
						const length = parseInt(contentLength);
						if (isNaN(length)) {
							this.fireError(/* @__PURE__ */ new Error(`Content-Length value must be a number. Got ${contentLength}`));
							return;
						}
						this.nextMessageLength = length;
					}
					const body = this.buffer.tryReadBody(this.nextMessageLength);
					if (body === void 0) {
						/** We haven't received the full message yet. */
						this.setPartialMessageTimer();
						return;
					}
					this.clearPartialMessageTimer();
					this.nextMessageLength = -1;
					this.readSemaphore.lock(async () => {
						const bytes = this.options.contentDecoder !== void 0 ? await this.options.contentDecoder.decode(body) : body;
						const message = await this.options.contentTypeDecoder.decode(bytes, this.options);
						this.callback(message);
					}).catch((error) => {
						this.fireError(error);
					});
				}
			} catch (error) {
				this.fireError(error);
			}
		}
		clearPartialMessageTimer() {
			if (this.partialMessageTimer) {
				this.partialMessageTimer.dispose();
				this.partialMessageTimer = void 0;
			}
		}
		setPartialMessageTimer() {
			this.clearPartialMessageTimer();
			if (this._partialMessageTimeout <= 0) return;
			this.partialMessageTimer = (0, ral_1.default)().timer.setTimeout((token, timeout) => {
				this.partialMessageTimer = void 0;
				if (token === this.messageToken) {
					this.firePartialMessage({
						messageToken: token,
						waitingTime: timeout
					});
					this.setPartialMessageTimer();
				}
			}, this._partialMessageTimeout, this.messageToken, this._partialMessageTimeout);
		}
	};
	exports.ReadableStreamMessageReader = ReadableStreamMessageReader;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/messageWriter.js
var require_messageWriter = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || (function() {
		var ownKeys = function(o) {
			ownKeys = Object.getOwnPropertyNames || function(o) {
				var ar = [];
				for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
				return ar;
			};
			return ownKeys(o);
		};
		return function(mod) {
			if (mod && mod.__esModule) return mod;
			var result = {};
			if (mod != null) {
				for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
			}
			__setModuleDefault(result, mod);
			return result;
		};
	})();
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.WriteableStreamMessageWriter = exports.AbstractMessageWriter = exports.MessageWriter = void 0;
	var ral_1 = __importDefault(require_ral());
	var Is = __importStar(require_is());
	var semaphore_1 = require_semaphore();
	var events_1 = require_events();
	var ContentLength = "Content-Length: ";
	var CRLF = "\r\n";
	var MessageWriter;
	(function(MessageWriter) {
		function is(value) {
			const candidate = value;
			return candidate && Is.func(candidate.dispose) && Is.func(candidate.onClose) && Is.func(candidate.onError) && Is.func(candidate.write);
		}
		MessageWriter.is = is;
	})(MessageWriter || (exports.MessageWriter = MessageWriter = {}));
	var AbstractMessageWriter = class {
		errorEmitter;
		closeEmitter;
		constructor() {
			this.errorEmitter = new events_1.Emitter();
			this.closeEmitter = new events_1.Emitter();
		}
		dispose() {
			this.errorEmitter.dispose();
			this.closeEmitter.dispose();
		}
		get onError() {
			return this.errorEmitter.event;
		}
		fireError(error, message, count) {
			this.errorEmitter.fire([
				this.asError(error),
				message,
				count
			]);
		}
		get onClose() {
			return this.closeEmitter.event;
		}
		fireClose() {
			this.closeEmitter.fire(void 0);
		}
		asError(error) {
			if (error instanceof Error) return error;
			else return /* @__PURE__ */ new Error(`Writer received error. Reason: ${Is.string(error.message) ? error.message : "unknown"}`);
		}
	};
	exports.AbstractMessageWriter = AbstractMessageWriter;
	var ResolvedMessageWriterOptions;
	(function(ResolvedMessageWriterOptions) {
		function fromOptions(options) {
			if (options === void 0 || typeof options === "string") return {
				charset: options ?? "utf-8",
				contentTypeEncoder: (0, ral_1.default)().applicationJson.encoder
			};
			else return {
				charset: options.charset ?? "utf-8",
				contentEncoder: options.contentEncoder,
				contentTypeEncoder: options.contentTypeEncoder ?? (0, ral_1.default)().applicationJson.encoder
			};
		}
		ResolvedMessageWriterOptions.fromOptions = fromOptions;
	})(ResolvedMessageWriterOptions || (ResolvedMessageWriterOptions = {}));
	var WriteableStreamMessageWriter = class extends AbstractMessageWriter {
		writable;
		options;
		errorCount;
		writeSemaphore;
		constructor(writable, options) {
			super();
			this.writable = writable;
			this.options = ResolvedMessageWriterOptions.fromOptions(options);
			this.errorCount = 0;
			this.writeSemaphore = new semaphore_1.Semaphore(1);
			this.writable.onError((error) => this.fireError(error));
			this.writable.onClose(() => this.fireClose());
		}
		async write(msg) {
			return this.writeSemaphore.lock(async () => {
				return this.options.contentTypeEncoder.encode(msg, this.options).then((buffer) => {
					if (this.options.contentEncoder !== void 0) return this.options.contentEncoder.encode(buffer);
					else return buffer;
				}).then((buffer) => {
					const headers = [];
					headers.push(ContentLength, buffer.byteLength.toString(), CRLF);
					headers.push(CRLF);
					return this.doWrite(msg, headers, buffer);
				}, (error) => {
					this.fireError(error);
					throw error;
				});
			});
		}
		async doWrite(msg, headers, data) {
			try {
				await this.writable.write(headers.join(""), "ascii");
				return this.writable.write(data);
			} catch (error) {
				this.handleError(error, msg);
				return Promise.reject(error);
			}
		}
		handleError(error, msg) {
			this.errorCount++;
			this.fireError(error, msg, this.errorCount);
		}
		end() {
			this.writable.end();
		}
	};
	exports.WriteableStreamMessageWriter = WriteableStreamMessageWriter;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/messageBuffer.js
var require_messageBuffer = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.AbstractMessageBuffer = void 0;
	var CR = 13;
	var LF = 10;
	var CRLF = "\r\n";
	var AbstractMessageBuffer = class {
		_encoding;
		_chunks;
		_totalLength;
		constructor(encoding = "utf-8") {
			this._encoding = encoding;
			this._chunks = [];
			this._totalLength = 0;
		}
		get encoding() {
			return this._encoding;
		}
		append(chunk) {
			const toAppend = typeof chunk === "string" ? this.fromString(chunk, this._encoding) : chunk;
			this._chunks.push(toAppend);
			this._totalLength += toAppend.byteLength;
		}
		tryReadHeaders(lowerCaseKeys = false) {
			if (this._chunks.length === 0) return;
			let state = 0;
			let chunkIndex = 0;
			let offset = 0;
			let chunkBytesRead = 0;
			row: while (chunkIndex < this._chunks.length) {
				const chunk = this._chunks[chunkIndex];
				offset = 0;
				while (offset < chunk.length) {
					switch (chunk[offset]) {
						case CR:
							switch (state) {
								case 0:
									state = 1;
									break;
								case 2:
									state = 3;
									break;
								default: state = 0;
							}
							break;
						case LF:
							switch (state) {
								case 1:
									state = 2;
									break;
								case 3:
									state = 4;
									offset++;
									break row;
								default: state = 0;
							}
							break;
						default: state = 0;
					}
					offset++;
				}
				chunkBytesRead += chunk.byteLength;
				chunkIndex++;
			}
			if (state !== 4) return;
			const buffer = this._read(chunkBytesRead + offset);
			const result = /* @__PURE__ */ new Map();
			const headers = this.toString(buffer, "ascii").split(CRLF);
			if (headers.length < 2) return result;
			for (let i = 0; i < headers.length - 2; i++) {
				const header = headers[i];
				const index = header.indexOf(":");
				if (index === -1) throw new Error(`Message header must separate key and value using ':'\n${header}`);
				const key = header.substr(0, index);
				const value = header.substr(index + 1).trim();
				result.set(lowerCaseKeys ? key.toLowerCase() : key, value);
			}
			return result;
		}
		tryReadBody(length) {
			if (this._totalLength < length) return;
			return this._read(length);
		}
		get numberOfBytes() {
			return this._totalLength;
		}
		_read(byteCount) {
			if (byteCount === 0) return this.emptyBuffer();
			if (byteCount > this._totalLength) throw new Error(`Cannot read so many bytes!`);
			if (this._chunks[0].byteLength === byteCount) {
				const chunk = this._chunks[0];
				this._chunks.shift();
				this._totalLength -= byteCount;
				return this.asNative(chunk);
			}
			if (this._chunks[0].byteLength > byteCount) {
				const chunk = this._chunks[0];
				const result = this.asNative(chunk, byteCount);
				this._chunks[0] = chunk.slice(byteCount);
				this._totalLength -= byteCount;
				return result;
			}
			const result = this.allocNative(byteCount);
			let resultOffset = 0;
			const chunkIndex = 0;
			while (byteCount > 0) {
				const chunk = this._chunks[chunkIndex];
				if (chunk.byteLength > byteCount) {
					const chunkPart = chunk.slice(0, byteCount);
					result.set(chunkPart, resultOffset);
					resultOffset += byteCount;
					this._chunks[chunkIndex] = chunk.slice(byteCount);
					this._totalLength -= byteCount;
					byteCount -= byteCount;
				} else {
					result.set(chunk, resultOffset);
					resultOffset += chunk.byteLength;
					this._chunks.shift();
					this._totalLength -= chunk.byteLength;
					byteCount -= chunk.byteLength;
				}
			}
			return result;
		}
	};
	exports.AbstractMessageBuffer = AbstractMessageBuffer;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/connection.js
var require_connection = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __setModuleDefault = exports && exports.__setModuleDefault || (Object.create ? (function(o, v) {
		Object.defineProperty(o, "default", {
			enumerable: true,
			value: v
		});
	}) : function(o, v) {
		o["default"] = v;
	});
	var __importStar = exports && exports.__importStar || (function() {
		var ownKeys = function(o) {
			ownKeys = Object.getOwnPropertyNames || function(o) {
				var ar = [];
				for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
				return ar;
			};
			return ownKeys(o);
		};
		return function(mod) {
			if (mod && mod.__esModule) return mod;
			var result = {};
			if (mod != null) {
				for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
			}
			__setModuleDefault(result, mod);
			return result;
		};
	})();
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ConnectionOptions = exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.CancellationReceiverStrategy = exports.RequestCancellationReceiverStrategy = exports.IdCancellationReceiverStrategy = exports.ConnectionStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.TraceValue = exports.Trace = exports.NullLogger = exports.ProgressType = exports.ProgressToken = void 0;
	exports.createMessageConnection = createMessageConnection;
	var ral_1 = __importDefault(require_ral());
	var Is = __importStar(require_is());
	var messages_1 = require_messages();
	var linkedMap_1 = require_linkedMap();
	var events_1 = require_events();
	var cancellation_1 = require_cancellation();
	var CancelNotification;
	(function(CancelNotification) {
		CancelNotification.type = new messages_1.NotificationType("$/cancelRequest");
	})(CancelNotification || (CancelNotification = {}));
	var ProgressToken;
	(function(ProgressToken) {
		function is(value) {
			return typeof value === "string" || typeof value === "number";
		}
		ProgressToken.is = is;
	})(ProgressToken || (exports.ProgressToken = ProgressToken = {}));
	var ProgressNotification;
	(function(ProgressNotification) {
		ProgressNotification.type = new messages_1.NotificationType("$/progress");
	})(ProgressNotification || (ProgressNotification = {}));
	var ProgressType = class {
		/**
		* Clients must not use these properties. They are here to ensure correct typing.
		* in TypeScript
		*/
		__;
		_pr;
		constructor() {}
	};
	exports.ProgressType = ProgressType;
	var StarRequestHandler;
	(function(StarRequestHandler) {
		function is(value) {
			return Is.func(value);
		}
		StarRequestHandler.is = is;
	})(StarRequestHandler || (StarRequestHandler = {}));
	exports.NullLogger = Object.freeze({
		error: () => {},
		warn: () => {},
		info: () => {},
		log: () => {}
	});
	var Trace;
	(function(Trace) {
		Trace[Trace["Off"] = 0] = "Off";
		Trace[Trace["Messages"] = 1] = "Messages";
		Trace[Trace["Compact"] = 2] = "Compact";
		Trace[Trace["Verbose"] = 3] = "Verbose";
	})(Trace || (exports.Trace = Trace = {}));
	var TraceValue;
	(function(TraceValue) {
		/**
		* Turn tracing off.
		*/
		TraceValue.Off = "off";
		/**
		* Trace messages only.
		*/
		TraceValue.Messages = "messages";
		/**
		* Compact message tracing.
		*/
		TraceValue.Compact = "compact";
		/**
		* Verbose message tracing.
		*/
		TraceValue.Verbose = "verbose";
	})(TraceValue || (exports.TraceValue = TraceValue = {}));
	/**
	* @deprecated Use TraceValue instead
	*/
	exports.TraceValues = TraceValue;
	(function(Trace) {
		function fromString(value) {
			if (!Is.string(value)) return Trace.Off;
			value = value.toLowerCase();
			switch (value) {
				case "off": return Trace.Off;
				case "messages": return Trace.Messages;
				case "compact": return Trace.Compact;
				case "verbose": return Trace.Verbose;
				default: return Trace.Off;
			}
		}
		Trace.fromString = fromString;
		function toString(value) {
			switch (value) {
				case Trace.Off: return "off";
				case Trace.Messages: return "messages";
				case Trace.Compact: return "compact";
				case Trace.Verbose: return "verbose";
				default: return "off";
			}
		}
		Trace.toString = toString;
	})(Trace || (exports.Trace = Trace = {}));
	var TraceFormat;
	(function(TraceFormat) {
		TraceFormat["Text"] = "text";
		TraceFormat["JSON"] = "json";
	})(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
	(function(TraceFormat) {
		function fromString(value) {
			if (!Is.string(value)) return TraceFormat.Text;
			value = value.toLowerCase();
			if (value === "json") return TraceFormat.JSON;
			else return TraceFormat.Text;
		}
		TraceFormat.fromString = fromString;
	})(TraceFormat || (exports.TraceFormat = TraceFormat = {}));
	var SetTraceNotification;
	(function(SetTraceNotification) {
		SetTraceNotification.type = new messages_1.NotificationType("$/setTrace");
	})(SetTraceNotification || (exports.SetTraceNotification = SetTraceNotification = {}));
	var LogTraceNotification;
	(function(LogTraceNotification) {
		LogTraceNotification.type = new messages_1.NotificationType("$/logTrace");
	})(LogTraceNotification || (exports.LogTraceNotification = LogTraceNotification = {}));
	var ConnectionErrors;
	(function(ConnectionErrors) {
		/**
		* The connection is closed.
		*/
		ConnectionErrors[ConnectionErrors["Closed"] = 1] = "Closed";
		/**
		* The connection got disposed.
		*/
		ConnectionErrors[ConnectionErrors["Disposed"] = 2] = "Disposed";
		/**
		* The connection is already in listening mode.
		*/
		ConnectionErrors[ConnectionErrors["AlreadyListening"] = 3] = "AlreadyListening";
	})(ConnectionErrors || (exports.ConnectionErrors = ConnectionErrors = {}));
	var ConnectionError = class ConnectionError extends Error {
		code;
		constructor(code, message) {
			super(message);
			this.code = code;
			Object.setPrototypeOf(this, ConnectionError.prototype);
		}
	};
	exports.ConnectionError = ConnectionError;
	var ConnectionStrategy;
	(function(ConnectionStrategy) {
		function is(value) {
			const candidate = value;
			return candidate && Is.func(candidate.cancelUndispatched);
		}
		ConnectionStrategy.is = is;
	})(ConnectionStrategy || (exports.ConnectionStrategy = ConnectionStrategy = {}));
	var IdCancellationReceiverStrategy;
	(function(IdCancellationReceiverStrategy) {
		function is(value) {
			const candidate = value;
			return candidate && (candidate.kind === void 0 || candidate.kind === "id") && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
		}
		IdCancellationReceiverStrategy.is = is;
	})(IdCancellationReceiverStrategy || (exports.IdCancellationReceiverStrategy = IdCancellationReceiverStrategy = {}));
	var RequestCancellationReceiverStrategy;
	(function(RequestCancellationReceiverStrategy) {
		function is(value) {
			const candidate = value;
			return candidate && candidate.kind === "request" && Is.func(candidate.createCancellationTokenSource) && (candidate.dispose === void 0 || Is.func(candidate.dispose));
		}
		RequestCancellationReceiverStrategy.is = is;
	})(RequestCancellationReceiverStrategy || (exports.RequestCancellationReceiverStrategy = RequestCancellationReceiverStrategy = {}));
	var CancellationReceiverStrategy;
	(function(CancellationReceiverStrategy) {
		CancellationReceiverStrategy.Message = Object.freeze({ createCancellationTokenSource(_) {
			return new cancellation_1.CancellationTokenSource();
		} });
		function is(value) {
			return IdCancellationReceiverStrategy.is(value) || RequestCancellationReceiverStrategy.is(value);
		}
		CancellationReceiverStrategy.is = is;
	})(CancellationReceiverStrategy || (exports.CancellationReceiverStrategy = CancellationReceiverStrategy = {}));
	var CancellationSenderStrategy;
	(function(CancellationSenderStrategy) {
		CancellationSenderStrategy.Message = Object.freeze({
			sendCancellation(conn, id) {
				return conn.sendNotification(CancelNotification.type, { id });
			},
			cleanup(_) {}
		});
		function is(value) {
			const candidate = value;
			return candidate && Is.func(candidate.sendCancellation) && Is.func(candidate.cleanup);
		}
		CancellationSenderStrategy.is = is;
	})(CancellationSenderStrategy || (exports.CancellationSenderStrategy = CancellationSenderStrategy = {}));
	var CancellationStrategy;
	(function(CancellationStrategy) {
		CancellationStrategy.Message = Object.freeze({
			receiver: CancellationReceiverStrategy.Message,
			sender: CancellationSenderStrategy.Message
		});
		function is(value) {
			const candidate = value;
			return candidate && CancellationReceiverStrategy.is(candidate.receiver) && CancellationSenderStrategy.is(candidate.sender);
		}
		CancellationStrategy.is = is;
	})(CancellationStrategy || (exports.CancellationStrategy = CancellationStrategy = {}));
	var MessageStrategy;
	(function(MessageStrategy) {
		function is(value) {
			const candidate = value;
			return candidate && Is.func(candidate.handleMessage);
		}
		MessageStrategy.is = is;
	})(MessageStrategy || (exports.MessageStrategy = MessageStrategy = {}));
	var ConnectionOptions;
	(function(ConnectionOptions) {
		function is(value) {
			const candidate = value;
			return candidate && (CancellationStrategy.is(candidate.cancellationStrategy) || ConnectionStrategy.is(candidate.connectionStrategy) || MessageStrategy.is(candidate.messageStrategy) || Is.number(candidate.maxParallelism));
		}
		ConnectionOptions.is = is;
	})(ConnectionOptions || (exports.ConnectionOptions = ConnectionOptions = {}));
	var ConnectionState;
	(function(ConnectionState) {
		ConnectionState[ConnectionState["New"] = 1] = "New";
		ConnectionState[ConnectionState["Listening"] = 2] = "Listening";
		ConnectionState[ConnectionState["Closed"] = 3] = "Closed";
		ConnectionState[ConnectionState["Disposed"] = 4] = "Disposed";
	})(ConnectionState || (ConnectionState = {}));
	function createMessageConnection(messageReader, messageWriter, _logger, options) {
		const logger = _logger !== void 0 ? _logger : exports.NullLogger;
		let sequenceNumber = 0;
		let notificationSequenceNumber = 0;
		let unknownResponseSequenceNumber = 0;
		const version = "2.0";
		const maxParallelism = options?.maxParallelism ?? -1;
		let inFlight = 0;
		let starRequestHandler = void 0;
		const requestHandlers = /* @__PURE__ */ new Map();
		let starNotificationHandler = void 0;
		const notificationHandlers = /* @__PURE__ */ new Map();
		const progressHandlers = /* @__PURE__ */ new Map();
		let timer;
		let messageQueue = new linkedMap_1.LinkedMap();
		let responsePromises = /* @__PURE__ */ new Map();
		let knownCanceledRequests = /* @__PURE__ */ new Set();
		let requestTokens = /* @__PURE__ */ new Map();
		let trace = Trace.Off;
		let traceFormat = TraceFormat.Text;
		let tracer;
		let state = ConnectionState.New;
		const errorEmitter = new events_1.Emitter();
		const closeEmitter = new events_1.Emitter();
		const unhandledNotificationEmitter = new events_1.Emitter();
		const unhandledProgressEmitter = new events_1.Emitter();
		const disposeEmitter = new events_1.Emitter();
		const cancellationStrategy = options && options.cancellationStrategy ? options.cancellationStrategy : CancellationStrategy.Message;
		function cancelUndispatched(_message) {}
		function isListening() {
			return state === ConnectionState.Listening;
		}
		function isClosed() {
			return state === ConnectionState.Closed;
		}
		function isDisposed() {
			return state === ConnectionState.Disposed;
		}
		function closeHandler() {
			if (state === ConnectionState.New || state === ConnectionState.Listening) {
				state = ConnectionState.Closed;
				closeEmitter.fire(void 0);
			}
		}
		function readErrorHandler(error) {
			errorEmitter.fire([
				error,
				void 0,
				void 0
			]);
		}
		function writeErrorHandler(data) {
			errorEmitter.fire(data);
		}
		messageReader.onClose(closeHandler);
		messageReader.onError(readErrorHandler);
		messageWriter.onClose(closeHandler);
		messageWriter.onError(writeErrorHandler);
		function createRequestQueueKey(id) {
			if (id === null) throw new Error(`Can't send requests with id null since the response can't be correlated.`);
			return "req-" + id.toString();
		}
		function createResponseQueueKey(id) {
			if (id === null) return "res-unknown-" + (++unknownResponseSequenceNumber).toString();
			else return "res-" + id.toString();
		}
		function createNotificationQueueKey() {
			return "not-" + (++notificationSequenceNumber).toString();
		}
		function addMessageToQueue(queue, message) {
			if (messages_1.Message.isRequest(message)) queue.set(createRequestQueueKey(message.id), message);
			else if (messages_1.Message.isResponse(message)) {
				if (maxParallelism === -1) queue.set(createResponseQueueKey(message.id), message);
				else handleResponse(message);
			} else queue.set(createNotificationQueueKey(), message);
		}
		function triggerMessageQueue() {
			if (timer || messageQueue.size === 0) return;
			if (maxParallelism !== -1 && inFlight >= maxParallelism) return;
			timer = (0, ral_1.default)().timer.setImmediate(async () => {
				timer = void 0;
				if (messageQueue.size === 0) return;
				if (maxParallelism !== -1 && inFlight >= maxParallelism) return;
				const message = messageQueue.shift();
				let result;
				try {
					inFlight++;
					const messageStrategy = options?.messageStrategy;
					if (MessageStrategy.is(messageStrategy)) result = messageStrategy.handleMessage(message, handleMessage);
					else result = handleMessage(message);
				} catch (error) {
					logger.error(`Processing message queue failed: ${error.toString()}`);
				} finally {
					if (result instanceof Promise) result.then(() => {
						inFlight--;
						triggerMessageQueue();
					}).catch((error) => {
						logger.error(`Processing message queue failed: ${error.toString()}`);
					});
					else inFlight--;
					triggerMessageQueue();
				}
			});
		}
		async function handleMessage(message) {
			if (messages_1.Message.isRequest(message)) return handleRequest(message);
			else if (messages_1.Message.isNotification(message)) return handleNotification(message);
			else if (messages_1.Message.isResponse(message)) return handleResponse(message);
			else return handleInvalidMessage(message);
		}
		const callback = (message) => {
			try {
				if (messages_1.Message.isNotification(message) && message.method === CancelNotification.type.method) {
					const cancelId = message.params.id;
					const key = createRequestQueueKey(cancelId);
					const toCancel = messageQueue.get(key);
					if (messages_1.Message.isRequest(toCancel)) {
						const strategy = options?.connectionStrategy;
						const response = strategy && strategy.cancelUndispatched ? strategy.cancelUndispatched(toCancel, cancelUndispatched) : void 0;
						if (response && (response.error !== void 0 || response.result !== void 0)) {
							messageQueue.delete(key);
							requestTokens.delete(cancelId);
							response.id = toCancel.id;
							traceSendingResponse(response, message.method, Date.now());
							messageWriter.write(response).catch(() => logger.error(`Sending response for canceled message failed.`));
							return;
						}
					}
					const cancellationToken = requestTokens.get(cancelId);
					if (cancellationToken !== void 0) {
						cancellationToken.cancel();
						traceReceivedNotification(message);
						return;
					} else knownCanceledRequests.add(cancelId);
				}
				addMessageToQueue(messageQueue, message);
			} finally {
				triggerMessageQueue();
			}
		};
		async function handleRequest(requestMessage) {
			if (isDisposed()) return Promise.resolve();
			function reply(resultOrError, method, startTime) {
				const message = {
					jsonrpc: version,
					id: requestMessage.id
				};
				if (resultOrError instanceof messages_1.ResponseError) message.error = resultOrError.toJson();
				else message.result = resultOrError === void 0 ? null : resultOrError;
				traceSendingResponse(message, method, startTime);
				return messageWriter.write(message);
			}
			function replyError(error, method, startTime) {
				const message = {
					jsonrpc: version,
					id: requestMessage.id,
					error: error.toJson()
				};
				traceSendingResponse(message, method, startTime);
				return messageWriter.write(message);
			}
			traceReceivedRequest(requestMessage);
			const element = requestHandlers.get(requestMessage.method);
			let type;
			let requestHandler;
			if (element) {
				type = element.type;
				requestHandler = element.handler;
			}
			const startTime = Date.now();
			if (requestHandler || starRequestHandler) {
				const tokenKey = requestMessage.id ?? String(Date.now());
				const cancellationSource = IdCancellationReceiverStrategy.is(cancellationStrategy.receiver) ? cancellationStrategy.receiver.createCancellationTokenSource(tokenKey) : cancellationStrategy.receiver.createCancellationTokenSource(requestMessage);
				if (requestMessage.id !== null && knownCanceledRequests.has(requestMessage.id)) cancellationSource.cancel();
				if (requestMessage.id !== null) requestTokens.set(tokenKey, cancellationSource);
				try {
					let handlerResult;
					if (requestHandler) {
						if (requestMessage.params === void 0) {
							if (type !== void 0 && type.numberOfParams !== 0) return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines ${type.numberOfParams} params but received none.`), requestMessage.method, startTime);
							handlerResult = requestHandler(cancellationSource.token);
						} else if (Array.isArray(requestMessage.params)) {
							if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byName) return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by name but received parameters by position`), requestMessage.method, startTime);
							handlerResult = requestHandler(...requestMessage.params, cancellationSource.token);
						} else {
							if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) return replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InvalidParams, `Request ${requestMessage.method} defines parameters by position but received parameters by name`), requestMessage.method, startTime);
							handlerResult = requestHandler(requestMessage.params, cancellationSource.token);
						}
					} else if (starRequestHandler) handlerResult = starRequestHandler(requestMessage.method, requestMessage.params, cancellationSource.token);
					await reply(await handlerResult, requestMessage.method, startTime);
				} catch (error) {
					if (error instanceof messages_1.ResponseError) await reply(error, requestMessage.method, startTime);
					else if (error && Is.string(error.message)) await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed with message: ${error.message}`), requestMessage.method, startTime);
					else await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.InternalError, `Request ${requestMessage.method} failed unexpectedly without providing any details.`), requestMessage.method, startTime);
				} finally {
					requestTokens.delete(tokenKey);
				}
			} else await replyError(new messages_1.ResponseError(messages_1.ErrorCodes.MethodNotFound, `Unhandled method ${requestMessage.method}`), requestMessage.method, startTime);
		}
		function handleResponse(responseMessage) {
			if (isDisposed()) return;
			if (responseMessage.id === null) {
				if (responseMessage.error) logger.error(`Received response message without id: Error is: \n${JSON.stringify(responseMessage.error, void 0, 4)}`);
				else logger.error(`Received response message without id. No further error information provided.`);
			} else {
				const key = responseMessage.id;
				const responsePromise = responsePromises.get(key);
				traceReceivedResponse(responseMessage, responsePromise);
				if (responsePromise !== void 0) {
					responsePromises.delete(key);
					try {
						if (responseMessage.error) {
							const error = responseMessage.error;
							responsePromise.reject(new messages_1.ResponseError(error.code, error.message, error.data));
						} else if (responseMessage.result !== void 0) responsePromise.resolve(responseMessage.result);
						else throw new Error("Should never happen.");
					} catch (error) {
						if (error.message) logger.error(`Response handler '${responsePromise.method}' failed with message: ${error.message}`);
						else logger.error(`Response handler '${responsePromise.method}' failed unexpectedly.`);
					}
				}
			}
		}
		async function handleNotification(message) {
			if (isDisposed()) return;
			let type = void 0;
			let notificationHandler;
			if (message.method === CancelNotification.type.method) {
				const cancelId = message.params.id;
				knownCanceledRequests.delete(cancelId);
				traceReceivedNotification(message);
				return;
			} else {
				const element = notificationHandlers.get(message.method);
				if (element) {
					notificationHandler = element.handler;
					type = element.type;
				}
			}
			if (notificationHandler || starNotificationHandler) try {
				traceReceivedNotification(message);
				if (notificationHandler) {
					if (message.params === void 0) {
						if (type !== void 0) {
							if (type.numberOfParams !== 0 && type.parameterStructures !== messages_1.ParameterStructures.byName) logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received none.`);
						}
						await notificationHandler();
					} else if (Array.isArray(message.params)) {
						const params = message.params;
						if (message.method === ProgressNotification.type.method && params.length === 2 && ProgressToken.is(params[0])) await notificationHandler({
							token: params[0],
							value: params[1]
						});
						else {
							if (type !== void 0) {
								if (type.parameterStructures === messages_1.ParameterStructures.byName) logger.error(`Notification ${message.method} defines parameters by name but received parameters by position`);
								if (type.numberOfParams !== message.params.length) logger.error(`Notification ${message.method} defines ${type.numberOfParams} params but received ${params.length} arguments`);
							}
							await notificationHandler(...params);
						}
					} else {
						if (type !== void 0 && type.parameterStructures === messages_1.ParameterStructures.byPosition) logger.error(`Notification ${message.method} defines parameters by position but received parameters by name`);
						await notificationHandler(message.params);
					}
				} else if (starNotificationHandler) await starNotificationHandler(message.method, message.params);
			} catch (error) {
				if (error.message) logger.error(`Notification handler '${message.method}' failed with message: ${error.message}`);
				else logger.error(`Notification handler '${message.method}' failed unexpectedly.`);
			}
			else unhandledNotificationEmitter.fire(message);
		}
		function handleInvalidMessage(message) {
			if (!message) {
				logger.error("Received empty message.");
				return;
			}
			logger.error(`Received message which is neither a response nor a notification message:\n${JSON.stringify(message, null, 4)}`);
			const responseMessage = message;
			if (Is.string(responseMessage.id) || Is.number(responseMessage.id)) {
				const key = responseMessage.id;
				const responseHandler = responsePromises.get(key);
				if (responseHandler) responseHandler.reject(/* @__PURE__ */ new Error("The received response has neither a result nor an error property."));
			}
		}
		function stringifyTrace(params) {
			if (params === void 0 || params === null) return;
			switch (trace) {
				case Trace.Verbose: return JSON.stringify(params, null, 4);
				case Trace.Compact: return JSON.stringify(params);
				default: return;
			}
		}
		function traceSendingRequest(message) {
			if (trace === Trace.Off || !tracer) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if ((trace === Trace.Verbose || trace === Trace.Compact) && message.params) data = `Params: ${stringifyTrace(message.params)}`;
				tracer.log(`Sending request '${message.method} - (${message.id})'.`, data);
			} else logLSPMessage("send-request", message);
		}
		function traceSendingNotification(message) {
			if (trace === Trace.Off || !tracer) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if (trace === Trace.Verbose || trace === Trace.Compact) {
					if (message.params) data = `Params: ${stringifyTrace(message.params)}`;
					else data = "No parameters provided.";
				}
				tracer.log(`Sending notification '${message.method}'.`, data);
			} else logLSPMessage("send-notification", message);
		}
		function traceSendingResponse(message, method, startTime) {
			if (trace === Trace.Off || !tracer) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if (trace === Trace.Verbose || trace === Trace.Compact) {
					if (message.error && message.error.data) data = `Error data: ${stringifyTrace(message.error.data)}`;
					else if (message.result) data = `Result: ${stringifyTrace(message.result)}`;
					else if (message.error === void 0) data = "No result returned.";
				}
				tracer.log(`Sending response '${method} - (${message.id})'. Processing request took ${Date.now() - startTime}ms`, data);
			} else logLSPMessage("send-response", message);
		}
		function traceReceivedRequest(message) {
			if (trace === Trace.Off || !tracer) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if ((trace === Trace.Verbose || trace === Trace.Compact) && message.params) data = `Params: ${stringifyTrace(message.params)}`;
				tracer.log(`Received request '${message.method} - (${message.id})'.`, data);
			} else logLSPMessage("receive-request", message);
		}
		function traceReceivedNotification(message) {
			if (trace === Trace.Off || !tracer || message.method === LogTraceNotification.type.method) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if (trace === Trace.Verbose || trace === Trace.Compact) {
					if (message.params) data = `Params: ${stringifyTrace(message.params)}`;
					else data = "No parameters provided.";
				}
				tracer.log(`Received notification '${message.method}'.`, data);
			} else logLSPMessage("receive-notification", message);
		}
		function traceReceivedResponse(message, responsePromise) {
			if (trace === Trace.Off || !tracer) return;
			if (traceFormat === TraceFormat.Text) {
				let data = void 0;
				if (trace === Trace.Verbose || trace === Trace.Compact) {
					if (message.error && message.error.data) data = `Error data: ${stringifyTrace(message.error.data)}`;
					else if (message.result) data = `Result: ${stringifyTrace(message.result)}`;
					else if (message.error === void 0) data = "No result returned.";
				}
				if (responsePromise) {
					const error = message.error ? ` Request failed: ${message.error.message} (${message.error.code}).` : "";
					tracer.log(`Received response '${responsePromise.method} - (${message.id})' in ${Date.now() - responsePromise.timerStart}ms.${error}`, data);
				} else tracer.log(`Received response ${message.id} without active response promise.`, data);
			} else logLSPMessage("receive-response", message);
		}
		function logLSPMessage(type, message) {
			if (!tracer || trace === Trace.Off) return;
			const lspMessage = {
				isLSPMessage: true,
				type,
				message,
				timestamp: Date.now()
			};
			tracer.log(lspMessage);
		}
		function throwIfClosedOrDisposed() {
			if (isClosed()) throw new ConnectionError(ConnectionErrors.Closed, "Connection is closed.");
			if (isDisposed()) throw new ConnectionError(ConnectionErrors.Disposed, "Connection is disposed.");
		}
		function throwIfListening() {
			if (isListening()) throw new ConnectionError(ConnectionErrors.AlreadyListening, "Connection is already listening");
		}
		function throwIfNotListening() {
			if (!isListening()) throw new Error("Call listen() first.");
		}
		function undefinedToNull(param) {
			if (param === void 0) return null;
			else return param;
		}
		function nullToUndefined(param) {
			if (param === null) return;
			else return param;
		}
		function isNamedParam(param) {
			return param !== void 0 && param !== null && !Array.isArray(param) && typeof param === "object";
		}
		function computeSingleParam(parameterStructures, param) {
			switch (parameterStructures) {
				case messages_1.ParameterStructures.auto: if (isNamedParam(param)) return nullToUndefined(param);
				else return [undefinedToNull(param)];
				case messages_1.ParameterStructures.byName:
					if (!isNamedParam(param)) throw new Error(`Received parameters by name but param is not an object literal.`);
					return nullToUndefined(param);
				case messages_1.ParameterStructures.byPosition: return [undefinedToNull(param)];
				default: throw new Error(`Unknown parameter structure ${parameterStructures.toString()}`);
			}
		}
		function computeMessageParams(type, params) {
			let result;
			const numberOfParams = type.numberOfParams;
			switch (numberOfParams) {
				case 0:
					result = void 0;
					break;
				case 1:
					result = computeSingleParam(type.parameterStructures, params[0]);
					break;
				default:
					result = [];
					for (let i = 0; i < params.length && i < numberOfParams; i++) result.push(undefinedToNull(params[i]));
					if (params.length < numberOfParams) for (let i = params.length; i < numberOfParams; i++) result.push(null);
			}
			return result;
		}
		const connection = {
			sendNotification: (type, ...args) => {
				throwIfClosedOrDisposed();
				let method;
				let messageParams;
				if (Is.string(type)) {
					method = type;
					const first = args[0];
					let paramStart = 0;
					let parameterStructures = messages_1.ParameterStructures.auto;
					if (messages_1.ParameterStructures.is(first)) {
						paramStart = 1;
						parameterStructures = first;
					}
					const paramEnd = args.length;
					const numberOfParams = paramEnd - paramStart;
					switch (numberOfParams) {
						case 0:
							messageParams = void 0;
							break;
						case 1:
							messageParams = computeSingleParam(parameterStructures, args[paramStart]);
							break;
						default:
							if (parameterStructures === messages_1.ParameterStructures.byName) throw new Error(`Received ${numberOfParams} parameters for 'by Name' notification parameter structure.`);
							messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
					}
				} else {
					const params = args;
					method = type.method;
					messageParams = computeMessageParams(type, params);
				}
				const notificationMessage = {
					jsonrpc: version,
					method,
					params: messageParams
				};
				traceSendingNotification(notificationMessage);
				return messageWriter.write(notificationMessage).catch((error) => {
					logger.error(`Sending notification failed.`);
					throw error;
				});
			},
			onNotification: (type, handler) => {
				throwIfClosedOrDisposed();
				let method;
				if (Is.func(type)) starNotificationHandler = type;
				else if (handler) {
					if (Is.string(type)) {
						method = type;
						notificationHandlers.set(type, {
							type: void 0,
							handler
						});
					} else {
						method = type.method;
						notificationHandlers.set(type.method, {
							type,
							handler
						});
					}
				}
				return { dispose: () => {
					if (method !== void 0) {
						if (notificationHandlers.get(method)?.handler === handler) notificationHandlers.delete(method);
					} else if (starNotificationHandler === type) starNotificationHandler = void 0;
				} };
			},
			onProgress: (_type, token, handler) => {
				if (progressHandlers.has(token)) throw new Error(`Progress handler for token ${token} already registered`);
				progressHandlers.set(token, handler);
				return { dispose: () => {
					if (progressHandlers.get(token) === handler) progressHandlers.delete(token);
				} };
			},
			sendProgress: (_type, token, value) => {
				return connection.sendNotification(ProgressNotification.type, {
					token,
					value
				});
			},
			onUnhandledProgress: unhandledProgressEmitter.event,
			sendRequest: (type, ...args) => {
				throwIfClosedOrDisposed();
				throwIfNotListening();
				function sendCancellation(connection, id) {
					const p = cancellationStrategy.sender.sendCancellation(connection, id);
					if (p === void 0) logger.log(`Received no promise from cancellation strategy when cancelling id ${id}`);
					else p.catch(() => {
						logger.log(`Sending cancellation messages for id ${id} failed.`);
					});
				}
				let method;
				let messageParams;
				let token = void 0;
				if (Is.string(type)) {
					method = type;
					const first = args[0];
					const last = args[args.length - 1];
					let paramStart = 0;
					let parameterStructures = messages_1.ParameterStructures.auto;
					if (messages_1.ParameterStructures.is(first)) {
						paramStart = 1;
						parameterStructures = first;
					}
					let paramEnd = args.length;
					if (cancellation_1.CancellationToken.is(last)) {
						paramEnd = paramEnd - 1;
						token = last;
					}
					const numberOfParams = paramEnd - paramStart;
					switch (numberOfParams) {
						case 0:
							messageParams = void 0;
							break;
						case 1:
							messageParams = computeSingleParam(parameterStructures, args[paramStart]);
							break;
						default:
							if (parameterStructures === messages_1.ParameterStructures.byName) throw new Error(`Received ${numberOfParams} parameters for 'by Name' request parameter structure.`);
							messageParams = args.slice(paramStart, paramEnd).map((value) => undefinedToNull(value));
					}
				} else {
					const params = args;
					method = type.method;
					messageParams = computeMessageParams(type, params);
					const numberOfParams = type.numberOfParams;
					token = cancellation_1.CancellationToken.is(params[numberOfParams]) ? params[numberOfParams] : void 0;
				}
				const id = sequenceNumber++;
				let disposable;
				let tokenWasCancelled = false;
				if (token !== void 0) {
					if (token.isCancellationRequested) tokenWasCancelled = true;
					else disposable = token.onCancellationRequested(() => {
						sendCancellation(connection, id);
					});
				}
				const requestMessage = {
					jsonrpc: version,
					id,
					method,
					params: messageParams
				};
				traceSendingRequest(requestMessage);
				if (typeof cancellationStrategy.sender.enableCancellation === "function") cancellationStrategy.sender.enableCancellation(requestMessage);
				return new Promise(async (resolve, reject) => {
					const resolveWithCleanup = (r) => {
						resolve(r);
						cancellationStrategy.sender.cleanup(id);
						disposable?.dispose();
					};
					const rejectWithCleanup = (r) => {
						reject(r);
						cancellationStrategy.sender.cleanup(id);
						disposable?.dispose();
					};
					const responsePromise = {
						method,
						timerStart: Date.now(),
						resolve: resolveWithCleanup,
						reject: rejectWithCleanup
					};
					try {
						responsePromises.set(id, responsePromise);
						await messageWriter.write(requestMessage);
						if (tokenWasCancelled) sendCancellation(connection, id);
					} catch (error) {
						responsePromises.delete(id);
						responsePromise.reject(new messages_1.ResponseError(messages_1.ErrorCodes.MessageWriteError, error.message ? error.message : "Unknown reason"));
						logger.error(`Sending request failed.`);
						throw error;
					}
				});
			},
			onRequest: (type, handler) => {
				throwIfClosedOrDisposed();
				let method = null;
				if (StarRequestHandler.is(type)) {
					method = void 0;
					starRequestHandler = type;
				} else if (Is.string(type)) {
					method = null;
					if (handler !== void 0) {
						method = type;
						requestHandlers.set(type, {
							handler,
							type: void 0
						});
					}
				} else if (handler !== void 0) {
					method = type.method;
					requestHandlers.set(type.method, {
						type,
						handler
					});
				}
				return { dispose: () => {
					if (method === null) return;
					if (method !== void 0) {
						if (requestHandlers.get(method)?.handler === handler) requestHandlers.delete(method);
					} else if (starRequestHandler === type) starRequestHandler = void 0;
				} };
			},
			hasPendingResponse: () => {
				return responsePromises.size > 0;
			},
			trace: async (_value, _tracer, sendNotificationOrTraceOptions) => {
				let _sendNotification = false;
				let _traceFormat = TraceFormat.Text;
				if (sendNotificationOrTraceOptions !== void 0) {
					if (Is.boolean(sendNotificationOrTraceOptions)) _sendNotification = sendNotificationOrTraceOptions;
					else {
						_sendNotification = sendNotificationOrTraceOptions.sendNotification || false;
						_traceFormat = sendNotificationOrTraceOptions.traceFormat || TraceFormat.Text;
					}
				}
				trace = _value;
				traceFormat = _traceFormat;
				if (trace === Trace.Off) tracer = void 0;
				else tracer = _tracer;
				if (_sendNotification && !isClosed() && !isDisposed()) await connection.sendNotification(SetTraceNotification.type, { value: Trace.toString(_value) });
			},
			onError: errorEmitter.event,
			onClose: closeEmitter.event,
			onUnhandledNotification: unhandledNotificationEmitter.event,
			onDispose: disposeEmitter.event,
			end: () => {
				messageWriter.end();
			},
			dispose: () => {
				if (isDisposed()) return;
				state = ConnectionState.Disposed;
				disposeEmitter.fire(void 0);
				const error = new messages_1.ResponseError(messages_1.ErrorCodes.PendingResponseRejected, "Pending response rejected since connection got disposed");
				for (const promise of responsePromises.values()) promise.reject(error);
				responsePromises = /* @__PURE__ */ new Map();
				requestTokens = /* @__PURE__ */ new Map();
				knownCanceledRequests = /* @__PURE__ */ new Set();
				messageQueue = new linkedMap_1.LinkedMap();
				if (Is.func(messageWriter.dispose)) messageWriter.dispose();
				if (Is.func(messageReader.dispose)) messageReader.dispose();
			},
			listen: () => {
				throwIfClosedOrDisposed();
				throwIfListening();
				state = ConnectionState.Listening;
				messageReader.listen(callback);
			},
			inspect: () => {
				(0, ral_1.default)().console.log("inspect");
			}
		};
		connection.onNotification(LogTraceNotification.type, (params) => {
			if (trace === Trace.Off || !tracer) return;
			const verbose = trace === Trace.Verbose || trace === Trace.Compact;
			tracer.log(params.message, verbose ? params.verbose : void 0);
		});
		connection.onNotification(ProgressNotification.type, async (params) => {
			const handler = progressHandlers.get(params.token);
			if (handler) await handler(params.value);
			else unhandledProgressEmitter.fire(params);
		});
		return connection;
	}
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/common/api.js
var require_api = /* @__PURE__ */ __commonJSMin(((exports) => {
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.ProgressType = exports.ProgressToken = exports.createMessageConnection = exports.NullLogger = exports.ConnectionOptions = exports.ConnectionStrategy = exports.AbstractMessageBuffer = exports.WriteableStreamMessageWriter = exports.AbstractMessageWriter = exports.MessageWriter = exports.ReadableStreamMessageReader = exports.AbstractMessageReader = exports.MessageReader = exports.SharedArrayReceiverStrategy = exports.SharedArraySenderStrategy = exports.CancellationToken = exports.CancellationTokenSource = exports.Emitter = exports.Event = exports.Disposable = exports.LRUCache = exports.Touch = exports.LinkedMap = exports.ParameterStructures = exports.NotificationType9 = exports.NotificationType8 = exports.NotificationType7 = exports.NotificationType6 = exports.NotificationType5 = exports.NotificationType4 = exports.NotificationType3 = exports.NotificationType2 = exports.NotificationType1 = exports.NotificationType0 = exports.NotificationType = exports.ErrorCodes = exports.ResponseError = exports.RequestType9 = exports.RequestType8 = exports.RequestType7 = exports.RequestType6 = exports.RequestType5 = exports.RequestType4 = exports.RequestType3 = exports.RequestType2 = exports.RequestType1 = exports.RequestType0 = exports.RequestType = exports.Message = exports.RAL = void 0;
	exports.MessageStrategy = exports.CancellationStrategy = exports.CancellationSenderStrategy = exports.RequestCancellationReceiverStrategy = exports.IdCancellationReceiverStrategy = exports.CancellationReceiverStrategy = exports.ConnectionError = exports.ConnectionErrors = exports.LogTraceNotification = exports.SetTraceNotification = exports.TraceFormat = exports.TraceValues = exports.TraceValue = exports.Trace = void 0;
	var messages_1 = require_messages();
	Object.defineProperty(exports, "Message", {
		enumerable: true,
		get: function() {
			return messages_1.Message;
		}
	});
	Object.defineProperty(exports, "RequestType", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType;
		}
	});
	Object.defineProperty(exports, "RequestType0", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType0;
		}
	});
	Object.defineProperty(exports, "RequestType1", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType1;
		}
	});
	Object.defineProperty(exports, "RequestType2", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType2;
		}
	});
	Object.defineProperty(exports, "RequestType3", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType3;
		}
	});
	Object.defineProperty(exports, "RequestType4", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType4;
		}
	});
	Object.defineProperty(exports, "RequestType5", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType5;
		}
	});
	Object.defineProperty(exports, "RequestType6", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType6;
		}
	});
	Object.defineProperty(exports, "RequestType7", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType7;
		}
	});
	Object.defineProperty(exports, "RequestType8", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType8;
		}
	});
	Object.defineProperty(exports, "RequestType9", {
		enumerable: true,
		get: function() {
			return messages_1.RequestType9;
		}
	});
	Object.defineProperty(exports, "ResponseError", {
		enumerable: true,
		get: function() {
			return messages_1.ResponseError;
		}
	});
	Object.defineProperty(exports, "ErrorCodes", {
		enumerable: true,
		get: function() {
			return messages_1.ErrorCodes;
		}
	});
	Object.defineProperty(exports, "NotificationType", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType;
		}
	});
	Object.defineProperty(exports, "NotificationType0", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType0;
		}
	});
	Object.defineProperty(exports, "NotificationType1", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType1;
		}
	});
	Object.defineProperty(exports, "NotificationType2", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType2;
		}
	});
	Object.defineProperty(exports, "NotificationType3", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType3;
		}
	});
	Object.defineProperty(exports, "NotificationType4", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType4;
		}
	});
	Object.defineProperty(exports, "NotificationType5", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType5;
		}
	});
	Object.defineProperty(exports, "NotificationType6", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType6;
		}
	});
	Object.defineProperty(exports, "NotificationType7", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType7;
		}
	});
	Object.defineProperty(exports, "NotificationType8", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType8;
		}
	});
	Object.defineProperty(exports, "NotificationType9", {
		enumerable: true,
		get: function() {
			return messages_1.NotificationType9;
		}
	});
	Object.defineProperty(exports, "ParameterStructures", {
		enumerable: true,
		get: function() {
			return messages_1.ParameterStructures;
		}
	});
	var linkedMap_1 = require_linkedMap();
	Object.defineProperty(exports, "LinkedMap", {
		enumerable: true,
		get: function() {
			return linkedMap_1.LinkedMap;
		}
	});
	Object.defineProperty(exports, "LRUCache", {
		enumerable: true,
		get: function() {
			return linkedMap_1.LRUCache;
		}
	});
	Object.defineProperty(exports, "Touch", {
		enumerable: true,
		get: function() {
			return linkedMap_1.Touch;
		}
	});
	var disposable_1 = require_disposable();
	Object.defineProperty(exports, "Disposable", {
		enumerable: true,
		get: function() {
			return disposable_1.Disposable;
		}
	});
	var events_1 = require_events();
	Object.defineProperty(exports, "Event", {
		enumerable: true,
		get: function() {
			return events_1.Event;
		}
	});
	Object.defineProperty(exports, "Emitter", {
		enumerable: true,
		get: function() {
			return events_1.Emitter;
		}
	});
	var cancellation_1 = require_cancellation();
	Object.defineProperty(exports, "CancellationTokenSource", {
		enumerable: true,
		get: function() {
			return cancellation_1.CancellationTokenSource;
		}
	});
	Object.defineProperty(exports, "CancellationToken", {
		enumerable: true,
		get: function() {
			return cancellation_1.CancellationToken;
		}
	});
	var sharedArrayCancellation_1 = require_sharedArrayCancellation();
	Object.defineProperty(exports, "SharedArraySenderStrategy", {
		enumerable: true,
		get: function() {
			return sharedArrayCancellation_1.SharedArraySenderStrategy;
		}
	});
	Object.defineProperty(exports, "SharedArrayReceiverStrategy", {
		enumerable: true,
		get: function() {
			return sharedArrayCancellation_1.SharedArrayReceiverStrategy;
		}
	});
	var messageReader_1 = require_messageReader();
	Object.defineProperty(exports, "MessageReader", {
		enumerable: true,
		get: function() {
			return messageReader_1.MessageReader;
		}
	});
	Object.defineProperty(exports, "AbstractMessageReader", {
		enumerable: true,
		get: function() {
			return messageReader_1.AbstractMessageReader;
		}
	});
	Object.defineProperty(exports, "ReadableStreamMessageReader", {
		enumerable: true,
		get: function() {
			return messageReader_1.ReadableStreamMessageReader;
		}
	});
	var messageWriter_1 = require_messageWriter();
	Object.defineProperty(exports, "MessageWriter", {
		enumerable: true,
		get: function() {
			return messageWriter_1.MessageWriter;
		}
	});
	Object.defineProperty(exports, "AbstractMessageWriter", {
		enumerable: true,
		get: function() {
			return messageWriter_1.AbstractMessageWriter;
		}
	});
	Object.defineProperty(exports, "WriteableStreamMessageWriter", {
		enumerable: true,
		get: function() {
			return messageWriter_1.WriteableStreamMessageWriter;
		}
	});
	var messageBuffer_1 = require_messageBuffer();
	Object.defineProperty(exports, "AbstractMessageBuffer", {
		enumerable: true,
		get: function() {
			return messageBuffer_1.AbstractMessageBuffer;
		}
	});
	var connection_1 = require_connection();
	Object.defineProperty(exports, "ConnectionStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionStrategy;
		}
	});
	Object.defineProperty(exports, "ConnectionOptions", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionOptions;
		}
	});
	Object.defineProperty(exports, "NullLogger", {
		enumerable: true,
		get: function() {
			return connection_1.NullLogger;
		}
	});
	Object.defineProperty(exports, "createMessageConnection", {
		enumerable: true,
		get: function() {
			return connection_1.createMessageConnection;
		}
	});
	Object.defineProperty(exports, "ProgressToken", {
		enumerable: true,
		get: function() {
			return connection_1.ProgressToken;
		}
	});
	Object.defineProperty(exports, "ProgressType", {
		enumerable: true,
		get: function() {
			return connection_1.ProgressType;
		}
	});
	Object.defineProperty(exports, "Trace", {
		enumerable: true,
		get: function() {
			return connection_1.Trace;
		}
	});
	Object.defineProperty(exports, "TraceValue", {
		enumerable: true,
		get: function() {
			return connection_1.TraceValue;
		}
	});
	Object.defineProperty(exports, "TraceFormat", {
		enumerable: true,
		get: function() {
			return connection_1.TraceFormat;
		}
	});
	Object.defineProperty(exports, "SetTraceNotification", {
		enumerable: true,
		get: function() {
			return connection_1.SetTraceNotification;
		}
	});
	Object.defineProperty(exports, "LogTraceNotification", {
		enumerable: true,
		get: function() {
			return connection_1.LogTraceNotification;
		}
	});
	Object.defineProperty(exports, "ConnectionErrors", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionErrors;
		}
	});
	Object.defineProperty(exports, "ConnectionError", {
		enumerable: true,
		get: function() {
			return connection_1.ConnectionError;
		}
	});
	Object.defineProperty(exports, "CancellationReceiverStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.CancellationReceiverStrategy;
		}
	});
	Object.defineProperty(exports, "IdCancellationReceiverStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.IdCancellationReceiverStrategy;
		}
	});
	Object.defineProperty(exports, "RequestCancellationReceiverStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.RequestCancellationReceiverStrategy;
		}
	});
	Object.defineProperty(exports, "CancellationSenderStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.CancellationSenderStrategy;
		}
	});
	Object.defineProperty(exports, "CancellationStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.CancellationStrategy;
		}
	});
	Object.defineProperty(exports, "MessageStrategy", {
		enumerable: true,
		get: function() {
			return connection_1.MessageStrategy;
		}
	});
	Object.defineProperty(exports, "TraceValues", {
		enumerable: true,
		get: function() {
			return connection_1.TraceValues;
		}
	});
	exports.RAL = __importDefault(require_ral()).default;
}));
//#endregion
//#region node_modules/.pnpm/vscode-jsonrpc@9.0.2/node_modules/vscode-jsonrpc/lib/browser/ril.js
var require_ril = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.PromiseImpl = exports.QueueMicrotaskImpl = void 0;
	var api_1 = require_api();
	var MessageBuffer = class MessageBuffer extends api_1.AbstractMessageBuffer {
		static emptyBuffer = /* @__PURE__ */ new Uint8Array(0);
		asciiDecoder;
		constructor(encoding = "utf-8") {
			super(encoding);
			this.asciiDecoder = new TextDecoder("ascii");
		}
		emptyBuffer() {
			return MessageBuffer.emptyBuffer;
		}
		fromString(value, _encoding) {
			return new TextEncoder().encode(value);
		}
		toString(value, encoding) {
			if (encoding === "ascii") return this.asciiDecoder.decode(value);
			else return new TextDecoder(encoding).decode(value);
		}
		asNative(buffer, length) {
			if (length === void 0) return buffer;
			else return buffer.slice(0, length);
		}
		allocNative(length) {
			return new Uint8Array(length);
		}
	};
	var ReadableStreamWrapper = class {
		socket;
		_onData;
		_messageListener;
		constructor(socket) {
			this.socket = socket;
			this._onData = new api_1.Emitter();
			this._messageListener = (event) => {
				event.data.arrayBuffer().then((buffer) => {
					this._onData.fire(new Uint8Array(buffer));
				}, () => {
					(0, api_1.RAL)().console.error(`Converting blob to array buffer failed.`);
				});
			};
			this.socket.addEventListener("message", this._messageListener);
		}
		onClose(listener) {
			this.socket.addEventListener("close", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("close", listener));
		}
		onError(listener) {
			this.socket.addEventListener("error", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("error", listener));
		}
		onEnd(listener) {
			this.socket.addEventListener("end", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("end", listener));
		}
		onData(listener) {
			return this._onData.event(listener);
		}
	};
	var WritableStreamWrapper = class {
		socket;
		constructor(socket) {
			this.socket = socket;
		}
		onClose(listener) {
			this.socket.addEventListener("close", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("close", listener));
		}
		onError(listener) {
			this.socket.addEventListener("error", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("error", listener));
		}
		onEnd(listener) {
			this.socket.addEventListener("end", listener);
			return api_1.Disposable.create(() => this.socket.removeEventListener("end", listener));
		}
		write(data, encoding) {
			if (typeof data === "string") {
				if (encoding !== void 0 && encoding !== "utf-8") throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${encoding}`);
				this.socket.send(data);
			} else if (data.buffer instanceof ArrayBuffer) this.socket.send(data.buffer);
			else this.socket.send(new Uint8Array(data.buffer).slice().buffer);
			return Promise.resolve();
		}
		end() {
			this.socket.close();
		}
	};
	var QueueMicrotaskImpl = class {
		isDisposed;
		constructor(callback, ...args) {
			this.isDisposed = false;
			queueMicrotask(() => {
				if (!this.isDisposed) callback(...args);
			});
		}
		dispose() {
			this.isDisposed = true;
		}
	};
	exports.QueueMicrotaskImpl = QueueMicrotaskImpl;
	var PromiseImpl = class {
		isDisposed;
		constructor(callback, ...args) {
			this.isDisposed = false;
			Promise.resolve().then(() => {
				if (!this.isDisposed) callback(...args);
			}, () => {});
		}
		dispose() {
			this.isDisposed = true;
		}
	};
	exports.PromiseImpl = PromiseImpl;
	var _textEncoder = new TextEncoder();
	var _ril = Object.freeze({
		messageBuffer: Object.freeze({ create: (encoding) => new MessageBuffer(encoding) }),
		applicationJson: Object.freeze({
			encoder: Object.freeze({
				name: "application/json",
				encode: (msg, options) => {
					if (options.charset !== "utf-8") throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${options.charset}`);
					return Promise.resolve(_textEncoder.encode(JSON.stringify(msg, void 0, 0)));
				}
			}),
			decoder: Object.freeze({
				name: "application/json",
				decode: (buffer, options) => {
					if (!(buffer instanceof Uint8Array)) throw new Error(`In a Browser environments only Uint8Arrays are supported.`);
					return Promise.resolve(JSON.parse(new TextDecoder(options.charset).decode(buffer)));
				}
			})
		}),
		stream: Object.freeze({
			asReadableStream: (socket) => new ReadableStreamWrapper(socket),
			asWritableStream: (socket) => new WritableStreamWrapper(socket)
		}),
		console,
		timer: Object.freeze({
			setTimeout(callback, ms, ...args) {
				const handle = setTimeout(callback, ms, ...args);
				return { dispose: () => clearTimeout(handle) };
			},
			setImmediate(callback, ...args) {
				if (typeof globalThis.queueMicrotask === "function") return new QueueMicrotaskImpl(callback, ...args);
				else if (Promise !== void 0) return new PromiseImpl(callback, ...args);
				else {
					const handle = setTimeout(callback, 0, ...args);
					return { dispose: () => clearTimeout(handle) };
				}
			},
			setInterval(callback, ms, ...args) {
				const handle = setInterval(callback, ms, ...args);
				return { dispose: () => clearInterval(handle) };
			}
		})
	});
	function RIL() {
		return _ril;
	}
	(function(RIL) {
		function install() {
			api_1.RAL.install(_ril);
		}
		RIL.install = install;
	})(RIL || (RIL = {}));
	exports.default = RIL;
}));
(/* @__PURE__ */ __commonJSMin(((exports) => {
	var __createBinding = exports && exports.__createBinding || (Object.create ? (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		var desc = Object.getOwnPropertyDescriptor(m, k);
		if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) desc = {
			enumerable: true,
			get: function() {
				return m[k];
			}
		};
		Object.defineProperty(o, k2, desc);
	}) : (function(o, m, k, k2) {
		if (k2 === void 0) k2 = k;
		o[k2] = m[k];
	}));
	var __exportStar = exports && exports.__exportStar || function(m, exports$1) {
		for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports$1, p)) __createBinding(exports$1, m, p);
	};
	var __importDefault = exports && exports.__importDefault || function(mod) {
		return mod && mod.__esModule ? mod : { "default": mod };
	};
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.BrowserMessageWriter = exports.BrowserMessageReader = void 0;
	exports.createMessageConnection = createMessageConnection;
	__importDefault(require_ril()).default.install();
	var api_1 = require_api();
	__exportStar(require_api(), exports);
	var BrowserMessageReader = class extends api_1.AbstractMessageReader {
		_onData;
		_messageListener;
		constructor(port) {
			super();
			this._onData = new api_1.Emitter();
			this._messageListener = (event) => {
				this._onData.fire(event.data);
			};
			port.addEventListener("error", (event) => this.fireError(event));
			port.onmessage = this._messageListener;
		}
		listen(callback) {
			return this._onData.event(callback);
		}
	};
	exports.BrowserMessageReader = BrowserMessageReader;
	var BrowserMessageWriter = class extends api_1.AbstractMessageWriter {
		port;
		errorCount;
		constructor(port) {
			super();
			this.port = port;
			this.errorCount = 0;
			port.addEventListener("error", (event) => this.fireError(event));
		}
		write(msg) {
			try {
				this.port.postMessage(msg);
				return Promise.resolve();
			} catch (error) {
				this.handleError(error, msg);
				return Promise.reject(error);
			}
		}
		handleError(error, msg) {
			this.errorCount++;
			this.fireError(error, msg, this.errorCount);
		}
		end() {}
	};
	exports.BrowserMessageWriter = BrowserMessageWriter;
	function createMessageConnection(reader, writer, logger, options) {
		if (logger === void 0) logger = api_1.NullLogger;
		if (api_1.ConnectionStrategy.is(options)) options = { connectionStrategy: options };
		return (0, api_1.createMessageConnection)(reader, writer, logger, options);
	}
})))();
var import_api = require_api();
function createMdxpConnection(reader, writer) {
	const raw = (0, import_api.createMessageConnection)(reader, writer);
	return {
		listen: () => raw.listen(),
		sendRequest: (method, params, token) => token === void 0 ? raw.sendRequest(method, params) : raw.sendRequest(method, params, token),
		onRequest: (method, handler) => {
			raw.onRequest(method, ((params, token) => handler(params, token)));
		},
		sendNotification: (name, params) => {
			if (params === void 0) raw.sendNotification(name);
			else raw.sendNotification(name, params);
		},
		onNotification: (name, handler) => {
			raw.onNotification(name, (params) => handler(params));
		},
		dispose: () => raw.dispose(),
		raw
	};
}
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/errors.js
var ErrorCodes = Object.freeze({
	ParseError: -32700,
	InvalidRequest: -32600,
	MethodNotFound: -32601,
	InvalidParams: -32602,
	InternalError: -32603,
	RequestCancelled: -32800,
	AdapterError: -32001,
	ResourceUnavailable: -32002,
	PermissionDenied: -32003,
	RateLimited: -32004,
	CapabilityNotSupported: -32005,
	PairRevoked: -32006
});
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/methods.js
var Methods = Object.freeze({
	MotrixInitialize: "motrix/initialize",
	DownloadSubmit: "download/submit",
	DownloadCancel: "download/cancel",
	UrlProbe: "url/probe",
	UrlResolve: "url/resolve",
	SystemPing: "system/ping",
	DownloadAdd: "download/add",
	TaskList: "task/list",
	TaskGet: "task/get",
	TaskPause: "task/pause",
	TaskResume: "task/resume",
	TaskRemove: "task/remove",
	TaskReveal: "task/reveal",
	StatsGet: "stats/get",
	EngineStatus: "engine/status"
});
var Notifications = Object.freeze({
	MotrixInitialized: "motrix/initialized",
	TaskProgress: "$/task/progress",
	TaskCompleted: "$/task/completed",
	TaskError: "$/task/error",
	PairRevoked: "$/pair/revoked",
	CancelRequest: "$/cancelRequest",
	StatsUpdate: "$/stats"
});
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/resource.js
var HttpUrl = httpUrl$2({ message: "URL must be http: or https:" });
var CookieSchema = object({
	name: string(),
	value: string(),
	domain: string(),
	path: string().default("/"),
	secure: boolean().default(false),
	httpOnly: boolean().default(false),
	sameSite: _enum([
		"strict",
		"lax",
		"none",
		"unspecified"
	]).default("unspecified"),
	expiresAt: number().optional()
});
var ResourceSchema = object({
	url: HttpUrl,
	headers: record(string(), string()).default({}),
	cookies: array(CookieSchema).default([]),
	refererPolicy: string().default("strict-origin-when-cross-origin")
});
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/selection.js
var SelectionSchema = discriminatedUnion("kind", [
	object({
		kind: literal("direct"),
		primary: ResourceSchema,
		container: string().optional()
	}),
	object({
		kind: literal("hls"),
		primary: ResourceSchema,
		container: _enum([
			"mp4",
			"mkv",
			"ts"
		]).default("mp4")
	}),
	object({
		kind: literal("dash"),
		primary: ResourceSchema,
		container: _enum(["mp4", "mkv"]).default("mp4")
	}),
	object({
		kind: literal("mux"),
		video: ResourceSchema,
		audio: ResourceSchema,
		container: _enum(["mp4", "mkv"]).default("mp4")
	}),
	object({
		kind: literal("magnet"),
		uri: string().startsWith("magnet:?")
	})
]);
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/download.js
var DownloadSubmitParamsSchema = object({
	source: object({
		pageUrl: string().url(),
		pageTitle: string().max(500),
		detectedAt: number(),
		siteHint: string().max(64).optional()
	}),
	selection: SelectionSchema,
	meta: object({
		suggestedFilename: string().max(255),
		qualityLabel: string().max(64),
		estimatedBytes: number().nonnegative().optional(),
		durationSec: number().nonnegative().optional()
	}),
	/**
	* Client-generated key identifying ONE logical submit. Motrix dedups on
	* (session, key): a retransmit of the same submission — lost response,
	* reconnect replay — returns the original task instead of creating a
	* duplicate. Optional for backward compatibility.
	*/
	idempotencyKey: string().min(8).max(128).optional()
});
object({ taskId: string().min(1) });
object({ taskId: string().min(1) });
object({ ok: literal(true) });
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/task.js
/**
* Control-plane task status. Richer than the lossy 4-value
* `$/task/progress.phase`; snake_case-aligned with the host's domain
* `TaskStatus` so the host-side mapper is near-identity. `metadata_ready` maps
* to `queued` and `removed` is filtered out of `task/list` (not a value here).
*/
var MdxpTaskStatusSchema = _enum([
	"queued",
	"fetching_metadata",
	"downloading",
	"paused",
	"seeding",
	"finalizing",
	"completed",
	"error"
]);
var MdxpTaskTypeSchema = _enum([
	"http",
	"ftp",
	"bt",
	"magnet",
	"metalink"
]);
/** BitTorrent-only public subset (omits swarm/announce/piece internals). */
var MdxpBtSchema = object({
	peers: number(),
	seeds: number(),
	ratio: number(),
	trackers: array(string())
});
/**
* First-class public task DTO — a deliberate NARROW projection of the host's
* ~40-field domain `DownloadTask`. Result/notification payload, so non-strict
* (a newer server may add fields older clients ignore). The public id is `id`,
* never the volatile engine gid.
*/
var MdxpTaskSchema = object({
	id: string(),
	type: MdxpTaskTypeSchema,
	name: string(),
	status: MdxpTaskStatusSchema,
	/** Fraction in [0,1] — identity with the domain (DownloadTask.progress is
	*  already completed/total). `finalPath`, by contrast, is a conditional
	*  projection (non-null only once completed), not a blind copy. */
	progress: number(),
	bytesDone: number(),
	bytesTotal: number().nullable(),
	speedBps: number(),
	etaSec: number().nullable(),
	saveDir: string(),
	error: string().nullable(),
	createdAt: number(),
	finishedAt: number().nullable(),
	finalPath: string().nullable(),
	infoHash: string().nullable().optional(),
	bt: MdxpBtSchema.optional(),
	/** Open set of `DL_*` values (host's `DownloadErrorCode`); the host may add
	*  new codes over time, so consumers MUST tolerate an unrecognized string
	*  here rather than reject it — adding a value is not a breaking change. */
	errorCode: string().nullish()
});
object({ ok: literal(true) });
strictObject({
	status: MdxpTaskStatusSchema.optional(),
	limit: number().int().positive().optional(),
	offset: number().int().nonnegative().optional()
});
object({
	tasks: array(MdxpTaskSchema),
	total: number()
});
strictObject({ taskId: string().min(1) });
object({ task: MdxpTaskSchema.nullable() });
strictObject({ taskId: string().min(1) });
strictObject({ taskId: string().min(1) });
strictObject({
	taskId: string().min(1),
	deleteFiles: boolean().optional()
});
strictObject({ taskId: string().min(1) });
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/download-add.js
var HttpHeaderSchema = object({
	name: string(),
	value: string()
});
/**
* Network download schemes allowed on the public, agent-facing `download/add`
* surface. Pinned at the contract boundary so an LLM-callable tool can never
* be coerced into `file://` (local file read / path traversal), `javascript:`,
* `data:`, etc. — independent of whatever the host handler does later.
*/
var SAFE_DOWNLOAD_URL = /^(https?|ftps?|sftp):\/\//i;
var safeDownloadUrl = string().url().refine((u) => SAFE_DOWNLOAD_URL.test(u), { message: "unsupported URL scheme (allowed: http, https, ftp, ftps, sftp)" });
discriminatedUnion("kind", [
	strictObject({
		kind: literal("url"),
		saveDir: string().min(1),
		uris: array(safeDownloadUrl).min(1),
		filename: string().optional(),
		headers: array(HttpHeaderSchema).optional(),
		connections: number().int().min(1).max(128).optional(),
		proxy: string().optional(),
		idempotencyKey: string().min(8).max(128).optional()
	}),
	strictObject({
		kind: literal("magnet"),
		saveDir: string().min(1),
		uri: string().startsWith("magnet:?"),
		selectedFiles: array(number().int().nonnegative()).optional(),
		idempotencyKey: string().min(8).max(128).optional()
	}),
	strictObject({
		kind: literal("torrent"),
		saveDir: string().min(1),
		base64: string().min(1),
		selectedFiles: array(number().int().nonnegative()).optional(),
		displayName: string().optional(),
		idempotencyKey: string().min(8).max(128).optional()
	})
]);
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/engine.js
var EngineStateSchema = _enum([
	"stopped",
	"starting",
	"ready",
	"restarting",
	"failed"
]);
/** Capability-discovery info; all fields are external-safe. `features` is the
*  raw engine feature-string list (e.g. contains 'SQLite3-Persistence'). */
var EngineFeatureReportSchema = object({
	version: string(),
	features: array(string()),
	hasBtSeedUnverified: boolean(),
	hasBtSaveMetadata: boolean(),
	hasMoveStorage: boolean(),
	hasSqlitePersistence: boolean()
});
strictObject({});
object({
	state: EngineStateSchema,
	featureReport: EngineFeatureReportSchema.nullable()
});
object({
	taskId: string().min(1),
	bytesDone: number().nonnegative(),
	bytesTotal: number().nonnegative().nullable(),
	speedBps: number().nonnegative(),
	etaSec: number().nonnegative().nullable(),
	phase: _enum([
		"queued",
		"downloading",
		"muxing",
		"finalizing"
	])
});
object({
	taskId: string().min(1),
	filePath: string().min(1),
	durationMs: number().nonnegative()
});
object({
	taskId: string().min(1),
	code: string(),
	message: string()
});
object({ reason: string() });
object({ id: string().min(1) });
//#endregion
//#region node_modules/.pnpm/@motrix+mdxp@0.6.0/node_modules/@motrix/mdxp/dist/schemas/initialize.js
var PROTOCOL_VERSION = "1.0";
var AdapterDeclSchema = object({
	id: string().min(1),
	version: string().min(1),
	urlPatterns: array(string()),
	capabilities: array(_enum([
		"resolve",
		"sniff",
		"batch"
	]))
});
var ClientCapabilitiesSchema = object({
	submitDownload: boolean().optional(),
	resolveUrl: boolean().optional(),
	probeUrl: boolean().optional(),
	cancellation: boolean().optional(),
	progress: boolean().optional()
});
var ExtensionClientSchema = object({
	kind: literal("extension"),
	name: string().min(1),
	version: string().min(1),
	extensionId: string().min(1),
	browser: _enum(["chromium", "firefox"]),
	browserVersion: string().min(1),
	locale: string().min(1)
});
var CliClientSchema = object({
	kind: literal("cli"),
	name: string().min(1),
	version: string().min(1),
	locale: string().min(1).optional(),
	pid: number().int().optional(),
	host: string().optional()
});
/**
* Client identity, generalized to a `kind` discriminated union so non-extension
* clients (CLI/agents) can connect. Compat shim: the shipped extension sends NO
* `kind` field, so inject `kind: 'extension'` when absent before discriminating
* — keeping `PROTOCOL_VERSION` '1.0' and the existing extension payload valid.
*/
var ClientSchema = preprocess((value) => value && typeof value === "object" && !Array.isArray(value) && value.kind === void 0 ? {
	...value,
	kind: "extension"
} : value, discriminatedUnion("kind", [ExtensionClientSchema, CliClientSchema]));
object({
	protocolVersion: literal(PROTOCOL_VERSION),
	client: ClientSchema,
	capabilities: ClientCapabilitiesSchema,
	adapters: array(AdapterDeclSchema)
});
var ServerAdapterSchema = object({
	id: string().min(1),
	urlPatterns: array(string())
});
var ServerCapabilitiesSchema = object({
	ffmpegAvailable: boolean(),
	selectionKinds: array(_enum([
		"direct",
		"hls",
		"dash",
		"mux"
	])),
	progress: boolean(),
	cancellation: boolean(),
	/** Optional on the wire for protocol 1.0 compatibility; absent is false. */
	taskReveal: boolean().optional().default(false)
});
var InitializeResultSchema = object({
	protocolVersion: literal(PROTOCOL_VERSION),
	server: object({
		name: string().min(1),
		version: string().min(1),
		runtime: _enum(["electron", "server"])
	}),
	capabilities: ServerCapabilitiesSchema,
	serverAdapters: array(ServerAdapterSchema),
	pairToken: string().optional()
});
object({
	totalDownloadSpeed: number(),
	totalUploadSpeed: number(),
	activeTasks: number(),
	waitingTasks: number(),
	stoppedTasks: number()
});
strictObject({});
object({ sentAt: number() });
object({
	sentAt: number(),
	recvAt: number()
});
object({
	url: string().url(),
	hint: object({ siteName: string().optional() }).optional()
});
object({
	handled: boolean(),
	adapterId: string().optional(),
	confidence: _enum([
		"high",
		"medium",
		"low"
	]).optional()
});
var QualityEnum = _enum([
	"360p",
	"720p",
	"1080p",
	"1440p",
	"2160p",
	"best"
]);
var ResolvedSelectionSchema = discriminatedUnion("kind", [
	object({
		kind: literal("direct"),
		primary: ResourceSchema,
		container: string().optional(),
		quality: string(),
		sizeBytes: number().nonnegative().optional()
	}),
	object({
		kind: literal("hls"),
		primary: ResourceSchema,
		container: string(),
		quality: string()
	}),
	object({
		kind: literal("mux"),
		video: ResourceSchema,
		audio: ResourceSchema,
		container: string(),
		quality: string(),
		sizeBytes: number().nonnegative().optional()
	})
]);
var SubtitleSchema = object({
	languageCode: string(),
	languageName: string(),
	url: string().url(),
	format: _enum([
		"vtt",
		"srt",
		"ttml"
	])
});
object({
	url: string().url(),
	preferences: object({
		maxQuality: QualityEnum.optional(),
		preferContainer: _enum([
			"mp4",
			"mkv",
			"webm"
		]).optional(),
		includeAudio: boolean().optional(),
		includeSubtitles: boolean().optional()
	}).optional()
});
object({
	selections: array(ResolvedSelectionSchema),
	meta: object({
		title: string(),
		author: string().optional(),
		durationSec: number().nonnegative().optional(),
		thumbnail: string().url().optional(),
		description: string().optional(),
		publishedAt: number().optional(),
		tags: array(string()).optional()
	}),
	subtitles: array(SubtitleSchema).optional(),
	extractedBy: object({
		adapterId: string(),
		adapterVersion: string(),
		extractedAt: number()
	})
});
Methods.UrlProbe, Methods.UrlResolve;
Methods.MotrixInitialize, Methods.MotrixInitialize, Methods.SystemPing, Methods.SystemPing, Methods.DownloadSubmit, Methods.DownloadSubmit, Methods.DownloadCancel, Methods.DownloadCancel, Methods.DownloadAdd, Methods.DownloadAdd, Methods.TaskList, Methods.TaskList, Methods.TaskGet, Methods.TaskGet, Methods.TaskPause, Methods.TaskPause, Methods.TaskResume, Methods.TaskResume, Methods.TaskRemove, Methods.TaskRemove, Methods.TaskReveal, Methods.TaskReveal, Methods.StatsGet, Methods.StatsGet, Methods.EngineStatus, Methods.EngineStatus;
//#endregion
//#region src/adapters/index.ts
var adapterRegistry$1 = [];
//#endregion
//#region src/adapters/SiteAdapter.ts
/**
* Convert an MDXP URL pattern (e.g. `*://*.youtube.com/*`) to a JS
* regex. Mirrors Chrome match-pattern semantics: scheme://host/path,
* with `*` wildcards in any segment.
*/
function urlPatternToRegex(pattern) {
	const escaped = pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*");
	return new RegExp(`^${escaped}$`);
}
//#endregion
//#region src/background/AdapterRegistry.ts
/**
* Background-side adapter registry. Holds only adapter metadata —
* SiteAdapter.resolve() lives in the content script, not here, because
* extraction needs access to the live tab's DOM/cookies.
*/
var BgAdapterRegistry = class {
	entries;
	constructor(adapters = adapterRegistry$1) {
		this.entries = adapters.map((a) => ({
			decl: {
				id: a.id,
				version: a.version,
				urlPatterns: a.urlPatterns,
				capabilities: a.capabilities
			},
			regexes: a.urlPatterns.map(urlPatternToRegex)
		}));
	}
	/** Adapter decls for motrix/initialize.adapters[]. */
	list() {
		return this.entries.map((e) => e.decl);
	}
	/** Find the adapter that owns this URL, or null if none match. */
	findFor(url) {
		for (const e of this.entries) if (e.regexes.some((r) => r.test(url))) return e.decl;
		return null;
	}
};
//#endregion
//#region src/background/BackendOperationCoordinator.ts
/**
* Serializes backend-catalog mutations with endpoint-scoped pairing actions.
* The queue covers both storage work and active-connection side effects, so a
* delayed operation for backend A cannot stop or clear the gate for backend B.
*/
var BackendOperationCoordinator = class {
	operationTail = Promise.resolve();
	run(operation) {
		const result = this.operationTail.then(operation);
		this.operationTail = result.then(() => void 0, () => void 0);
		return result;
	}
};
//#endregion
//#region src/background/badge/computeBadge.ts
var RED = "#e03131";
var AMBER = "#f0a020";
var GREEN = "#12b886";
var WHITE = "#ffffff";
var mk = (text, bg) => ({
	text,
	bg,
	fg: WHITE
});
function computeBadge(i) {
	const icon = i.connection === "connected" ? "color" : "grey";
	if (i.hasUnackError) return {
		icon,
		badge: mk("!", RED),
		tooltipKey: "badge.tooltip.error"
	};
	if (i.connection === "denied") return {
		icon,
		badge: mk("!", AMBER),
		tooltipKey: "badge.tooltip.denied"
	};
	if (i.connection === "bootstrapping" || i.connection === "connecting" || i.connection === "handshaking" || i.connection === "awaiting-code") return {
		icon,
		badge: null,
		tooltipKey: "badge.tooltip.connecting"
	};
	if (i.connection === "connected" && i.hasActivity) return {
		icon,
		badge: mk("↓", GREEN),
		tooltipKey: "badge.tooltip.downloading"
	};
	return {
		icon,
		badge: null,
		tooltipKey: i.connection === "connected" ? "badge.tooltip.connected" : "badge.tooltip.disconnected"
	};
}
//#endregion
//#region src/background/badge/BadgeController.ts
var ICONS = {
	color: {
		16: "icons/icon-16.png",
		32: "icons/icon-32.png"
	},
	grey: {
		16: "icons/icon-16-grey.png",
		32: "icons/icon-32-grey.png"
	}
};
var BadgeController = class {
	deps;
	constructor(deps) {
		this.deps = deps;
	}
	async refresh() {
		try {
			const hasUnackError = await this.deps.errorStore.get();
			const visual = computeBadge({
				connection: this.deps.getState(),
				hasActivity: this.deps.hasActiveTasks(),
				hasUnackError
			});
			await browser.action.setBadgeText({ text: visual.badge?.text ?? "" });
			if (visual.badge) {
				await browser.action.setBadgeBackgroundColor({ color: visual.badge.bg });
				await browser.action.setBadgeTextColor?.({ color: visual.badge.fg });
			}
			await browser.action.setTitle({ title: instance.t(visual.tooltipKey) });
			await browser.action.setIcon({ path: ICONS[visual.icon] });
		} catch {}
	}
	async markError() {
		await this.deps.errorStore.set(true);
		await this.refresh();
	}
	async clearError() {
		await this.deps.errorStore.set(false);
		await this.refresh();
	}
};
/**
* Wrap the injected `notify` so an `error` severity lights the badge and a
* `confirm` (a success) clears it — ungated by NotificationsConfig, so the
* badge lights even when OS notifications are muted.
*/
function makeBadgeNotify(base, badge) {
	return (n) => {
		base(n);
		if (n.severity === "error") badge.markError();
		else if (n.severity === "confirm") badge.clearError();
	};
}
//#endregion
//#region src/background/badge/BadgeErrorStore.ts
var STORAGE_KEY$8 = "motrix.badgeError";
var BadgeErrorStore = class {
	async get() {
		const v = (await browser.storage.local.get(STORAGE_KEY$8))[STORAGE_KEY$8];
		return typeof v === "boolean" ? v : false;
	}
	async set(v) {
		await browser.storage.local.set({ [STORAGE_KEY$8]: v });
	}
};
//#endregion
//#region src/background/ConnectionGate.ts
/**
* Authority-scoped "may this backend auto-connect now?" state.
*
* A Chrome MV3 service worker is routinely restarted. The durable gate keeps a
* pending pairing from being duplicated after a restart and remembers an
* operator denial until the user explicitly retries. Remote Motrix Servers
* must not share either state with the local App or with another Server, so v2
* stores one row per opaque `BackendAuthority`.
*
* The no-argument constructor is an explicit local compatibility facade for
* the existing local ConnectionManager. Remote integration must construct a
* module-issued authority and pass it to `forAuthority` (or the constructor).
*/
var STORAGE_KEY$7 = "motrix.connectionGate";
var STORAGE_VERSION = 2;
var DEFAULT_PAIR_PENDING_MS = 9e4;
var MAX_LAST_ERROR_LENGTH = 512;
var OPEN = Object.freeze({
	reason: null,
	pausedUntil: 0,
	lastError: null
});
var CLOSED_UNSUPPORTED = Object.freeze({
	reason: "denied",
	pausedUntil: Number.POSITIVE_INFINITY,
	lastError: "connection gate version is unsupported"
});
var CLOSED_CORRUPT = Object.freeze({
	reason: "denied",
	pausedUntil: Number.POSITIVE_INFINITY,
	lastError: "connection gate state is corrupt"
});
var LOCAL_AUTHORITY_KEY$1 = backendAuthorityKey(LOCAL_BACKEND_AUTHORITY);
var enqueueConnectionGateOperation = createOperationQueue();
function nowMs() {
	return Date.now();
}
function emptySet$1() {
	return {
		version: STORAGE_VERSION,
		states: []
	};
}
function isNonEmptyString$1(value) {
	return typeof value === "string" && value.length > 0;
}
function normalizeLastError(value) {
	if (typeof value !== "string" || value.length === 0) return null;
	return value.length <= MAX_LAST_ERROR_LENGTH ? value : value.slice(0, MAX_LAST_ERROR_LENGTH);
}
function readState(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	const raw = value;
	if (!isNonEmptyString$1(raw.authorityKey) || raw.reason !== "pair-pending" && raw.reason !== "denied") return null;
	if (raw.reason === "pair-pending") {
		if (typeof raw.pausedUntil !== "number" || !Number.isFinite(raw.pausedUntil)) return null;
		return {
			authorityKey: raw.authorityKey,
			reason: raw.reason,
			pausedUntil: raw.pausedUntil,
			lastError: null
		};
	}
	return {
		authorityKey: raw.authorityKey,
		reason: raw.reason,
		pausedUntil: Number.POSITIVE_INFINITY,
		lastError: normalizeLastError(raw.lastError)
	};
}
function sanitizeStates(value) {
	if (!Array.isArray(value)) return null;
	const byAuthority = /* @__PURE__ */ new Map();
	for (const candidate of value) {
		const candidateAuthorityKey = candidate && typeof candidate === "object" && !Array.isArray(candidate) ? candidate.authorityKey : null;
		const state = readState(candidate);
		if (state === null) {
			if (isNonEmptyString$1(candidateAuthorityKey)) {
				byAuthority.set(candidateAuthorityKey, {
					authorityKey: candidateAuthorityKey,
					reason: "denied",
					pausedUntil: Number.POSITIVE_INFINITY,
					lastError: "connection gate state is malformed"
				});
				continue;
			}
			return null;
		}
		if (byAuthority.has(state.authorityKey)) byAuthority.set(state.authorityKey, {
			authorityKey: state.authorityKey,
			reason: "denied",
			pausedUntil: Number.POSITIVE_INFINITY,
			lastError: "connection gate state is ambiguous"
		});
		else byAuthority.set(state.authorityKey, state);
	}
	return [...byAuthority.values()].filter((state) => state !== null);
}
function readStoredSet$2(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return {
		kind: "known",
		set: emptySet$1()
	};
	const raw = value;
	if (Object.hasOwn(raw, "version")) {
		if (raw.version !== STORAGE_VERSION) return { kind: "future" };
		const states = sanitizeStates(raw.states);
		if (states === null) return { kind: "corrupt" };
		return {
			kind: "known",
			set: {
				version: STORAGE_VERSION,
				states
			}
		};
	}
	const legacy = readState({
		...raw,
		authorityKey: LOCAL_AUTHORITY_KEY$1
	});
	return {
		kind: "legacy",
		set: {
			version: STORAGE_VERSION,
			states: legacy === null ? [] : [legacy]
		}
	};
}
async function loadSet$1(forMutation) {
	const result = readStoredSet$2((await browser.storage.local.get(STORAGE_KEY$7))[STORAGE_KEY$7]);
	if (forMutation && result.kind === "future") throw new UnsupportedConnectionGateVersionError();
	if (forMutation && result.kind === "corrupt") throw new CorruptConnectionGateStateError();
	return result;
}
async function persistSet$1(set) {
	if (set.states.length === 0) {
		await browser.storage.local.remove(STORAGE_KEY$7);
		return;
	}
	await browser.storage.local.set({ [STORAGE_KEY$7]: set });
}
var UnsupportedConnectionGateVersionError = class extends Error {
	constructor() {
		super("connection gate version is unsupported");
	}
};
var CorruptConnectionGateStateError = class extends Error {
	constructor() {
		super("connection gate state is corrupt");
	}
};
var ConnectionGate = class ConnectionGate {
	authorityKey;
	constructor(...args) {
		const resolved = args.length === 0 ? LOCAL_BACKEND_AUTHORITY : args[0];
		assertBackendAuthority(resolved);
		this.authorityKey = backendAuthorityKey(resolved);
	}
	static forAuthority(authority) {
		return new ConnectionGate(authority);
	}
	async get() {
		return enqueueConnectionGateOperation(async () => {
			const result = await loadSet$1(false);
			if (result.kind === "future") return { ...CLOSED_UNSUPPORTED };
			if (result.kind === "corrupt") return { ...CLOSED_CORRUPT };
			if (result.kind === "legacy") await persistSet$1(result.set);
			const state = result.set.states.find(({ authorityKey }) => authorityKey === this.authorityKey);
			return state === void 0 ? { ...OPEN } : {
				reason: state.reason,
				pausedUntil: state.pausedUntil,
				lastError: state.lastError
			};
		});
	}
	async pausePending(ttlMs = DEFAULT_PAIR_PENDING_MS) {
		if (typeof ttlMs !== "number" || !Number.isFinite(ttlMs)) throw new TypeError("connection gate TTL must be finite");
		const state = {
			authorityKey: this.authorityKey,
			reason: "pair-pending",
			pausedUntil: nowMs() + ttlMs,
			lastError: null
		};
		await this.replace(state);
	}
	async pauseDenied(lastError) {
		const state = {
			authorityKey: this.authorityKey,
			reason: "denied",
			pausedUntil: Number.POSITIVE_INFINITY,
			lastError: normalizeLastError(lastError)
		};
		await this.replace(state);
	}
	async clear() {
		return enqueueConnectionGateOperation(async () => {
			const result = await loadSet$1(true);
			if (result.kind === "future") throw new UnsupportedConnectionGateVersionError();
			if (result.kind === "corrupt") throw new CorruptConnectionGateStateError();
			const states = result.set.states.filter(({ authorityKey }) => authorityKey !== this.authorityKey);
			if (states.length === result.set.states.length && result.kind !== "legacy") return;
			await persistSet$1({
				version: STORAGE_VERSION,
				states
			});
		});
	}
	/**
	* True iff this authority may auto-connect now (open, or an expired pending
	* gate). Expiry is observed without mutating storage so the caller can still
	* display the last durable state until its explicit retry clears it.
	*/
	async shouldAutoConnect() {
		const state = await this.get();
		if (state.reason === null) return true;
		if (state.reason === "denied") return false;
		return state.pausedUntil <= nowMs();
	}
	async replace(state) {
		return enqueueConnectionGateOperation(async () => {
			const result = await loadSet$1(true);
			if (result.kind === "future") throw new UnsupportedConnectionGateVersionError();
			if (result.kind === "corrupt") throw new CorruptConnectionGateStateError();
			const states = result.set.states.filter(({ authorityKey }) => authorityKey !== this.authorityKey);
			states.push(state);
			await persistSet$1({
				version: STORAGE_VERSION,
				states
			});
		});
	}
};
//#endregion
//#region src/background/EndpointCatalogService.ts
var backendAttemptMutationCapabilityBrand = Symbol("BackendAttemptMutationCapability");
var issuedBackendAttemptMutationCapabilities = /* @__PURE__ */ new WeakSet();
function assertBackendAttemptMutationCapability(capability) {
	if (typeof capability !== "object" || capability === null || !issuedBackendAttemptMutationCapabilities.has(capability)) throw new TypeError("backend attempt mutation capability was not issued");
}
var issuedAttemptLeases = /* @__PURE__ */ new WeakMap();
var endpointIncarnationGenerations = /* @__PURE__ */ new Map();
function endpointIncarnationGeneration(endpointId) {
	return endpointIncarnationGenerations.get(endpointId) ?? 0;
}
function invalidateEndpointIncarnation(endpointId) {
	const current = endpointIncarnationGeneration(endpointId);
	if (current === Number.MAX_SAFE_INTEGER) throw new Error("endpoint lifecycle incarnation is exhausted");
	endpointIncarnationGenerations.set(endpointId, current + 1);
}
var InvalidBackendAttemptLeaseError = class extends Error {
	constructor() {
		super("backend attempt lease was not issued by the lifecycle service");
	}
};
var StaleBackendAttemptLeaseError = class extends Error {
	constructor() {
		super("backend attempt lease is stale");
	}
};
var RemoteBackendAttemptRequiredError = class extends Error {
	constructor() {
		super("a ready backend is required");
	}
};
var EndpointCleanupPendingError = class extends Error {
	constructor() {
		super("server cleanup is still pending");
	}
};
/**
* Serializes catalogue mutations and couples them to credential cleanup.
* UI callers use intent-specific methods so a stale Popup cannot overwrite a
* Server added from Options merely by switching the active backend.
*/
var EndpointCatalogService = class {
	endpointConfigStore;
	endpointConfigWriter;
	createId;
	beforeConnectionChange;
	afterConnectionChange;
	coordinator;
	retireAuthority;
	constructor(endpointConfigStore, retirementService, options = {}) {
		this.endpointConfigStore = endpointConfigStore;
		this.endpointConfigWriter = endpointConfigStore.issueLifecycleWriter();
		this.createId = options.createId ?? (() => crypto.randomUUID());
		this.beforeConnectionChange = options.beforeConnectionChange ?? (() => void 0);
		this.afterConnectionChange = options.afterConnectionChange ?? (() => void 0);
		this.coordinator = options.coordinator ?? new BackendOperationCoordinator();
		this.retireAuthority = (authority) => retirementService.retire(authority);
	}
	/** Capture one immutable backend profile incarnation. The opaque lease is
	* useful across network awaits but proves nothing until revalidated below. */
	async issueBackendAttemptLease(endpointId) {
		return this.enqueue(async () => {
			const config = await this.endpointConfigStore.getForLifecycleMutation();
			const endpoint = endpointId === void 0 ? resolveActiveEndpoint(config) : resolveEndpointById(config, endpointId);
			if (endpoint === null || endpointId === void 0 && endpoint.mode === "local" && config.activeEndpointId !== "local") throw new RemoteBackendAttemptRequiredError();
			const lease = Object.freeze({ kind: "remote-backend-attempt-lease" });
			issuedAttemptLeases.set(lease, {
				endpointId: endpoint.mode === "local" ? LOCAL_ENDPOINT_ID : endpoint.endpointId,
				canonicalWsBase: endpoint.mode === "local" ? null : endpoint.remoteUrl,
				revision: endpoint.mode === "local" ? 0 : endpoint.revision,
				incarnationGeneration: endpointIncarnationGeneration(endpoint.mode === "local" ? LOCAL_ENDPOINT_ID : endpoint.endpointId)
			});
			return lease;
		});
	}
	/** Revalidate immediately before and for the full duration of one bounded
	* durable mutation. Catalogue edit/delete uses the same coordinator, so no
	* lifecycle change can slip between this check and the callback's write. */
	async runWithBackendAttemptLease(lease, operation) {
		return this.enqueue(async () => {
			const snapshot = typeof lease === "object" && lease !== null ? issuedAttemptLeases.get(lease) : void 0;
			if (snapshot === void 0) throw new InvalidBackendAttemptLeaseError();
			const config = await this.endpointConfigStore.getForLifecycleMutation();
			const endpoint = resolveEndpointById(config, snapshot.endpointId);
			if (endpoint === null || (endpoint.mode === "local" ? snapshot.canonicalWsBase !== null || snapshot.revision !== 0 : endpoint.remoteUrl !== snapshot.canonicalWsBase || endpoint.revision !== snapshot.revision) || endpointIncarnationGeneration(snapshot.endpointId) !== snapshot.incarnationGeneration) throw new StaleBackendAttemptLeaseError();
			const authority = endpoint.mode === "local" ? LOCAL_BACKEND_AUTHORITY : createRemoteBackendAuthority({
				endpointId: endpoint.endpointId,
				wsBase: endpoint.remoteUrl
			});
			return operation(Object.freeze({
				authority,
				endpointId: endpoint.mode === "local" ? LOCAL_ENDPOINT_ID : endpoint.endpointId,
				canonicalWsBase: endpoint.mode === "local" ? null : endpoint.remoteUrl,
				revision: endpoint.mode === "local" ? 0 : endpoint.revision
			}));
		});
	}
	bindBackendAttemptLease(lease, guard = () => void 0) {
		if (typeof lease !== "object" || lease === null || !issuedAttemptLeases.has(lease)) throw new InvalidBackendAttemptLeaseError();
		return new IssuedBackendAttemptMutationCapability(this, lease, guard);
	}
	async activate(endpointId) {
		return this.enqueue(async () => {
			const previous = await this.endpointConfigStore.getForLifecycleMutation();
			if (resolveEndpointById(previous, endpointId) === null) throw new Error(`unknown endpoint: ${endpointId}`);
			if (previous.activeEndpointId === endpointId) return {
				config: previous,
				activeChanged: false
			};
			await this.beforeConnectionChange();
			await this.endpointConfigWriter.set({
				...previous,
				activeEndpointId: endpointId
			});
			const config = await this.endpointConfigStore.getForLifecycleMutation();
			await this.afterConnectionChange();
			return {
				config,
				activeChanged: true
			};
		});
	}
	async addServer(input) {
		return this.enqueue(async () => {
			const previous = await this.endpointConfigStore.getForLifecycleMutation();
			const canonicalUrl = normalizeRemoteEndpoint(input.url);
			this.assertUrlAvailable(previous, canonicalUrl);
			const server = {
				id: this.createId(),
				name: input.name,
				url: canonicalUrl,
				revision: 0,
				state: "ready"
			};
			if (previous.servers.some(({ id }) => id === server.id)) throw new Error(`server id already exists: ${server.id}`);
			this.assertEndpointAvailable(previous, server.id, server.url);
			await this.endpointConfigWriter.set({
				...previous,
				servers: [...previous.servers, server]
			});
			const config = await this.endpointConfigStore.getForLifecycleMutation();
			const normalizedServer = config.servers.find(({ id }) => id === server.id);
			if (!normalizedServer) throw new Error("failed to add server");
			return {
				config,
				server: normalizedServer
			};
		});
	}
	async updateServer(endpointId, expected, changes) {
		return this.enqueue(async () => {
			const previous = await this.endpointConfigStore.getForLifecycleMutation();
			const existing = this.requireServer(previous, endpointId);
			this.assertExpected(existing, expected);
			this.assertMutable(existing);
			const canonicalUrl = normalizeRemoteEndpoint(changes.url);
			this.assertUrlAvailable(previous, canonicalUrl, endpointId);
			const urlChanged = normalizeRemoteEndpoint(existing.url) !== canonicalUrl;
			const active = previous.activeEndpointId === endpointId;
			const candidate = {
				...existing,
				name: changes.name,
				url: canonicalUrl
			};
			if (!urlChanged) {
				const servers = previous.servers.map((current) => current.id === endpointId ? candidate : current);
				await this.endpointConfigWriter.set({
					...previous,
					servers
				});
				const next = await this.endpointConfigStore.getForLifecycleMutation();
				return {
					config: next,
					server: this.requireServer(next, endpointId),
					urlChanged,
					active
				};
			}
			if (existing.revision === Number.MAX_SAFE_INTEGER) throw new Error("server revision is exhausted");
			if (active) await this.beforeConnectionChange();
			invalidateEndpointIncarnation(endpointId);
			await this.endpointConfigWriter.set(this.withPendingCleanup(previous, {
				...candidate,
				revision: existing.revision + 1,
				state: "cleanup-pending"
			}, {
				endpointId,
				canonicalWsBase: existing.url,
				invalidatedRevision: existing.revision
			}));
			await this.retireAuthority(createRemoteBackendAuthority({
				endpointId,
				wsBase: existing.url
			}));
			await this.endpointConfigWriter.set(this.finishCleanup(await this.endpointConfigStore.getForLifecycleMutation(), endpointId));
			const next = await this.endpointConfigStore.getForLifecycleMutation();
			if (active) await this.afterConnectionChange();
			return {
				config: next,
				server: this.requireServer(next, endpointId),
				urlChanged,
				active
			};
		});
	}
	async removeServer(endpointId, expected) {
		return this.enqueue(async () => {
			if (endpointId === "local") throw new Error("the local App endpoint cannot be removed");
			const previous = await this.endpointConfigStore.getForLifecycleMutation();
			const existing = this.requireServer(previous, endpointId);
			this.assertExpected(existing, expected);
			this.assertMutable(existing);
			const wasActive = previous.activeEndpointId === endpointId;
			if (wasActive) await this.beforeConnectionChange();
			invalidateEndpointIncarnation(endpointId);
			await this.endpointConfigWriter.set(this.withPendingCleanup(previous, null, {
				endpointId,
				canonicalWsBase: existing.url,
				invalidatedRevision: existing.revision
			}, wasActive ? LOCAL_ENDPOINT_ID : previous.activeEndpointId));
			await this.retireAuthority(createRemoteBackendAuthority({
				endpointId,
				wsBase: existing.url
			}));
			await this.endpointConfigWriter.set(this.finishCleanup(await this.endpointConfigStore.getForLifecycleMutation(), endpointId));
			return {
				config: await this.endpointConfigStore.getForLifecycleMutation(),
				wasActive
			};
		});
	}
	async recoverPendingCleanup() {
		return this.enqueue(async () => {
			let config = await this.endpointConfigStore.getForLifecycleMutation();
			for (const tombstone of config.cleanupTombstones) {
				await this.retireAuthority(createRemoteBackendAuthority({
					endpointId: tombstone.endpointId,
					wsBase: tombstone.canonicalWsBase
				}));
				config = this.finishCleanup(await this.endpointConfigStore.getForLifecycleMutation(), tombstone.endpointId);
				await this.endpointConfigWriter.set(config);
				config = await this.endpointConfigStore.getForLifecycleMutation();
			}
		});
	}
	withPendingCleanup(config, nextProfile, tombstone, activeEndpointId = config.activeEndpointId) {
		const cleanupTombstones = [...config.cleanupTombstones.filter((candidate) => candidate.endpointId !== tombstone.endpointId), tombstone];
		const servers = config.servers.filter(({ id }) => id !== tombstone.endpointId).concat(nextProfile === null ? [] : [nextProfile]);
		return {
			version: config.version,
			activeEndpointId,
			servers,
			cleanupTombstones
		};
	}
	finishCleanup(config, endpointId) {
		return {
			version: config.version,
			activeEndpointId: config.activeEndpointId,
			servers: config.servers.map((server) => server.id === endpointId && server.state === "cleanup-pending" ? {
				...server,
				state: "ready"
			} : server),
			cleanupTombstones: config.cleanupTombstones.filter((candidate) => candidate.endpointId !== endpointId)
		};
	}
	requireServer(config, endpointId) {
		const server = config.servers.find(({ id }) => id === endpointId);
		if (!server) throw new Error(`unknown endpoint: ${endpointId}`);
		return server;
	}
	assertExpected(actual, expected) {
		if (actual.name !== expected.name.trim() || normalizeRemoteEndpoint(actual.url) !== normalizeRemoteEndpoint(expected.url) || actual.revision !== expected.revision) throw new Error("server changed; refresh and try again");
	}
	assertMutable(server) {
		if (server.state !== "ready") throw new EndpointCleanupPendingError();
	}
	assertEndpointAvailable(config, endpointId, canonicalUrl) {
		if (endpointId !== "" && config.cleanupTombstones.some((candidate) => candidate.endpointId === endpointId)) throw new EndpointCleanupPendingError();
		if (config.cleanupTombstones.some((candidate) => candidate.canonicalWsBase === canonicalUrl)) throw new Error("server URL cleanup is still pending");
	}
	assertUrlAvailable(config, canonicalUrl, exceptEndpointId) {
		if (config.servers.some((candidate) => candidate.id !== exceptEndpointId && normalizeRemoteEndpoint(candidate.url) === canonicalUrl)) throw new Error("server URL is already configured");
		this.assertEndpointAvailable(config, exceptEndpointId ?? "", canonicalUrl);
	}
	enqueue(operation) {
		return this.coordinator.run(operation);
	}
};
var IssuedBackendAttemptMutationCapability = class {
	owner;
	lease;
	guard;
	[backendAttemptMutationCapabilityBrand] = true;
	constructor(owner, lease, guard) {
		this.owner = owner;
		this.lease = lease;
		this.guard = guard;
		issuedBackendAttemptMutationCapabilities.add(this);
	}
	run(operation) {
		return this.owner.runWithBackendAttemptLease(this.lease, async (attempt) => {
			this.guard(attempt);
			const result = await operation(attempt);
			this.guard(attempt);
			return result;
		});
	}
};
//#endregion
//#region src/background/mbp1/envelope.ts
/**
* MBP1 AEAD envelope (bridge-pairing-protocol.md §10).
*
* Active on `/pair` after §6.6 and on `/v1` after §8, in both directions, for
* every frame. MDXP JSON-RPC payload bytes are the plaintext, unchanged.
*
* ```
* frame  = seq64BE ‖ AES-256-GCM(key = k_dir, nonce, plaintext, aad)
* nonce  = dirTag(4 bytes BE) ‖ seq64BE          (12 bytes)
* dirTag = 0x00000001 (client→server) | 0x00000002 (server→client)
* aad    = "MBP1/env/v1" (ASCII, 11 bytes)
* ```
*
* `seq` starts at 0 per direction and increments by exactly 1 per frame. The
* receiver requires strict equality with its expected counter — no window —
* so replay protection *is* the strict sequence check: any gap, repeat, or
* GCM authentication failure is an `EnvelopeViolation` and MUST close the
* connection. The 1 MiB plaintext cap is enforced on both `seal` and `open`:
* a peer that holds the key could otherwise force unbounded buffering on the
* receive side by simply sending an oversized frame, so the cap has to be
* checked before this module ever asks WebCrypto to authenticate it.
*
* This module uses WebCrypto (`crypto.subtle`) for AES-256-GCM — permitted by
* §3 for symmetric primitives (curves must go through noble, never
* WebCrypto) — so its interface is necessarily async, unlike a `node:crypto`
* server-side implementation of the same envelope.
*
* `k_dir` (both direction keys) MUST NOT be logged at any level (§11), and
* nothing here persists or caches key material beyond the imported
* `CryptoKey` handles for the lifetime of one connection.
*/
/**
* Thrown by `seal`/`open` on any protocol-level envelope failure (§10). Every
* instance MUST close the connection — none of these reasons are recoverable
* in place, and §10 provides no in-place rekey in v1.
*
* **Closing and blaming are separate decisions.** Which method threw, not just
* `reason`, determines whether the peer is at fault:
*
* - From `open`, the frame came from the peer, so `malformedFrame`,
*   `oversizePlaintext`, `sequenceMismatch`, and `gcmAuthFailure` are the
*   peer's fault and are the §10 `envelopeViolation` closes.
* - From `seal`, the input came from *this* side. `oversizePlaintext` on
*   `seal` is a local caller handing us a frame over the 1 MiB cap — our bug,
*   never the peer's — so it MUST NOT be reported to the peer as
*   `envelopeViolation`.
*
* `usageBoundExceeded` is the exception, and it is **not** an
* `envelopeViolation` in either direction. The agreed cross-implementation
* contract is: both sides treat a usage-bound event as *close this connection
* and re-establish via §8 with fresh keys*, and **neither side reports it to
* the peer as a protocol violation.**
*
* - From `seal`: **we** exhausted our own outbound key. Nobody misbehaved.
*   Reporting it to the peer would accuse them of a fault that is ours.
* - From `open`: the **peer** kept sending past the point where §10 required it
*   to close and reconnect, so it did fail a MUST — but the frame itself is
*   well-formed and authentic (it passed the sequence check and GCM), §10 lists
*   only gap, repeat, and GCM failure as `envelopeViolation`, and the remedy is
*   the same reconnect either way. So: reconnect, don't accuse.
*
* The direction still changes what *happened*, which is why the message text
* differs; it no longer changes what the caller should do.
*
* **For the caller that turns these into wire behavior.** The error's shape is
* not what protects you here — the mapping layer is. Line A's server split this
* into a distinct error class and *still* collapsed it at its wire layer, where
* a fall-through closed with an internal-error code and a message reading like a
* server bug. So: switch on `reason`, map `usageBoundExceeded` to a reconnect
* rather than to a user-visible error state, and do not surface it as a failure.
* Expect a well-behaved peer to close with a code meaning "reconnect" rather
* than `1011`, but do not *depend* on the close code — our own outbound counter
* reaching the bound is sufficient signal on its own.
*/
var EnvelopeViolation = class extends Error {
	reason;
	constructor(reason, message) {
		super(message);
		this.name = "EnvelopeViolation";
		this.reason = reason;
	}
};
var DIR_TAG = {
	c2s: 1,
	s2c: 2
};
var AAD = utf8("MBP1/env/v1");
var SEQ_BYTES = 8;
var GCM_TAG_BYTES = 16;
var AES_BLOCK_BYTES = 16;
var MAX_PLAINTEXT_BYTES = 1048576;
/** §10: a direction MUST be closed and rekeyed before either bound is hit. */
var MAX_FRAMES_PER_DIRECTION = 2 ** 24;
var MAX_BLOCKS_PER_DIRECTION = 2 ** 30;
function blocksFor(plaintextByteLength) {
	return Math.ceil(plaintextByteLength / AES_BLOCK_BYTES);
}
/** Plain equality on two fixed-width, non-secret sequence encodings. */
function sequenceBytesEqual(a, b) {
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
/**
* WebCrypto's `BufferSource` requires a concrete `ArrayBuffer` backing
* store, but every byte value in this module — and in the `canonical.ts`
* encoders it composes with — is typed as plain `Uint8Array` (which this
* package's `Uint8Array<TArrayBuffer = ArrayBufferLike>` default leaves
* unpinned). None of them are ever constructed over a `SharedArrayBuffer`,
* so this narrows the type at the WebCrypto boundary without copying or
* changing runtime behavior.
*/
function asBufferSource(bytes) {
	return bytes;
}
async function importAesGcmKey(rawKey) {
	return crypto.subtle.importKey("raw", asBufferSource(rawKey), "AES-GCM", false, ["encrypt", "decrypt"]);
}
/**
* One side of one MBP1 secure-channel connection: seals its own outbound
* direction and opens the peer's inbound direction, each with strict,
* independently-tracked sequence counters and usage bounds. `role`
* determines the direction mapping (§10): the client seals `c2s` and opens
* `s2c`; the server seals `s2c` and opens `c2s`.
*/
var EnvelopeCodec = class EnvelopeCodec {
	outboundDirection;
	inboundDirection;
	outboundKey;
	inboundKey;
	outboundSeq = 0;
	outboundBlocks = 0;
	inboundSeq = 0;
	inboundBlocks = 0;
	constructor(outboundDirection, inboundDirection, outboundKey, inboundKey) {
		this.outboundDirection = outboundDirection;
		this.inboundDirection = inboundDirection;
		this.outboundKey = outboundKey;
		this.inboundKey = inboundKey;
	}
	static async create(keyC2S, keyS2C, role) {
		const importedC2S = await importAesGcmKey(keyC2S);
		const importedS2C = await importAesGcmKey(keyS2C);
		return role === "client" ? new EnvelopeCodec("c2s", "s2c", importedC2S, importedS2C) : new EnvelopeCodec("s2c", "c2s", importedS2C, importedC2S);
	}
	/** Seals `plaintext` on this codec's outbound direction, then advances its seq. */
	async seal(plaintext) {
		if (plaintext.length > MAX_PLAINTEXT_BYTES) throw new EnvelopeViolation("oversizePlaintext", `plaintext of ${plaintext.length} bytes exceeds the 1 MiB frame cap`);
		const blocks = blocksFor(plaintext.length);
		if (this.outboundSeq >= MAX_FRAMES_PER_DIRECTION || this.outboundBlocks + blocks > MAX_BLOCKS_PER_DIRECTION) throw new EnvelopeViolation("usageBoundExceeded", "outbound direction reached its 2^24-frame / 2^30-block usage bound; rekey required");
		const seqBytes = encU64BE(this.outboundSeq);
		const nonce = concatBytes$2(encU32BE(DIR_TAG[this.outboundDirection]), seqBytes);
		const ciphertext = new Uint8Array(await crypto.subtle.encrypt({
			name: "AES-GCM",
			iv: asBufferSource(nonce),
			additionalData: asBufferSource(AAD),
			tagLength: 128
		}, this.outboundKey, asBufferSource(plaintext)));
		this.outboundSeq += 1;
		this.outboundBlocks += blocks;
		return concatBytes$2(seqBytes, ciphertext);
	}
	/**
	* Opens `frame` on this codec's inbound direction. Requires `frame`'s
	* leading seq to equal the expected counter exactly (no window) before any
	* decryption is attempted, and rejects a plaintext over the 1 MiB cap from
	* the frame's declared length alone — before WebCrypto ever runs — so an
	* oversized frame cannot force this side to buffer or authenticate more
	* than the cap allows.
	*/
	async open(frame) {
		if (frame.length < 24) throw new EnvelopeViolation("malformedFrame", `frame of ${frame.length} bytes is too short for a seq + GCM tag`);
		const seqBytes = frame.slice(0, SEQ_BYTES);
		const ciphertext = frame.slice(SEQ_BYTES);
		const plaintextLength = ciphertext.length - GCM_TAG_BYTES;
		if (plaintextLength > MAX_PLAINTEXT_BYTES) throw new EnvelopeViolation("oversizePlaintext", `frame declares a plaintext of ${plaintextLength} bytes, exceeding the 1 MiB frame cap`);
		if (!sequenceBytesEqual(seqBytes, encU64BE(this.inboundSeq))) throw new EnvelopeViolation("sequenceMismatch", "frame seq does not equal the expected inbound counter (gap or repeat)");
		const blocks = blocksFor(plaintextLength);
		if (this.inboundSeq >= MAX_FRAMES_PER_DIRECTION || this.inboundBlocks + blocks > MAX_BLOCKS_PER_DIRECTION) throw new EnvelopeViolation("usageBoundExceeded", "inbound direction reached its 2^24-frame / 2^30-block usage bound; rekey required");
		const nonce = concatBytes$2(encU32BE(DIR_TAG[this.inboundDirection]), seqBytes);
		let plaintext;
		try {
			plaintext = await crypto.subtle.decrypt({
				name: "AES-GCM",
				iv: asBufferSource(nonce),
				additionalData: asBufferSource(AAD),
				tagLength: 128
			}, this.inboundKey, asBufferSource(ciphertext));
		} catch {
			throw new EnvelopeViolation("gcmAuthFailure", "GCM authentication failed (tampered ciphertext, wrong key, or wrong dirTag)");
		}
		this.inboundSeq += 1;
		this.inboundBlocks += blocks;
		return new Uint8Array(plaintext);
	}
};
//#endregion
//#region src/background/EnvelopeWebSocketStream.ts
var OPEN_STATE$1 = 1;
var CLOSED_STATE = 3;
var textEncoder = new TextEncoder();
var textDecoder$1 = new TextDecoder();
/**
* §11's usage-bound close code — the one §11 code inside the 1000/3000–4999
* range the WebSocket API lets a browser send (see the module doc).
*/
var WS_CLOSE_ENVELOPE_USAGE_LIMIT = 4001;
function closeIfOpen(ws, code) {
	if (ws.readyState === CLOSED_STATE) return;
	if (code === void 0) {
		ws.close();
		return;
	}
	ws.close(code);
}
/**
* The close code for an `EnvelopeViolation`, from either direction:
* `usageBoundExceeded` is §11's `4001`; everything else closes bare because
* the code §11 would assign (`1002` for a peer violation, `1011` for our own
* fault) is unsendable from a browser.
*/
function closeCodeFor(violation) {
	return violation.reason === "usageBoundExceeded" ? WS_CLOSE_ENVELOPE_USAGE_LIMIT : void 0;
}
var EnvelopeMessageReader = class {
	ws;
	envelope;
	preQueuedFrames;
	errorEmitter = new import_api.Emitter();
	closeEmitter = new import_api.Emitter();
	partialMessageEmitter = new import_api.Emitter();
	/** Serializes `envelope.open` calls — see the module doc. */
	enqueue = createOperationQueue();
	dataCallback = null;
	listening = false;
	disposed = false;
	/**
	* Messages already opened and parsed before `listen()` supplied a
	* callback to deliver them to. Decrypting cannot wait for `listen()` —
	* see the constructor's own doc — so a message that arrives in that
	* window is held here, in arrival order, until `listen()` flushes it.
	*/
	pendingMessages = [];
	messageListener = (ev) => {
		const data = ev.data;
		if (!(data instanceof ArrayBuffer)) {
			this.errorEmitter.fire(/* @__PURE__ */ new Error("unsupported WS frame type (expected binary)"));
			closeIfOpen(this.ws);
			return;
		}
		const frame = new Uint8Array(data);
		this.enqueue(() => this.handleFrame(frame));
	};
	closeListener = () => {
		this.closeEmitter.fire(void 0);
	};
	errorListener = () => {
		this.errorEmitter.fire(/* @__PURE__ */ new Error("WebSocket error event"));
	};
	/**
	* Listeners attach here, in the constructor, not in `listen()`. The
	* caller (`ConnectionManager.finishMbp1Connection`) awaits at least one
	* real `storage.local` write — `gate.pausePending()`, on the first-pair
	* path — between constructing this reader and calling `listen()` from
	* `doInitialize`. A proactive envelope-sealed frame from a peer that
	* behaved perfectly must not find the socket with no listener at all in
	* that gap; attaching here instead of in `listen()` closes it. Opening
	* cannot wait for `listen()` either, or the §10 sequence counter would
	* desync the moment a live frame is finally allowed to run ahead of one
	* still sitting on the wire — so a frame that arrives before `listen()`
	* is opened and parsed immediately, through the same `enqueue`d,
	* in-order path as always, and only its *delivery* waits, in
	* `pendingMessages`.
	*
	* `preQueuedFrames` are handed over from a pre-auth
	* `WebSocketFrameChannel.release()` — anything that arrived after the
	* flow's last `receive*()` call but before the socket was handed to this
	* reader. Enqueued here too, before the listener above can observe
	* anything new (event dispatch happens on a later turn of the event
	* loop), so they open strictly before whatever the listener picks up.
	*/
	constructor(ws, envelope, preQueuedFrames = []) {
		this.ws = ws;
		this.envelope = envelope;
		this.preQueuedFrames = preQueuedFrames;
		this.ws.addEventListener("message", this.messageListener);
		this.ws.addEventListener("close", this.closeListener);
		this.ws.addEventListener("error", this.errorListener);
		for (const frame of this.preQueuedFrames) this.enqueue(() => this.handleFrame(frame));
	}
	get onError() {
		return this.errorEmitter.event;
	}
	get onClose() {
		return this.closeEmitter.event;
	}
	get onPartialMessage() {
		return this.partialMessageEmitter.event;
	}
	listen(callback) {
		if (this.listening) throw new Error("EnvelopeMessageReader already listening");
		this.listening = true;
		this.dataCallback = callback;
		for (const message of this.pendingMessages.splice(0)) callback(message);
		return { dispose: () => this.dispose() };
	}
	dispose() {
		if (this.disposed) return;
		this.disposed = true;
		this.ws.removeEventListener("message", this.messageListener);
		this.ws.removeEventListener("close", this.closeListener);
		this.ws.removeEventListener("error", this.errorListener);
		this.dataCallback = null;
		this.errorEmitter.dispose();
		this.closeEmitter.dispose();
		this.partialMessageEmitter.dispose();
	}
	async handleFrame(frame) {
		let plaintext;
		try {
			plaintext = await this.envelope.open(frame);
		} catch (error) {
			if (error instanceof EnvelopeViolation) {
				this.errorEmitter.fire(/* @__PURE__ */ new Error(`envelope open failed: ${error.reason}`));
				closeIfOpen(this.ws, closeCodeFor(error));
				return;
			}
			this.errorEmitter.fire(error);
			return;
		}
		let parsed;
		try {
			parsed = JSON.parse(textDecoder$1.decode(plaintext));
		} catch (error) {
			this.errorEmitter.fire(/* @__PURE__ */ new Error(`failed to parse envelope plaintext: ${error.message}`));
			return;
		}
		if (this.dataCallback === null) {
			this.pendingMessages.push(parsed);
			return;
		}
		this.dataCallback(parsed);
	}
};
var EnvelopeMessageWriter = class {
	ws;
	envelope;
	errorEmitter = new import_api.Emitter();
	closeEmitter = new import_api.Emitter();
	/** Serializes `envelope.seal` calls — see the module doc. */
	enqueue = createOperationQueue();
	closeListener = () => {
		this.closeEmitter.fire(void 0);
	};
	attached = false;
	constructor(ws, envelope) {
		this.ws = ws;
		this.envelope = envelope;
		this.ws.addEventListener("close", this.closeListener);
		this.attached = true;
	}
	get onError() {
		return this.errorEmitter.event;
	}
	get onClose() {
		return this.closeEmitter.event;
	}
	async write(msg) {
		return this.enqueue(async () => {
			if (this.ws.readyState !== OPEN_STATE$1) {
				const error = /* @__PURE__ */ new Error(`WebSocket is closed (readyState=${this.ws.readyState})`);
				this.errorEmitter.fire([
					error,
					msg,
					void 0
				]);
				throw error;
			}
			let sealed;
			try {
				sealed = await this.envelope.seal(textEncoder.encode(JSON.stringify(msg)));
			} catch (error) {
				if (error instanceof EnvelopeViolation) {
					this.errorEmitter.fire([
						error,
						msg,
						void 0
					]);
					closeIfOpen(this.ws, closeCodeFor(error));
					throw error;
				}
				this.errorEmitter.fire([
					error,
					msg,
					void 0
				]);
				throw error;
			}
			try {
				this.ws.send(sealed);
			} catch (error) {
				this.errorEmitter.fire([
					error,
					msg,
					void 0
				]);
				throw error;
			}
		});
	}
	end() {
		if (this.ws.readyState === OPEN_STATE$1) this.ws.close();
	}
	dispose() {
		if (!this.attached) return;
		this.ws.removeEventListener("close", this.closeListener);
		this.attached = false;
		this.errorEmitter.dispose();
		this.closeEmitter.dispose();
	}
};
//#endregion
//#region src/background/log.ts
var PREFIX = "[motrix-ext]";
var current = DEFAULT_LOG_LEVEL;
/** Keep credentials, signed query strings, paths and fragments out of logs. */
function describeUrlForLog(value) {
	try {
		const parsed = new URL(value);
		return parsed.host ? `${parsed.protocol}//${parsed.host}` : `${parsed.protocol}<redacted>`;
	} catch {
		return "<invalid-url>";
	}
}
function emit(level, args) {
	if (LOG_LEVEL_RANK[level] > LOG_LEVEL_RANK[current]) return;
	const tag = `${PREFIX}[${level}]`;
	console[level](tag, ...args);
}
var log = {
	error: (...args) => emit("error", args),
	warn: (...args) => emit("warn", args),
	info: (...args) => emit("info", args),
	debug: (...args) => emit("debug", args),
	setLevel: (level) => {
		current = level;
	}
};
/** Read the persisted level into the cache. Call once at background startup. */
async function initLogLevel() {
	log.setLevel(await getLogLevel());
}
//#endregion
//#region src/background/mbp1/bridge-route.ts
/**
* Pure remote MBP1 route derivation.
*
* Routes are transport locations, never authenticated identity. The peer is
* trusted only after MBP1 succeeds and proves the pinned server identity.
*/
var BRIDGE_ROUTE_BRAND = Symbol("motrix.mbp1.bridge-route");
var issuedRoutes = /* @__PURE__ */ new WeakSet();
var CANONICAL_MBP1_PAIR_NONCE = /^[A-Za-z0-9_-]{21}[AQgw]$/u;
/** MBP1 v1 `/nonce` is the unpadded canonical base64url encoding of exactly
* 16 random bytes. The final alphabet restriction rejects alternate encodings
* whose unused low four bits are non-zero. */
function isCanonicalMbp1PairNonce(value) {
	return typeof value === "string" && CANONICAL_MBP1_PAIR_NONCE.test(value);
}
function normalizeAuthority(authority) {
	assertBackendAuthority(authority);
	if (authority.kind !== "remote") throw new Error("remote BridgeRoute requires a remote BackendAuthority");
	return createRemoteBackendAuthority({
		endpointId: authority.endpointId,
		wsBase: authority.canonicalWsBase
	});
}
/**
* Derive HTTP discovery/nonce and websocket reconnect endpoints from one
* canonical WS/WSS base. A reverse-proxy prefix remains part of every route.
*/
function deriveRemoteBridgeRoute(authority) {
	const normalized = normalizeAuthority(authority);
	const wsBase = normalized.canonicalWsBase;
	const websocketUrl = new URL(wsBase);
	const httpBase = `${websocketUrl.protocol === "wss:" ? "https:" : "http:"}${wsBase.slice(websocketUrl.protocol.length)}`;
	const route = Object.freeze({
		[BRIDGE_ROUTE_BRAND]: true,
		authority: normalized,
		discoveryUrl: `${httpBase}/discovery`,
		nonceUrl: `${httpBase}/nonce`,
		v1Url: `${wsBase}/v1`
	});
	issuedRoutes.add(route);
	return route;
}
/** Build the first-pair route. The query contains only the encoded nonce. */
function remotePairUrl(route, nonce) {
	if (!issuedRoutes.has(route) || route[BRIDGE_ROUTE_BRAND] !== true) throw new Error("BridgeRoute must be created by deriveRemoteBridgeRoute");
	const authority = normalizeAuthority(route.authority);
	if (!isCanonicalMbp1PairNonce(nonce)) throw new Error("MBP1 pair nonce is not canonical");
	return `${authority.canonicalWsBase}/pair?nonce=${nonce}`;
}
//#endregion
//#region src/background/mbp1/client-installation-id.ts
/**
* MBP1 `clientInstallationId` (bridge-pairing-protocol.md §6.4, §6.7).
*
* A random opaque tag for this extension *install*. It is a member of
* `Principal` (§6.7), a field of `pairHello` (§6.1), and one of the four
* strings bound into `A_id` — so it is inside the SPAKE2 transcript (§6.4).
* Its only job is to separate multiple installs or browser profiles of the
* same extension, which is what makes the post-authentication
* `prunePrincipalExcept` sound: a second profile is a *different* principal
* and pairs as its own credential instead of pruning the first profile's.
*
* It is client-chosen and unauthenticated. The server binds it into the
* transcript but never trusts it, so nothing here is a security decision.
*
* **Never derived from anything fingerprintable.** `crypto.randomUUID()` only —
* no hardware, locale, timezone, screen, user-agent or installation-time
* input. A derived value would turn a routing tag into a cross-site
* identifier, and it would also break the multi-profile story, since two
* profiles on one machine would derive the same tag and merge into one
* principal.
*
* ## Why first-write-wins has to be enforced by re-reading
*
* The naive shape — `get()`, and if absent generate and `set()` — races, and
* MV3 service workers really do get concurrent invocations. If two flows each
* generate a different id, one wins the write while the other may already have
* sent *its* id in `pairHello`. The transcript then binds an id that is not
* the persisted one, the next reconnect computes a different `principalKey`,
* and the credential just created is orphaned and permanently unreachable —
* the user's pairing silently stops working and no retry fixes it, because the
* stored credential can never be looked up again.
*
* So the whole `read → generate-if-absent → write` sequence runs inside one
* serialized critical section, with the read *inside* it. The queue is
* module-level rather than per-instance on purpose: a per-instance queue only
* serializes callers that happen to share an object, and the two racing flows
* here are independent call sites, not a shared store handle. There is
* deliberately no class to construct, so there is no way to accidentally
* create a second queue.
*
* After a first write the value is re-read and the *persisted* value returned.
* `storage.local` offers no compare-and-swap, so a second JS realm (an options
* page driving pairing directly, rather than messaging the service worker)
* could still clobber the write; re-reading narrows that residual window to
* the write itself and guarantees the returned id equals what storage held
* when the critical section ended, instead of returning a value that was
* already overwritten.
*
* The id is never cleared — not on unpair, not on "Forget". It identifies the
* install, not the pairing, and regenerating it would make every stored
* credential of the old principal unreachable, which is the same failure the
* serialization above exists to prevent.
*/
var STORAGE_KEY$6 = "motrix.mbp1.clientInstallationId";
/**
* A bound on the persisted value. `crypto.randomUUID()` is 36 characters; the
* cap only exists so a corrupted or oversized storage value cannot bloat every
* `A_id` and `principalKey` computation from then on.
*/
var MAX_ID_LENGTH = 128;
/**
* Accepts only a printable-ASCII, non-empty, bounded id.
*
* This is stricter than the wire's "ASCII string", and deliberately so: the
* only producer is `crypto.randomUUID()`, so a value with a space, a control
* character, or a byte >= 0x80 is storage corruption rather than a legitimate
* id worth preserving. Rejecting it here costs one regeneration; accepting it
* would throw out of `enc()` (§2 rejects non-ASCII) in the middle of a
* handshake, on every attempt, forever.
*/
function readStoredId(value) {
	if (!value || typeof value !== "object") return null;
	const stored = value;
	if (stored.version !== 1) return null;
	const id = stored.clientInstallationId;
	if (typeof id !== "string") return null;
	if (id.length === 0 || id.length > MAX_ID_LENGTH) return null;
	for (let i = 0; i < id.length; i++) {
		const code = id.charCodeAt(i);
		if (code < 33 || code > 126) return null;
	}
	return id;
}
async function read$1() {
	return readStoredId((await browser.storage.local.get(STORAGE_KEY$6))[STORAGE_KEY$6]);
}
async function write$1(clientInstallationId) {
	const stored = {
		version: 1,
		clientInstallationId
	};
	await browser.storage.local.set({ [STORAGE_KEY$6]: stored });
}
/**
* Module scope, not per instance: the racing callers here are independent call
* sites rather than holders of a shared object, so only a realm-wide queue
* closes the race. See `operation-queue.ts`.
*/
var enqueue$1 = createOperationQueue();
/**
* Returns this install's `clientInstallationId`, generating and persisting one
* on first use.
*
* Stable across service-worker restarts and browser restarts, and never
* regenerated while a usable value is present. Concurrent callers all receive
* the same id and exactly one write happens — see the module comment for why
* that is load-bearing rather than merely tidy.
*/
async function getClientInstallationId() {
	return enqueue$1(async () => {
		const existing = await read$1();
		if (existing !== null) return existing;
		const generated = crypto.randomUUID();
		await write$1(generated);
		return await read$1() ?? generated;
	});
}
//#endregion
//#region src/background/mbp1/credential-store.ts
/**
* Durable MBP1 client credentials (bridge-pairing-protocol.md §6.7, §12).
*
* The wire principal identifies the browser profile. `BackendAuthority` is a
* separate, client-local namespace which prevents two Motrix backends from
* sharing credentials for that principal. Authentication stays below MDXP;
* neither the authority nor its storage key is added to the MBP1 transcript.
*
* Every operation is serialized by one module-level queue. This is deliberate:
* browser wiring should create one root store, but an accidental second root
* must not turn two read-modify-write operations into a lost update.
*/
var credentialLifecycleStoreBrand = Symbol("CredentialLifecycleStore");
var STORAGE_KEY$5 = "motrix.mbp1.credentials";
var PROVISIONAL_TTL_MS = 6e5;
var MAX_INSTANCE_ID_LENGTH$3 = 128;
var ACTIVE_KEY_DOMAIN = "MBP1/credential-active/v2";
var enqueueCredentialOperation = createOperationQueue();
var LOCAL_AUTHORITY_KEY = backendAuthorityKey(LOCAL_BACKEND_AUTHORITY);
var issuedCredentialLifecycleStores = /* @__PURE__ */ new WeakSet();
/**
* Process-local lifecycle fence. Durable endpoint state remains the
* coordinator's responsibility, but this closes the in-realm queue race:
* work issued by a stale authority view can never run after Forget finishes.
*/
var authorityRevocationStates = /* @__PURE__ */ new Map();
function authorityRevocationState(authorityKey) {
	return authorityRevocationStates.get(authorityKey) ?? {
		generation: 0,
		revoking: false
	};
}
function beginAuthorityRevocation(authorityKey) {
	const generation = authorityRevocationState(authorityKey).generation + 1;
	authorityRevocationStates.set(authorityKey, {
		generation,
		revoking: true
	});
	return generation;
}
function finishAuthorityRevocation(authorityKey, generation) {
	if (authorityRevocationState(authorityKey).generation !== generation) return;
	authorityRevocationStates.set(authorityKey, {
		generation,
		revoking: false
	});
}
/** Stable, injective storage key for a wire principal. */
function principalKey(p) {
	return b64uEncode(concatBytes$2(enc(p.browser), enc(p.verifiedOrigin), enc(p.clientInstallationId)));
}
/** Stable, injective map key for `{authorityKey, principalKey}`. */
function activeCredentialMapKey(authorityKey, ownerPrincipalKey) {
	return b64uEncode(concatBytes$2(enc(ACTIVE_KEY_DOMAIN), enc(authorityKey), enc(ownerPrincipalKey)));
}
function tupleKey(left, right) {
	return JSON.stringify([left, right]);
}
function isNonEmptyString(value) {
	return typeof value === "string" && value.length > 0;
}
function isEncodableNonEmptyString(value) {
	if (!isNonEmptyString(value)) return false;
	try {
		enc(value);
		return true;
	} catch {
		return false;
	}
}
function isNullableInstanceId(value) {
	return value === null || isEncodableNonEmptyString(value) && value.length <= MAX_INSTANCE_ID_LENGTH$3;
}
/** Read the state-machine fields shared by v1 and v2. */
function readCredentialBase(value) {
	if (!value || typeof value !== "object") return null;
	const raw = value;
	if (!isNonEmptyString(raw.credentialId) || !isNonEmptyString(raw.mutualKey) || !isEncodableNonEmptyString(raw.principalKey) || typeof raw.createdAt !== "number" || !Number.isFinite(raw.createdAt)) return null;
	const base = {
		credentialId: raw.credentialId,
		mutualKey: raw.mutualKey,
		principalKey: raw.principalKey,
		createdAt: raw.createdAt
	};
	if (raw.state === "committed") return {
		...base,
		state: "committed"
	};
	if (raw.state === "provisional" && (raw.sub === "unacked" || raw.sub === "commit-uncertain")) return {
		...base,
		state: "provisional",
		sub: raw.sub
	};
	return null;
}
function readV2Credential(value) {
	const base = readCredentialBase(value);
	if (base === null || !value || typeof value !== "object") return null;
	const raw = value;
	if (!isEncodableNonEmptyString(raw.authorityKey) || !isNullableInstanceId(raw.authenticatedInstanceId)) return null;
	if (raw.authorityKey !== LOCAL_AUTHORITY_KEY && raw.authenticatedInstanceId === null) return null;
	return {
		...base,
		authorityKey: raw.authorityKey,
		authenticatedInstanceId: raw.authenticatedInstanceId
	};
}
/**
* Parse entries independently. If persisted data contains two rows for the
* same `{authority, credentialId}`, both are dropped: choosing one could pick
* attacker-controlled key material. An unrelated valid entry still survives.
*/
function readV2Set(value) {
	if (!Array.isArray(value.credentials) || !value.activeCredentialIds || typeof value.activeCredentialIds !== "object" || Array.isArray(value.activeCredentialIds)) return null;
	const byIdentity = /* @__PURE__ */ new Map();
	const rawCredentials = value.credentials;
	for (const raw of rawCredentials) {
		const credential = readV2Credential(raw);
		if (credential === null) continue;
		const identity = tupleKey(credential.authorityKey, credential.credentialId);
		if (byIdentity.has(identity)) byIdentity.set(identity, null);
		else byIdentity.set(identity, credential);
	}
	const credentials = [...byIdentity.values()].filter((credential) => credential !== null);
	const rawActiveCredentialIds = value.activeCredentialIds;
	const activeCredentialIds = {};
	for (const credential of credentials) {
		if (credential.state !== "committed") continue;
		const key = activeCredentialMapKey(credential.authorityKey, credential.principalKey);
		if (rawActiveCredentialIds[key] === credential.credentialId) activeCredentialIds[key] = credential.credentialId;
	}
	return sanitizeSet({
		version: 2,
		credentials,
		activeCredentialIds
	});
}
/** Safely migrates every provable v1 credential into the local authority. */
function readV1Set(value) {
	const legacy = value;
	const byId = /* @__PURE__ */ new Map();
	const rawCredentials = Array.isArray(legacy.credentials) ? legacy.credentials : [];
	for (const raw of rawCredentials) {
		const credential = readCredentialBase(raw);
		if (credential === null) continue;
		if (byId.has(credential.credentialId)) byId.set(credential.credentialId, null);
		else byId.set(credential.credentialId, credential);
	}
	const credentials = [...byId.values()].filter((credential) => credential !== null).map((credential) => ({
		...credential,
		authorityKey: LOCAL_AUTHORITY_KEY,
		authenticatedInstanceId: null
	}));
	const activeCredentialIds = {};
	if (isNonEmptyString(legacy.activeCredentialId)) {
		const target = credentials.find((credential) => credential.credentialId === legacy.activeCredentialId && credential.state === "committed");
		if (target !== void 0) activeCredentialIds[activeCredentialMapKey(LOCAL_AUTHORITY_KEY, target.principalKey)] = target.credentialId;
	}
	return {
		version: 2,
		credentials,
		activeCredentialIds
	};
}
function readStoredSet$1(value, present) {
	if (!present) return {
		kind: "known",
		set: emptySet()
	};
	if (!value || typeof value !== "object" || Array.isArray(value)) return { kind: "corrupt" };
	const raw = value;
	if (raw.version === 2) {
		const set = readV2Set(raw);
		return set === null ? { kind: "corrupt" } : {
			kind: "known",
			set
		};
	}
	if (raw.version === 1) return {
		kind: "legacy",
		set: readV1Set(raw)
	};
	if (Object.hasOwn(raw, "version")) return { kind: "future" };
	return { kind: "corrupt" };
}
function emptySet() {
	return {
		version: 2,
		credentials: [],
		activeCredentialIds: {}
	};
}
function sanitizeSet(set) {
	const activeCredentialIds = {};
	for (const credential of set.credentials) {
		if (credential.state !== "committed") continue;
		const mapKey = activeCredentialMapKey(credential.authorityKey, credential.principalKey);
		if (set.activeCredentialIds[mapKey] === credential.credentialId) activeCredentialIds[mapKey] = credential.credentialId;
	}
	return {
		version: 2,
		credentials: set.credentials,
		activeCredentialIds
	};
}
async function persistSet(set) {
	const stored = sanitizeSet(set);
	if (stored.credentials.length === 0) {
		await browser.storage.local.remove(STORAGE_KEY$5);
		return;
	}
	await browser.storage.local.set({ [STORAGE_KEY$5]: stored });
}
/**
* Reads and, when necessary, atomically migrates v1. A future version returns
* no data to readers and throws before every mutation, preserving its bytes.
*/
async function loadSet(forMutation) {
	const storedObject = await browser.storage.local.get(STORAGE_KEY$5);
	const result = readStoredSet$1(storedObject[STORAGE_KEY$5], Object.hasOwn(storedObject, STORAGE_KEY$5));
	if (result.kind === "future") {
		if (forMutation) throw new UnsupportedCredentialStoreVersionError();
		return null;
	}
	if (result.kind === "corrupt") {
		if (forMutation) throw new CorruptCredentialStoreError();
		return null;
	}
	if (result.kind === "legacy") await persistSet(result.set);
	return result.set;
}
/** Fixed protocol error; the credential id and key never enter its message. */
var CredentialCollisionError = class extends Error {
	constructor() {
		super("credential offer conflicts with existing credential metadata");
	}
};
/** Fixed fail-closed error for a record written by an unknown version. */
var UnsupportedCredentialStoreVersionError = class extends Error {
	constructor() {
		super("credential store version is unsupported");
	}
};
/** Fixed fail-closed error for a malformed current-version container. */
var CorruptCredentialStoreError = class extends Error {
	constructor() {
		super("credential store is corrupt");
	}
};
/** Fixed protocol error; the authenticated identity never enters its message. */
var CredentialInstanceMismatchError = class extends Error {
	constructor() {
		super("authenticated server instance conflicts with credential metadata");
	}
};
/** A stale authority view attempted to write after an authority revocation. */
var CredentialAuthorityRevokedError = class extends Error {
	constructor() {
		super("credential authority view is stale or being revoked");
	}
};
/** A split finalize/prune caller no longer owns the active credential slot. */
var CredentialFinalizeConflictError = class extends Error {
	constructor() {
		super("credential finalize no longer owns the active slot");
	}
};
var OfferContradictsSlotError = class extends Error {};
function isUnacked(c) {
	return c.state === "provisional" && c.sub === "unacked";
}
function isCommitUncertain(c) {
	return c.state === "provisional" && c.sub === "commit-uncertain";
}
function newestFirst(a, b) {
	return b.createdAt - a.createdAt;
}
function validateAuthenticatedInstanceId(remote, authenticatedInstanceId) {
	if (!isNullableInstanceId(authenticatedInstanceId) || remote && authenticatedInstanceId === null) throw new Error("authenticated instance id is required for remote authority");
}
function assertAuthorityInstanceContinuity(set, authorityKey, remote, authenticatedInstanceId) {
	if (!remote) return;
	for (const credential of set.credentials) if (credential.authorityKey === authorityKey && credential.authenticatedInstanceId !== authenticatedInstanceId) throw new CredentialInstanceMismatchError();
}
function authorityHasInstanceConflict(set, authorityKey) {
	let instanceId = null;
	for (const credential of set.credentials) {
		if (credential.authorityKey !== authorityKey) continue;
		if (instanceId === null) instanceId = credential.authenticatedInstanceId;
		else if (credential.authenticatedInstanceId !== instanceId) return true;
	}
	return false;
}
function publicCredential(credential) {
	const base = {
		credentialId: credential.credentialId,
		mutualKey: credential.mutualKey,
		principalKey: credential.principalKey,
		state: credential.state,
		createdAt: credential.createdAt,
		authenticatedInstanceId: credential.authenticatedInstanceId
	};
	if (credential.state === "provisional" && credential.sub !== void 0) return {
		...base,
		sub: credential.sub
	};
	return base;
}
/** A scoped view. It owns no queue; all views use the module queue above. */
var authorityCredentialStoreIssuance = Symbol("AuthorityCredentialStore");
var AuthorityCredentialStore = class {
	[credentialLifecycleStoreBrand] = true;
	authorityKey;
	remote;
	authorityGeneration;
	constructor(authority, issuance) {
		if (issuance !== authorityCredentialStoreIssuance) throw new TypeError("authority credential store was not issued");
		this.authorityKey = backendAuthorityKey(authority);
		this.remote = authority.kind === "remote";
		const revocation = authorityRevocationState(this.authorityKey);
		this.authorityGeneration = revocation.revoking ? -1 : revocation.generation;
		issuedCredentialLifecycleStores.add(this);
	}
	assertWritableAuthority() {
		const revocation = authorityRevocationState(this.authorityKey);
		if (revocation.revoking || revocation.generation !== this.authorityGeneration) throw new CredentialAuthorityRevokedError();
	}
	async writeProvisionalUnacked(principal, cred, authenticatedInstanceId) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			validateAuthenticatedInstanceId(this.remote, authenticatedInstanceId);
			assertAuthorityInstanceContinuity(set, this.authorityKey, this.remote, authenticatedInstanceId);
			const existing = set.credentials.find((credential) => credential.authorityKey === this.authorityKey && credential.credentialId === cred.credentialId);
			if (existing !== void 0) {
				if (existing.principalKey === key && existing.mutualKey === cred.mutualKey && existing.authenticatedInstanceId === authenticatedInstanceId) return;
				throw new CredentialCollisionError();
			}
			const mine = set.credentials.filter((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key);
			const committed = mine.find((credential) => credential.state === "committed");
			const staleCommitUncertain = mine.find((credential) => isCommitUncertain(credential) && Date.now() - credential.createdAt > PROVISIONAL_TTL_MS);
			const liveCommitUncertain = mine.find((credential) => isCommitUncertain(credential) && Date.now() - credential.createdAt <= PROVISIONAL_TTL_MS);
			if (committed === void 0 && liveCommitUncertain !== void 0) throw new OfferContradictsSlotError("credentialOffer contradicts a live commit-uncertain slot");
			const credentials = set.credentials.filter((credential) => {
				if (credential.authorityKey !== this.authorityKey || credential.principalKey !== key) return true;
				if (isUnacked(credential)) return false;
				if (committed === void 0 && credential === staleCommitUncertain) return false;
				return true;
			});
			credentials.push({
				authorityKey: this.authorityKey,
				credentialId: cred.credentialId,
				mutualKey: cred.mutualKey,
				principalKey: key,
				state: "provisional",
				sub: "unacked",
				createdAt: Date.now(),
				authenticatedInstanceId
			});
			await persistSet({
				...set,
				credentials
			});
		});
	}
	async markCommitUncertain(credentialId) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			const index = set.credentials.findIndex((credential) => credential.authorityKey === this.authorityKey && credential.credentialId === credentialId);
			const target = set.credentials[index];
			if (target === void 0) throw new Error("markCommitUncertain: unknown credential");
			if (this.remote && target.authenticatedInstanceId === null) throw new CredentialInstanceMismatchError();
			assertAuthorityInstanceContinuity(set, this.authorityKey, this.remote, target.authenticatedInstanceId);
			if (target.state === "committed" || target.sub === "commit-uncertain") return;
			const credentials = [...set.credentials];
			credentials[index] = {
				...target,
				sub: "commit-uncertain"
			};
			await persistSet({
				...set,
				credentials
			});
		});
	}
	async commitAndActivate(credentialId, principal, authenticatedInstanceId) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			validateAuthenticatedInstanceId(this.remote, authenticatedInstanceId);
			const index = set.credentials.findIndex((credential) => credential.authorityKey === this.authorityKey && credential.credentialId === credentialId);
			const target = set.credentials[index];
			if (target === void 0) throw new Error("commitAndActivate: unknown credential");
			if (target.principalKey !== key) throw new Error("commitAndActivate: credential belongs to another principal");
			if (target.authenticatedInstanceId !== null && target.authenticatedInstanceId !== authenticatedInstanceId) throw new CredentialInstanceMismatchError();
			const storedInstanceId = target.authenticatedInstanceId ?? authenticatedInstanceId;
			validateAuthenticatedInstanceId(this.remote, storedInstanceId);
			assertAuthorityInstanceContinuity(set, this.authorityKey, this.remote, storedInstanceId);
			const credentials = [...set.credentials];
			credentials[index] = {
				authorityKey: target.authorityKey,
				credentialId: target.credentialId,
				mutualKey: target.mutualKey,
				principalKey: target.principalKey,
				state: "committed",
				createdAt: target.createdAt,
				authenticatedInstanceId: storedInstanceId
			};
			const activeCredentialIds = { ...set.activeCredentialIds };
			activeCredentialIds[activeCredentialMapKey(this.authorityKey, target.principalKey)] = target.credentialId;
			await persistSet({
				version: 2,
				credentials,
				activeCredentialIds
			});
		});
	}
	/**
	* Authenticated finalize and §12 prune in one queue transaction and one
	* durable write. `beforeDelete` runs while every soon-to-be-deleted
	* credential is still present, preserving the pins-first crash ordering.
	*/
	async finalizeAndPrune(credentialId, principal, authenticatedInstanceId, beforeDelete) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			validateAuthenticatedInstanceId(this.remote, authenticatedInstanceId);
			const target = set.credentials.find((credential) => credential.authorityKey === this.authorityKey && credential.credentialId === credentialId);
			if (target === void 0) throw new Error("finalizeAndPrune: unknown credential");
			if (target.principalKey !== key) throw new Error("finalizeAndPrune: credential belongs to another principal");
			if (target.authenticatedInstanceId !== null && target.authenticatedInstanceId !== authenticatedInstanceId) throw new CredentialInstanceMismatchError();
			const storedInstanceId = target.authenticatedInstanceId ?? authenticatedInstanceId;
			validateAuthenticatedInstanceId(this.remote, storedInstanceId);
			assertAuthorityInstanceContinuity(set, this.authorityKey, this.remote, storedInstanceId);
			const pruned = set.credentials.filter((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key && credential.credentialId !== credentialId).map((credential) => credential.credentialId);
			await beforeDelete?.(Object.freeze([...pruned]));
			const committedTarget = {
				authorityKey: target.authorityKey,
				credentialId: target.credentialId,
				mutualKey: target.mutualKey,
				principalKey: target.principalKey,
				state: "committed",
				createdAt: target.createdAt,
				authenticatedInstanceId: storedInstanceId
			};
			const credentials = set.credentials.flatMap((credential) => {
				if (credential.authorityKey !== this.authorityKey || credential.principalKey !== key) return [credential];
				return credential.credentialId === credentialId ? [committedTarget] : [];
			});
			const activeCredentialIds = { ...set.activeCredentialIds };
			activeCredentialIds[activeCredentialMapKey(this.authorityKey, key)] = credentialId;
			await persistSet({
				version: 2,
				credentials,
				activeCredentialIds
			});
			return pruned;
		});
	}
	async prunePrincipalExcept(principal, keepCredentialId, beforeDelete) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			const credentials = [];
			const pruned = [];
			for (const credential of set.credentials) if (credential.authorityKey === this.authorityKey && credential.principalKey === key && credential.credentialId !== keepCredentialId) pruned.push(credential.credentialId);
			else credentials.push(credential);
			if (pruned.length === 0) return pruned;
			const keep = set.credentials.find((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key && credential.credentialId === keepCredentialId);
			const activeId = set.activeCredentialIds[activeCredentialMapKey(this.authorityKey, key)] ?? null;
			if (keep?.state !== "committed" || activeId !== keepCredentialId) throw new CredentialFinalizeConflictError();
			await beforeDelete?.(Object.freeze([...pruned]));
			await persistSet({
				...set,
				credentials
			});
			return pruned;
		});
	}
	async recoverOrder(principal) {
		return enqueueCredentialOperation(async () => {
			const key = principalKey(principal);
			const set = await loadSet(false);
			if (set === null) return [];
			if (this.remote && authorityHasInstanceConflict(set, this.authorityKey)) return [];
			const mine = set.credentials.filter((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key && (!this.remote || credential.authenticatedInstanceId !== null));
			const activeId = set.activeCredentialIds[activeCredentialMapKey(this.authorityKey, key)] ?? null;
			const ordered = [];
			const taken = /* @__PURE__ */ new Set();
			const take = (candidates) => {
				for (const candidate of candidates) {
					if (taken.has(candidate.credentialId)) continue;
					taken.add(candidate.credentialId);
					ordered.push(candidate);
				}
			};
			take(mine.filter((credential) => credential.credentialId === activeId));
			take(mine.filter(isCommitUncertain).sort(newestFirst));
			take(mine.filter((credential) => credential.state === "committed").sort(newestFirst));
			take(mine.filter((credential) => credential.state === "provisional").sort(newestFirst));
			return ordered.map(publicCredential);
		});
	}
	async hasCommittedCredential(principal) {
		return enqueueCredentialOperation(async () => {
			const key = principalKey(principal);
			const set = await loadSet(false);
			if (set === null) return false;
			if (this.remote && authorityHasInstanceConflict(set, this.authorityKey)) return false;
			return set.credentials.some((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key && (!this.remote || credential.authenticatedInstanceId !== null) && credential.state === "committed");
		});
	}
	async revokeAll(principal, beforeDelete) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			const credentials = [];
			const revoked = [];
			for (const credential of set.credentials) if (credential.authorityKey === this.authorityKey && credential.principalKey === key) revoked.push(credential.credentialId);
			else credentials.push(credential);
			if (revoked.length === 0) return revoked;
			await beforeDelete?.(Object.freeze([...revoked]));
			await persistSet({
				...set,
				credentials
			});
			return revoked;
		});
	}
	/**
	* Removes every principal in this authority, leaving other authorities.
	*
	* The generation is advanced synchronously, before this operation joins the
	* module queue. Thus a write already waiting in the queue observes a stale
	* view and cannot land after the deletion. A new lifecycle must acquire a
	* fresh authority view after this promise settles.
	*/
	revokeAuthority(beforeDelete) {
		const revocationGeneration = beginAuthorityRevocation(this.authorityKey);
		return enqueueCredentialOperation(async () => {
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			const credentials = [];
			const revoked = [];
			for (const credential of set.credentials) if (credential.authorityKey === this.authorityKey) revoked.push(credential.credentialId);
			else credentials.push(credential);
			if (revoked.length > 0) await beforeDelete?.(Object.freeze([...revoked]));
			await persistSet({
				...set,
				credentials
			});
			finishAuthorityRevocation(this.authorityKey, revocationGeneration);
			return revoked;
		});
	}
	async ageOutUnacked(now) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			const credentials = set.credentials.filter((credential) => !(credential.authorityKey === this.authorityKey && isUnacked(credential) && now - credential.createdAt > PROVISIONAL_TTL_MS));
			if (credentials.length === set.credentials.length) return;
			await persistSet({
				...set,
				credentials
			});
		});
	}
	async cleanupFirstPairOrphans(principal, now) {
		this.assertWritableAuthority();
		return enqueueCredentialOperation(async () => {
			this.assertWritableAuthority();
			const key = principalKey(principal);
			const set = await loadSet(true);
			if (set === null) throw new UnsupportedCredentialStoreVersionError();
			if (set.credentials.some((credential) => credential.authorityKey === this.authorityKey && credential.principalKey === key && credential.state === "committed")) return;
			const credentials = set.credentials.filter((credential) => !(credential.authorityKey === this.authorityKey && credential.principalKey === key && isCommitUncertain(credential) && now - credential.createdAt > PROVISIONAL_TTL_MS));
			if (credentials.length === set.credentials.length) return;
			await persistSet({
				...set,
				credentials
			});
		});
	}
};
/** Nominal lifecycle facade that re-enters a profile lease immediately before
* every durable credential mutation. It exposes no recovery/read helpers, so
* remote orchestration cannot accidentally retain an unguarded write view. */
var BoundaryCredentialLifecycleStore = class {
	inner;
	boundary;
	[credentialLifecycleStoreBrand] = true;
	constructor(inner, boundary) {
		this.inner = inner;
		this.boundary = boundary;
		issuedCredentialLifecycleStores.add(this);
	}
	writeProvisionalUnacked(principal, cred, authenticatedInstanceId) {
		return this.boundary.run(() => this.inner.writeProvisionalUnacked(principal, cred, authenticatedInstanceId));
	}
	markCommitUncertain(credentialId) {
		return this.boundary.run(() => this.inner.markCommitUncertain(credentialId));
	}
	commitAndActivate(credentialId, principal, authenticatedInstanceId) {
		return this.boundary.run(() => this.inner.commitAndActivate(credentialId, principal, authenticatedInstanceId));
	}
	finalizeAndPrune(credentialId, principal, authenticatedInstanceId, beforeDelete) {
		return this.boundary.run(() => this.inner.finalizeAndPrune(credentialId, principal, authenticatedInstanceId, beforeDelete));
	}
	prunePrincipalExcept(principal, keepCredentialId, beforeDelete) {
		return this.boundary.run(() => this.inner.prunePrincipalExcept(principal, keepCredentialId, beforeDelete));
	}
	recoverOrder(principal) {
		return this.boundary.run(() => this.inner.recoverOrder(principal));
	}
	hasCommittedCredential(principal) {
		return this.boundary.run(() => this.inner.hasCommittedCredential(principal));
	}
	revokeAll(principal, beforeDelete) {
		return this.boundary.run(() => this.inner.revokeAll(principal, beforeDelete));
	}
	ageOutUnacked(now) {
		return this.boundary.run(() => this.inner.ageOutUnacked(now));
	}
	cleanupFirstPairOrphans(principal, now) {
		return this.boundary.run(() => this.inner.cleanupFirstPairOrphans(principal, now));
	}
};
function issueAuthorityCredentialStore(authority) {
	return new AuthorityCredentialStore(authority, authorityCredentialStoreIssuance);
}
/** Root facade. Production connection flows can obtain only a nominal,
* lease-bound attempt view; intent-specific status/revoke helpers never expose
* a retained raw authority writer. */
var CredentialStore = class {
	local = issueAuthorityCredentialStore(LOCAL_BACKEND_AUTHORITY);
	/** Raw storage-core fixture view. Production source is forbidden from
	* calling it by scripts/check-imports.mjs. */
	forAuthorityForTest(authority) {
		return issueAuthorityCredentialStore(authority);
	}
	forAttempt(authority, boundary) {
		assertBackendAttemptMutationCapability(boundary);
		return new BoundaryCredentialLifecycleStore(issueAuthorityCredentialStore(authority), boundary);
	}
	async hasCommittedCredentialForAuthority(authority, principal) {
		return issueAuthorityCredentialStore(authority).hasCommittedCredential(principal);
	}
	async revokePrincipalForAuthority(authority, principal, beforeDelete) {
		return issueAuthorityCredentialStore(authority).revokeAll(principal, beforeDelete);
	}
	async revokeAuthority(authority, beforeDelete) {
		return issueAuthorityCredentialStore(authority).revokeAuthority(beforeDelete);
	}
	/** @deprecated Local-only compatibility facade. */
	async writeProvisionalUnacked(principal, cred, authenticatedInstanceId = null) {
		return this.local.writeProvisionalUnacked(principal, cred, authenticatedInstanceId);
	}
	/** @deprecated Local-only compatibility facade. */
	async markCommitUncertain(credentialId) {
		return this.local.markCommitUncertain(credentialId);
	}
	/** @deprecated Local-only compatibility facade. */
	async commitAndActivate(credentialId, principal, authenticatedInstanceId = null) {
		return this.local.commitAndActivate(credentialId, principal, authenticatedInstanceId);
	}
	/** @deprecated Local-only compatibility facade. */
	async prunePrincipalExcept(principal, keepCredentialId, beforeDelete) {
		return this.local.prunePrincipalExcept(principal, keepCredentialId, beforeDelete);
	}
	/** @deprecated Local-only compatibility facade. */
	async recoverOrder(principal) {
		return this.local.recoverOrder(principal);
	}
	/** @deprecated Local-only compatibility facade. */
	async hasCommittedCredential(principal) {
		return this.local.hasCommittedCredential(principal);
	}
	/** @deprecated Local-only compatibility facade. */
	async revokeAll(principal, beforeDelete) {
		return this.local.revokeAll(principal, beforeDelete);
	}
	/** @deprecated Local-only compatibility facade. */
	async ageOutUnacked(now) {
		return this.local.ageOutUnacked(now);
	}
	/** @deprecated Local-only compatibility facade. */
	async cleanupFirstPairOrphans(principal, now) {
		return this.local.cleanupFirstPairOrphans(principal, now);
	}
};
function resolveCredentialLifecycleStore(source) {
	if (source instanceof CredentialStore) return issueAuthorityCredentialStore(LOCAL_BACKEND_AUTHORITY);
	if (!issuedCredentialLifecycleStores.has(source)) throw new TypeError("credential lifecycle store was not issued by a scope");
	return source;
}
//#endregion
//#region src/background/mbp1/discovery-service.ts
/** §4: the bridge binds the first free port of this range. */
var DEFAULT_CANDIDATE_PORTS = [
	16802,
	16803,
	16804,
	16805,
	16806
];
/**
* One knob covers the pinned probe and every sweep probe, because they are the
* same request to the same kind of endpoint; two knobs would only invite them
* to drift. 500 ms is generous for loopback — a port with nothing on it fails
* immediately with a connection refusal, so this bounds only the case where
* something accepted the connection and then went quiet.
*/
var DEFAULT_DISCOVERY_TIMEOUT_MS = 500;
var DEFAULT_WAKE_DEADLINE_MS = 2e4;
/**
* Gap between sweeps inside `wakeAndPoll`. Repeating `GET /discovery` is cheap
* by design — §4.1 is unauthenticated, replayable and `no-store`, with none of
* §4.2's one-shot or capped semantics — which is exactly why it is the right
* liveness probe and `/nonce` is not.
*/
var WAKE_POLL_INTERVAL_MS = 500;
var WAKE_URL = "motrix://open";
/** Matches `NativeBootstrap`'s existing bound on a host-supplied nonce. */
var MAX_NONCE_LENGTH$1 = 512;
var MAX_INSTANCE_ID_LENGTH$2 = 128;
var MAX_APP_VERSION_LENGTH$1 = 64;
var SUPPORTED_MBP1_VERSION = 1;
var SUPPORTED_MDXP_VERSION$1 = "1.0";
function isValidPort(value) {
	return typeof value === "number" && Number.isInteger(value) && value >= 1 && value <= 65535;
}
function isPrintableAscii$2(value) {
	for (let i = 0; i < value.length; i++) {
		const code = value.charCodeAt(i);
		if (code < 33 || code > 126) return false;
	}
	return true;
}
/**
* §4.2's nonce is an "opaque ASCII string". ASCII is not cosmetic: the nonce
* is bound into the §6.4 AAD through `enc()`, which rejects a byte >= 0x80, so
* a non-ASCII nonce would throw mid-handshake on every attempt. Rejecting it
* here degrades to "no nonce", which the caller can recover from.
*/
function readNonce(value) {
	if (typeof value !== "string") return null;
	if (value.length === 0 || value.length > MAX_NONCE_LENGTH$1) return null;
	if (!isPrintableAscii$2(value)) return null;
	return value;
}
/**
* Parses a `GET /discovery` body (§4.1).
*
* `app === 'motrix-bridge'` is the only acceptance gate, and `apiVersion` is
* checked for *shape* but deliberately **not** for value. Gating a hint on a
* version number would make a newer Motrix invisible to this extension
* entirely; version incompatibility is the wire protocol's job and surfaces as
* §11's `unsupportedVersion`, which is a far better outcome for the user than
* "no Motrix found".
*
* `instanceId` is required because it is the hint `tryPinnedPort` compares
* against — a document without one is useless as a routing hint. `appVersion`
* is display data only, so a document missing it still describes a live
* Motrix and must not be discarded; it degrades to an empty string.
*/
function readNumericVersions$1(value) {
	if (!Array.isArray(value) || value.length === 0) return null;
	const versions = value.filter((entry) => typeof entry === "number" && Number.isInteger(entry) && entry >= 0);
	return versions.length === value.length ? versions : null;
}
function readStringVersions(value) {
	if (!Array.isArray(value) || value.length === 0) return null;
	const versions = value.filter((entry) => typeof entry === "string" && entry.length > 0);
	return versions.length === value.length ? versions : null;
}
function isStrictlyNewerMdxp$1(version) {
	const match = /^(\d+)\.(\d+)$/.exec(version);
	if (match === null) return false;
	const major = Number(match[1]);
	const minor = Number(match[2]);
	return major > 1 || major === 1 && minor > 0;
}
/**
* Classifies explicit discovery capabilities. Missing or malformed fields are
* an old/incomplete backend, while a well-formed set containing only versions
* newer than this client is the one case that asks the user to update the
* extension. This avoids blaming the extension for an older Motrix build.
*/
function readCompatibility(doc) {
	const runtime = doc.runtime === "electron" || doc.runtime === "server" ? doc.runtime : void 0;
	if (runtime === "server") return { compatibility: "unsupportedRemote" };
	const pairing = doc.extensionPairing && typeof doc.extensionPairing === "object" ? doc.extensionPairing : null;
	const applicationProtocols = doc.applicationProtocols && typeof doc.applicationProtocols === "object" ? doc.applicationProtocols : null;
	const mbp1Versions = readNumericVersions$1(pairing?.versions);
	const mdxpVersions = readStringVersions(applicationProtocols?.mdxp);
	if (runtime === void 0 || pairing?.protocol !== "mbp1" || mbp1Versions === null || mdxpVersions === null) return { compatibility: "backendUpgradeRequired" };
	const supportsMbp1 = mbp1Versions.includes(SUPPORTED_MBP1_VERSION);
	const supportsMdxp = mdxpVersions.includes(SUPPORTED_MDXP_VERSION$1);
	if (supportsMbp1 && supportsMdxp) return { compatibility: "compatible" };
	const incompatibleMbp1IsOnlyNewer = supportsMbp1 || mbp1Versions.every((version) => version > SUPPORTED_MBP1_VERSION);
	const incompatibleMdxpIsOnlyNewer = supportsMdxp || mdxpVersions.every(isStrictlyNewerMdxp$1);
	if (incompatibleMbp1IsOnlyNewer && incompatibleMdxpIsOnlyNewer) return { compatibility: "extensionUpgradeRequired" };
	return { compatibility: "backendUpgradeRequired" };
}
function readDiscoveryDoc(port, body) {
	if (!body || typeof body !== "object") return null;
	const doc = body;
	if (doc.app !== "motrix-bridge") return null;
	if (typeof doc.apiVersion !== "number" || !Number.isFinite(doc.apiVersion)) return null;
	const instanceId = doc.instanceId;
	if (typeof instanceId !== "string" || instanceId.length === 0 || instanceId.length > MAX_INSTANCE_ID_LENGTH$2) return null;
	const rawAppVersion = doc.appVersion;
	return {
		port,
		instanceId,
		appVersion: typeof rawAppVersion === "string" && rawAppVersion.length <= MAX_APP_VERSION_LENGTH$1 ? rawAppVersion : "",
		...readCompatibility(doc)
	};
}
function toProbeResult(candidate) {
	return {
		transport: "probe",
		wsPort: candidate.port,
		instanceId: candidate.instanceId,
		appVersion: candidate.appVersion,
		compatibility: candidate.compatibility
	};
}
function sleep(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
/** Structural lookup, so an environment without `browser.tabs` simply has none. */
function resolveAmbientTabs() {
	const ambient = globalThis.browser?.tabs;
	if (!ambient || typeof ambient !== "object") return null;
	const tabs = ambient;
	if (typeof tabs.create !== "function") return null;
	return tabs;
}
var DiscoveryService = class {
	pins;
	config;
	nativeBootstrap;
	fetchImpl;
	tabs;
	constructor(options) {
		this.pins = options.pins;
		this.config = {
			candidatePorts: options.candidatePorts ?? DEFAULT_CANDIDATE_PORTS,
			discoveryTimeoutMs: options.discoveryTimeoutMs ?? DEFAULT_DISCOVERY_TIMEOUT_MS,
			wakeDeadlineMs: options.wakeDeadlineMs ?? DEFAULT_WAKE_DEADLINE_MS
		};
		this.nativeBootstrap = options.nativeBootstrap ?? null;
		this.fetchImpl = options.fetchImpl ?? null;
		this.tabs = options.tabs ?? null;
	}
	/**
	* The §12 fast path: probe the port this credential last authenticated on
	* and accept it only if the responder reports the same `instanceId`.
	*
	* The `instanceId` match is a routing check, not an authentication — anything
	* local can echo the value back. It earns its place by catching the common
	* benign case where a *different* Motrix instance (or an unrelated service)
	* now holds that port, so the flow sweeps instead of spending its §8
	* challenge–response on an endpoint that provably is not the pinned one.
	*
	* Returns `null` on a mismatch, a dead port, or no pin — and leaves the pin
	* in place either way (see the module comment).
	*/
	async tryPinnedPort(credentialId) {
		const pin = await this.pins.get(credentialId);
		if (pin === null) return null;
		return this.probePin(pin);
	}
	/** Probes every candidate port concurrently and collects the live ones (§4.1). */
	async sweepCandidates() {
		return this.sweep(this.config.discoveryTimeoutMs);
	}
	/**
	* The §12 reconnect chain: pinned port → sweep for the pin's `instanceId` →
	* give up.
	*
	* With **no pin stored** — an interrupted rotation can leave a
	* `commit-uncertain` credential that never got one — the chain falls back to
	* the sweep and accepts it only when there is **exactly one** live
	* candidate. Picking one of several would be discovery data deciding
	* something, which §4.1 rules out; and refusing to try the single obvious
	* candidate would force a re-pair the protocol does not require. The
	* ambiguous case returns `null` and lands in the same recovery branch as a
	* mismatch.
	*
	* Returns `null` rather than throwing when nothing matches: "no endpoint
	* found" is an ordinary outcome the recovery order has to handle anyway.
	*/
	async discoverForReconnect(credentialId) {
		const pin = await this.pins.get(credentialId);
		if (pin !== null) {
			const pinned = await this.probePin(pin);
			if (pinned !== null) return pinned;
		}
		const live = await this.sweepCandidates();
		if (pin !== null) {
			const match = live.find((candidate) => candidate.instanceId === pin.instanceId);
			return match === void 0 ? null : toProbeResult(match);
		}
		const only = live.length === 1 ? live[0] : void 0;
		return only === void 0 ? null : toProbeResult(only);
	}
	/**
	* Enumerates every endpoint a first pairing could target, for the user to
	* choose from.
	*
	* The NM bootstrap is preferred when a host port is injected: it is the only
	* path that can produce a §9.2 attestation ticket, and it returns a nonce
	* for free. On success it is the *only* result — a host that answered has
	* already told us which instance it speaks for, so offering a choice
	* alongside it would just invite the user to pick a less-attested route.
	*
	* **No nonce is fetched here.** `/nonce` is one-shot and capped (§4.2), so
	* fetching one per candidate would burn the server's budget on candidates
	* the user never picks. Call `ensureNonce` on the selected result instead.
	*
	* `allowLaunch` is forwarded to the host, which wakes a sleeping Motrix only
	* when it is literally `true`. This method does not escalate to
	* `wakeAndPoll` on an empty sweep: that needs a user gesture to open a tab,
	* so it is the caller's decision, not a silent side effect of discovery.
	*/
	async discoverForFirstPair(opts) {
		const viaNm = await this.tryNativeBootstrap(opts.allowLaunch, opts.bindingPub);
		if (viaNm !== null) return [viaNm];
		return (await this.sweepCandidates()).map(toProbeResult);
	}
	/**
	* Opens `motrix://open` to wake Motrix, then polls `GET /discovery` against
	* a **single wall-clock deadline** and returns whatever came up.
	*
	* The deadline is one budget for the whole call, not per port and not per
	* sweep, so a slow or half-open port cannot extend it: each probe's own
	* timeout is clamped to the time left.
	*
	* Poll requests are §4.1 `GET /discovery` **only** — never §4.2 `POST
	* /nonce`. See the module comment for what happened the one time that was
	* confused.
	*
	* A tab that could not be created is not fatal: Motrix may already be
	* starting for some other reason, so the poll runs regardless.
	*/
	async wakeAndPoll() {
		const deadline = Date.now() + this.config.wakeDeadlineMs;
		const tabId = await this.openWakeTab();
		while (Date.now() < deadline) {
			const live = await this.sweep(Math.min(this.config.discoveryTimeoutMs, deadline - Date.now()));
			if (live.length > 0) {
				await this.closeWakeTab(tabId);
				return live.map(toProbeResult);
			}
			await sleep(Math.max(0, Math.min(WAKE_POLL_INTERVAL_MS, deadline - Date.now())));
		}
		return [];
	}
	/**
	* Completes `result` with a §4.2 nonce, fetching one only if it does not
	* already have it. Returns `null` when no usable nonce could be obtained.
	*
	* This is the **only** public path that reaches `POST /nonce`, and it must be
	* called at most once, for the candidate the user actually selected. An NM
	* result whose host already supplied a nonce is returned untouched and costs
	* zero requests.
	*
	* A `/v1` reconnect needs no nonce (§4), so nothing on the reconnect chain
	* calls this.
	*/
	async ensureNonce(result) {
		if (result.nonce !== void 0) return result;
		const nonce = await this.fetchNonce(result.wsPort);
		return nonce === null ? null : {
			...result,
			nonce
		};
	}
	/**
	* Resolves the compatibility hint for the candidate the user actually chose.
	* Probe candidates already carry their parsed `/discovery` document. Native
	* Messaging replies do not, so they receive exactly one liveness probe here.
	* The host may already have minted a nonce; an incompatible result is still
	* rejected by `ConnectionManager` before that nonce or the pairing backoff is
	* touched.
	*/
	async preflightCompatibility(result) {
		if (result.compatibility !== void 0) return result;
		const live = await this.probe(result.wsPort, this.config.discoveryTimeoutMs);
		if (live === null) return {
			...result,
			compatibility: "backendUpgradeRequired"
		};
		return {
			...result,
			instanceId: live.instanceId,
			appVersion: live.appVersion,
			compatibility: live.compatibility
		};
	}
	async probePin(pin) {
		const live = await this.probe(pin.port, this.config.discoveryTimeoutMs);
		if (live === null || live.instanceId !== pin.instanceId) return null;
		return {
			transport: "probe",
			wsPort: pin.port,
			instanceId: live.instanceId
		};
	}
	/**
	* Probes all candidates concurrently. The result keeps **candidate-port
	* order**, not completion order, so a user-facing list is stable across
	* sweeps — it is an enumeration, not a ranking.
	*/
	async sweep(timeoutMs) {
		return (await Promise.all(this.config.candidatePorts.map((port) => this.probe(port, timeoutMs)))).filter((candidate) => candidate !== null);
	}
	/**
	* One `GET /discovery` (§4.1). Never rejects: a refused connection, a
	* timeout, a non-2xx status and a body that is not a Motrix discovery
	* document are all just "not live here".
	*/
	async probe(port, timeoutMs) {
		if (timeoutMs <= 0) return null;
		try {
			const response = await this.request(`http://127.0.0.1:${port}/discovery`, { signal: AbortSignal.timeout(timeoutMs) });
			if (!response.ok) return null;
			return readDiscoveryDoc(port, await response.json());
		} catch {
			return null;
		}
	}
	/** One `POST /nonce` (§4.2). The only place the bridge header is sent. */
	async fetchNonce(port) {
		try {
			const response = await this.request(`http://127.0.0.1:${port}/nonce`, {
				method: "POST",
				headers: { "X-Motrix-Bridge": "1" },
				signal: AbortSignal.timeout(this.config.discoveryTimeoutMs)
			});
			if (!response.ok) return null;
			const body = await response.json();
			if (!body || typeof body !== "object") return null;
			return readNonce(body.nonce);
		} catch {
			return null;
		}
	}
	/**
	* `cache: 'no-store'` keeps a stale hint from being replayed out of the HTTP
	* cache, and `redirect: 'error'` keeps a loopback impostor from bouncing
	* either request — including the one carrying `X-Motrix-Bridge` — to a
	* non-loopback host.
	*/
	request(url, init) {
		return (this.fetchImpl ?? globalThis.fetch)(url, {
			cache: "no-store",
			redirect: "error",
			...init
		});
	}
	async tryNativeBootstrap(allowLaunch, bindingPub) {
		if (this.nativeBootstrap === null) return null;
		let reply;
		try {
			reply = await this.nativeBootstrap.bootstrap({
				allowLaunch,
				...bindingPub === void 0 ? {} : { bindingPub }
			});
		} catch {
			return null;
		}
		if (!isValidPort(reply.port)) return null;
		const result = {
			transport: "nm",
			wsPort: reply.port
		};
		const nonce = readNonce(reply.nonce);
		if (nonce !== null) result.nonce = nonce;
		if (reply.nmTicket !== void 0 && reply.nmTicket !== null) result.nmTicket = reply.nmTicket;
		return result;
	}
	async openWakeTab() {
		const tabs = this.tabs ?? resolveAmbientTabs();
		if (tabs === null) return null;
		try {
			const tab = await tabs.create({ url: WAKE_URL });
			return typeof tab?.id === "number" ? tab.id : null;
		} catch {
			return null;
		}
	}
	/** Tolerates an already-closed tab, and a `tabs` port without `remove`. */
	async closeWakeTab(tabId) {
		if (tabId === null) return;
		const tabs = this.tabs ?? resolveAmbientTabs();
		if (tabs === null || typeof tabs.remove !== "function") return;
		try {
			await tabs.remove(tabId);
		} catch {}
	}
};
//#endregion
//#region src/background/mbp1/first-pair-backoff.ts
/**
* MBP1 client-side global first-pair backoff (bridge-pairing-protocol.md §7.3).
*
* The client analogue of the server's `PairFloodControl` lockout, and the
* client's half of the defense against online code guessing: the 40-bit code
* space only holds up because a guesser is limited to ~3 attempts per session
* *and* the sessions themselves are rate-limited.
*
* ```
* lockout before failure n = min(30 · 2^(n-1), 3600) seconds, from that failure
* ```
*
* ## One counter, keyed by nothing
*
* §7.3 requires "a **single truly global** first-pair failure counter — one
* counter for all unauthenticated first-pair targets, deliberately **not**
* keyed by `instanceId`, `port`, or any other attacker-controllable value".
* There is therefore no key parameter anywhere in this API, by construction
* rather than by convention.
*
* Review round 3 found the bug this exists to prevent: a counter keyed by
* `instanceId` handed a fake listener a fresh counter every session, since the
* listener simply returns a new `instanceId` each time. `instanceId` is a
* routing hint and never a security signal (§4.1), so keying on it is keying on
* the attacker's own input.
*
* The known cost — any local process can drive *everyone's* first-pair backoff
* up by failing pairings — is an **accepted** residual in §1.1. Do not "fix" it
* by narrowing the key; that reintroduces the round-3 bypass.
*
* ## Two reset arms, both required
*
* §7.3: the counter "resets on a successful pairing **or after 24 h**". The
* second arm is not cosmetic. Without it the exponent never decays, so a user
* who mistypes a code a handful of times spread over months accumulates an
* unbounded exponent and eventually sits permanently at the 3600 s ceiling —
* while the server, which does implement the 24 h reset, would impose only
* 30 s. The client would lock itself out for an hour where the server invites
* an immediate retry. Line A's `flood-control.ts` uses the same 24 h window, so
* the two sides agree about when backoff has cleared.
*
* This module logs nothing at any level (§11): the only inputs are a failure
* count and a timestamp, and both are security-sensitive here.
*/
var STORAGE_KEY$4 = "motrix.mbp1.firstPairBackoff";
/**
* The base actually used: the spec constant, unless a local-debug build
* shrank the window via `MOTRIX_DEV_PAIR_BACKOFF_MS` (dev builds only —
* `buildFlags.ts` documents the double fence keeping it out of Web Store
* artifacts). Only the base changes; the doubling and the 1 h ceiling stay.
*/
var EFFECTIVE_BASE_LOCKOUT_MS = 3e4;
/** §7.3 / Line A `flood-control.ts`: the lockout ceiling (1 hour). */
var MAX_LOCKOUT_MS = 36e5;
/**
* Validates the persisted record. Anything uninterpretable — including a
* future `version` — degrades to "no backoff" rather than to a lockout: a
* corrupted record must not be able to permanently deny the user a pairing,
* and the cost of the lenient direction is bounded at one extra session before
* the counter rebuilds from 1.
*/
function readStored(value) {
	if (!value || typeof value !== "object") return null;
	const raw = value;
	if (raw.version !== 1) return null;
	const failures = raw.consecutiveFailures;
	const last = raw.lastFailureAt;
	if (typeof failures !== "number" || !Number.isInteger(failures) || failures < 0 || typeof last !== "number" || !Number.isFinite(last)) return null;
	return {
		version: 1,
		consecutiveFailures: failures,
		lastFailureAt: last
	};
}
/**
* `min(30 · 2^(n-1), 3600)` seconds in milliseconds, for the `n`th consecutive
* failure.
*
* The ceiling is applied to the *result*, never to the exponent: `2 ** 60`
* evaluates fine in JS and would silently produce an effectively permanent
* lockout.
*/
function lockoutMsFor(consecutiveFailures) {
	return Math.min(EFFECTIVE_BASE_LOCKOUT_MS * 2 ** (consecutiveFailures - 1), MAX_LOCKOUT_MS);
}
/**
* The failure count that is still in force at `now`, applying §7.3's 24 h
* reset. Shared by the gate and by `recordFailure`, so the stored exponent
* decays too — a gate-only reset would still let the next failure resume at
* `n + 1` and grow without bound.
*
* A `lastFailureAt` in the *future* is treated as stale as well. A stored
* timestamp ahead of `now` cannot be read as an elapsed duration, and the
* alternative — locking the user out for the whole clock delta, which can be
* months — is a self-inflicted denial of service. It grants an attacker
* nothing new: anyone who can move the system clock backwards can equally move
* it forwards past the legitimate 24 h reset, and a local process with that
* power is already out of scope (§1.1).
*/
function effectiveFailures(stored, now) {
	if (stored === null || stored.consecutiveFailures === 0) return 0;
	const elapsed = now - stored.lastFailureAt;
	if (elapsed >= 864e5 || elapsed < 0) return 0;
	return stored.consecutiveFailures;
}
async function read() {
	return readStored((await browser.storage.local.get(STORAGE_KEY$4))[STORAGE_KEY$4]);
}
async function write(stored) {
	await browser.storage.local.set({ [STORAGE_KEY$4]: stored });
}
/**
* Module scope, not per instance: the racing callers here are independent call
* sites rather than holders of a shared object, so only a realm-wide queue
* closes the race. See `operation-queue.ts`.
*/
var enqueue = createOperationQueue();
var FirstPairBackoff = class {
	/**
	* The §7.3 gate, to be consulted **before** opening `/pair` — refusing the
	* connection is the point, so calling it after the socket is open would
	* already have queued a dialog on the user's screen.
	*
	* Deliberately read-only: a gate that wrote would have to decide what to
	* write for a first-ever check, and any record it created would make the
	* first real failure look like the second. The 24 h decay is applied to the
	* *stored* exponent by `recordFailure` instead.
	*/
	async check(now) {
		return enqueue(async () => {
			const stored = await read();
			const failures = effectiveFailures(stored, now);
			if (failures === 0 || stored === null) return { allowed: true };
			const retryAtMs = stored.lastFailureAt + lockoutMsFor(failures);
			if (now >= retryAtMs) return { allowed: true };
			return {
				allowed: false,
				retryAtMs
			};
		});
	}
	/**
	* Records one qualifying §7.3 failure: a first-pair session that reached
	* `pakeA` and ended without mutual confirmation, **for any reason**.
	*
	* That includes a session the extension itself abandoned by closing the
	* socket. §7.3 names the disconnect case explicitly so a guesser cannot dodge
	* the counter by hanging up before exhausting a code, and the caller
	* (`PairingFlow`) is what enforces it — this method cannot tell why it was
	* called.
	*/
	async recordFailure(now) {
		return enqueue(async () => {
			await write({
				version: 1,
				consecutiveFailures: effectiveFailures(await read(), now) + 1,
				lastFailureAt: now
			});
		});
	}
	/**
	* §7.3's first reset arm: a successful pairing clears the counter outright.
	*
	* Takes no timestamp because there is nothing left to time — the record is
	* removed rather than zeroed, so an absent record and a zero count are the
	* same state and `readStored` never has to distinguish them.
	*/
	async recordSuccess() {
		return enqueue(async () => {
			await browser.storage.local.remove(STORAGE_KEY$4);
		});
	}
};
var POINT_BYTES = 32;
var MAC_BYTES = 32;
var SIGNATURE_BYTES = 64;
var KEY_BYTES = 32;
var NONCE_BYTES = 32;
/** `exp` in seconds, bounded so `exp * 1000` stays an exact JS integer. */
var MAX_EXP_SECONDS = Math.floor(Number.MAX_SAFE_INTEGER / 1e3);
function isAscii(s) {
	for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) > 127) return false;
	return true;
}
/**
* A string field that reaches `enc()` (§2) and therefore must be ASCII-only.
* `enc` throws on a non-ASCII string, so rejecting it at the schema turns a
* would-be exception deep inside transcript construction into an ordinary
* frame-parse failure.
*/
var asciiString = () => string().refine(isAscii, { message: "must be ASCII-only" });
/**
* A base64url field decoding **canonically** to exactly `byteLength` bytes
* (§2, §6.1). `b64uDecode` rejects `=` padding, standard-base64 `+`/`/`, an
* impossible length, and a final character whose unused low bits are nonzero —
* the same three rejections Line A's decoder makes, so a value this accepts is
* a value the peer accepts.
*
* Length is part of the wire shape for every binary field MBP1 defines, so a
* wrong-length field is a malformed frame rather than a cryptographic failure
* to be reported as one.
*/
var base64UrlBytes = (byteLength) => string().refine((s) => {
	try {
		return b64uDecode(s).length === byteLength;
	} catch {
		return false;
	}
}, { message: `must be canonical base64url of exactly ${byteLength} bytes` });
var protocolVersionField = number().int().min(0).max(4294967295);
var browserField = _enum(["chromium", "firefox"]);
/**
* `pairHello` (A→B, §6.1) — the first frame on `/pair`, and where identity now
* lives. `/pair` carries only `?nonce=`; the old query-parameter identity is
* gone, and `extensionName`/`extensionVersion` have no home here at all.
*
* `nmTicket` stays `unknown` so the host's ticket object travels **byte-for-byte
* unmodified** — the client never rewrites, normalizes, or drops it (§9.2, and
* see `pairing-flow.ts` on why dropping one is worse than sending it).
*
* The refinement is the "required iff" rule Line A enforces with the same
* wording: a ticketless attempt omits **both** fields — not `null`, not an
* empty string.
*/
var pairHelloFrameSchema = object({
	type: literal("pairHello"),
	protocolVersion: protocolVersionField,
	browser: browserField,
	claimedExtensionId: asciiString(),
	clientInstallationId: asciiString(),
	nmTicket: unknown().optional(),
	ticketBindingKey: base64UrlBytes(KEY_BYTES).optional()
}).strict().refine((f) => f.nmTicket === void 0 === (f.ticketBindingKey === void 0), { message: "ticketBindingKey is required if and only if nmTicket is present" });
/** `pakeA` (A→B, §6.1): A's SPAKE2 public share. No `protocolVersion`. */
var pakeAFrameSchema = object({
	type: literal("pakeA"),
	pA: base64UrlBytes(POINT_BYTES)
}).strict();
/**
* `confirmA` (A→B, §6.1, §6.5). No `protocolVersion`.
*
* `ticketProof` is required **iff** an `nmTicket` was sent in `pairHello`. That
* cross-frame condition cannot live in a schema — only the session remembers
* whether a ticket was presented — so `pairing-flow.ts` enforces it and Line
* A's session enforces the mirror. The 64-byte length *is* enforced here, which
* is why a wrong-length proof is a `protocolViolation` rather than surfacing as
* a `codeMismatch`.
*/
var confirmAFrameSchema = object({
	type: literal("confirmA"),
	cA: base64UrlBytes(MAC_BYTES),
	ticketProof: base64UrlBytes(SIGNATURE_BYTES).optional()
}).strict();
/**
* `credentialAck` (A→B, §6.7 step 2). Travels inside the AEAD envelope.
*
* The server compares the echoed `credentialId` against the one it offered, so
* it must be echoed back exactly.
*/
var credentialAckFrameSchema = object({
	type: literal("credentialAck"),
	credentialId: asciiString()
}).strict();
/**
* `reconnectResponse` (A→B, §8).
*
* **Carries no `protocolVersion`** — the single easiest frame to get wrong,
* because `reconnectChallenge` (the frame it answers) does carry one. Adding it
* here is an extra property against Line A's strict schema and kills the
* reconnect.
*/
var reconnectResponseFrameSchema = object({
	type: literal("reconnectResponse"),
	credentialId: asciiString(),
	C: base64UrlBytes(NONCE_BYTES),
	mac: base64UrlBytes(MAC_BYTES)
}).strict();
/**
* `pairAccept` (B→A, §6.1) — sent when the server has **queued the approval
* dialog**, and carrying **no approval semantics whatsoever**.
*
* Line A's own comment is explicit that it "carries no approval semantics —
* only successful key confirmation proves the user approved". The user may
* still be looking at the dialog, or may dismiss it. So nothing may be
* persisted on the strength of this frame and no UI state may read "connected",
* "approved" or "paired" — the only proof of approval is a `confirmB` that
* verifies.
*
* `instanceId` is the §4.1 routing hint, never a security signal.
*/
var pairAcceptFrameSchema = object({
	type: literal("pairAccept"),
	protocolVersion: protocolVersionField,
	instanceId: asciiString()
}).strict();
/** `pakeB` (B→A, §6.1): B's SPAKE2 public share. */
var pakeBFrameSchema = object({
	type: literal("pakeB"),
	pB: base64UrlBytes(POINT_BYTES)
}).strict();
/** `confirmB` (B→A, §6.1, §6.5). */
var confirmBFrameSchema = object({
	type: literal("confirmB"),
	cB: base64UrlBytes(MAC_BYTES)
}).strict();
/**
* `credentialOffer` (B→A, §6.7 step 1). Travels inside the AEAD envelope.
*
* `mutualKey` stays the base64url string all the way into `CredentialStore`; it
* is never decoded at the storage layer.
*/
var credentialOfferFrameSchema = object({
	type: literal("credentialOffer"),
	credentialId: asciiString(),
	mutualKey: base64UrlBytes(KEY_BYTES)
}).strict();
/** `credentialCommitted` (B→A, §6.7 step 3). No payload, inside the envelope. */
var credentialCommittedFrameSchema = object({ type: literal("credentialCommitted") }).strict();
/** `reconnectChallenge` (B→A, §8). The server speaks first on `/v1`. */
var reconnectChallengeFrameSchema = object({
	type: literal("reconnectChallenge"),
	protocolVersion: protocolVersionField,
	S: base64UrlBytes(NONCE_BYTES)
}).strict();
/** `reconnectAccept` (B→A, §8). No `protocolVersion`. */
var reconnectAcceptFrameSchema = object({
	type: literal("reconnectAccept"),
	mac: base64UrlBytes(MAC_BYTES)
}).strict();
/**
* `pairError` (B→A, §11). **Pre-channel only** — it never appears inside the
* AEAD envelope.
*
* `attemptsRemaining` is untrusted display data: the client enforces its own
* §6.5 ceiling and its own §7.3 backoff regardless of what this says.
*/
var pairErrorFrameSchema = object({
	type: literal("pairError"),
	code: _enum([
		"unsupportedVersion",
		"busy",
		"rateLimited",
		"codeMismatch",
		"expired",
		"aborted",
		"denied",
		"authFailed",
		"protocolViolation",
		"pairingFailed"
	]),
	attemptsRemaining: number().int().min(0).optional()
}).strict();
/**
* The `pairHello.nmTicket` wire shape (§9.2), used **only** to recover the
* parsed field values §6.4's `ticketDigest` hashes. The client never validates
* a ticket — that is the server's job (§9.2) — it only re-encodes what it
* parsed so both sides compute the same AAD.
*/
var nmTicketWireSchema = object({
	v: number().int().min(0).max(4294967295),
	purpose: asciiString(),
	protocolVersion: number().int().min(0).max(4294967295),
	serverGeneration: asciiString(),
	browser: asciiString(),
	callerId: asciiString(),
	exp: number().int().min(0).max(MAX_EXP_SECONDS),
	bindingPub: base64UrlBytes(KEY_BYTES),
	mac: base64UrlBytes(MAC_BYTES)
}).strict();
/**
* The discriminator envelope every pre-channel frame shares (§6.1): one JSON
* object with a string `type`.
*/
var frameEnvelopeSchema = object({ type: string() });
var FrameError = class extends Error {
	kind;
	constructor(kind, message) {
		super(message);
		this.name = "FrameError";
		this.kind = kind;
	}
};
/**
* Validates a frame this side is about to emit against its own schema, and
* returns it as a plain JSON object.
*
* Self-checking outbound frames is what makes the "one schema describes both
* directions" claim literally true, and it is the cheapest possible guard
* against the failure mode this whole module exists to prevent: Line A's
* schemas are strict, so a stray property would come back as a socket closed
* with `protocolViolation` and no indication of which field was wrong.
*/
function validateOutbound(schema, frame) {
	const parsed = schema.safeParse(frame);
	if (!parsed.success) throw new FrameError("invalidBody", `refusing to send a frame that fails its own schema: ${parsed.error.issues.map((issue) => issue.path.join(".")).join(", ")}`);
	return parsed.data;
}
/**
* Builds `pairHello`. `nmTicket` and `ticketBindingKey` are both present or
* both absent — passing one alone throws here rather than at the peer.
*
* `nmTicket` is passed through exactly as received from the host.
*/
function buildPairHello(args) {
	const frame = {
		type: "pairHello",
		protocolVersion: 1,
		browser: args.browser,
		claimedExtensionId: args.claimedExtensionId,
		clientInstallationId: args.clientInstallationId
	};
	if (args.nmTicket !== void 0) frame.nmTicket = args.nmTicket;
	if (args.ticketBindingKey !== void 0) frame.ticketBindingKey = args.ticketBindingKey;
	return validateOutbound(pairHelloFrameSchema, frame);
}
/** Builds `pakeA`. */
function buildPakeA(pA) {
	return validateOutbound(pakeAFrameSchema, {
		type: "pakeA",
		pA
	});
}
/** Builds `confirmA`, with `ticketProof` present iff one was supplied. */
function buildConfirmA(cA, ticketProof) {
	const frame = {
		type: "confirmA",
		cA
	};
	if (ticketProof !== void 0) frame.ticketProof = ticketProof;
	return validateOutbound(confirmAFrameSchema, frame);
}
/** Builds `credentialAck`, echoing the offered `credentialId` exactly. */
function buildCredentialAck(credentialId) {
	return validateOutbound(credentialAckFrameSchema, {
		type: "credentialAck",
		credentialId
	});
}
/** Builds `reconnectResponse`. Note: no `protocolVersion`. */
function buildReconnectResponse(args) {
	return validateOutbound(reconnectResponseFrameSchema, {
		type: "reconnectResponse",
		credentialId: args.credentialId,
		C: args.C,
		mac: args.mac
	});
}
var SERVER_FRAME_SCHEMAS = {
	pairAccept: pairAcceptFrameSchema,
	pakeB: pakeBFrameSchema,
	confirmB: confirmBFrameSchema,
	credentialOffer: credentialOfferFrameSchema,
	credentialCommitted: credentialCommittedFrameSchema,
	reconnectChallenge: reconnectChallengeFrameSchema,
	reconnectAccept: reconnectAcceptFrameSchema,
	pairError: pairErrorFrameSchema
};
/**
* Parses one server→client frame, envelope first (§6.1).
*
* The two-step order is deliberate and mirrors Line A's: it is what makes
* "unknown message type" distinguishable from "known type, invalid body",
* which the two sides' error reporting has to agree on. A single
* discriminated-union parse would collapse both into one failure.
*/
function parseServerFrame(value) {
	const envelope = frameEnvelopeSchema.safeParse(value);
	if (!envelope.success) throw new FrameError("malformed", "payload is not a JSON object with a string `type`");
	const type = envelope.data.type;
	const schema = Object.hasOwn(SERVER_FRAME_SCHEMAS, type) ? SERVER_FRAME_SCHEMAS[type] : void 0;
	if (schema === void 0) throw new FrameError("unknownType", "unrecognized frame type");
	const parsed = schema.safeParse(value);
	if (!parsed.success) throw new FrameError("invalidBody", `frame ${type} failed its schema: ${parsed.error.issues.map((issue) => issue.path.join(".")).join(", ")}`);
	return parsed.data;
}
var utf8Encoder = new TextEncoder();
/**
* Parses one raw **text** frame off the wire: §6.1's size cap, then JSON, then
* `parseServerFrame`.
*
* The size cap is checked first because §6.1 makes an oversize
* pre-authentication frame a `protocolViolation` in its own right — and
* checking it before `JSON.parse` is what keeps a hostile peer from forcing
* this side to parse an arbitrarily large document. §6.1's cap is a **wire
* byte** cap, and the wire bytes of a WebSocket text frame are UTF-8, so the
* real measure is the string's UTF-8 size: `raw.length` counts UTF-16 code
* units, which UNDER-counts UTF-8 by up to 3× for non-ASCII content. The
* code-unit check still runs first — every code unit encodes to at least one
* byte, so it rejects everything huge without allocating, which bounds the
* exact re-encode below to ~3× the cap.
*/
function parseTextFrame(raw) {
	if (raw.length > 16384 || utf8Encoder.encode(raw).byteLength > 16384) throw new FrameError("malformed", "frame exceeds the 16 KiB §6.1 cap");
	let body;
	try {
		body = JSON.parse(raw);
	} catch {
		throw new FrameError("malformed", "frame is not valid JSON");
	}
	return parseServerFrame(body);
}
/**
* §11: a `protocolVersion` other than 1 is `unsupportedVersion`, not a generic
* violation. Fail closed — MBP1 has no negotiation (§3).
*/
function assertProtocolVersion(protocolVersion) {
	if (protocolVersion !== 1) throw new FrameError("unsupportedVersion", "peer speaks a protocol version this client does not implement");
}
/**
* Reads a host-supplied `nmTicket` into the parsed field values §6.4's
* `ticketDigest` hashes — `v`/`protocolVersion` as integers, `exp` as an
* integer, strings as-is, and `bindingPub`/`mac` as the **raw bytes** their
* base64url wire encoding decodes to.
*
* This is a reader, not a validator: whether the ticket is *acceptable* is
* §9.2's question and the server's alone. All this decides is whether the
* client can compute an AAD at all.
*/
function parseNmTicket(value) {
	const parsed = nmTicketWireSchema.safeParse(value);
	if (!parsed.success) throw new FrameError("invalidBody", `nmTicket is not a well-formed ticket object: ${parsed.error.issues.map((issue) => issue.path.join(".")).join(", ")}`);
	const wire = parsed.data;
	return {
		v: wire.v,
		purpose: wire.purpose,
		protocolVersion: wire.protocolVersion,
		serverGeneration: wire.serverGeneration,
		browser: wire.browser,
		callerId: wire.callerId,
		exp: wire.exp,
		bindingPub: b64uDecode(wire.bindingPub),
		mac: b64uDecode(wire.mac)
	};
}
/** The WebSocket subprotocol every MBP1 upgrade must request (Line A: 401 without it). */
var MBP1_SUBPROTOCOL = "motrix-bridge.v1";
/**
* `ws://127.0.0.1:<port>/pair?nonce=<nonce>` (§4).
*
* `/pair` carries **only** `?nonce=`. Identity moved into `pairHello`, and
* there is no `?token=` mode on `/pair` at all.
*/
function pairUrl(port, nonce) {
	return `ws://127.0.0.1:${port}/pair?nonce=${encodeURIComponent(nonce)}`;
}
/** `ws://127.0.0.1:<port>/v1` (§4) — no query credentials, ever. */
function reconnectUrl(port) {
	return `ws://127.0.0.1:${port}/v1`;
}
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_u64.js
var U32_MASK64 = /* @__PURE__ */ (() => BigInt(2 ** 32 - 1))();
var _32n = /* @__PURE__ */ BigInt(32);
function fromBig(n, le = false) {
	if (le) return {
		h: Number(n & U32_MASK64),
		l: Number(n >> _32n & U32_MASK64)
	};
	return {
		h: Number(n >> _32n & U32_MASK64) | 0,
		l: Number(n & U32_MASK64) | 0
	};
}
function split(lst, le = false) {
	const len = lst.length;
	let Ah = new Uint32Array(len);
	let Al = new Uint32Array(len);
	for (let i = 0; i < len; i++) {
		const { h, l } = fromBig(lst[i], le);
		[Ah[i], Al[i]] = [h, l];
	}
	return [Ah, Al];
}
var fromNumH = (n) => n / 2 ** 32 | 0;
var fromNumL = (n) => n >>> 0;
function setU64FromNum(view, byteOffset, n, isLE) {
	const h = fromNumH(n);
	const l = fromNumL(n);
	view.setUint32(byteOffset, isLE ? l : h, isLE);
	view.setUint32(byteOffset + 4, isLE ? h : l, isLE);
}
var shrSH = (h, _l, s) => h >>> s;
var shrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrSH = (h, l, s) => h >>> s | l << 32 - s;
var rotrSL = (h, l, s) => h << 32 - s | l >>> s;
var rotrBH = (h, l, s) => h << 64 - s | l >>> s - 32;
var rotrBL = (h, l, s) => h >>> s - 32 | l << 64 - s;
function add(Ah, Al, Bh, Bl) {
	const l = (Al >>> 0) + (Bl >>> 0);
	return {
		h: Ah + Bh + (l / 2 ** 32 | 0) | 0,
		l: l | 0
	};
}
var add3L = (Al, Bl, Cl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0);
var add3H = (low, Ah, Bh, Ch) => Ah + Bh + Ch + (low / 2 ** 32 | 0) | 0;
var add4L = (Al, Bl, Cl, Dl) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0);
var add4H = (low, Ah, Bh, Ch, Dh) => Ah + Bh + Ch + Dh + (low / 2 ** 32 | 0) | 0;
var add5L = (Al, Bl, Cl, Dl, El) => (Al >>> 0) + (Bl >>> 0) + (Cl >>> 0) + (Dl >>> 0) + (El >>> 0);
var add5H = (low, Ah, Bh, Ch, Dh, Eh) => Ah + Bh + Ch + Dh + Eh + (low / 2 ** 32 | 0) | 0;
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/utils.js
/**
* Checks if something is Uint8Array. Be careful: nodejs Buffer will return true.
* @param a - value to test
* @returns `true` when the value is a Uint8Array-compatible view.
* @example
* Check whether a value is a Uint8Array-compatible view.
* ```ts
* isBytes(new Uint8Array([1, 2, 3]));
* ```
*/
function isBytes$1(a) {
	return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
var atitle$1 = (title) => title ? `"${title}" ` : "";
/**
* Asserts something is a non-negative integer.
* @param n - number to validate
* @param title - label included in thrown errors
* @returns The validated number.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate a non-negative integer option.
* ```ts
* anumber(32, 'length');
* ```
*/
function anumber$1(n, title = "") {
	if (typeof n !== "number") throw new TypeError(atitle$1(title) + "expected number, got " + typeof n);
	if (!Number.isSafeInteger(n) || n < 0) throw new RangeError(atitle$1(title) + "expected integer >= 0, got " + n);
	return n;
}
/**
* Asserts something is Uint8Array.
* @param value - value to validate
* @param length - optional exact length constraint
* @param title - label included in thrown errors
* @returns The validated byte array.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate that a value is a byte array.
* ```ts
* abytes(new Uint8Array([1, 2, 3]));
* ```
*/
function abytes$1(value, length, title = "") {
	if (isBytes$1(value) && (length === void 0 || value.length === length)) return value;
	if (length !== void 0) anumber$1(length, "length");
	const bytes = isBytes$1(value);
	const ofLen = length !== void 0 ? ` of length ${length}` : "";
	const got = bytes ? `length=${value.length}` : `type=${typeof value}`;
	const message = atitle$1(title) + "expected Uint8Array" + ofLen + ", got " + got;
	if (!bytes) throw new TypeError(message);
	throw new RangeError(message);
}
/**
* Asserts something is a wrapped hash constructor.
* @param h - hash constructor to validate
* @throws On wrong argument types or invalid hash wrapper shape. {@link TypeError}
* @throws On invalid hash metadata ranges or values. {@link RangeError}
* @throws If the hash metadata allows empty outputs or block sizes. {@link Error}
* @example
* Validate a callable hash wrapper.
* ```ts
* import { ahash } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* ahash(sha256);
* ```
*/
function ahash(h) {
	if (typeof h !== "function" || typeof h.create !== "function") throw new TypeError("expected hash wrapped by utils.createHasher");
	anumber$1(h.outputLen);
	anumber$1(h.blockLen);
	if (h.outputLen < 1 || h.blockLen < 1) throw new Error("hash blockLen / outputLen must be >= 1");
}
var aobject$1 = (value, label) => {
	if (value === null || typeof value !== "object" || Array.isArray(value)) throw new TypeError((label === "object" ? "" : `"${label}" `) + "expected object, got type=" + typeof value);
};
var aopts = (value, label) => {
	aobject$1(value, label);
	const proto = Object.getPrototypeOf(value);
	if (proto !== Object.prototype && proto !== null) throw new TypeError(`"${label}" expected plain object`);
	if (Object.hasOwn(value, "__proto__")) throw new TypeError(`"${label}.__proto__" is not allowed`);
};
/**
* Asserts a hash instance has not been destroyed or finished.
* @param instance - hash instance to validate
* @param checkFinished - whether to reject finalized instances
* @throws If the hash instance has already been destroyed or finalized. {@link Error}
* @example
* Validate that a hash instance is still usable.
* ```ts
* import { aexists } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const hash = sha256.create();
* aexists(hash);
* ```
*/
function aexists(instance, checkFinished = true) {
	if (instance.destroyed) throw new Error("hash was destroyed");
	if (checkFinished && instance.finished) throw new Error("digest() was already called");
}
/**
* Asserts output is a sufficiently-sized byte array.
* @param out - destination buffer
* @param instance - hash instance providing output length
* Oversized buffers are allowed; downstream code only promises to fill the first `outputLen` bytes.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate a caller-provided digest buffer.
* ```ts
* import { aoutput } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const hash = sha256.create();
* aoutput(new Uint8Array(hash.outputLen), hash);
* ```
*/
function aoutput(out, instance) {
	abytes$1(out, void 0, "output");
	const min = instance.outputLen;
	if (!(out.length >= min)) throw new RangeError("\"output\" expected length >= " + min);
}
/**
* Casts a typed array view to Uint32Array.
* `arr.byteOffset` must already be 4-byte aligned or the platform
* Uint32Array constructor will throw.
* @param arr - source typed array
* @returns Uint32Array view over the same buffer.
* @example
* Reinterpret a byte array as 32-bit words.
* ```ts
* u32(new Uint8Array(8));
* ```
*/
function u32(arr) {
	return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
/**
* Zeroizes typed arrays in place. Warning: JS provides no guarantees.
* @param arrays - arrays to overwrite with zeros
* @example
* Zeroize sensitive buffers in place.
* ```ts
* clean(new Uint8Array([1, 2, 3]));
* ```
*/
function clean(...arrays) {
	for (let i = 0; i < arrays.length; i++) arrays[i].fill(0);
}
/**
* Creates a DataView for byte-level manipulation.
* @param arr - source typed array
* @returns DataView over the same buffer region.
* @example
* Create a DataView over an existing buffer.
* ```ts
* createView(new Uint8Array(4));
* ```
*/
function createView(arr) {
	return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
/**
* Rotate-right operation for uint32 values.
* @param word - source word
* @param shift - shift amount in bits
* @returns Rotated word.
* @example
* Rotate a 32-bit word to the right.
* ```ts
* rotr(0x12345678, 8);
* ```
*/
function rotr(word, shift) {
	return word << 32 - shift | word >>> shift;
}
/**
* Rotate-left operation for uint32 values.
* @param word - source word
* @param shift - shift amount in bits
* @returns Rotated word.
* @example
* Rotate a 32-bit word to the left.
* ```ts
* rotl(0x12345678, 8);
* ```
*/
function rotl(word, shift) {
	return word << shift | word >>> 32 - shift >>> 0;
}
/** Whether the current platform is little-endian. */
var isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
/**
* Byte-swap operation for uint32 values.
* @param word - source word
* @returns Word with reversed byte order.
* @example
* Reverse the byte order of a 32-bit word.
* ```ts
* byteSwap(0x11223344);
* ```
*/
function byteSwap(word) {
	return word << 24 & 4278190080 | word << 8 & 16711680 | word >>> 8 & 65280 | word >>> 24 & 255;
}
/**
* Byte-swaps every word of a Uint32Array in place.
* @param arr - array to mutate
* @returns The same array after mutation; callers pass live state arrays here.
* @example
* Reverse the byte order of every word in place.
* ```ts
* byteSwap32(new Uint32Array([0x11223344]));
* ```
*/
function byteSwap32(arr) {
	for (let i = 0; i < arr.length; i++) arr[i] = byteSwap(arr[i]);
	return arr;
}
/**
* Conditionally byte-swaps a Uint32Array on big-endian platforms.
* @param u - array to normalize for host endianness
* @returns Original or byte-swapped array depending on platform endianness.
*   On big-endian runtimes this mutates `u` in place via `byteSwap32(...)`.
* @example
* Normalize a word array for host endianness.
* ```ts
* swap32IfBE(new Uint32Array([0x11223344]));
* ```
*/
var swap32IfBE = isLE ? (u) => u : byteSwap32;
var hasHexBuiltin = /* @__PURE__ */ (() => typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function")();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
/**
* Convert byte array to hex string.
* Uses the built-in function when available and assumes it matches the tested
* fallback semantics.
* @param bytes - bytes to encode
* @returns Lowercase hexadecimal string.
* @throws On wrong argument types. {@link TypeError}
* @example
* Convert bytes to lowercase hexadecimal.
* ```ts
* bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])); // 'cafe0123'
* ```
*/
function bytesToHex$1(bytes) {
	abytes$1(bytes);
	if (hasHexBuiltin) return bytes.toHex();
	let hex = "";
	for (let i = 0; i < bytes.length; i++) hex += hexes[bytes[i]];
	return hex;
}
function asciiToBase16(ch) {
	return ch >= 48 && ch <= 57 ? ch - 48 : ch >= 65 && ch <= 70 ? ch - 55 : ch >= 97 && ch <= 102 ? ch - 87 : void 0;
}
/**
* Convert hex string to byte array. Uses built-in function, when available.
* @param hex - hexadecimal string to decode
* @returns Decoded bytes.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Decode lowercase hexadecimal into bytes.
* ```ts
* hexToBytes('cafe0123'); // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
* ```
*/
function hexToBytes$1(hex) {
	if (typeof hex !== "string") throw new TypeError("hex string expected, got " + typeof hex);
	if (hasHexBuiltin) try {
		return Uint8Array.fromHex(hex);
	} catch (error) {
		if (error instanceof SyntaxError) throw new RangeError(error.message);
		throw error;
	}
	const hl = hex.length;
	const al = hl / 2;
	if (hl % 2) throw new RangeError("hex string expected, got unpadded hex of length " + hl);
	const array = new Uint8Array(al);
	for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
		const n1 = asciiToBase16(hex.charCodeAt(hi));
		const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
		if (n1 === void 0 || n2 === void 0) {
			const char = hex[hi] + hex[hi + 1];
			throw new RangeError("hex string expected, got non-hex character \"" + char + "\" at index " + hi);
		}
		array[ai] = n1 * 16 + n2;
	}
	return array;
}
/**
* Converts string to bytes using UTF8 encoding.
* Built-in doesn't validate input to be string: we do the check.
* Non-ASCII details are delegated to the platform `TextEncoder`.
* @param str - string to encode
* @returns UTF-8 encoded bytes.
* @throws On wrong argument types. {@link TypeError}
* @example
* Encode a string as UTF-8 bytes.
* ```ts
* utf8ToBytes('abc'); // Uint8Array.from([97, 98, 99])
* ```
*/
function utf8ToBytes(str) {
	if (typeof str !== "string") throw new TypeError("string expected");
	const encoded = new TextEncoder().encode(str);
	try {
		return new Uint8Array(encoded);
	} finally {
		clean(encoded);
	}
}
/**
* Helper for KDFs: consumes Uint8Array or string.
* String inputs are UTF-8 encoded; byte-array inputs stay aliased to the caller buffer.
* @param data - user-provided KDF input
* @param errorTitle - label included in thrown errors
* @returns Byte representation of the input.
* @throws On wrong argument types. {@link TypeError}
* @example
* Normalize KDF input to bytes.
* ```ts
* kdfInputToBytes('password');
* ```
*/
function kdfInputToBytes(data, errorTitle = "") {
	if (typeof data === "string") return utf8ToBytes(data);
	return abytes$1(data, void 0, errorTitle);
}
/**
* Copies several Uint8Arrays into one.
* @param arrays - arrays to concatenate
* @returns Concatenated byte array.
* @throws On wrong argument types. {@link TypeError}
* @example
* Concatenate multiple byte arrays.
* ```ts
* concatBytes(new Uint8Array([1]), new Uint8Array([2]));
* ```
*/
function concatBytes$1(...arrays) {
	let sum = 0;
	for (let i = 0; i < arrays.length; i++) {
		const a = arrays[i];
		abytes$1(a);
		sum += a.length;
	}
	const res = new Uint8Array(sum);
	for (let i = 0, pad = 0; i < arrays.length; i++) {
		const a = arrays[i];
		res.set(a, pad);
		pad += a.length;
	}
	return res;
}
/**
* Merges default options and passed options.
* @param defaults - base option object
* @param opts - user overrides
* @param title - label included in thrown override errors
* @returns Fresh merged option object with a null prototype.
* @throws On wrong argument types. {@link TypeError}
* @example
* Merge user overrides onto default options.
* ```ts
* checkOpts({ dkLen: 32 }, { asyncTick: 10 });
* ```
*/
function checkOpts(defaults, opts, title = "opts") {
	aopts(defaults, "defaults");
	if (opts !== void 0) aopts(opts, title);
	return Object.assign(Object.create(null), defaults, opts);
}
/**
* Creates a callable hash function from a stateful class constructor.
* @param hashCons - hash constructor or factory
* @param info - optional metadata such as DER OID
* @returns Frozen callable hash wrapper with `.create()`.
*   Wrapper construction eagerly calls `hashCons(undefined)` once to read
*   `outputLen` / `blockLen`, so constructor side effects happen at module
*   init time.
* @throws On wrong argument types. {@link TypeError}
* @example
* Wrap a stateful hash constructor into a callable helper.
* ```ts
* import { createHasher } from '@noble/hashes/utils.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const wrapped = createHasher(sha256.create, { oid: sha256.oid });
* wrapped(new Uint8Array([1]));
* ```
*/
function createHasher(hashCons, info = {}) {
	if (typeof hashCons !== "function") throw new TypeError("\"hashCons\" expected function, got type=" + typeof hashCons);
	info = checkOpts({}, info, "info");
	const hashC = (msg, opts) => hashCons(opts).update(msg).digest();
	const tmp = hashCons(void 0);
	hashC.outputLen = tmp.outputLen;
	hashC.blockLen = tmp.blockLen;
	hashC.canXOF = tmp.canXOF;
	hashC.create = (opts) => hashCons(opts);
	Object.assign(hashC, info);
	return Object.freeze(hashC);
}
/**
* Cryptographically secure PRNG backed by `crypto.getRandomValues`.
* @param bytesLength - number of random bytes to generate
* @returns Random bytes.
* The platform `getRandomValues()` implementation still defines any
* single-call length cap, and this helper rejects oversize requests
* with a stable library `RangeError` instead of host-specific errors.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @throws If the current runtime does not provide `crypto.getRandomValues`. {@link Error}
* @example
* Generate a fresh random key or nonce.
* ```ts
* const key = randomBytes(16);
* ```
*/
function randomBytes$1(bytesLength = 32) {
	anumber$1(bytesLength, "bytesLength");
	const cr = typeof globalThis === "object" ? globalThis.crypto : null;
	if (typeof cr?.getRandomValues !== "function") throw new Error("crypto.getRandomValues must be defined");
	if (bytesLength > 65536) throw new RangeError(`"bytesLength" expected <= 65536, got ${bytesLength}`);
	return cr.getRandomValues(new Uint8Array(bytesLength));
}
/**
* Creates OID metadata for NIST hashes with prefix `06 09 60 86 48 01 65 03 04 02`.
* @param suffix - final OID byte for the selected hash.
*   The helper accepts any byte even though only the documented NIST hash
*   suffixes are meaningful downstream.
* @returns Object containing the DER-encoded OID.
* @example
* Build OID metadata for a NIST hash.
* ```ts
* oidNist(0x01);
* ```
*/
var oidNist = (suffix) => ({ oid: Uint8Array.from([
	6,
	9,
	96,
	134,
	72,
	1,
	101,
	3,
	4,
	2,
	suffix
]) });
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/_md.js
/**
* Internal Merkle-Damgard hash utils.
* @module
*/
/**
* Shared 32-bit conditional boolean primitive reused by SHA-256, SHA-1, and MD5 `F`.
* Returns bits from `b` when `a` is set, otherwise from `c`.
* The XOR form is equivalent to MD5's `F(X,Y,Z) = XY v not(X)Z` because the masked terms never
* set the same bit.
* @param a - selector word
* @param b - word chosen when selector bit is set
* @param c - word chosen when selector bit is clear
* @returns Mixed 32-bit word.
* @example
* Combine three words with the shared 32-bit choice primitive.
* ```ts
* Chi(0xffffffff, 0x12345678, 0x87654321);
* ```
*/
function Chi(a, b, c) {
	return a & b ^ ~a & c;
}
/**
* Shared 32-bit majority primitive reused by SHA-256 and SHA-1.
* Returns bits shared by at least two inputs.
* @param a - first input word
* @param b - second input word
* @param c - third input word
* @returns Mixed 32-bit word.
* @example
* Combine three words with the shared 32-bit majority primitive.
* ```ts
* Maj(0xffffffff, 0x12345678, 0x87654321);
* ```
*/
function Maj(a, b, c) {
	return a & b ^ a & c ^ b & c;
}
/**
* Merkle-Damgard hash construction base class.
* Could be used to create MD5, RIPEMD, SHA1, SHA2.
* Accepts only byte-aligned `Uint8Array` input, even when the underlying spec describes bit
* strings with partial-byte tails.
* @param blockLen - internal block size in bytes
* @param outputLen - digest size in bytes
* @param padOffset - trailing length field size in bytes
* @param isLE - whether length and state words are encoded in little-endian
* @example
* Use a concrete subclass to get the shared Merkle-Damgard update/digest flow.
* ```ts
* import { _SHA1 } from '@noble/hashes/legacy.js';
* const hash = new _SHA1();
* hash.update(new Uint8Array([97, 98, 99]));
* hash.digest();
* ```
*/
var HashMD = class {
	blockLen;
	outputLen;
	canXOF = false;
	padOffset;
	isLE;
	buffer;
	view;
	finished = false;
	length = 0;
	pos = 0;
	destroyed = false;
	constructor(blockLen, outputLen, padOffset, isLE) {
		this.blockLen = blockLen;
		this.outputLen = outputLen;
		this.padOffset = padOffset;
		this.isLE = isLE;
		this.buffer = new Uint8Array(blockLen);
		this.view = createView(this.buffer);
	}
	update(data) {
		aexists(this);
		abytes$1(data);
		const { view, buffer, blockLen } = this;
		const len = data.length;
		let processed = false;
		for (let pos = 0; pos < len;) {
			const take = Math.min(blockLen - this.pos, len - pos);
			if (take === blockLen) {
				const dataView = createView(data);
				for (; blockLen <= len - pos; pos += blockLen) this.process(dataView, pos);
				processed = true;
				continue;
			}
			buffer.set(pos === 0 && take === len ? data : data.subarray(pos, pos + take), this.pos);
			this.pos += take;
			pos += take;
			if (this.pos === blockLen) {
				this.process(view, 0);
				this.pos = 0;
				processed = true;
			}
		}
		this.length += data.length;
		if (processed) this.roundClean();
		return this;
	}
	digestInto(out) {
		aexists(this);
		aoutput(out, this);
		this.finished = true;
		const { buffer, view, blockLen, isLE } = this;
		let { pos } = this;
		buffer[pos++] = 128;
		buffer.fill(0, pos);
		if (this.padOffset > blockLen - pos) {
			this.process(view, 0);
			buffer.fill(0);
		}
		setU64FromNum(view, blockLen - 8, this.length * 8, isLE);
		this.process(view, 0);
		this.roundClean();
		const oview = out === buffer ? view : createView(out);
		const len = this.outputLen;
		const outLen = len / 4;
		const state = this.get();
		if (len % 4 || outLen > state.length) throw new Error("invalid outputLen");
		for (let i = 0; i < outLen; i++) oview.setUint32(4 * i, state[i], isLE);
	}
	digest() {
		const { buffer, outputLen } = this;
		this.digestInto(buffer);
		const res = buffer.slice(0, outputLen);
		this.destroy();
		return res;
	}
	_cloneIntoMeta(to) {
		const { buffer, length, finished, destroyed, pos } = this;
		to.destroyed = destroyed;
		to.finished = finished;
		to.length = length;
		to.pos = pos;
		if (pos) to.buffer.set(buffer);
		return to;
	}
	clone() {
		return this._cloneInto();
	}
};
/**
* Initial SHA-2 state: fractional parts of square roots of first 16 primes 2..53.
* Check out `test/misc/sha2-gen-iv.js` for recomputation guide.
*/
/** Initial SHA256 state from RFC 6234 §6.1: the first 32 bits of the fractional parts of the
* square roots of the first eight prime numbers. Exported as a shared table; callers must treat
* it as read-only because constructors copy words from it by index. */
var SHA256_IV = /* @__PURE__ */ Uint32Array.from([
	1779033703,
	3144134277,
	1013904242,
	2773480762,
	1359893119,
	2600822924,
	528734635,
	1541459225
]);
/** Initial SHA512 state from RFC 6234 §6.3: eight RFC 64-bit `H(0)` words stored as sixteen
* big-endian 32-bit halves. Derived from the fractional parts of the square roots of the first
* eight prime numbers. Exported as a shared table; callers must treat it as read-only because
* constructors copy halves from it by index. */
var SHA512_IV = /* @__PURE__ */ Uint32Array.from([
	1779033703,
	4089235720,
	3144134277,
	2227873595,
	1013904242,
	4271175723,
	2773480762,
	1595750129,
	1359893119,
	2917565137,
	2600822924,
	725511199,
	528734635,
	4215389547,
	1541459225,
	327033209
]);
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/sha2.js
/**
* SHA2 hash function. A.k.a. sha256, sha384, sha512, sha512_224, sha512_256.
* SHA256 is the fastest hash implementable in JS, even faster than Blake3.
* Check out {@link https://www.rfc-editor.org/rfc/rfc4634 | RFC 4634} and
* {@link https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf | FIPS 180-4}.
* @module
*/
/**
* SHA-224 / SHA-256 round constants from RFC 6234 §5.1: the first 32 bits
* of the cube roots of the first 64 primes (2..311).
*/
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
/** Reusable SHA-224 / SHA-256 message schedule buffer `W_t` from RFC 6234 §6.2 step 1. */
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
/** Internal SHA-224 / SHA-256 compression engine from RFC 6234 §6.2. */
var SHA2_32B = class extends HashMD {
	A = 0;
	B = 0;
	C = 0;
	D = 0;
	E = 0;
	F = 0;
	G = 0;
	H = 0;
	constructor(outputLen, IV) {
		super(64, outputLen, 8, false);
		this.A = IV[0] | 0;
		this.B = IV[1] | 0;
		this.C = IV[2] | 0;
		this.D = IV[3] | 0;
		this.E = IV[4] | 0;
		this.F = IV[5] | 0;
		this.G = IV[6] | 0;
		this.H = IV[7] | 0;
	}
	get() {
		const { A, B, C, D, E, F, G, H } = this;
		return [
			A,
			B,
			C,
			D,
			E,
			F,
			G,
			H
		];
	}
	set(A, B, C, D, E, F, G, H) {
		this.A = A | 0;
		this.B = B | 0;
		this.C = C | 0;
		this.D = D | 0;
		this.E = E | 0;
		this.F = F | 0;
		this.G = G | 0;
		this.H = H | 0;
	}
	_cloneInto(to) {
		(to ||= new this.constructor()).set(...this.get());
		return this._cloneIntoMeta(to);
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) SHA256_W[i] = view.getUint32(offset, false);
		for (let i = 16; i < 64; i++) {
			const W15 = SHA256_W[i - 15];
			const W2 = SHA256_W[i - 2];
			const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
			const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
			SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
		}
		let { A, B, C, D, E, F, G, H } = this;
		for (let i = 0; i < 64; i++) {
			const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
			const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
			const T2 = (rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22)) + Maj(A, B, C) | 0;
			H = G;
			G = F;
			F = E;
			E = D + T1 | 0;
			D = C;
			C = B;
			B = A;
			A = T1 + T2 | 0;
		}
		A = A + this.A | 0;
		B = B + this.B | 0;
		C = C + this.C | 0;
		D = D + this.D | 0;
		E = E + this.E | 0;
		F = F + this.F | 0;
		G = G + this.G | 0;
		H = H + this.H | 0;
		this.set(A, B, C, D, E, F, G, H);
	}
	roundClean() {
		clean(SHA256_W);
	}
	destroy() {
		this.destroyed = true;
		this.set(0, 0, 0, 0, 0, 0, 0, 0);
		clean(this.buffer);
	}
};
/** Internal SHA-256 hash class grounded in RFC 6234 §6.2. */
var _SHA256 = class extends SHA2_32B {
	constructor() {
		super(32, SHA256_IV);
	}
};
var K512 = /* @__PURE__ */ (() => split([
	"0x428a2f98d728ae22",
	"0x7137449123ef65cd",
	"0xb5c0fbcfec4d3b2f",
	"0xe9b5dba58189dbbc",
	"0x3956c25bf348b538",
	"0x59f111f1b605d019",
	"0x923f82a4af194f9b",
	"0xab1c5ed5da6d8118",
	"0xd807aa98a3030242",
	"0x12835b0145706fbe",
	"0x243185be4ee4b28c",
	"0x550c7dc3d5ffb4e2",
	"0x72be5d74f27b896f",
	"0x80deb1fe3b1696b1",
	"0x9bdc06a725c71235",
	"0xc19bf174cf692694",
	"0xe49b69c19ef14ad2",
	"0xefbe4786384f25e3",
	"0x0fc19dc68b8cd5b5",
	"0x240ca1cc77ac9c65",
	"0x2de92c6f592b0275",
	"0x4a7484aa6ea6e483",
	"0x5cb0a9dcbd41fbd4",
	"0x76f988da831153b5",
	"0x983e5152ee66dfab",
	"0xa831c66d2db43210",
	"0xb00327c898fb213f",
	"0xbf597fc7beef0ee4",
	"0xc6e00bf33da88fc2",
	"0xd5a79147930aa725",
	"0x06ca6351e003826f",
	"0x142929670a0e6e70",
	"0x27b70a8546d22ffc",
	"0x2e1b21385c26c926",
	"0x4d2c6dfc5ac42aed",
	"0x53380d139d95b3df",
	"0x650a73548baf63de",
	"0x766a0abb3c77b2a8",
	"0x81c2c92e47edaee6",
	"0x92722c851482353b",
	"0xa2bfe8a14cf10364",
	"0xa81a664bbc423001",
	"0xc24b8b70d0f89791",
	"0xc76c51a30654be30",
	"0xd192e819d6ef5218",
	"0xd69906245565a910",
	"0xf40e35855771202a",
	"0x106aa07032bbd1b8",
	"0x19a4c116b8d2d0c8",
	"0x1e376c085141ab53",
	"0x2748774cdf8eeb99",
	"0x34b0bcb5e19b48a8",
	"0x391c0cb3c5c95a63",
	"0x4ed8aa4ae3418acb",
	"0x5b9cca4f7763e373",
	"0x682e6ff3d6b2b8a3",
	"0x748f82ee5defb2fc",
	"0x78a5636f43172f60",
	"0x84c87814a1f0ab72",
	"0x8cc702081a6439ec",
	"0x90befffa23631e28",
	"0xa4506cebde82bde9",
	"0xbef9a3f7b2c67915",
	"0xc67178f2e372532b",
	"0xca273eceea26619c",
	"0xd186b8c721c0c207",
	"0xeada7dd6cde0eb1e",
	"0xf57d4f7fee6ed178",
	"0x06f067aa72176fba",
	"0x0a637dc5a2c898a6",
	"0x113f9804bef90dae",
	"0x1b710b35131c471b",
	"0x28db77f523047d84",
	"0x32caab7b40c72493",
	"0x3c9ebe0a15c9bebc",
	"0x431d67c49c100d4c",
	"0x4cc5d4becb3e42b6",
	"0x597f299cfc657e2a",
	"0x5fcb6fab3ad6faec",
	"0x6c44198c4a475817"
].map((n) => BigInt(n))))();
var SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
var SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
/** Internal SHA-384 / SHA-512 compression engine from RFC 6234 §6.4. */
var SHA2_64B = class extends HashMD {
	Ah = 0;
	Al = 0;
	Bh = 0;
	Bl = 0;
	Ch = 0;
	Cl = 0;
	Dh = 0;
	Dl = 0;
	Eh = 0;
	El = 0;
	Fh = 0;
	Fl = 0;
	Gh = 0;
	Gl = 0;
	Hh = 0;
	Hl = 0;
	constructor(outputLen, IV) {
		super(128, outputLen, 16, false);
		this.Ah = IV[0] | 0;
		this.Al = IV[1] | 0;
		this.Bh = IV[2] | 0;
		this.Bl = IV[3] | 0;
		this.Ch = IV[4] | 0;
		this.Cl = IV[5] | 0;
		this.Dh = IV[6] | 0;
		this.Dl = IV[7] | 0;
		this.Eh = IV[8] | 0;
		this.El = IV[9] | 0;
		this.Fh = IV[10] | 0;
		this.Fl = IV[11] | 0;
		this.Gh = IV[12] | 0;
		this.Gl = IV[13] | 0;
		this.Hh = IV[14] | 0;
		this.Hl = IV[15] | 0;
	}
	get() {
		const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		return [
			Ah,
			Al,
			Bh,
			Bl,
			Ch,
			Cl,
			Dh,
			Dl,
			Eh,
			El,
			Fh,
			Fl,
			Gh,
			Gl,
			Hh,
			Hl
		];
	}
	set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
		this.Ah = Ah | 0;
		this.Al = Al | 0;
		this.Bh = Bh | 0;
		this.Bl = Bl | 0;
		this.Ch = Ch | 0;
		this.Cl = Cl | 0;
		this.Dh = Dh | 0;
		this.Dl = Dl | 0;
		this.Eh = Eh | 0;
		this.El = El | 0;
		this.Fh = Fh | 0;
		this.Fl = Fl | 0;
		this.Gh = Gh | 0;
		this.Gl = Gl | 0;
		this.Hh = Hh | 0;
		this.Hl = Hl | 0;
	}
	_cloneInto(to) {
		(to ||= new this.constructor()).set(...this.get());
		return this._cloneIntoMeta(to);
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) {
			SHA512_W_H[i] = view.getUint32(offset);
			SHA512_W_L[i] = view.getUint32(offset += 4);
		}
		for (let i = 16; i < 80; i++) {
			const W15h = SHA512_W_H[i - 15] | 0;
			const W15l = SHA512_W_L[i - 15] | 0;
			const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
			const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
			const W2h = SHA512_W_H[i - 2] | 0;
			const W2l = SHA512_W_L[i - 2] | 0;
			const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
			const SUMl = add4L(s0l, rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6), SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
			const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
			SHA512_W_H[i] = SUMh | 0;
			SHA512_W_L[i] = SUMl | 0;
		}
		let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		for (let i = 0; i < 80; i++) {
			const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
			const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
			const CHIh = Eh & Fh ^ ~Eh & Gh;
			const CHIl = El & Fl ^ ~El & Gl;
			const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
			const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
			const T1l = T1ll | 0;
			const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
			const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
			const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
			const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
			Hh = Gh | 0;
			Hl = Gl | 0;
			Gh = Fh | 0;
			Gl = Fl | 0;
			Fh = Eh | 0;
			Fl = El | 0;
			({h: Eh, l: El} = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
			Dh = Ch | 0;
			Dl = Cl | 0;
			Ch = Bh | 0;
			Cl = Bl | 0;
			Bh = Ah | 0;
			Bl = Al | 0;
			const All = add3L(T1l, sigma0l, MAJl);
			Ah = add3H(All, T1h, sigma0h, MAJh);
			Al = All | 0;
		}
		({h: Ah, l: Al} = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
		({h: Bh, l: Bl} = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
		({h: Ch, l: Cl} = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
		({h: Dh, l: Dl} = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
		({h: Eh, l: El} = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
		({h: Fh, l: Fl} = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
		({h: Gh, l: Gl} = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
		({h: Hh, l: Hl} = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
		this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
	}
	roundClean() {
		clean(SHA512_W_H, SHA512_W_L);
	}
	destroy() {
		this.destroyed = true;
		clean(this.buffer);
		this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
};
/** Internal SHA-512 hash class grounded in RFC 6234 §6.3 and §6.4. */
var _SHA512 = class extends SHA2_64B {
	constructor() {
		super(64, SHA512_IV);
	}
};
/**
* SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
*
* - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
* - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
* - Each sha256 hash is executing 2^18 bit operations.
* - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
* @param msg - message bytes to hash
* @param opts - Reserved hash options.
* @returns Digest bytes.
* @example
* Hash a message with SHA2-256.
* ```ts
* sha256(new Uint8Array([97, 98, 99]));
* ```
*/
var sha256 = /* @__PURE__ */ createHasher(() => new _SHA256(), /* @__PURE__ */ oidNist(1));
/**
* SHA2-512 hash function from RFC 4634.
* @param msg - message bytes to hash
* @param opts - Reserved hash options.
* @returns Digest bytes.
* @example
* Hash a message with SHA2-512.
* ```ts
* sha512(new Uint8Array([97, 98, 99]));
* ```
*/
var sha512 = /* @__PURE__ */ createHasher(() => new _SHA512(), /* @__PURE__ */ oidNist(3));
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/utils.js
/**
* Hex, bytes and number utilities.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
/**
* Validates that a value is an array, optionally validating each element.
* @param item - Value to validate.
* @param title - Label included in thrown errors.
* @param inner - Optional per-element validator, called with the element and its label.
* @returns The validated array.
* @example
* Validate an array of points before batch processing.
*
* ```ts
* aarray([1n, 2n], 'scalars');
* ```
*/
function aarray(item, title, inner = () => {}) {
	if (!Array.isArray(item)) throw new TypeError(`"${title}" expected array, got type=${typeof item}`);
	for (let i = 0; i < item.length; i++) inner(item[i], `${title}[${i}]`);
	return item;
}
/**
* Validates that a value is a byte array.
* @param value - Value to validate.
* @param length - Optional exact byte length.
* @param title - Optional field name.
* @returns Original byte array.
* @example
* Reject non-byte input before passing data into curve code.
*
* ```ts
* abytes(new Uint8Array(1));
* ```
*/
var abytes = (value, length, title) => abytes$1(value, length, title);
/**
* Validates that a value is a non-negative safe integer.
* @param n - Value to validate.
* @param title - Optional field name.
* @returns The validated number.
* @example
* Validate a numeric length before allocating buffers.
*
* ```ts
* anumber(1);
* ```
*/
var anumber = anumber$1;
/**
* Asserts something is a string.
* @param value - Value to validate.
* @param title - Label included in thrown errors.
* @returns The validated string.
* @throws On wrong argument types. {@link TypeError}
* @example
* Validate a label string.
*
* ```ts
* astring('example', 'label');
* ```
*/
function astring(value, title = "") {
	if (typeof value !== "string") {
		const prefix = title && `"${title}" `;
		throw new TypeError(prefix + "expected string, got type=" + typeof value);
	}
	return value;
}
/**
* Asserts something is a plain object-ish value, not null or array.
* @param value - Value to validate.
* @param title - Label included in thrown errors.
* @returns The validated object.
* @throws On wrong argument types. {@link TypeError}
* @example
* Validate an options object before checking fields.
*
* ```ts
* aobject({ flag: true });
* ```
*/
function aobject(value, title = "object") {
	if (value === null || typeof value !== "object" || Array.isArray(value)) throw new TypeError(title === "object" ? "expected valid options object" : `"${title}" expected object, got type=${typeof value}`);
	return value;
}
/**
* Asserts something is a function.
* @param value - Value to validate.
* @param title - Label included in thrown errors.
* @returns The validated function.
* @throws On wrong argument types. {@link TypeError}
* @example
* Validate a required method before calling it.
*
* ```ts
* afunction(() => true, 'predicate');
* ```
*/
function afunction(value, title) {
	if (typeof value !== "function") throw new TypeError(`"${title}" is invalid: expected function, got ${typeof value}`);
	return value;
}
/**
* Encodes bytes as lowercase hex.
* @param bytes - Bytes to encode.
* @returns Lowercase hex string.
* @example
* Serialize bytes as hex for logging or fixtures.
*
* ```ts
* bytesToHex(Uint8Array.of(1, 2, 3));
* ```
*/
var bytesToHex = bytesToHex$1;
/**
* Concatenates byte arrays.
* @param arrays - Byte arrays to join.
* @returns Concatenated bytes.
* @example
* Join domain-separated chunks into one buffer.
*
* ```ts
* concatBytes(Uint8Array.of(1), Uint8Array.of(2));
* ```
*/
var concatBytes = (...arrays) => concatBytes$1(...arrays);
/**
* Decodes lowercase or uppercase hex into bytes.
* @param hex - Hex string to decode.
* @returns Decoded bytes.
* @example
* Parse fixture hex into bytes before hashing.
*
* ```ts
* hexToBytes('0102');
* ```
*/
var hexToBytes = (hex) => hexToBytes$1(hex);
/**
* Checks whether a value is a Uint8Array.
* @param a - Value to inspect.
* @returns `true` when `a` is a Uint8Array.
* @example
* Branch on byte input before decoding it.
*
* ```ts
* isBytes(new Uint8Array(1));
* ```
*/
var isBytes = isBytes$1;
/**
* Reads random bytes from the platform CSPRNG.
* @param bytesLength - Number of random bytes to read.
* @returns Fresh random bytes.
* @example
* Generate a random seed for a keypair.
*
* ```ts
* randomBytes(2);
* ```
*/
var randomBytes = (bytesLength) => randomBytes$1(bytesLength);
var _0n$5 = /* @__PURE__ */ BigInt(0);
var _1n$5 = /* @__PURE__ */ BigInt(1);
var atitle = (title) => title ? `"${title}" ` : "";
/**
* Validates that a flag is boolean.
* @param value - Value to validate.
* @param title - Optional field name.
* @returns Original value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Reject non-boolean option flags early.
*
* ```ts
* abool(true);
* ```
*/
function abool(value, title = "") {
	if (typeof value !== "boolean") throw new TypeError(atitle(title) + "expected boolean, got type=" + typeof value);
	return value;
}
/**
* Validates that a value is a non-negative bigint or safe integer.
* @param n - Value to validate.
* @returns The same validated value.
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate one integer-like value before serializing it.
*
* ```ts
* abignumber(1n);
* ```
*/
function abignumber(n) {
	if (typeof n === "bigint") {
		if (!isPosBig(n)) throw new RangeError("positive bigint expected, got " + n);
	} else anumber(n);
	return n;
}
/**
* Validates that a value is a safe integer.
* @param value - Integer to validate.
* @param title - Optional field name.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate a window size before scalar arithmetic uses it.
*
* ```ts
* asafenumber(1);
* ```
*/
function asafenumber(value, title = "") {
	if (typeof value !== "number") {
		const prefix = title && `"${title}" `;
		throw new TypeError(prefix + "expected number, got type=" + typeof value);
	}
	if (!Number.isSafeInteger(value)) {
		const prefix = title && `"${title}" `;
		throw new RangeError(prefix + "expected safe integer, got " + value);
	}
}
/**
* Encodes a bigint into even-length big-endian hex.
* The historical "unpadded" name only means "no fixed-width field padding"; odd-length hex still
* gets one leading zero nibble so the result always represents whole bytes.
* @param num - Number to encode.
* @returns Big-endian hex string.
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Encode a scalar into hex without a `0x` prefix.
*
* ```ts
* numberToHexUnpadded(255n);
* ```
*/
function numberToHexUnpadded(num) {
	const hex = abignumber(num).toString(16);
	return hex.length & 1 ? "0" + hex : hex;
}
/**
* Parses a big-endian hex string into bigint.
* Accepts odd-length hex through the native `BigInt('0x' + hex)` parser and currently surfaces the
* same native `SyntaxError` for malformed hex instead of wrapping it in a library-specific error.
* @param hex - Hex string without `0x`.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Parse a scalar from fixture hex.
*
* ```ts
* hexToNumber('ff');
* ```
*/
function hexToNumber(hex) {
	if (typeof hex !== "string") throw new TypeError("hex string expected, got " + typeof hex);
	return hex === "" ? _0n$5 : BigInt("0x" + hex);
}
/**
* Parses big-endian bytes into bigint.
* @param bytes - Bytes in big-endian order.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Read a scalar encoded in network byte order.
*
* ```ts
* bytesToNumberBE(Uint8Array.of(1, 0));
* ```
*/
function bytesToNumberBE(bytes) {
	return hexToNumber(bytesToHex$1(bytes));
}
/**
* Parses little-endian bytes into bigint.
* @param bytes - Bytes in little-endian order.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Read a scalar encoded in little-endian form.
*
* ```ts
* bytesToNumberLE(Uint8Array.of(1, 0));
* ```
*/
function bytesToNumberLE(bytes) {
	return hexToNumber(bytesToHex$1(copyBytes(abytes$1(bytes)).reverse()));
}
/**
* Encodes a bigint into fixed-length big-endian bytes.
* @param n - Number to encode.
* @param len - Output length in bytes. Must be greater than zero.
* @returns Big-endian byte array.
* @throws On wrong argument ranges or values. {@link RangeError}
* @throws If a documented runtime validation or state check fails. {@link Error}
* @example
* Serialize a scalar into a 32-byte field element.
*
* ```ts
* numberToBytesBE(255n, 2);
* ```
*/
function numberToBytesBE(n, len) {
	anumber$1(len);
	if (len === 0) throw new Error("zero output length is invalid");
	n = abignumber(n);
	const expectedLen = len * 2;
	const hex = n.toString(16);
	if (hex.length > expectedLen) throw new RangeError("number is too large");
	return hexToBytes$1(hex.padStart(expectedLen, "0"));
}
/**
* Encodes a bigint into fixed-length little-endian bytes.
* @param n - Number to encode.
* @param len - Output length in bytes.
* @returns Little-endian byte array.
* @throws On wrong argument ranges or values. {@link RangeError}
* @throws If a documented runtime validation or state check fails. {@link Error}
* @example
* Serialize a scalar for little-endian protocols.
*
* ```ts
* numberToBytesLE(255n, 2);
* ```
*/
function numberToBytesLE(n, len) {
	return numberToBytesBE(n, len).reverse();
}
/**
* Copies Uint8Array. We can't use u8a.slice(), because u8a can be Buffer,
* and Buffer#slice creates mutable copy. Never use Buffers!
* @param bytes - Bytes to copy.
* @returns Detached copy.
* @example
* Make an isolated copy before mutating serialized bytes.
*
* ```ts
* copyBytes(Uint8Array.of(1, 2, 3));
* ```
*/
function copyBytes(bytes) {
	return Uint8Array.from(abytes(bytes));
}
/**
* Checks whether n is non-negative bigint. Historical name.
* @param n - candidate value
* @returns `true` when the value is bigint and 0 or larger
* @example
* Check a candidate scalar before range validation.
*
* ```ts
* isPosBig(2n);
* ```
*/
function isPosBig(n) {
	return typeof n === "bigint" && _0n$5 <= n;
}
/**
* Checks whether a bigint lies inside a half-open range.
* @param n - Candidate value.
* @param min - Inclusive lower bound.
* @param max - Exclusive upper bound.
* @returns `true` when the value is inside the range.
* @example
* Check whether a candidate scalar fits the field order.
*
* ```ts
* inRange(2n, 1n, 3n);
* ```
*/
function inRange(n, min, max) {
	return isPosBig(n) && isPosBig(min) && isPosBig(max) && min <= n && n < max;
}
/**
* Asserts `min <= n < max`. NOTE: upper bound is exclusive.
* @param title - Value label for error messages.
* @param n - Candidate value.
* @param min - Inclusive lower bound.
* @param max - Exclusive upper bound.
* Wrong-type inputs are not separated from out-of-range values here: they still flow through the
* shared `RangeError` path because this is only a throwing wrapper around `inRange(...)`.
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Assert that a bigint stays within one half-open range.
*
* ```ts
* aInRange('x', 2n, 1n, 256n);
* ```
*/
function aInRange(title, n, min, max) {
	if (!inRange(n, min, max)) throw new RangeError("expected valid " + title + ": " + min + " <= n < " + max + ", got " + n);
}
/**
* Calculates amount of bits in a bigint.
* Same as `n.toString(2).length`
* TODO: merge with nLength in modular
* @param n - Value to inspect.
* @returns Bit length.
* @throws If the value is negative. {@link Error}
* @example
* Measure the bit length of a scalar before serialization.
*
* ```ts
* bitLen(8n);
* ```
*/
function bitLen(n) {
	if (n < _0n$5) throw new Error("expected non-negative bigint, got " + n);
	return n === _0n$5 ? 0 : n.toString(2).length;
}
/**
* Calculate mask for N bits. Not using ** operator with bigints because of old engines.
* Same as BigInt(`0b${Array(i).fill('1').join('')}`)
* @param n - Number of bits. Negative widths are currently passed through to raw bigint shift
*   semantics and therefore produce `-1n`.
* @returns Bitmask value.
* @example
* Calculate mask for N bits.
*
* ```ts
* bitMask(4);
* ```
*/
var bitMask = (n) => {
	asafenumber(n, "n");
	return (_1n$5 << BigInt(n)) - _1n$5;
};
/**
* Minimal HMAC-DRBG from NIST 800-90 for RFC6979 sigs.
* @param hashLen - Hash output size in bytes. Callers are expected to pass a positive length; `0`
*   is not rejected here and would make the internal generate loop non-progressing.
* @param qByteLen - Requested output size in bytes. Callers are expected to pass a positive length.
* @param hmacFn - HMAC implementation.
* @returns Function that will call DRBG until the predicate returns anything
*   other than `undefined`.
* @throws On wrong argument types. {@link TypeError}
* @example
* Build a deterministic nonce generator for RFC6979-style signing.
*
* ```ts
* import { createHmacDrbg } from '@noble/curves/utils.js';
* import { hmac } from '@noble/hashes/hmac.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const hmacFn = (key: Uint8Array, msg: Uint8Array) => hmac(sha256, key, msg);
* const drbg = createHmacDrbg(32, 32, hmacFn);
* const seed = new Uint8Array(32);
* drbg(seed, (bytes) => bytes);
* ```
*/
function createHmacDrbg(hashLen, qByteLen, hmacFn) {
	anumber$1(hashLen, "hashLen");
	anumber$1(qByteLen, "qByteLen");
	if (typeof hmacFn !== "function") throw new TypeError("hmacFn must be a function");
	const u8n = (len) => new Uint8Array(len);
	const NULL = Uint8Array.of();
	const byte0 = Uint8Array.of(0);
	const byte1 = Uint8Array.of(1);
	const _maxDrbgIters = 1e3;
	let v = u8n(hashLen);
	let k = u8n(hashLen);
	let i = 0;
	const reset = () => {
		v.fill(1);
		k.fill(0);
		i = 0;
	};
	const h = (...msgs) => hmacFn(k, concatBytes(v, ...msgs));
	const reseed = (seed = NULL) => {
		k = h(byte0, seed);
		v = h();
		if (seed.length === 0) return;
		k = h(byte1, seed);
		v = h();
	};
	const gen = () => {
		if (i++ >= _maxDrbgIters) throw new Error("drbg: tried max amount of iterations");
		let len = 0;
		const out = [];
		while (len < qByteLen) {
			v = h();
			const sl = v.slice();
			out.push(sl);
			len += v.length;
		}
		return concatBytes(...out);
	};
	const genUntil = (seed, pred) => {
		reset();
		reseed(seed);
		let res = void 0;
		while ((res = pred(gen())) === void 0) reseed();
		reset();
		return res;
	};
	return genUntil;
}
/**
* Validates declared required and optional field types on a plain object.
* Extra keys are intentionally ignored because many callers validate only the subset they use from
* richer option bags or runtime objects.
* This walks field schemas and formats detailed errors, so avoid it on hot paths; use direct
* one-line guards such as `aobject()`, `afunction()`, `abool()`, or `asafenumber()` instead.
* @param object - Object to validate.
* @param fields - Required field types.
* @param optFields - Optional field types.
* @param title - Object label included in thrown errors.
* @throws On wrong argument types. {@link TypeError}
* @example
* Check user options before building a curve helper.
*
* ```ts
* validateObject({ flag: true }, { flag: 'boolean' });
* ```
*/
function validateObject(object, fields = {}, optFields = {}, title = "object") {
	aobject(object, title);
	aobject(fields, "fields");
	aobject(optFields, "optFields");
	function checkField(fieldName, expectedType, isOpt) {
		const label = title === "object" ? `param "${String(fieldName)}"` : `"${title}.${String(fieldName)}"`;
		const val = object[fieldName];
		if (!Object.hasOwn(object, fieldName) && (isOpt ? val !== void 0 : expectedType !== "function")) throw new TypeError(`${label} is invalid: expected own property`);
		if (isOpt && val === void 0) return;
		const current = typeof val;
		if (current !== expectedType || val === null) throw new TypeError(`${label} is invalid: expected ${expectedType}, got ${current}`);
	}
	const iter = (f, isOpt) => Object.entries(f).forEach(([k, v]) => checkField(k, v, isOpt));
	iter(fields, false);
	iter(optFields, true);
}
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/abstract/modular.js
/**
* Utils for modular division and fields.
* Field over 11 is a finite (Galois) field is integer number operations `mod 11`.
* There is no division: it is replaced by modular multiplicative inverse.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$4 = /* @__PURE__ */ BigInt(0);
var _1n$4 = /* @__PURE__ */ BigInt(1);
var _2n$3 = /* @__PURE__ */ BigInt(2);
var _3n$1 = /* @__PURE__ */ BigInt(3);
var _4n$3 = /* @__PURE__ */ BigInt(4);
var _5n$1 = /* @__PURE__ */ BigInt(5);
var _7n = /* @__PURE__ */ BigInt(7);
var _8n$2 = /* @__PURE__ */ BigInt(8);
var _9n = /* @__PURE__ */ BigInt(9);
var _15n = /* @__PURE__ */ BigInt(15);
var _16n = /* @__PURE__ */ BigInt(16);
var POW_WINDOWED_MIN = /* @__PURE__ */ BigInt("0x10000000000000000");
/**
* @param a - Dividend value.
* @param b - Positive modulus.
* @returns Reduced value in `[0, b)` only when `b` is positive.
* @throws If the modulus is not positive. {@link Error}
* @example
* Normalize a bigint into one field residue.
*
* ```ts
* mod(-1n, 5n);
* ```
*/
function mod(a, b) {
	if (b <= _0n$4) throw new Error("mod: expected positive modulus, got " + b);
	const result = a % b;
	return result >= _0n$4 ? result : b + result;
}
/**
* Efficiently raise num to a power with modular reduction.
* Unsafe in some contexts: uses ladder, so can expose bigint bits.
* Low-level helper: callers that need canonical residues must pass a valid `num` for the chosen
* modulus instead of relying on the `power===0/1` fast paths to normalize it.
* @param num - Base value.
* @param power - Exponent value.
* @param modulo - Reduction modulus.
* @returns Modular exponentiation result.
* @throws If the modulus or exponent is invalid. {@link Error}
* @example
* Raise one bigint to a modular power.
*
* ```ts
* pow(2n, 6n, 11n) // 64n % 11n == 9n
* ```
*/
function pow(num, power, modulo) {
	if (modulo <= _1n$4) throw new Error("pow: expected modulus > 1, got " + modulo);
	if (typeof power !== "bigint") throw new TypeError("invalid exponent: expected bigint, got " + typeof power);
	if (power < _0n$4) throw new Error("invalid exponent, negatives unsupported");
	if (power === _0n$4) return _1n$4;
	if (power === _1n$4) return num;
	let d = num % modulo;
	if (d < _0n$4) d += modulo;
	if (power < POW_WINDOWED_MIN) {
		let p = _1n$4;
		while (power > _0n$4) {
			if (power & _1n$4) p = p * d % modulo;
			d = d * d % modulo;
			power >>= _1n$4;
		}
		return p;
	}
	const digits = [];
	while (power > _0n$4) {
		digits.push(Number(power & _15n));
		power >>= _4n$3;
	}
	const table = new Array(16);
	table[0] = _1n$4;
	table[1] = d;
	for (let i = 2; i < 16; i++) table[i] = table[i - 1] * d % modulo;
	let p = table[digits[digits.length - 1]];
	for (let w = digits.length - 2; w >= 0; w--) {
		p = p * p % modulo;
		p = p * p % modulo;
		p = p * p % modulo;
		p = p * p % modulo;
		const digit = digits[w];
		if (digit !== 0) p = p * table[digit] % modulo;
	}
	return p;
}
/**
* Does `x^(2^power)` mod p. `pow2(30, 4)` == `30^(2^4)`.
* Low-level helper: callers that need canonical residues must pass a valid `x` for the chosen
* modulus; the `power===0` fast path intentionally returns the input unchanged.
* @param x - Base value.
* @param power - Number of squarings.
* @param modulo - Reduction modulus.
* @returns Repeated-squaring result.
* @throws If the exponent is negative. {@link Error}
* @example
* Apply repeated squaring inside one field.
*
* ```ts
* pow2(3n, 2n, 11n);
* ```
*/
function pow2(x, power, modulo) {
	if (modulo <= _1n$4) throw new Error("pow2: expected modulus > 1, got " + modulo);
	if (power < _0n$4) throw new Error("pow2: expected non-negative exponent, got " + power);
	let res = x;
	while (power-- > _0n$4) {
		res *= res;
		res %= modulo;
	}
	return res;
}
/**
* Inverses number over modulo.
* Implemented using the {@link https://brilliant.org/wiki/extended-euclidean-algorithm/ | extended Euclidean algorithm}.
* @param number - Value to invert.
* @param modulo - Modulus greater than 1.
* @returns Multiplicative inverse.
* @throws If the modulus is invalid or the inverse does not exist. {@link Error}
* @example
* Compute one modular inverse with the extended Euclidean algorithm.
*
* ```ts
* invert(3n, 11n);
* ```
*/
function invert(number, modulo) {
	if (number === _0n$4) throw new Error("invert: expected non-zero number");
	if (modulo <= _1n$4) throw new Error("invert: expected modulus > 1, got " + modulo);
	let a = mod(number, modulo);
	let b = modulo;
	let x = _0n$4, u = _1n$4;
	while (a !== _0n$4) {
		const q = b / a;
		const r = b - a * q;
		const m = x - u * q;
		b = a, a = r, x = u, u = m;
	}
	if (b !== _1n$4) throw new Error("invert: does not exist");
	return mod(x, modulo);
}
/**
* Inverses number over modulo using Fermat's little theorem: `a^(p-2) ≡ a⁻¹ (mod p)`.
*
* Unlike {@link invert} (extended Euclidean), the exponent `p-2` is a public constant, so the
* underlying square-and-multiply has the same control flow for every secret `a`: there is no
* data-dependent branching or loop count that could leak `a` through timing (e.g. Minerva-style
* ECDSA nonce-inversion attacks). This is only "algorithmically" constant-time — JS bigint
* multiplication/reduction is still value-dependent — and it is roughly 4x slower than
* {@link invert}.
*
* REQUIRES a prime modulus; Fermat's theorem does not hold otherwise. The result is verified to be
* a real inverse, so a non-prime modulus (or a non-invertible input) fails closed with an error
* instead of returning a wrong value.
* @param a - Value to invert.
* @param prime - Prime modulus.
* @returns Multiplicative inverse in `[1, prime)`.
* @throws If the modulus is below 2, the input reduces to zero, or the inverse does not exist.
*   {@link Error}
* @example
* Compute one modular inverse without secret-dependent branching.
*
* ```ts
* invertCt(3n, 11n); // 4n, since 3 * 4 = 12 ≡ 1 (mod 11)
* ```
*/
function invertCt(a, prime) {
	if (prime <= _1n$4) throw new Error("invertCt: expected prime modulus > 1, got " + prime);
	const an = mod(a, prime);
	if (an === _0n$4) throw new Error("invertCt: expected non-zero number");
	const inverse = pow(an, prime - _2n$3, prime);
	if (mod(an * inverse, prime) !== _1n$4) throw new Error("invertCt: does not exist");
	return inverse;
}
function assertIsSquare(Fp, root, n) {
	const F = Fp;
	if (!F.eql(F.sqr(root), n)) throw new Error("Cannot find square root");
}
function aoddModulus(order, fnName) {
	if ((order & _1n$4) === _0n$4) throw new Error(fnName + ": expected odd modulus, got " + order);
}
function sqrt3mod4(Fp, n) {
	const F = Fp;
	const p1div4 = (F.ORDER + _1n$4) / _4n$3;
	const root = F.pow(n, p1div4);
	assertIsSquare(F, root, n);
	return root;
}
function sqrt5mod8(Fp, n) {
	const F = Fp;
	const p5div8 = (F.ORDER - _5n$1) / _8n$2;
	const n2 = F.mul(n, _2n$3);
	const v = F.pow(n2, p5div8);
	const nv = F.mul(n, v);
	const i = F.mul(F.mul(nv, _2n$3), v);
	const root = F.mul(nv, F.sub(i, F.ONE));
	assertIsSquare(F, root, n);
	return root;
}
function sqrt9mod16(P) {
	const Fp_ = Field(P);
	const tn = tonelliShanks(P);
	const c1 = tn(Fp_, Fp_.neg(Fp_.ONE));
	const c2 = tn(Fp_, c1);
	const c3 = tn(Fp_, Fp_.neg(c1));
	const c4 = (P + _7n) / _16n;
	return ((Fp, n) => {
		const F = Fp;
		let tv1 = F.pow(n, c4);
		let tv2 = F.mul(tv1, c1);
		const tv3 = F.mul(tv1, c2);
		const tv4 = F.mul(tv1, c3);
		const e1 = F.eql(F.sqr(tv2), n);
		const e2 = F.eql(F.sqr(tv3), n);
		tv1 = F.cmov(tv1, tv2, e1);
		tv2 = F.cmov(tv4, tv3, e2);
		const e3 = F.eql(F.sqr(tv2), n);
		const root = F.cmov(tv1, tv2, e3);
		assertIsSquare(F, root, n);
		return root;
	});
}
/**
* Tonelli-Shanks square root search algorithm.
* This implementation is variable-time: it searches data-dependently for the first non-residue `Z`
* and for the smallest `i` in the main loop, unlike RFC 9380 Appendix I.4's constant-time shape.
* 1. {@link https://eprint.iacr.org/2012/685.pdf | eprint 2012/685}, page 12
* 2. Square Roots from 1; 24, 51, 10 to Dan Shanks
* @param P - field order
* @returns function that takes field Fp (created from P) and number n
* @throws If the field is too small, non-prime, or the square root does not exist. {@link Error}
* @example
* Construct a square-root helper for primes that need Tonelli-Shanks.
*
* ```ts
* import { Field, tonelliShanks } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const sqrt = tonelliShanks(17n)(Fp, 4n);
* ```
*/
function tonelliShanks(P) {
	if (P < _3n$1) throw new Error("sqrt is not defined for small field");
	aoddModulus(P, "tonelliShanks");
	let Q = P - _1n$4;
	let S = 0;
	while (Q % _2n$3 === _0n$4) {
		Q /= _2n$3;
		S++;
	}
	let Z = _2n$3;
	const _Fp = Field(P);
	while (FpLegendre(_Fp, Z) === 1) if (Z++ > 1e3) throw new Error("Cannot find square root: probably non-prime P");
	if (S === 1) return sqrt3mod4;
	let cc = _Fp.pow(Z, Q);
	const Q1div2 = (Q + _1n$4) / _2n$3;
	return function tonelliSlow(Fp, n) {
		const F = Fp;
		if (F.is0(n)) return n;
		if (FpLegendre(F, n) !== 1) throw new Error("Cannot find square root");
		let M = S;
		let c = F.mul(F.ONE, cc);
		let t = F.pow(n, Q);
		let R = F.pow(n, Q1div2);
		while (!F.eql(t, F.ONE)) {
			if (F.is0(t)) throw new Error("Cannot find square root: probably non-prime P");
			let i = 1;
			let t_tmp = F.sqr(t);
			while (!F.eql(t_tmp, F.ONE)) {
				i++;
				t_tmp = F.sqr(t_tmp);
				if (i === M) throw new Error("Cannot find square root");
			}
			const exponent = _1n$4 << BigInt(M - i - 1);
			const b = F.pow(c, exponent);
			M = i;
			c = F.sqr(b);
			t = F.mul(t, c);
			R = F.mul(R, b);
		}
		return R;
	};
}
/**
* Square root for a finite field. Will try optimized versions first:
*
* 1. P ≡ 3 (mod 4)
* 2. P ≡ 5 (mod 8)
* 3. P ≡ 9 (mod 16)
* 4. Tonelli-Shanks algorithm
*
* Different algorithms can give different roots, it is up to user to decide which one they want.
* For example there is FpSqrtOdd/FpSqrtEven to choose a root by oddness
* (used for hash-to-curve).
* @param P - Field order.
* @returns Square-root helper. The generic fallback inherits Tonelli-Shanks' variable-time
*   behavior and this selector assumes prime-field-style integer moduli.
* @throws If the field is unsupported or the square root does not exist. {@link Error}
* @example
* Choose the square-root helper appropriate for one field modulus.
*
* ```ts
* import { Field, FpSqrt } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const sqrt = FpSqrt(17n)(Fp, 4n);
* ```
*/
function FpSqrt(P) {
	aoddModulus(P, "Fp.sqrt");
	if (P % _4n$3 === _3n$1) return sqrt3mod4;
	if (P % _8n$2 === _5n$1) return sqrt5mod8;
	if (P % _16n === _9n) return sqrt9mod16(P);
	return tonelliShanks(P);
}
/**
* @param num - Value to inspect.
* @param modulo - Field modulus.
* @returns `true` when the least-significant little-endian bit is set.
* @throws If the modulus is invalid for `mod(...)`. {@link Error}
* @example
* Inspect the low bit used by little-endian sign conventions.
*
* ```ts
* isNegativeLE(3n, 11n);
* ```
*/
var isNegativeLE = (num, modulo) => (mod(num, modulo) & _1n$4) === _1n$4;
var FIELD_FIELDS = [
	"create",
	"isValid",
	"is0",
	"neg",
	"inv",
	"sqrt",
	"sqr",
	"eql",
	"add",
	"sub",
	"mul",
	"pow",
	"div",
	"addN",
	"subN",
	"mulN",
	"sqrN"
];
/**
* @param field - Field implementation.
* @returns Validated field. This only checks the arithmetic subset needed by generic helpers; it
*   does not guarantee full runtime-method coverage for serialization, batching, `cmov`, or
*   field-specific extras beyond positive `BYTES` / `BITS`.
* @throws If the field shape or numeric metadata are invalid. {@link Error}
* @example
* Check that a field implementation exposes the operations curve code expects.
*
* ```ts
* import { Field, validateField } from '@noble/curves/abstract/modular.js';
* const Fp = validateField(Field(17n));
* ```
*/
function validateField(field) {
	aobject(field, "field");
	if (typeof field.ORDER !== "bigint") throw new TypeError("param \"ORDER\" is invalid: expected bigint, got " + typeof field.ORDER);
	asafenumber(field.BYTES, "BYTES");
	asafenumber(field.BITS, "BITS");
	for (const name of FIELD_FIELDS) afunction(field[name], "field." + name);
	if (field.BYTES < 1 || field.BITS < 1) throw new Error("invalid field: expected BYTES/BITS > 0");
	if (field.ORDER <= _1n$4) throw new Error("invalid field: expected ORDER > 1, got " + field.ORDER);
	return field;
}
function FpInvertBatch(Fp, nums, passZero = false) {
	validateField(Fp);
	aarray(nums, "nums");
	abool(passZero, "passZero");
	const F = Fp;
	const inverted = new Array(nums.length).fill(passZero ? F.ZERO : void 0);
	const multipliedAcc = nums.reduce((acc, num, i) => {
		if (F.is0(num)) return acc;
		inverted[i] = acc;
		return F.mul(acc, num);
	}, F.ONE);
	const invertedAcc = F.inv(multipliedAcc);
	nums.reduceRight((acc, num, i) => {
		if (F.is0(num)) return acc;
		inverted[i] = F.mul(acc, inverted[i]);
		return F.mul(acc, num);
	}, invertedAcc);
	return inverted;
}
/**
* Legendre symbol.
* Legendre constant is used to calculate Legendre symbol (a | p)
* which denotes the value of a^((p-1)/2) (mod p).
*
* * (a | p) ≡ 1    if a is a square (mod p), quadratic residue
* * (a | p) ≡ -1   if a is not a square (mod p), quadratic non residue
* * (a | p) ≡ 0    if a ≡ 0 (mod p)
* @param Fp - Field implementation.
* @param n - Value to inspect.
* @returns Legendre symbol.
* @throws If the powered value does not match a valid Legendre symbol. {@link Error}
* @example
* Compute the Legendre symbol of one field element.
*
* ```ts
* import { Field, FpLegendre } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const symbol = FpLegendre(Fp, 4n);
* ```
*/
function FpLegendre(Fp, n) {
	validateField(Fp);
	const F = Fp;
	aoddModulus(F.ORDER, "FpLegendre");
	const p1mod2 = (F.ORDER - _1n$4) / _2n$3;
	const powered = F.pow(n, p1mod2);
	const yes = F.eql(powered, F.ONE);
	const zero = F.eql(powered, F.ZERO);
	const no = F.eql(powered, F.neg(F.ONE));
	if (!yes && !zero && !no) throw new Error("invalid Legendre symbol result");
	return yes ? 1 : zero ? 0 : -1;
}
/**
* @param n - Curve order. Callers are expected to pass a positive order.
* @param nBitLength - Optional cached bit length. Callers are expected to pass a positive cached
*   value when overriding the derived bit length.
* @returns Byte and bit lengths.
* @throws If the order or cached bit length is invalid. {@link Error}
* @example
* Measure the encoding sizes needed for one modulus.
*
* ```ts
* nLength(255n);
* ```
*/
function nLength(n, nBitLength) {
	if (nBitLength !== void 0) anumber(nBitLength);
	if (n <= _0n$4) throw new Error("invalid n length: expected positive n, got " + n);
	if (nBitLength !== void 0 && nBitLength < 1) throw new Error("invalid n length: expected positive bit length, got " + nBitLength);
	const bits = bitLen(n);
	if (nBitLength !== void 0 && nBitLength < bits) throw new Error(`invalid n length: expected nBitLength (${nBitLength}) >= bitLen(n) (${bits})`);
	const _nBitLength = nBitLength !== void 0 ? nBitLength : bits;
	return {
		nBitLength: _nBitLength,
		nByteLength: Math.ceil(_nBitLength / 8)
	};
}
var FIELD_SQRT = /* @__PURE__ */ new WeakMap();
var _Field = class {
	ORDER;
	BITS;
	BYTES;
	isLE;
	ZERO = _0n$4;
	ONE = _1n$4;
	_lengths;
	_mod;
	constructor(ORDER, opts = {}) {
		if (ORDER <= _1n$4) throw new Error("invalid field: expected ORDER > 1, got " + ORDER);
		let _nbitLength = void 0;
		this.isLE = false;
		if (opts != null && typeof opts === "object") {
			if (typeof opts.BITS === "number") _nbitLength = opts.BITS;
			if (typeof opts.sqrt === "function") Object.defineProperty(this, "sqrt", {
				value: opts.sqrt,
				enumerable: true
			});
			if (typeof opts.isLE === "boolean") this.isLE = opts.isLE;
			if (opts.allowedLengths) this._lengths = Object.freeze(opts.allowedLengths.slice());
			if (typeof opts.modFromBytes === "boolean") this._mod = opts.modFromBytes;
		}
		const { nBitLength, nByteLength } = nLength(ORDER, _nbitLength);
		if (nByteLength > 2048) throw new Error("invalid field: expected ORDER of <= 2048 bytes");
		this.ORDER = ORDER;
		this.BITS = nBitLength;
		this.BYTES = nByteLength;
		Object.freeze(this);
	}
	create(num) {
		return mod(num, this.ORDER);
	}
	isValid(num) {
		if (typeof num !== "bigint") throw new TypeError("invalid field element: expected bigint, got " + typeof num);
		return _0n$4 <= num && num < this.ORDER;
	}
	is0(num) {
		return num === _0n$4;
	}
	isValidNot0(num) {
		return !this.is0(num) && this.isValid(num);
	}
	isOdd(num) {
		return (num & _1n$4) === _1n$4;
	}
	neg(num) {
		return mod(-num, this.ORDER);
	}
	eql(lhs, rhs) {
		return lhs === rhs;
	}
	sqr(num) {
		return mod(num * num, this.ORDER);
	}
	add(lhs, rhs) {
		return mod(lhs + rhs, this.ORDER);
	}
	sub(lhs, rhs) {
		return mod(lhs - rhs, this.ORDER);
	}
	mul(lhs, rhs) {
		return mod(lhs * rhs, this.ORDER);
	}
	pow(num, power) {
		return pow(num, power, this.ORDER);
	}
	div(lhs, rhs) {
		return mod(lhs * invert(rhs, this.ORDER), this.ORDER);
	}
	sqrN(num) {
		return num * num;
	}
	addN(lhs, rhs) {
		return lhs + rhs;
	}
	subN(lhs, rhs) {
		return lhs - rhs;
	}
	mulN(lhs, rhs) {
		return lhs * rhs;
	}
	inv(num) {
		return invert(num, this.ORDER);
	}
	sqrt(num) {
		let sqrt = FIELD_SQRT.get(this);
		if (!sqrt) FIELD_SQRT.set(this, sqrt = FpSqrt(this.ORDER));
		return sqrt(this, num);
	}
	toBytes(num) {
		return this.isLE ? numberToBytesLE(num, this.BYTES) : numberToBytesBE(num, this.BYTES);
	}
	fromBytes(bytes, skipValidation = false) {
		abytes(bytes);
		const { _lengths: allowedLengths, BYTES, isLE, ORDER, _mod: modFromBytes } = this;
		if (allowedLengths) {
			if (bytes.length < 1 || !allowedLengths.includes(bytes.length) || bytes.length > BYTES) throw new Error("Field.fromBytes: expected " + allowedLengths + " bytes, got " + bytes.length);
			const padded = new Uint8Array(BYTES);
			padded.set(bytes, isLE ? 0 : padded.length - bytes.length);
			bytes = padded;
		}
		if (bytes.length !== BYTES) throw new Error("Field.fromBytes: expected " + BYTES + " bytes, got " + bytes.length);
		let scalar = isLE ? bytesToNumberLE(bytes) : bytesToNumberBE(bytes);
		if (modFromBytes) scalar = mod(scalar, ORDER);
		if (!skipValidation) {
			if (!this.isValid(scalar)) throw new Error("invalid field element: outside of range 0..ORDER");
		}
		return scalar;
	}
	invertBatch(lst) {
		return FpInvertBatch(this, lst, true);
	}
	cmov(a, b, condition) {
		abool(condition, "condition");
		return condition ? b : a;
	}
};
/**
* Creates a finite field. Major performance optimizations:
* * 1. Denormalized operations like mulN instead of mul.
* * 2. Identical object shape: never add or remove keys.
* * 3. Frozen stable object shape; the lazy sqrt cache lives in a module-level `WeakMap`.
* Fragile: always run a benchmark on a change.
* Security note: operations and low-level serializers like `toBytes` don't check `isValid` for
* all elements for performance and protocol-flexibility reasons; callers are responsible for
* supplying valid elements when they need canonical field behavior.
* This is low-level code, please make sure you know what you're doing.
*
* Note about field properties:
* * CHARACTERISTIC p = prime number, number of elements in main subgroup.
* * ORDER q = similar to cofactor in curves, may be composite `q = p^m`.
*
* @param ORDER - field order, probably prime, or could be composite
* @param opts - Field options such as bit length or endianness. See {@link FieldOpts}.
* @returns Frozen field instance with a stable object shape. This wrapper forwards `opts` straight
*   into `_Field`, so it inherits `_Field`'s assumptions about cached sizes and `allowedLengths`.
* @example
* Construct one prime field with optional overrides.
*
* ```ts
* Field(11n);
* ```
*/
function Field(ORDER, opts = {}) {
	Object.freeze(_Field.prototype);
	return new _Field(ORDER, opts);
}
/**
* Returns total number of bytes consumed by the field element.
* For example, 32 bytes for usual 256-bit weierstrass curve.
* @param fieldOrder - number of field elements, usually CURVE.n. Callers are expected to pass an
*   order greater than 1.
* @returns byte length of field
* @throws If the field order is not a bigint. {@link Error}
* @example
* Read the fixed-width byte length of one field.
*
* ```ts
* getFieldBytesLength(255n);
* ```
*/
function getFieldBytesLength(fieldOrder) {
	if (typeof fieldOrder !== "bigint") throw new Error("field order must be bigint");
	if (fieldOrder <= _1n$4) throw new Error("field order must be greater than 1");
	const bitLength = bitLen(fieldOrder - _1n$4);
	return Math.ceil(bitLength / 8);
}
/**
* Returns minimal amount of bytes that can be safely reduced
* by field order.
* Should be 2^-128 for 128-bit curve such as P256.
* This is the reduction / modulo-bias lower bound; higher-level helpers may still impose a larger
* absolute floor for policy reasons.
* @param fieldOrder - number of field elements greater than 1, usually CURVE.n.
* @returns byte length of target hash
* @throws If the field order is invalid. {@link Error}
* @example
* Compute the minimum hash length needed for field reduction.
*
* ```ts
* getMinHashLength(255n);
* ```
*/
function getMinHashLength(fieldOrder) {
	const length = getFieldBytesLength(fieldOrder);
	return length + Math.ceil(length / 2);
}
/**
* "Constant-time" private key generation utility.
* Can take (n + n/2) or more bytes of uniform input e.g. from CSPRNG or KDF
* and convert them into private scalar, with the modulo bias being negligible.
* Needs at least 48 bytes of input for 32-byte private key. The implementation also keeps a hard
* 16-byte minimum even when `getMinHashLength(...)` is smaller, so toy-small inputs do not look
* accidentally acceptable for real scalar derivation.
* See {@link https://research.kudelskisecurity.com/2020/07/28/the-definitive-guide-to-modulo-bias-and-how-to-avoid-it/ | Kudelski's modulo-bias guide},
* {@link https://csrc.nist.gov/publications/detail/fips/186/5/final | FIPS 186-5 appendix A.2}, and
* {@link https://www.rfc-editor.org/rfc/rfc9380#section-5 | RFC 9380 section 5}. Unlike RFC 9380
* `hash_to_field`, this helper intentionally maps into the non-zero private-scalar range `1..n-1`.
* @param key - Uniform input bytes.
* @param fieldOrder - Size of subgroup.
* @param isLE - interpret hash bytes as LE num
* @returns valid private scalar
* @throws If the hash length or field order is invalid for scalar reduction. {@link Error}
* @example
* Map hash output into a private scalar range.
*
* ```ts
* mapHashToField(new Uint8Array(48).fill(1), 255n);
* ```
*/
function mapHashToField(key, fieldOrder, isLE = false) {
	abytes(key);
	const len = key.length;
	const fieldLen = getFieldBytesLength(fieldOrder);
	const minLen = Math.max(getMinHashLength(fieldOrder), 16);
	if (len < minLen || len > 1024) throw new Error("expected " + minLen + "-1024 bytes of input, got " + len);
	const reduced = mod(isLE ? bytesToNumberLE(key) : bytesToNumberBE(key), fieldOrder - _1n$4) + _1n$4;
	return isLE ? numberToBytesLE(reduced, fieldLen) : numberToBytesBE(reduced, fieldLen);
}
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/abstract/curve.js
/**
* Methods for elliptic curve multiplication by scalars.
* Contains wNAF-based ScalarMultiplier, pippenger.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$3 = /* @__PURE__ */ BigInt(0);
var _1n$3 = /* @__PURE__ */ BigInt(1);
var _4n$2 = /* @__PURE__ */ BigInt(4);
var BLIND_BYTES = 16;
var BLIND_BITS = 128;
var FW_WINDOW = 5;
var TABLE_BYTES_MAX = /* @__PURE__ */ (() => 2 ** 31)();
/**
* Validates the static surface of a point constructor.
* This is only a cheap sanity check for the constructor hooks and fields consumed by generic
* factories; it does not certify `BASE`/`ZERO` semantics or prove the curve implementation itself.
* @param Point - Runtime point constructor.
* @throws On missing constructor hooks or malformed field metadata. {@link TypeError}
* @example
* Check that one point constructor exposes the static hooks generic helpers need.
*
* ```ts
* import { ed25519 } from '@noble/curves/ed25519.js';
* import { validatePointCons } from '@noble/curves/abstract/curve.js';
* validatePointCons(ed25519.Point);
* ```
*/
function validatePointCons(Point) {
	const pc = Point;
	if (typeof pc !== "function") throw new TypeError("\"Point\" expected constructor, got type=" + typeof Point);
	afunction(pc.fromAffine, "Point.fromAffine");
	afunction(pc.fromBytes, "Point.fromBytes");
	afunction(pc.fromHex, "Point.fromHex");
	aobject(pc.BASE, "Point.BASE");
	aobject(pc.ZERO, "Point.ZERO");
	validateField(pc.Fp);
	validateField(pc.Fn);
}
/**
* Takes a bunch of Projective Points but executes only one
* inversion on all of them. Inversion is very slow operation,
* so this improves performance massively.
* Optimization: converts a list of projective points to a list of identical points with Z=1.
* Input points are left unchanged; the normalized points are returned as fresh instances.
* @param c - Point constructor.
* @param points - Projective points.
* @returns Fresh projective points reconstructed from normalized affine coordinates.
* @example
* Batch-normalize projective points with a single shared inversion.
*
* ```ts
* import { normalizeZ } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const points = normalizeZ(p256.Point, [p256.Point.BASE, p256.Point.BASE.double()]);
* ```
*/
function normalizeZ(c, points) {
	validatePointCons(c);
	validateMSMPoints(points, c);
	const invertedZs = FpInvertBatch(c.Fp, points.map((p) => p.Z));
	return points.map((p, i) => c.fromAffine(p.toAffine(invertedZs[i])));
}
function validateW(W, bits, min = 1) {
	if (!Number.isSafeInteger(W) || W < min || W > bits) throw new Error("invalid window size, expected [" + min + ".." + bits + "], got W=" + W);
}
function validateTableBytes(numPoints, fpBytes) {
	const bytes = numPoints * (4 * fpBytes + 128);
	if (bytes > TABLE_BYTES_MAX) throw new Error("invalid window size: table would need ~" + Math.ceil(bytes / 2 ** 20) + " MiB, max " + TABLE_BYTES_MAX / 2 ** 20 + " MiB");
}
/**
* Probes an RNG once, at construction time: returns `undefined` when it is unavailable —
* throws or returns malformed bytes — so callers can downgrade to their unblinded /
* deterministic constant-time fallback. Blinding is defense-in-depth (DPA/template
* hardening), not a correctness or key-secrecy requirement, so availability-based
* downgrade is acceptable.
*
* The downgrade decision is deliberately static. After a successful probe the RNG becomes
* part of the trusted contract: later misbehavior must fail closed in per-call validation
* (throw), never downgrade — a dynamic fallback would let a tampered RNG silently strip
* blinding on demand. A probe can only ever classify broken environments, not adversarial
* RNGs: a stateful RNG can always behave while probed and misbehave later.
* @param randomBytes - RNG to probe, or `undefined` when the environment provides none.
* @param length - Byte length requested from the probe call.
* @returns The RNG when the probe produced `length` valid bytes; `undefined` otherwise.
* @example
* Probe an RNG once before enabling scalar blinding.
*
* ```ts
* import { probeRandomBytes } from '@noble/curves/abstract/curve.js';
* import { randomBytes } from '@noble/hashes/utils.js';
* const rng = probeRandomBytes(randomBytes, 16);
* ```
*/
function probeRandomBytes(randomBytes, length) {
	if (randomBytes === void 0) return void 0;
	afunction(randomBytes, "randomBytes");
	try {
		const probe = randomBytes(length);
		if (!isBytes(probe) || probe.length !== length) return void 0;
	} catch {
		return;
	}
	return randomBytes;
}
function validateMSMPoints(points, c) {
	aarray(points, "points");
	points.forEach((p, i) => {
		if (!(p instanceof c)) throw new Error("invalid point at index " + i);
	});
}
function validateMSMScalars(scalars, field, maxScalar) {
	if (!Array.isArray(scalars)) throw new Error("array of scalars expected");
	scalars.forEach((s, i) => {
		if (!(maxScalar === void 0 ? field.isValid(s) : isPosBig(s) && s < maxScalar)) throw new Error("invalid scalar at index " + i);
	});
}
var pointWindowSizes = /* @__PURE__ */ new WeakMap();
function getWindowSize(P) {
	return pointWindowSizes.get(P) || 1;
}
/** Table of odd multiples [1P, 3P, ..., (2⋅size−1)P]; width-W wNAF uses size = 2^(W−2). */
function oddMultiples(p, size) {
	const dbl = p.double();
	const t = [p];
	for (let j = 1; j < size; j++) t.push(t[j - 1].add(dbl));
	return t;
}
/**
* Width-W wNAF signed-digit recoding (W >= 2), LSB-first: digits are 0 or odd with
* |digit| < 2^(W−1); nonzero density ~1/(W+1) (a nonzero digit is followed by W−1 zeros).
*/
function wnafDigits(n, W) {
	const size = 2 ** W;
	const half = size / 2;
	const mask = BigInt(size - 1);
	const d = [];
	while (n > _0n$3) {
		let w = 0;
		if (n & _1n$3) {
			w = Number(n & mask);
			if (w >= half) w -= size;
			n -= BigInt(w);
		}
		d.push(w);
		n >>= _1n$3;
	}
	return d;
}
/**
* Fixed-position signed-window recoding for precomputed wNAF: `n = Σ digits[w]⋅2^(w⋅W)` with
* digits in `[−2^(W−1)+1, 2^(W−1)]`. Digit count is fixed by `windows` (callers reserve one
* extra window for the final carry), so recoding length does not depend on the scalar.
*/
function signedWindowDigits(n, W, windows) {
	const size = 2 ** W;
	const half = size / 2;
	const mask = BigInt(size - 1);
	const shiftBy = BigInt(W);
	const d = [];
	for (let w = 0; w < windows; w++) {
		let v = Number(n & mask);
		n >>= shiftBy;
		if (v > half) {
			v -= size;
			n += _1n$3;
		}
		d.push(v);
	}
	if (n !== _0n$3) throw new Error("invalid wnaf");
	return d;
}
/**
* Shared vartime walk over per-scalar wNAF digit streams: one doubling of a single shared
* accumulator per bit position of the longest recoding, one signed table addition per
* nonzero digit. `tables[i]` must hold the odd multiples of the i-th point.
*/
function wnafWalk(zero, tables, digits) {
	let max = 0;
	for (const d of digits) max = Math.max(max, d.length);
	let acc = zero;
	for (let bit = max - 1; bit >= 0; bit--) {
		if (bit !== max - 1) acc = acc.double();
		for (let i = 0; i < digits.length; i++) {
			const w = digits[i][bit];
			if (w) {
				const item = tables[i][Math.abs(w) - 1 >> 1];
				acc = acc.add(w < 0 ? item.negate() : item);
			}
		}
	}
	return acc;
}
/**
* Elliptic curve multiplication of Point by scalar.
* Routes between cached-table, fixed-window, and one-shot wNAF paths; entry points validate
* their own scalars (`mulCT`/`mulCTBlinded`: `1 <= s < Fn.ORDER`; `mulUnsafe`: up to the
* `Fn.ORDER^4` DoS cap via {@link mulAddUnsafe}).
* Table generation is expensive and happens on first call of `multiply()`
* (or eagerly via `precompute(W, false)`). By default, `BASE` point is precomputed.
*
* Cached algorithm is signed fixed-window wNAF:
* - table stores, for every window w, the multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P` — all doublings
*   are baked in, so a multiplication is exactly one table addition per window
* - window count is fixed (`ceil(bits/W) + 1`), so the point-operation count is scalar-independent
*   (basis of the constant-time path)
* - for a 256-bit curve and W=6: 44⋅32 = 1408 table points, 44 additions per multiply
* - secret scalars are additionally blinded (see {@link ScalarMultiplier.mulCTBlinded}), which
*   widens tables by 128 bits
* @param Point - Point constructor.
* @param randomBytes - RNG used for scalar blinding; required by the blinded secret path.
* @example
* Elliptic curve multiplication of Point by scalar.
*
* ```ts
* import { ScalarMultiplier } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const mul = new ScalarMultiplier(p256.Point);
* ```
*/
var ScalarMultiplier = class {
	Point;
	BASE;
	ZERO;
	randomBytes;
	wnafPrecomputes = /* @__PURE__ */ new WeakMap();
	baseCanBeBlinded;
	bits;
	constructor(Point, randomBytes) {
		validatePointCons(Point);
		this.randomBytes = probeRandomBytes(randomBytes, BLIND_BYTES);
		this.Point = Point;
		this.BASE = Point.BASE;
		this.ZERO = Point.ZERO;
		this.bits = Point.Fn.BITS;
	}
	/**
	* Creates a signed fixed-window wNAF precomputation table: for every window w, the
	* multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P`, flattened. All doublings are baked into the table,
	* so cached multiplication is additions-only. `windows = ceil(bits/W) + 1`: the extra
	* window absorbs the final carry of signed-digit recoding.
	* For a 256-bit curve and W=6, the table is 44⋅32 = 1408 points.
	* @param point - Point instance
	* @param W - window size
	* @param bits - scalar bitlength the table must cover
	*/
	buildWnafTable(point, W, bits) {
		const windows = Math.ceil(bits / W) + 1;
		const half = 2 ** (W - 1);
		const comp = [];
		let base = point;
		for (let w = 0; w < windows; w++) {
			let acc = base;
			for (let i = 0; i < half; i++) {
				comp.push(acc);
				acc = acc.add(base);
			}
			base = comp[comp.length - 1].double();
		}
		return {
			W,
			bits,
			windows,
			comp
		};
	}
	/**
	* Implements ec multiplication using precomputed signed fixed-window wNAF tables.
	* Constant-time: fixed window count with one table addition per window — zero digits feed
	* the fake accumulator — and no doublings; the lookup scans the whole window slice.
	* Scalar bounds are validated by the public entry points ({@link ScalarMultiplier.mulCT},
	* {@link ScalarMultiplier.mulCTBlinded}, {@link ScalarMultiplier.mulUnsafe});
	* signedWindowDigits throws if `n` exceeds the table.
	* @returns real and fake (for const-time) points
	*/
	wnafCachedCT(precomputes, n) {
		const { W, windows, comp } = precomputes;
		const half = 2 ** (W - 1);
		const digits = signedWindowDigits(n, W, windows);
		let p = this.ZERO;
		let f = this.BASE;
		for (let w = 0; w < windows; w++) {
			const digit = digits[w];
			const start = w * half;
			const idx = Math.abs(digit) - 1;
			let sel = comp[start];
			for (let i = 1; i < half; i++) sel = i === idx ? comp[start + i] : sel;
			const neg = sel.negate();
			if (digit === 0) f = f.add(comp[start]);
			else p = p.add(digit < 0 ? neg : sel);
		}
		return {
			p,
			f
		};
	}
	getWnafPrecomputes(W, point, bits, transform) {
		let entries = this.wnafPrecomputes.get(point);
		let comp = entries?.find((entry) => entry.W === W && entry.bits === bits);
		if (!comp) {
			comp = this.buildWnafTable(point, W, bits);
			if (typeof transform === "function") comp = {
				...comp,
				comp: transform(comp.comp)
			};
			if (!entries) {
				entries = [];
				this.wnafPrecomputes.set(point, entries);
			}
			entries.push(comp);
		}
		return comp;
	}
	assertPoint(point) {
		if (!(point instanceof this.Point)) throw new TypeError("\"point\" expected Point instance, got type=" + typeof point);
	}
	validateMulInput(point, scalar) {
		this.assertPoint(point);
		if (!inRange(scalar, _1n$3, this.Point.Fn.ORDER)) throw new Error("invalid scalar");
	}
	runCT(point, n, bits, transform) {
		const W = getWindowSize(point);
		if (W === 1) return this.fixedWindowCT(point, n, bits);
		return this.wnafCachedCT(this.getWnafPrecomputes(W, point, bits, transform), n);
	}
	mulCT(point, scalar, transform) {
		this.validateMulInput(point, scalar);
		return this.runCT(point, scalar, this.bits, transform);
	}
	mulCTBlinded(point, scalar, transform) {
		this.validateMulInput(point, scalar);
		if (this.randomBytes === void 0) throw new Error("randomBytes is required for scalar blinding");
		const bits = this.Point.Fn.BITS + BLIND_BITS;
		const blind = this.randomBytes(BLIND_BYTES);
		if (!isBytes(blind) || blind.length !== BLIND_BYTES) throw new Error("randomBytes returned invalid byte array");
		blind[0] = blind[0] & 63 | 128;
		const n = scalar + bytesToNumberBE(blind) * this.Point.Fn.ORDER;
		return this.runCT(point, n, bits, transform);
	}
	/**
	* Constant-time multiplication `n*point` for an un-precomputed point, via a small fixed window.
	* A cached wNAF table only pays off when reused; a flat 2^FW_WINDOW table (`size-1` adds) is
	* far cheaper to build for a single use. The point-operation sequence is independent of `n`:
	* build the table, then per window exactly FW_WINDOW doublings, a data-oblivious scan over
	* every table entry, and one addition (adds the identity when the window digit is 0 — never
	* skipped).
	*
	* `n` must be `< 2^bits`. Assumes complete addition (adding the identity costs the same as any
	* add), which holds for the Weierstrass/Edwards point types used here. The table is left in
	* projective form (no normalizeZ): normalizing this small a table costs more than the
	* mixed-add savings it would buy for a single multiply.
	* @returns real point `p`; `f` duplicates it only to match {@link wnafCachedCT}'s return shape
	* (this path needs no fake accumulator — its op-count is already scalar-independent).
	*/
	fixedWindowCT(point, n, bits) {
		const W = FW_WINDOW;
		const size = 32;
		const mask = bitMask(W);
		const table = new Array(size);
		table[0] = this.ZERO;
		for (let i = 1; i < size; i++) table[i] = table[i - 1].add(point);
		const windows = Math.ceil(bits / W);
		let acc = this.ZERO;
		for (let window = windows - 1; window >= 0; window--) {
			if (window !== windows - 1) for (let d = 0; d < W; d++) acc = acc.double();
			const digit = Number(n >> BigInt(window * W) & mask);
			let sel = table[0];
			for (let i = 1; i < size; i++) sel = i === digit ? table[i] : sel;
			acc = acc.add(sel);
		}
		return {
			p: acc,
			f: acc
		};
	}
	shouldBlind(point, cofactor) {
		if (this.randomBytes === void 0) return false;
		if (cofactor === _1n$3) return true;
		if (point !== this.BASE) return false;
		if (this.baseCanBeBlinded === void 0) this.baseCanBeBlinded = this.mulUnsafe(this.BASE, this.Point.Fn.ORDER).is0();
		return this.baseCanBeBlinded;
	}
	mulSecret(point, scalar, cofactor, transform) {
		return this.shouldBlind(point, cofactor) ? this.mulCTBlinded(point, scalar, transform) : this.mulCT(point, scalar, transform);
	}
	mulUnsafe(point, scalar, transform) {
		this.assertPoint(point);
		if (!isPosBig(scalar)) throw new Error("invalid scalar");
		const W = getWindowSize(point);
		if (W === 1 || scalar >= this.Point.Fn.ORDER) return mulAddUnsafe(this.Point, [point], [scalar], true);
		const precomputes = this.getWnafPrecomputes(W, point, this.bits, transform);
		return this.wnafCachedCT(precomputes, scalar).p;
	}
	setWindowSize(point, W) {
		this.assertPoint(point);
		validateW(W, this.bits);
		validateTableBytes((Math.ceil((this.bits + BLIND_BITS) / W) + 1) * 2 ** (W - 1), this.Point.Fp.BYTES);
		pointWindowSizes.set(point, W);
		this.wnafPrecomputes.delete(point);
	}
	hasWindowSize(point) {
		return getWindowSize(point) !== 1;
	}
};
/**
* Combined multi-scalar multiplication `Σ scalars[i]⋅points[i]` via interleaved width-4 wNAF
* (Strauss–Shamir). Every input gets its own table of odd multiples `[1P, 3P, 5P, 7P]` and
* signed-digit recoding, but all walks share one doubling chain, so total cost is
* `~bits` doublings + `L⋅bits/5` additions instead of `L⋅bits` doublings for separate
* multiplications. Intended for the 2-4 point shapes of signature verification
* (`R = u1⋅G + u2⋅P`); use {@link pippenger} for larger batches.
*
* Not constant-time: only for public inputs. Scalars must satisfy `0 <= s < Fn.ORDER`;
* fold negative signs into the points before calling.
* @param c - Point constructor.
* @param points - Array of curve points.
* @param scalars - Array of non-negative scalars, same length as points.
* @param allowOversized - Replace the `s < Fn.ORDER` scalar check with a `Fn.ORDER^4` DoS cap.
*   Off by default. For scalars that must NOT be reduced mod ORDER: torsion checks
*   (`Fn.ORDER⋅P ≟ O`) and cofactor-clearing multiples. Walk length grows with `bitLen(s)`.
* @returns Combined multiplication result; identity for empty input.
* @throws If the point set or scalar set is invalid. {@link Error}
* @example
* Combined multi-scalar multiplication via Strauss–Shamir.
*
* ```ts
* import { mulAddUnsafe } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const G = p256.Point.BASE;
* const R = mulAddUnsafe(p256.Point, [G, G.double()], [2n, 3n]); // 2⋅G + 3⋅(2⋅G)
* ```
*/
function mulAddUnsafe(c, points, scalars, allowOversized = false) {
	validatePointCons(c);
	validateMSMPoints(points, c);
	abool(allowOversized, "allowOversized");
	validateMSMScalars(scalars, c.Fn, allowOversized ? c.Fn.ORDER ** _4n$2 : void 0);
	if (points.length !== scalars.length) throw new Error("arrays of points and scalars must have equal length");
	const tables = points.map((p) => oddMultiples(p, 4));
	const digits = scalars.map((n) => wnafDigits(n, 4));
	return wnafWalk(c.ZERO, tables, digits);
}
function createField(order, field, isLE) {
	if (field) {
		if (field.ORDER !== order) throw new Error("Field.ORDER must match order: Fp == p, Fn == n");
		validateField(field);
		return field;
	} else return Field(order, { isLE });
}
/**
* Validates basic CURVE shape and field membership, then creates fields.
* This does not prove that the generator is on-curve, that subgroup/order data are consistent, or
* that the curve equation itself is otherwise sane.
* @param type - Curve family.
* @param CURVE - Curve parameters.
* @param curveOpts - Optional field overrides. See {@link FpFn}:
*   - `Fp` (optional): Optional base-field override.
*   - `Fn` (optional): Optional scalar-field override.
* @param FpFnLE - Whether field encoding is little-endian.
* @returns Frozen curve parameters and fields.
* @throws If the curve parameters or field overrides are invalid. {@link Error}
* @example
* Build curve fields from raw constants before constructing a curve instance.
*
* ```ts
* const curve = createCurveFields('weierstrass', {
*   p: 17n,
*   n: 19n,
*   h: 1n,
*   a: 2n,
*   b: 2n,
*   Gx: 5n,
*   Gy: 1n,
* });
* ```
*/
function createCurveFields(type, CURVE, curveOpts = {}, FpFnLE) {
	if (type !== "weierstrass" && type !== "edwards") throw new Error("expected curve type \"weierstrass\" or \"edwards\"");
	if (FpFnLE === void 0) FpFnLE = type === "edwards";
	if (!CURVE || typeof CURVE !== "object") throw new Error(`expected valid ${type} CURVE object`);
	validateObject(curveOpts);
	for (const p of [
		"p",
		"n",
		"h"
	]) {
		const val = CURVE[p];
		if (!(isPosBig(val) && val !== _0n$3)) throw new Error(`CURVE.${p} must be positive bigint`);
	}
	const Fp = createField(CURVE.p, curveOpts.Fp, FpFnLE);
	const Fn = createField(CURVE.n, curveOpts.Fn, FpFnLE);
	const params = [
		"Gx",
		"Gy",
		"a",
		type === "weierstrass" ? "b" : "d"
	];
	for (const p of params) if (!Fp.isValid(CURVE[p])) throw new Error(`CURVE.${p} must be valid field element of CURVE.Fp`);
	CURVE = Object.freeze(Object.assign({}, CURVE));
	return {
		CURVE,
		Fp,
		Fn
	};
}
/**
* @param randomSecretKey - Secret-key generator.
* @param getPublicKey - Public-key derivation helper.
* @returns Keypair generator.
* @example
* Build a `keygen()` helper from existing secret-key and public-key primitives.
*
* ```ts
* import { createKeygen } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const keygen = createKeygen(p256.utils.randomSecretKey, p256.getPublicKey);
* const pair = keygen();
* ```
*/
function createKeygen(randomSecretKey, getPublicKey) {
	return function keygen(seed) {
		const secretKey = randomSecretKey(seed);
		return {
			secretKey,
			publicKey: getPublicKey(secretKey)
		};
	};
}
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/abstract/edwards.js
/**
* Twisted Edwards curve. The formula is: ax² + y² = 1 + dx²y².
* For design rationale of types / exports, see weierstrass module documentation.
* Untwisted Edwards curves exist, but they aren't used in real-world protocols.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$2 = /* @__PURE__ */ BigInt(0);
var _1n$2 = /* @__PURE__ */ BigInt(1);
var _2n$2 = /* @__PURE__ */ BigInt(2);
var _4n$1 = /* @__PURE__ */ BigInt(4);
var _8n$1 = /* @__PURE__ */ BigInt(8);
function isEdValidXY(Fp, CURVE, x, y) {
	const x2 = Fp.sqr(x);
	const y2 = Fp.sqr(y);
	const left = Fp.add(Fp.mul(CURVE.a, x2), y2);
	const right = Fp.add(Fp.ONE, Fp.mul(CURVE.d, Fp.mul(x2, y2)));
	return Fp.eql(left, right);
}
/**
* @param params - Curve parameters. See {@link EdwardsOpts}.
* @param extraOpts - Optional helpers and overrides. See {@link EdwardsExtraOpts}.
* @returns Edwards point constructor. Generator validation here only checks
*   that `(Gx, Gy)` satisfies the affine Edwards equation.
*   RFC 8032 base-point constraints like `B != (0,1)` and `[L]B = 0`
*   are left to the caller's chosen parameters, since eager subgroup
*   validation here adds about 10-15ms to heavyweight imports like ed448.
*   The returned constructor also eagerly marks `Point.BASE` for W=6
*   precompute caching. Some code paths still assume
*   `Fp.BYTES === Fn.BYTES`, so mismatched byte lengths are not fully audited here.
* @throws If the curve parameters or Edwards overrides are invalid. {@link Error}
* @example
* ```ts
* import { edwards } from '@noble/curves/abstract/edwards.js';
* import { jubjub } from '@noble/curves/misc.js';
* // Build a point constructor from explicit curve parameters, then use its base point.
* const Point = edwards(jubjub.Point.CURVE());
* Point.BASE.toHex();
* ```
*/
function edwards(params, extraOpts = {}) {
	validateObject(extraOpts, {}, {}, "extraOpts");
	const opts = extraOpts;
	const validated = createCurveFields("edwards", params, opts, opts.FpFnLE);
	const { Fp, Fn } = validated;
	let CURVE = validated.CURVE;
	const { h: cofactor } = CURVE;
	if (FpLegendre(Fp, CURVE.a) !== 1) throw new Error("edwards: CURVE.a must be a square in Fp for complete addition formulas");
	if (FpLegendre(Fp, CURVE.d) !== -1) throw new Error("edwards: CURVE.d must be a non-square in Fp for complete addition formulas");
	validateObject(opts, {}, {
		uvRatio: "function",
		randomBytes: "function"
	});
	const randomBytes$4 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
	const MASK = _2n$2 << BigInt(Fp.BYTES * 8) - _1n$2;
	function isOdd(n) {
		if (!Fp.isOdd) throw new Error("Field does not have .isOdd()");
		return Fp.isOdd(n);
	}
	const uvRatio = opts.uvRatio === void 0 ? (u, v) => {
		try {
			return {
				isValid: true,
				value: Fp.sqrt(Fp.div(u, v))
			};
		} catch (e) {
			return {
				isValid: false,
				value: _0n$2
			};
		}
	} : opts.uvRatio;
	if (!isEdValidXY(Fp, CURVE, CURVE.Gx, CURVE.Gy)) throw new Error("bad curve params: generator point");
	const mulA = Fp.eql(CURVE.a, Fp.neg(Fp.ONE)) ? (x) => Fp.neg(x) : Fp.eql(CURVE.a, Fp.ONE) ? (x) => x : (x) => Fp.mul(CURVE.a, x);
	/**
	* Asserts coordinate is valid: 0 <= n < MASK.
	* Coordinates >= Fp.ORDER are allowed for zip215.
	*/
	function acoord(title, n, banZero = false) {
		const min = banZero ? _1n$2 : _0n$2;
		aInRange("coordinate " + title, n, min, MASK);
		return n;
	}
	function aedpoint(other) {
		if (!(other instanceof Point)) throw new Error("EdwardsPoint expected");
	}
	class Point {
		static BASE = new Point(CURVE.Gx, CURVE.Gy, Fp.ONE, Fp.mul(CURVE.Gx, CURVE.Gy));
		static ZERO = new Point(Fp.ZERO, Fp.ONE, Fp.ONE, Fp.ZERO);
		static Fp = Fp;
		static Fn = Fn;
		X;
		Y;
		Z;
		T;
		constructor(X, Y, Z, T) {
			this.X = acoord("x", X);
			this.Y = acoord("y", Y);
			this.Z = acoord("z", Z, true);
			this.T = acoord("t", T);
			Object.freeze(this);
		}
		static CURVE() {
			return CURVE;
		}
		/**
		* Create one extended Edwards point from affine coordinates.
		* Does NOT validate that the point is on-curve or torsion-free.
		* Use `.assertValidity()` on adversarial inputs.
		*/
		static fromAffine(p) {
			if (p instanceof Point) throw new Error("extended point not allowed");
			const { x, y } = p || {};
			acoord("x", x);
			acoord("y", y);
			return new Point(x, y, Fp.ONE, Fp.mul(x, y));
		}
		static fromBytes(bytes, zip215 = false) {
			const len = Fp.BYTES;
			const { a, d } = CURVE;
			bytes = copyBytes(abytes(bytes, len, "point"));
			abool(zip215, "zip215");
			const normed = copyBytes(bytes);
			const lastByte = bytes[len - 1];
			normed[len - 1] = lastByte & -129;
			const y = bytesToNumberLE(normed);
			aInRange("point.y", y, _0n$2, zip215 ? MASK : Fp.ORDER);
			const y2 = Fp.sqr(y);
			const u = Fp.sub(y2, Fp.ONE);
			const v = Fp.sub(Fp.mulN(d, y2), a);
			let { isValid, value: x } = uvRatio(u, v);
			if (!isValid) throw new Error("bad point: invalid y coordinate");
			const isXOdd = isOdd(x);
			const isLastByteOdd = (lastByte & 128) !== 0;
			if (!zip215 && Fp.is0(x) && isLastByteOdd) throw new Error("bad point: x=0 and x_0=1");
			if (isLastByteOdd !== isXOdd) x = Fp.neg(x);
			return Point.fromAffine({
				x,
				y
			});
		}
		static fromHex(hex, zip215 = false) {
			return Point.fromBytes(hexToBytes(hex), zip215);
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		precompute(windowSize = 6, isLazy = true) {
			wnaf.setWindowSize(this, windowSize);
			if (!isLazy) this.multiply(_2n$2);
			return this;
		}
		assertValidity() {
			const p = this;
			const { a, d } = CURVE;
			if (p.is0()) throw new Error("bad point: ZERO");
			const { X, Y, Z, T } = p;
			const X2 = Fp.sqr(X);
			const Y2 = Fp.sqr(Y);
			const Z2 = Fp.sqr(Z);
			const Z4 = Fp.sqr(Z2);
			const aX2 = Fp.mul(X2, a);
			const left = Fp.mul(Fp.add(aX2, Y2), Z2);
			const right = Fp.add(Z4, Fp.mul(d, Fp.mul(X2, Y2)));
			if (!Fp.eql(left, right)) throw new Error("bad point: equation left != right (1)");
			const XY = Fp.mul(X, Y);
			const ZT = Fp.mul(Z, T);
			if (!Fp.eql(XY, ZT)) throw new Error("bad point: equation left != right (2)");
		}
		equals(other) {
			aedpoint(other);
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const { X: X2, Y: Y2, Z: Z2 } = other;
			const X1Z2 = Fp.mul(X1, Z2);
			const X2Z1 = Fp.mul(X2, Z1);
			const Y1Z2 = Fp.mul(Y1, Z2);
			const Y2Z1 = Fp.mul(Y2, Z1);
			return Fp.eql(X1Z2, X2Z1) && Fp.eql(Y1Z2, Y2Z1);
		}
		is0() {
			return this.equals(Point.ZERO);
		}
		negate() {
			return new Point(Fp.neg(this.X), this.Y, this.Z, Fp.neg(this.T));
		}
		double() {
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const A = Fp.sqr(X1);
			const B = Fp.sqr(Y1);
			const C = Fp.mul(Fp.sqr(Z1), _2n$2);
			const D = mulA(A);
			const x1y1 = Fp.addN(X1, Y1);
			const E = Fp.sub(Fp.subN(Fp.sqr(x1y1), A), B);
			const G = Fp.addN(D, B);
			const F = Fp.subN(G, C);
			const H = Fp.subN(D, B);
			const X3 = Fp.mul(E, F);
			const Y3 = Fp.mul(G, H);
			const T3 = Fp.mul(E, H);
			const Z3 = Fp.mul(F, G);
			return new Point(X3, Y3, Z3, T3);
		}
		add(other) {
			aedpoint(other);
			const { d } = CURVE;
			const { X: X1, Y: Y1, Z: Z1, T: T1 } = this;
			const { X: X2, Y: Y2, Z: Z2, T: T2 } = other;
			const A = Fp.mul(X1, X2);
			const B = Fp.mul(Y1, Y2);
			const C = Fp.mul(Fp.mulN(T1, d), T2);
			const D = Fp.mul(Z1, Z2);
			const E = Fp.sub(Fp.subN(Fp.mulN(Fp.addN(X1, Y1), Fp.addN(X2, Y2)), A), B);
			const F = Fp.subN(D, C);
			const G = Fp.addN(D, C);
			const H = Fp.sub(B, mulA(A));
			const X3 = Fp.mul(E, F);
			const Y3 = Fp.mul(G, H);
			const T3 = Fp.mul(E, H);
			const Z3 = Fp.mul(F, G);
			return new Point(X3, Y3, Z3, T3);
		}
		subtract(other) {
			aedpoint(other);
			return this.add(other.negate());
		}
		multiply(scalar) {
			if (!Fn.isValidNot0(scalar)) throw new RangeError("invalid scalar: expected 1 <= sc < curve.n");
			const { p, f } = wnaf.mulSecret(this, scalar, cofactor, normalize);
			return normalize([p, f])[0];
		}
		multiplyUnsafe(scalar) {
			if (!Fn.isValid(scalar)) throw new RangeError("invalid scalar: expected 0 <= sc < curve.n");
			if (scalar === _0n$2) return Point.ZERO;
			if (this.is0() || scalar === _1n$2) return this;
			return wnaf.mulUnsafe(this, scalar, normalize);
		}
		isSmallOrder() {
			return this.clearCofactor().is0();
		}
		isTorsionFree() {
			return wnaf.mulUnsafe(this, CURVE.n).is0();
		}
		toAffine(invertedZ) {
			const p = this;
			let iz = invertedZ;
			if (iz != null && typeof iz !== "bigint") throw new TypeError("\"invertedZ\" expected bigint, got type=" + typeof iz);
			const { X, Y, Z } = p;
			const is0 = p.is0();
			if (iz == null) iz = is0 ? Fp.create(_8n$1) : Fp.inv(Z);
			const x = Fp.mul(X, iz);
			const y = Fp.mul(Y, iz);
			const zz = Fp.mul(Z, iz);
			if (is0) return {
				x: Fp.ZERO,
				y: Fp.ONE
			};
			if (!Fp.eql(zz, Fp.ONE)) throw new Error("invZ was invalid");
			return {
				x,
				y
			};
		}
		clearCofactor() {
			if (cofactor === _1n$2) return this;
			if (cofactor === _2n$2) return this.double();
			if (cofactor === _4n$1) return this.double().double();
			if (cofactor === _8n$1) return this.double().double().double();
			return this.multiplyUnsafe(cofactor);
		}
		toBytes() {
			const { x, y } = this.toAffine();
			const bytes = Fp.toBytes(y);
			bytes[bytes.length - 1] |= isOdd(x) ? 128 : 0;
			return bytes;
		}
		toHex() {
			return bytesToHex(this.toBytes());
		}
		toString() {
			return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
		}
	}
	const normalize = (points) => normalizeZ(Point, points);
	const wnaf = new ScalarMultiplier(Point, randomBytes$4);
	if (wnaf.bits >= 6) Point.BASE.precompute(6);
	Object.freeze(Point.prototype);
	Object.freeze(Point);
	return Point;
}
/**
* Initializes EdDSA signatures over given Edwards curve.
* @param Point - Edwards point constructor.
* @param cHash - Hash function.
* @param eddsaOpts - Optional signature helpers. See {@link EdDSAOpts}.
* @returns EdDSA helper namespace.
* @throws If the hash function, options, or derived point operations are invalid. {@link Error}
* @example
* Initializes EdDSA signatures over given Edwards curve.
*
* ```ts
* import { eddsa } from '@noble/curves/abstract/edwards.js';
* import { jubjub } from '@noble/curves/misc.js';
* import { sha512 } from '@noble/hashes/sha2.js';
* const sigs = eddsa(jubjub.Point, sha512);
* const { secretKey, publicKey } = sigs.keygen();
* const msg = new TextEncoder().encode('hello noble');
* const sig = sigs.sign(msg, secretKey);
* const isValid = sigs.verify(sig, msg, publicKey);
* ```
*/
function eddsa(Point, cHash, eddsaOpts = {}) {
	validatePointCons(Point);
	if (typeof cHash !== "function") throw new Error("\"hash\" function param is required");
	const hash = cHash;
	const opts = eddsaOpts;
	validateObject(opts, {}, {
		adjustScalarBytes: "function",
		randomBytes: "function",
		domain: "function",
		prehash: "function",
		zip215: "boolean",
		mapToCurve: "function",
		toMontgomery: "function",
		toMontgomerySecret: "function"
	});
	const { prehash } = opts;
	const { BASE, Fp, Fn } = Point;
	const outputLen = hash.outputLen;
	const expectedLen = 2 * Fp.BYTES;
	if (outputLen !== void 0) {
		asafenumber(outputLen, "hash.outputLen");
		if (outputLen !== expectedLen) throw new Error(`hash.outputLen must be ${expectedLen}, got ${outputLen}`);
	}
	const randomBytes$5 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
	const toMontgomery = opts.toMontgomery;
	const toMontgomerySecret = opts.toMontgomerySecret;
	const adjustScalarBytes = opts.adjustScalarBytes === void 0 ? (bytes) => bytes : opts.adjustScalarBytes;
	const domain = opts.domain === void 0 ? (data, ctx, phflag) => {
		abool(phflag, "phflag");
		if (ctx.length || phflag) throw new Error("Contexts/pre-hash are not supported");
		return data;
	} : opts.domain;
	function modN_LE(hash) {
		return Fn.create(bytesToNumberLE(hash));
	}
	function getPrivateScalar(key) {
		const len = lengths.secretKey;
		abytes(key, lengths.secretKey, "secretKey");
		const hashed = abytes(hash(key), 2 * len, "hashedSecretKey");
		const head = adjustScalarBytes(hashed.slice(0, len));
		return {
			head,
			prefix: hashed.slice(len, 2 * len),
			scalar: modN_LE(head)
		};
	}
	/** Convenience method that creates public key from scalar. RFC8032 5.1.5
	* Also exposes the derived scalar/prefix tuple and point form reused by sign().
	*/
	function getExtendedPublicKey(secretKey) {
		const { head, prefix, scalar } = getPrivateScalar(secretKey);
		const point = BASE.multiply(scalar);
		return {
			head,
			prefix,
			scalar,
			point,
			pointBytes: point.toBytes()
		};
	}
	/** Calculates EdDSA pub key. RFC8032 5.1.5. */
	function getPublicKey(secretKey) {
		return getExtendedPublicKey(secretKey).pointBytes;
	}
	function hashDomainToScalar(context = Uint8Array.of(), ...msgs) {
		const msg = concatBytes(...msgs);
		return modN_LE(hash(domain(msg, abytes(context, void 0, "context"), !!prehash)));
	}
	/** Signs message with secret key. RFC8032 5.1.6 */
	function sign(msg, secretKey, options = {}) {
		validateObject(options, {}, {}, "options");
		msg = copyBytes(abytes(msg, void 0, "message"));
		if (prehash) msg = prehash(msg);
		const { prefix, scalar, pointBytes } = getExtendedPublicKey(secretKey);
		const r = hashDomainToScalar(options.context, prefix, msg);
		const R = BASE.multiply(r).toBytes();
		const k = hashDomainToScalar(options.context, R, pointBytes, msg);
		const s = Fn.create(r + k * scalar);
		if (!Fn.isValid(s)) throw new Error("sign failed: invalid s");
		return abytes(concatBytes(R, Fn.toBytes(s)), lengths.signature, "result");
	}
	const verifyOpts = { zip215: opts.zip215 };
	/**
	* Verifies EdDSA signature against message and public key. RFC 8032 §§5.1.7 and 5.2.7.
	* A cofactored verification equation is checked.
	*/
	function verify(sig, msg, publicKey, options = verifyOpts) {
		validateObject(options);
		const { context } = options;
		const zip215 = options.zip215 === void 0 ? !!verifyOpts.zip215 : options.zip215;
		const len = lengths.signature;
		sig = abytes(sig, len, "signature");
		msg = abytes(msg, void 0, "message");
		publicKey = abytes(publicKey, lengths.publicKey, "publicKey");
		if (zip215 !== void 0) abool(zip215, "zip215");
		if (prehash) msg = prehash(msg);
		const mid = len / 2;
		const r = sig.subarray(0, mid);
		const s = bytesToNumberLE(sig.subarray(mid, len));
		let A, R, SB;
		try {
			A = Point.fromBytes(publicKey, zip215);
			R = Point.fromBytes(r, zip215);
			SB = BASE.multiplyUnsafe(s);
		} catch (error) {
			return false;
		}
		if (!zip215 && A.isSmallOrder()) return false;
		const k = hashDomainToScalar(context, r, publicKey, msg);
		return R.add(A.multiplyUnsafe(k)).subtract(SB).clearCofactor().is0();
	}
	const _size = Fp.BYTES;
	const lengths = {
		secretKey: _size,
		publicKey: _size,
		signature: 2 * _size,
		seed: _size
	};
	function randomSecretKey(seed) {
		seed = seed === void 0 ? randomBytes$5(lengths.seed) : seed;
		return abytes(seed, lengths.seed, "seed");
	}
	function isValidSecretKey(key) {
		return isBytes(key) && key.length === lengths.secretKey;
	}
	function isValidPublicKey(key, zip215) {
		try {
			return !!Point.fromBytes(key, zip215 === void 0 ? verifyOpts.zip215 : zip215);
		} catch (error) {
			return false;
		}
	}
	const utils = {
		getExtendedPublicKey,
		randomSecretKey,
		isValidSecretKey,
		isValidPublicKey,
		/** Converts an Edwards public key to a companion Montgomery public key. */
		toMontgomery(publicKey) {
			if (toMontgomery === void 0) throw new Error("Montgomery conversion is not supported for this curve");
			return toMontgomery(Point.fromBytes(publicKey));
		},
		toMontgomerySecret(secretKey) {
			if (toMontgomerySecret === void 0) throw new Error("Montgomery conversion is not supported for this curve");
			return toMontgomerySecret(secretKey);
		}
	};
	Object.freeze(lengths);
	Object.freeze(utils);
	return Object.freeze({
		keygen: createKeygen(randomSecretKey, getPublicKey),
		getPublicKey,
		sign,
		verify,
		utils,
		Point,
		lengths
	});
}
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/ed25519.js
/**
* ed25519 Twisted Edwards curve with following addons:
* - X25519 ECDH
* - Ristretto cofactor elimination
* - Elligator hash-to-group / point indistinguishability
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _1n$1 = /* @__PURE__ */ BigInt(1);
var _2n$1 = /* @__PURE__ */ BigInt(2);
var _5n = /* @__PURE__ */ BigInt(5);
var _8n = /* @__PURE__ */ BigInt(8);
var ed25519_CURVE_p = /* @__PURE__ */ BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed");
var ed25519_CURVE = /* @__PURE__ */ (() => ({
	p: ed25519_CURVE_p,
	n: BigInt("0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed"),
	h: _8n,
	a: BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffec"),
	d: BigInt("0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3"),
	Gx: BigInt("0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a"),
	Gy: BigInt("0x6666666666666666666666666666666666666666666666666666666666666658")
}))();
function ed25519_pow_2_252_3(x) {
	const _10n = BigInt(10), _20n = BigInt(20), _40n = BigInt(40), _80n = BigInt(80);
	const P = ed25519_CURVE_p;
	const b2 = x * x % P * x % P;
	const b5 = pow2(pow2(b2, _2n$1, P) * b2 % P, _1n$1, P) * x % P;
	const b10 = pow2(b5, _5n, P) * b5 % P;
	const b20 = pow2(b10, _10n, P) * b10 % P;
	const b40 = pow2(b20, _20n, P) * b20 % P;
	const b80 = pow2(b40, _40n, P) * b40 % P;
	return {
		pow_p_5_8: pow2(pow2(pow2(pow2(b80, _80n, P) * b80 % P, _80n, P) * b80 % P, _10n, P) * b10 % P, _2n$1, P) * x % P,
		b2
	};
}
function adjustScalarBytes(bytes) {
	bytes[0] &= 248;
	bytes[31] &= 127;
	bytes[31] |= 64;
	return bytes;
}
var ED25519_SQRT_M1 = /* @__PURE__ */ BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
function uvRatio(u, v) {
	const P = ed25519_CURVE_p;
	const v3 = mod(v * v * v, P);
	const pow = ed25519_pow_2_252_3(u * mod(v3 * v3 * v, P)).pow_p_5_8;
	let x = mod(u * v3 * pow, P);
	const vx2 = mod(v * x * x, P);
	const root1 = x;
	const root2 = mod(x * ED25519_SQRT_M1, P);
	const useRoot1 = vx2 === u;
	const useRoot2 = vx2 === mod(-u, P);
	const noRoot = vx2 === mod(-u * ED25519_SQRT_M1, P);
	if (useRoot1) x = root1;
	if (useRoot2 || noRoot) x = root2;
	if (isNegativeLE(x, P)) x = mod(-x, P);
	return {
		isValid: useRoot1 || useRoot2,
		value: x
	};
}
var ed25519_Point = /* @__PURE__ */ edwards(ed25519_CURVE, { uvRatio });
var Fp = /* @__PURE__ */ (() => ed25519_Point.Fp)();
function toMontgomery(point) {
	const { y } = point;
	return Fp.toBytes(Fp.div(_1n$1 + y, _1n$1 - y));
}
function toMontgomerySecret(secretKey) {
	const size = ed25519_Point.Fp.BYTES;
	abytes$1(secretKey, size);
	return adjustScalarBytes(sha512(secretKey.subarray(0, size))).subarray(0, size);
}
function ed(opts) {
	return eddsa(ed25519_Point, sha512, Object.assign({
		adjustScalarBytes,
		toMontgomery,
		toMontgomerySecret,
		zip215: true
	}, opts));
}
/**
* ed25519 curve with EdDSA signatures.
* Seeded `keygen(seed)` / `utils.randomSecretKey(seed)` reuse the provided
* 32-byte seed buffer instead of copying it.
* @example
* Generate one Ed25519 keypair, sign a message, and verify it.
*
* ```js
* import { ed25519 } from '@noble/curves/ed25519.js';
* const { secretKey, publicKey } = ed25519.keygen();
* // const publicKey = ed25519.getPublicKey(secretKey);
* const msg = new TextEncoder().encode('hello noble');
* const sig = ed25519.sign(msg, secretKey);
* const isValid = ed25519.verify(sig, msg, publicKey); // ZIP215
* // RFC8032 / FIPS 186-5
* const isValid2 = ed25519.verify(sig, msg, publicKey, { zip215: false });
* ```
*/
var ed25519 = /* @__PURE__ */ ed({});
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/hmac.js
/**
* HMAC: RFC2104 message authentication code.
* @module
*/
/**
* Internal class for HMAC.
* Accepts any byte key, although RFC 2104 §3 recommends keys at least
* `HashLen` bytes long.
*/
var _HMAC = class {
	oHash;
	iHash;
	blockLen;
	outputLen;
	canXOF = false;
	finished = false;
	destroyed = false;
	constructor(hash, key) {
		ahash(hash);
		abytes$1(key, void 0, "key");
		this.iHash = hash.create();
		if (typeof this.iHash.update !== "function") throw new Error("expected Hash instance");
		this.blockLen = this.iHash.blockLen;
		this.outputLen = this.iHash.outputLen;
		const blockLen = this.blockLen;
		const pad = new Uint8Array(blockLen);
		pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
		for (let i = 0; i < pad.length; i++) pad[i] ^= 54;
		this.iHash.update(pad);
		this.oHash = hash.create();
		for (let i = 0; i < pad.length; i++) pad[i] ^= 106;
		this.oHash.update(pad);
		clean(pad);
	}
	update(buf) {
		aexists(this);
		this.iHash.update(buf);
		return this;
	}
	digestInto(out) {
		aexists(this);
		aoutput(out, this);
		this.finished = true;
		const buf = out.subarray(0, this.outputLen);
		this.iHash.digestInto(buf);
		this.oHash.update(buf);
		this.oHash.digestInto(buf);
		this.destroy();
	}
	digest() {
		const out = new Uint8Array(this.oHash.outputLen);
		this.digestInto(out);
		return out;
	}
	_cloneInto(to) {
		to ||= Object.create(Object.getPrototypeOf(this), {});
		const { oHash, iHash, finished, destroyed, blockLen, outputLen, canXOF } = this;
		to = to;
		to.finished = finished;
		to.destroyed = destroyed;
		to.blockLen = blockLen;
		to.outputLen = outputLen;
		to.canXOF = canXOF;
		to.oHash = oHash._cloneInto(to.oHash);
		to.iHash = iHash._cloneInto(to.iHash);
		return to;
	}
	clone() {
		return this._cloneInto();
	}
	destroy() {
		this.destroyed = true;
		this.oHash.destroy();
		this.iHash.destroy();
	}
};
var hmac = /* @__PURE__ */ (() => {
	const hmac_ = ((hash, key, message) => new _HMAC(hash, key).update(message).digest());
	hmac_.create = (hash, key) => new _HMAC(hash, key);
	return hmac_;
})();
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/pbkdf2.js
/**
* PBKDF (RFC 2898). Can be used to create a key from password and salt.
* @module
*/
function pbkdf2Init(hash, _password, _salt, _opts) {
	ahash(hash);
	const { c, dkLen, asyncTick } = checkOpts({
		dkLen: 32,
		asyncTick: 10
	}, _opts);
	anumber$1(c, "c");
	anumber$1(dkLen, "dkLen");
	anumber$1(asyncTick, "asyncTick");
	if (c < 1) throw new Error("\"c\" (iterations) must be >= 1");
	if (dkLen < 1) throw new Error("\"dkLen\" must be >= 1");
	if (dkLen > (2 ** 32 - 1) * hash.outputLen) throw new Error("derived key too long");
	const p = kdfInputToBytes(_password, "password");
	try {
		const s = kdfInputToBytes(_salt, "salt");
		try {
			const DK = new Uint8Array(dkLen);
			const { iHash, oHash, outputLen } = hmac.create(hash, p);
			return {
				c,
				dkLen,
				asyncTick,
				DK,
				outputLen,
				eng: pbkdf2Engine(iHash, oHash, s, new Uint8Array(outputLen))
			};
		} finally {
			if (typeof _salt === "string") clean(s);
		}
	} finally {
		if (typeof _password === "string") clean(p);
	}
}
function pbkdf2Engine(iHash, oHash, salt, u) {
	const counter = /* @__PURE__ */ new Uint8Array(4);
	const view = createView(counter);
	const salted = iHash._cloneInto().update(salt);
	const work = oHash._cloneInto();
	const iClone = iHash._cloneInto;
	const oClone = oHash._cloneInto;
	return {
		u1: (ti, Ti) => {
			view.setInt32(0, ti, false);
			salted._cloneInto(work).update(counter).digestInto(u);
			oHash._cloneInto(work).update(u).digestInto(u);
			Ti.set(u.subarray(0, Ti.length));
		},
		rounds: (c, Ti) => {
			for (let ui = 1; ui < c; ui++) {
				iClone.call(iHash, work).update(u).digestInto(u);
				oClone.call(oHash, work).update(u).digestInto(u);
				for (let i = 0; i < Ti.length; i++) Ti[i] ^= u[i];
			}
		},
		output: (DK) => {
			iHash.destroy();
			oHash.destroy();
			salted.destroy();
			work.destroy();
			clean(u);
			return DK;
		}
	};
}
/**
* PBKDF2-HMAC: RFC 8018 key derivation function.
* @param hash - hash function that would be used e.g. sha256
* @param password - password from which a derived key is generated;
*   JS string inputs are UTF-8 encoded first
* @param salt - cryptographic salt; JS string inputs are UTF-8 encoded first
* @param opts - PBKDF2 work factor and output settings. `dkLen`, if provided,
*   must be `>= 1` per RFC 8018 §5.2. See {@link Pbkdf2Opt}.
* @returns Derived key bytes.
* @throws If the PBKDF2 iteration count or derived-key settings are invalid. {@link Error}
* @example
* PBKDF2-HMAC: RFC 2898 key derivation function.
* ```ts
* import { pbkdf2 } from '@noble/hashes/pbkdf2.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const key = pbkdf2(sha256, 'password', 'salt', { dkLen: 32, c: Math.pow(2, 18) });
* ```
*/
function pbkdf2(hash, password, salt, opts) {
	const { c, dkLen, DK, outputLen, eng } = pbkdf2Init(hash, password, salt, opts);
	for (let ti = 1, pos = 0; pos < dkLen; ti++, pos += outputLen) {
		const Ti = DK.subarray(pos, pos + outputLen);
		eng.u1(ti, Ti);
		eng.rounds(c, Ti);
	}
	return eng.output(DK);
}
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/scrypt.js
/**
* RFC 7914 Scrypt KDF. Can be used to create a key from password and salt.
* @module
*/
function XorAndSalsa(prev, pi, input, ii, out, oi) {
	let y00 = prev[pi++] ^ input[ii++], y01 = prev[pi++] ^ input[ii++];
	let y02 = prev[pi++] ^ input[ii++], y03 = prev[pi++] ^ input[ii++];
	let y04 = prev[pi++] ^ input[ii++], y05 = prev[pi++] ^ input[ii++];
	let y06 = prev[pi++] ^ input[ii++], y07 = prev[pi++] ^ input[ii++];
	let y08 = prev[pi++] ^ input[ii++], y09 = prev[pi++] ^ input[ii++];
	let y10 = prev[pi++] ^ input[ii++], y11 = prev[pi++] ^ input[ii++];
	let y12 = prev[pi++] ^ input[ii++], y13 = prev[pi++] ^ input[ii++];
	let y14 = prev[pi++] ^ input[ii++], y15 = prev[pi++] ^ input[ii++];
	let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
	for (let i = 0; i < 8; i += 2) {
		x04 ^= rotl(x00 + x12 | 0, 7);
		x08 ^= rotl(x04 + x00 | 0, 9);
		x12 ^= rotl(x08 + x04 | 0, 13);
		x00 ^= rotl(x12 + x08 | 0, 18);
		x09 ^= rotl(x05 + x01 | 0, 7);
		x13 ^= rotl(x09 + x05 | 0, 9);
		x01 ^= rotl(x13 + x09 | 0, 13);
		x05 ^= rotl(x01 + x13 | 0, 18);
		x14 ^= rotl(x10 + x06 | 0, 7);
		x02 ^= rotl(x14 + x10 | 0, 9);
		x06 ^= rotl(x02 + x14 | 0, 13);
		x10 ^= rotl(x06 + x02 | 0, 18);
		x03 ^= rotl(x15 + x11 | 0, 7);
		x07 ^= rotl(x03 + x15 | 0, 9);
		x11 ^= rotl(x07 + x03 | 0, 13);
		x15 ^= rotl(x11 + x07 | 0, 18);
		x01 ^= rotl(x00 + x03 | 0, 7);
		x02 ^= rotl(x01 + x00 | 0, 9);
		x03 ^= rotl(x02 + x01 | 0, 13);
		x00 ^= rotl(x03 + x02 | 0, 18);
		x06 ^= rotl(x05 + x04 | 0, 7);
		x07 ^= rotl(x06 + x05 | 0, 9);
		x04 ^= rotl(x07 + x06 | 0, 13);
		x05 ^= rotl(x04 + x07 | 0, 18);
		x11 ^= rotl(x10 + x09 | 0, 7);
		x08 ^= rotl(x11 + x10 | 0, 9);
		x09 ^= rotl(x08 + x11 | 0, 13);
		x10 ^= rotl(x09 + x08 | 0, 18);
		x12 ^= rotl(x15 + x14 | 0, 7);
		x13 ^= rotl(x12 + x15 | 0, 9);
		x14 ^= rotl(x13 + x12 | 0, 13);
		x15 ^= rotl(x14 + x13 | 0, 18);
	}
	out[oi++] = y00 + x00 | 0;
	out[oi++] = y01 + x01 | 0;
	out[oi++] = y02 + x02 | 0;
	out[oi++] = y03 + x03 | 0;
	out[oi++] = y04 + x04 | 0;
	out[oi++] = y05 + x05 | 0;
	out[oi++] = y06 + x06 | 0;
	out[oi++] = y07 + x07 | 0;
	out[oi++] = y08 + x08 | 0;
	out[oi++] = y09 + x09 | 0;
	out[oi++] = y10 + x10 | 0;
	out[oi++] = y11 + x11 | 0;
	out[oi++] = y12 + x12 | 0;
	out[oi++] = y13 + x13 | 0;
	out[oi++] = y14 + x14 | 0;
	out[oi++] = y15 + x15 | 0;
}
function BlockMix(input, ii, out, oi, r) {
	let head = oi + 0;
	let tail = oi + 16 * r;
	for (let i = 0; i < 16; i++) out[tail + i] = input[ii + (2 * r - 1) * 16 + i];
	for (let i = 0; i < r; i++, head += 16, ii += 16) {
		XorAndSalsa(out, tail, input, ii, out, head);
		if (i > 0) tail += 16;
		XorAndSalsa(out, head, input, ii += 16, out, tail);
	}
}
var SCRYPT_DEFAULT_MAXMEM = 1024 * (2 ** 20 + 1 + 1);
function scryptInit(password, salt, _opts) {
	const { N, r, p, dkLen, asyncTick, maxmem, onProgress } = checkOpts({
		dkLen: 32,
		asyncTick: 10,
		maxmem: SCRYPT_DEFAULT_MAXMEM
	}, _opts);
	anumber$1(N, "N");
	anumber$1(r, "r");
	anumber$1(p, "p");
	anumber$1(dkLen, "dkLen");
	anumber$1(asyncTick, "asyncTick");
	anumber$1(maxmem, "maxmem");
	if (onProgress !== void 0 && typeof onProgress !== "function") throw new Error("\"onProgress\" must be a function");
	if (r < 1) throw new Error("\"r\" expected integer >= 1");
	const blockSize = 128 * r;
	const blockSize32 = blockSize / 4;
	const pow32 = Math.pow(2, 32);
	if (N <= 1 || (N & N - 1) !== 0 || N > pow32) throw new Error("\"N\" expected a power of 2, and 2^1 <= N <= 2^32");
	if (p < 1 || p > (pow32 - 1) * 32 / blockSize) throw new Error("\"p\" expected integer 1..((2^32 - 1) * 32) / (128 * r)");
	if (dkLen < 1 || dkLen > (pow32 - 1) * 32) throw new Error("\"dkLen\" expected integer 1..(2^32 - 1) * 32");
	const memUsed = blockSize * (N + p + 1);
	if (memUsed > maxmem) throw new Error("\"maxmem\" limit was hit: memUsed(128*r*(N+p+1))=" + memUsed + ", maxmem=" + maxmem);
	const B = pbkdf2(sha256, password, salt, {
		c: 1,
		dkLen: blockSize * p
	});
	const B32 = u32(B);
	const V = u32(new Uint8Array(blockSize * N));
	const tmp = u32(new Uint8Array(blockSize));
	let blockMixCb = () => {};
	if (onProgress) {
		const totalBlockMix = 2 * N * p;
		const callbackPer = Math.max(Math.floor(totalBlockMix / 1e4), 1);
		let blockMixCnt = 0;
		blockMixCb = () => {
			blockMixCnt++;
			if (onProgress && (!(blockMixCnt % callbackPer) || blockMixCnt === totalBlockMix)) try {
				onProgress(blockMixCnt / totalBlockMix);
			} catch (e) {
				clean(B, V, tmp);
				throw e;
			}
		};
	}
	return {
		N,
		r,
		p,
		dkLen,
		blockSize32,
		V,
		B32,
		B,
		tmp,
		blockMixCb,
		asyncTick
	};
}
function scryptOutput(password, dkLen, B, V, tmp) {
	const res = pbkdf2(sha256, password, B, {
		c: 1,
		dkLen
	});
	clean(B, V, tmp);
	return res;
}
/**
* Scrypt KDF from RFC 7914. See {@link ScryptOpts}.
* @param password - password or key material to derive from;
*   JS string inputs are UTF-8 encoded first
* @param salt - unique salt bytes or string; JS string inputs are UTF-8 encoded first
* @param opts - Scrypt cost and memory parameters. `dkLen`, if provided,
*   must be `>= 1` per RFC 7914 §2. See {@link ScryptOpts}.
* @returns Derived key bytes.
* @throws If the Scrypt cost, memory, or callback options are invalid. {@link Error}
* @example
* Derive a key with scrypt.
* ```ts
* scrypt('password', 'salt', { N: 2**18, r: 8, p: 1, dkLen: 32 });
* ```
* @example
* Derive a key with small demo costs and progress/memory controls.
* ```ts
* const progressLog: number[] = [];
* scrypt('password', 'salt', {
*   N: 16,
*   r: 8,
*   p: 1,
*   dkLen: 32,
*   maxmem: 1024 * 1024,
*   asyncTick: 10,
*   onProgress(progress) {
*     progressLog.push(progress);
*   },
* });
* ```
*/
function scrypt(password, salt, opts) {
	const { N, r, p, dkLen, blockSize32, V, B32, B, tmp, blockMixCb } = scryptInit(password, salt, opts);
	swap32IfBE(B32);
	for (let pi = 0; pi < p; pi++) {
		const Pi = blockSize32 * pi;
		for (let i = 0; i < blockSize32; i++) V[i] = B32[Pi + i];
		for (let i = 0, pos = 0; i < N - 1; i++) {
			BlockMix(V, pos, V, pos += blockSize32, r);
			blockMixCb();
		}
		BlockMix(V, (N - 1) * blockSize32, B32, Pi, r);
		blockMixCb();
		for (let i = 0; i < N; i++) {
			const j = (B32[Pi + blockSize32 - 16] & N - 1) >>> 0;
			for (let k = 0; k < blockSize32; k++) tmp[k] = B32[Pi + k] ^ V[j * blockSize32 + k];
			BlockMix(tmp, 0, B32, Pi, r);
			blockMixCb();
		}
	}
	swap32IfBE(B32);
	return scryptOutput(password, dkLen, B, V, tmp);
}
//#endregion
//#region src/background/mbp1/scrypt-w.ts
/**
* MBP1 pairing code -> scalar `w` derivation (bridge-pairing-protocol.md
* §6.2). Uses `@noble/hashes`'s scrypt rather than Node's `crypto.scryptSync`
* — this module runs inside a browser extension background worker, where
* Node's `crypto` module is unavailable.
*/
var SCRYPT_PARAMS = {
	N: 2 ** 14,
	r: 8,
	p: 1,
	dkLen: 64
};
function bytesToBigIntBE(bytes) {
	let n = 0n;
	for (const byte of bytes) n = n << 8n | BigInt(byte);
	return n;
}
function bigIntToBytesBE(n, length) {
	const out = new Uint8Array(length);
	let value = n;
	for (let i = length - 1; i >= 0; i--) {
		out[i] = Number(value & 255n);
		value >>= 8n;
	}
	return out;
}
/**
* Derive the SPAKE2 password scalar `w` from the normalized pairing code and
* the session's `pairNonce`:
*
* ```
* salt = "MBP1/w/v1" ‖ UTF8(pairNonce)
* h    = scrypt(pw, salt, N=2^14, r=8, p=1, dkLen=64)
* w    = OS2IP(h) mod ℓ
* ```
*
* `pairNonce` makes `w` session-unique. Throws if `w = 0` (probability
* ≈ 2^-252; §6.2 attaches no retry semantics to this case).
*/
function deriveW(codeNormalized, pairNonce) {
	const pw = assertAscii(codeNormalized, "deriveW: codeNormalized");
	assertAscii(pairNonce, "deriveW: pairNonce");
	const h = scrypt(pw, concatBytes$2(utf8("MBP1/w/v1"), utf8(pairNonce)), SCRYPT_PARAMS);
	const order = ed25519.Point.Fn.ORDER;
	const w = bytesToBigIntBE(h) % order;
	if (w === 0n) throw new Error("deriveW: w reduced to 0 mod the group order");
	return bigIntToBytesBE(w, 32);
}
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/abstract/der.js
/**
* ASN.1 DER (Distinguished Encoding Rules) helpers for ECDSA signatures.
* Only implements the tiny subset needed for `SEQUENCE(INTEGER r, INTEGER s)`.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$1 = /* @__PURE__ */ BigInt(0);
/**
* @param m - Error message.
* @example
* Throw a DER-specific error when signature parsing encounters invalid bytes.
*
* ```ts
* new DERErr('bad der');
* ```
*/
var DERErr = class extends Error {
	constructor(m = "") {
		super(m);
	}
};
var _DER = {
	Err: DERErr,
	_tlv: {
		encode: (tag, data) => {
			const { Err: E } = _DER;
			asafenumber(tag, "tag");
			if (tag < 0 || tag > 255) throw new E("tlv.encode: wrong tag");
			astring(data, "data");
			if (data.length & 1) throw new E("tlv.encode: unpadded data");
			const dataLen = data.length / 2;
			const len = numberToHexUnpadded(dataLen);
			if (len.length / 2 & 128) throw new E("tlv.encode: long form length too big");
			const lenLen = dataLen > 127 ? numberToHexUnpadded(len.length / 2 | 128) : "";
			return numberToHexUnpadded(tag) + lenLen + len + data;
		},
		decode(tag, data) {
			const { Err: E } = _DER;
			data = abytes(data, void 0, "DER data");
			let pos = 0;
			if (tag < 0 || tag > 255) throw new E("tlv.decode: wrong tag");
			if (data.length < 2 || data[pos++] !== tag) throw new E("tlv.decode: wrong tlv");
			const first = data[pos++];
			const isLong = !!(first & 128);
			let length = 0;
			if (!isLong) length = first;
			else {
				const lenLen = first & 127;
				if (!lenLen) throw new E("tlv.decode(long): indefinite length not supported");
				if (lenLen > 4) throw new E("tlv.decode(long): byte length is too big");
				const lengthBytes = data.subarray(pos, pos + lenLen);
				if (lengthBytes.length !== lenLen) throw new E("tlv.decode: length bytes not complete");
				if (lengthBytes[0] === 0) throw new E("tlv.decode(long): zero leftmost byte");
				for (const b of lengthBytes) length = length << 8 | b;
				pos += lenLen;
				if (length < 128) throw new E("tlv.decode(long): not minimal encoding");
			}
			const v = data.subarray(pos, pos + length);
			if (v.length !== length) throw new E("tlv.decode: wrong value length");
			return {
				v,
				l: data.subarray(pos + length)
			};
		}
	},
	_int: {
		encode(num) {
			const { Err: E } = _DER;
			abignumber(num);
			if (num < _0n$1) throw new E("integer: negative integers are not allowed");
			let hex = numberToHexUnpadded(num);
			if (Number.parseInt(hex[0], 16) & 8) hex = "00" + hex;
			if (hex.length & 1) throw new E("unexpected DER parsing assertion: unpadded hex");
			return hex;
		},
		decode(data) {
			const { Err: E } = _DER;
			if (data.length < 1) throw new E("invalid signature integer: empty");
			if (data[0] & 128) throw new E("invalid signature integer: negative");
			if (data.length > 1 && data[0] === 0 && !(data[1] & 128)) throw new E("invalid signature integer: unnecessary leading zero");
			return bytesToNumberBE(data);
		}
	},
	toSig(bytes, maxScalarBytes) {
		const { Err: E, _int: int, _tlv: tlv } = _DER;
		if (maxScalarBytes !== void 0) {
			asafenumber(maxScalarBytes, "maxScalarBytes");
			if (maxScalarBytes < 1) throw new E("invalid signature: maxScalarBytes must be positive");
		}
		const data = abytes(bytes, void 0, "signature");
		const { v: seqBytes, l: seqLeftBytes } = tlv.decode(48, data);
		if (seqLeftBytes.length) throw new E("invalid signature: left bytes after parsing");
		const { v: rBytes, l: rLeftBytes } = tlv.decode(2, seqBytes);
		const { v: sBytes, l: sLeftBytes } = tlv.decode(2, rLeftBytes);
		if (sLeftBytes.length) throw new E("invalid signature: left bytes after parsing");
		if (maxScalarBytes !== void 0 && (rBytes.length > maxScalarBytes || sBytes.length > maxScalarBytes)) throw new E("invalid signature: integer too large");
		return {
			r: int.decode(rBytes),
			s: int.decode(sBytes)
		};
	},
	hexFromSig(sig) {
		const { _tlv: tlv, _int: int } = _DER;
		validateObject(sig, {
			r: "bigint",
			s: "bigint"
		}, {}, "sig");
		const seq = tlv.encode(2, int.encode(sig.r)) + tlv.encode(2, int.encode(sig.s));
		return tlv.encode(48, seq);
	}
};
/**
* ASN.1 DER encoding utilities. ASN is very complex & fragile. Format:
*
*     [0x30 (SEQUENCE), bytelength, 0x02 (INTEGER), intLength, R, 0x02 (INTEGER), intLength, S]
*
* Docs: {@link https://letsencrypt.org/docs/a-warm-welcome-to-asn1-and-der/ | Let's Encrypt ASN.1 guide} and
* {@link https://luca.ntop.org/Teaching/Appunti/asn1.html | Luca Deri's ASN.1 notes}.
* @example
* ASN.1 DER encoding utilities.
*
* ```ts
* const der = DER.hexFromSig({ r: 1n, s: 2n });
* ```
*/
var DER = /* @__PURE__ */ (() => {
	Object.freeze(_DER._tlv);
	Object.freeze(_DER._int);
	return Object.freeze(_DER);
})();
//#endregion
//#region node_modules/.pnpm/@noble+curves@2.4.0/node_modules/@noble/curves/abstract/weierstrass.js
/**
* Short Weierstrass curve methods. The formula is: y² = x³ + ax + b.
*
* ### Design rationale for types
*
* * Interaction between classes from different curves should fail:
*   `k256.Point.BASE.add(p256.Point.BASE)`
* * For this purpose we want to use `instanceof` operator, which is fast and works during runtime
* * Different calls of `curve()` would return different classes -
*   `curve(params) !== curve(params)`: if somebody decided to monkey-patch their curve,
*   it won't affect others
*
* TypeScript can't infer types for classes created inside a function. Classes is one instance
* of nominative types in TypeScript and interfaces only check for shape, so it's hard to create
* unique type for every function call.
*
* We can use generic types via some param, like curve opts, but that would:
*     1. Enable interaction between `curve(params)` and `curve(params)` (curves of same params)
*     which is hard to debug.
*     2. Params can be generic and we can't enforce them to be constant value:
*     if somebody creates curve from non-constant params,
*     it would be allowed to interact with other curves with non-constant params
*
* @todo https://www.typescriptlang.org/docs/handbook/release-notes/typescript-2-7.html#unique-symbol
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var divNearest = (num, den) => (num + (num >= 0 ? den : -den) / _2n) / den;
/** Splits scalar for GLV endomorphism. */
function _splitEndoScalar(k, basis, n) {
	aInRange("scalar", k, _0n, n);
	const [[a1, b1], [a2, b2]] = basis;
	const c1 = divNearest(b2 * k, n);
	const c2 = divNearest(-b1 * k, n);
	let k1 = k - c1 * a1 - c2 * a2;
	let k2 = -c1 * b1 - c2 * b2;
	const k1neg = k1 < _0n;
	const k2neg = k2 < _0n;
	if (k1neg) k1 = -k1;
	if (k2neg) k2 = -k2;
	const MAX_NUM = bitMask(Math.ceil(bitLen(n) / 2)) + _1n;
	if (k1 < _0n || k1 >= MAX_NUM || k2 < _0n || k2 >= MAX_NUM) throw new Error("splitScalar (endomorphism): failed for k");
	return {
		k1neg,
		k1,
		k2neg,
		k2
	};
}
function validateSigFormat(format) {
	if (![
		"compact",
		"recovered",
		"der"
	].includes(format)) throw new Error("Signature format must be \"compact\", \"recovered\", or \"der\"");
	return format;
}
function validateSigOpts(opts, def) {
	validateObject(opts);
	const optsn = {};
	for (let optName of Object.keys(def)) optsn[optName] = opts[optName] === void 0 ? def[optName] : opts[optName];
	abool(optsn.lowS, "lowS");
	abool(optsn.prehash, "prehash");
	if (optsn.format !== void 0) validateSigFormat(optsn.format);
	return optsn;
}
var _0n = /* @__PURE__ */ BigInt(0);
var _1n = /* @__PURE__ */ BigInt(1);
var _2n = /* @__PURE__ */ BigInt(2);
var _3n = /* @__PURE__ */ BigInt(3);
var _4n = /* @__PURE__ */ BigInt(4);
/**
* Creates weierstrass Point constructor, based on specified curve options.
*
* See {@link WeierstrassOpts}.
* @param params - Curve parameters. See {@link WeierstrassOpts}.
* @param extraOpts - Optional helpers and overrides. See {@link WeierstrassExtraOpts}.
* @returns Weierstrass point constructor.
* @throws If the curve parameters, overrides, or point codecs are invalid. {@link Error}
*
* @example
* Construct a point type from explicit Weierstrass curve parameters.
*
* ```js
* const opts = {
*   p: 0xfffffffffffffffffffffffffffffffeffffac73n,
*   n: 0x100000000000000000001b8fa16dfab9aca16b6b3n,
*   h: 1n,
*   a: 0n,
*   b: 7n,
*   Gx: 0x3b4c382ce37aa192a4019e763036f4f5dd4d7ebbn,
*   Gy: 0x938cf935318fdced6bc28286531733c3f03c4feen,
* };
* const secp160k1_Point = weierstrass(opts);
* ```
*/
function weierstrass(params, extraOpts = {}) {
	const validated = createCurveFields("weierstrass", params, extraOpts);
	const Fp = validated.Fp;
	const Fn = validated.Fn;
	let CURVE = validated.CURVE;
	const { h: cofactor, n: CURVE_ORDER } = CURVE;
	validateObject(extraOpts, {}, {
		allowInfinityPoint: "boolean",
		clearCofactor: "function",
		isTorsionFree: "function",
		fromBytes: "function",
		toBytes: "function",
		endo: "object",
		randomBytes: "function"
	});
	const { endo: endoOpts, allowInfinityPoint, clearCofactor, isTorsionFree, fromBytes, toBytes } = extraOpts;
	const randomBytes$2 = extraOpts.randomBytes === void 0 ? randomBytes : extraOpts.randomBytes;
	if (endoOpts) {
		if (!Fp.is0(CURVE.a) || typeof endoOpts.beta !== "bigint" || !Array.isArray(endoOpts.basises)) throw new Error("invalid endo: expected \"beta\": bigint and \"basises\": array");
	}
	const endo = endoOpts ? {
		beta: endoOpts.beta,
		basises: endoOpts.basises.map((basis) => [...basis])
	} : void 0;
	const lengths = getWLengths(Fp, Fn);
	function assertCompressionIsSupported() {
		if (!Fp.isOdd) throw new Error("compression is not supported: Field does not have .isOdd()");
	}
	function pointToBytes(_c, point, isCompressed) {
		if (point.is0()) {
			if (!allowInfinityPoint) throw new Error("bad point: ZERO");
			return Uint8Array.of(0);
		}
		const { x, y } = point.toAffine();
		const bx = Fp.toBytes(x);
		abool(isCompressed, "isCompressed");
		if (isCompressed) {
			assertCompressionIsSupported();
			return concatBytes(pprefix(!Fp.isOdd(y)), bx);
		} else return concatBytes(Uint8Array.of(4), bx, Fp.toBytes(y));
	}
	function pointFromBytes(bytes) {
		abytes(bytes, void 0, "Point");
		const { publicKey: comp, publicKeyUncompressed: uncomp } = lengths;
		const length = bytes.length;
		const head = bytes[0];
		const tail = bytes.subarray(1);
		if (allowInfinityPoint && length === 1 && head === 0) return {
			x: Fp.ZERO,
			y: Fp.ZERO
		};
		if (length === comp && (head === 2 || head === 3)) {
			const x = Fp.fromBytes(tail);
			if (!Fp.isValid(x)) throw new Error("bad point: is not on curve, wrong x");
			const y2 = weierstrassEquation(x);
			let y;
			try {
				y = Fp.sqrt(y2);
			} catch (sqrtError) {
				const err = sqrtError instanceof Error ? ": " + sqrtError.message : "";
				throw new Error("bad point: is not on curve, sqrt error" + err);
			}
			assertCompressionIsSupported();
			const evenY = Fp.isOdd(y);
			if ((head & 1) === 1 !== evenY) y = Fp.neg(y);
			return {
				x,
				y
			};
		} else if (length === uncomp && head === 4) {
			const L = Fp.BYTES;
			const x = Fp.fromBytes(tail.subarray(0, L));
			const y = Fp.fromBytes(tail.subarray(L, L * 2));
			if (!isValidXY(x, y)) throw new Error("bad point: is not on curve");
			return {
				x,
				y
			};
		} else throw new Error(`bad point: got length ${length}, expected compressed=${comp} or uncompressed=${uncomp}`);
	}
	const encodePoint = toBytes === void 0 ? pointToBytes : toBytes;
	const decodePoint = fromBytes === void 0 ? pointFromBytes : fromBytes;
	const b3 = Fp.mul(CURVE.b, _3n);
	const mulA = Fp.is0(CURVE.a) ? (_) => Fp.ZERO : (x) => Fp.mul(CURVE.a, x);
	function weierstrassEquation(x) {
		const x2 = Fp.sqr(x);
		const x3 = Fp.mul(x2, x);
		return Fp.add(Fp.add(x3, Fp.mul(x, CURVE.a)), CURVE.b);
	}
	/** Checks whether equation holds for given x, y: y² == x³ + ax + b */
	function isValidXY(x, y) {
		const left = Fp.sqr(y);
		const right = weierstrassEquation(x);
		return Fp.eql(left, right);
	}
	if (!isValidXY(CURVE.Gx, CURVE.Gy)) throw new Error("bad curve params: generator point");
	const _4a3 = Fp.mul(Fp.pow(CURVE.a, _3n), _4n);
	const _27b2 = Fp.mul(Fp.sqr(CURVE.b), BigInt(27));
	if (Fp.is0(Fp.add(_4a3, _27b2))) throw new Error("bad curve params: a or b");
	/** Asserts coordinate is valid: 0 <= n < Fp.ORDER. */
	function acoord(title, n, banZero = false) {
		if (!Fp.isValid(n) || banZero && Fp.is0(n)) throw new Error(`bad point coordinate ${title}`);
		return typeof n === "object" && n !== null ? Fp.create(n) : n;
	}
	function aprjpoint(other) {
		if (!(other instanceof Point)) throw new Error("Weierstrass Point expected");
	}
	function splitEndoScalarN(k) {
		if (!endo || !endo.basises) throw new Error("no endo");
		return _splitEndoScalar(k, endo.basises, Fn.ORDER);
	}
	/**
	* Appends a (point, scalar) pair to the inputs of a vartime wNAF walk
	* ({@link mulAddUnsafe}). With GLV endomorphism the scalar is split into two half-width
	* pairs against P and ψ(P) = (β⋅x, y), halving the walk's shared doubling chain;
	* split signs fold into the points.
	*/
	function pushWnafPair(points, scalars, p, k) {
		if (!Fn.isValid(k)) throw new RangeError("invalid scalar: out of range");
		if (endo) {
			const { k1neg, k1, k2neg, k2 } = splitEndoScalarN(k);
			const psi = new Point(Fp.mul(p.X, endo.beta), p.Y, p.Z);
			points.push(k1neg ? p.negate() : p, k2neg ? psi.negate() : psi);
			scalars.push(k1, k2);
		} else {
			points.push(p);
			scalars.push(k);
		}
	}
	const validityCache = /* @__PURE__ */ new WeakSet();
	/**
	* Projective Point works in 3d / projective (homogeneous) coordinates:(X, Y, Z) ∋ (x=X/Z, y=Y/Z).
	* Default Point works in 2d / affine coordinates: (x, y).
	* We're doing calculations in projective, because its operations don't require costly inversion.
	*/
	class Point {
		static BASE = new Point(CURVE.Gx, CURVE.Gy, Fp.ONE);
		static ZERO = new Point(Fp.ZERO, Fp.ONE, Fp.ZERO);
		static Fp = Fp;
		static Fn = Fn;
		X;
		Y;
		Z;
		/** Does NOT validate if the point is valid. Use `.assertValidity()`. */
		constructor(X, Y, Z) {
			this.X = acoord("x", X);
			this.Y = acoord("y", Y, true);
			this.Z = acoord("z", Z);
			Object.freeze(this);
		}
		static CURVE() {
			return CURVE;
		}
		/** Does NOT validate if the point is valid. Use `.assertValidity()`. */
		static fromAffine(p) {
			const { x, y } = p || {};
			if (!p || !Fp.isValid(x) || !Fp.isValid(y)) throw new Error("invalid affine point");
			if (p instanceof Point) throw new Error("projective point not allowed");
			if (Fp.is0(x) && Fp.is0(y)) return Point.ZERO;
			return new Point(x, y, Fp.ONE);
		}
		static fromBytes(bytes) {
			const P = Point.fromAffine(decodePoint(abytes(bytes, void 0, "point")));
			P.assertValidity();
			return P;
		}
		static fromHex(hex) {
			return Point.fromBytes(hexToBytes(hex));
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		/**
		* @param isLazy - true will defer table computation until the first multiplication
		*/
		precompute(windowSize = 6, isLazy = true) {
			wnaf.setWindowSize(this, windowSize);
			if (!isLazy) this.multiply(_3n);
			return this;
		}
		/** A point on curve is valid if it conforms to equation. */
		assertValidity() {
			const p = this;
			if (p.is0()) {
				if (allowInfinityPoint && Fp.is0(p.X) && Fp.eql(p.Y, Fp.ONE) && Fp.is0(p.Z)) return;
				throw new Error("bad point: ZERO");
			}
			if (validityCache.has(p)) return;
			const { x, y } = p.toAffine();
			if (!Fp.isValid(x) || !Fp.isValid(y)) throw new Error("bad point: x or y not field elements");
			if (!isValidXY(x, y)) throw new Error("bad point: equation left != right");
			if (!p.isTorsionFree()) throw new Error("bad point: not in prime-order subgroup");
			validityCache.add(p);
		}
		hasEvenY() {
			const { y } = this.toAffine();
			if (!Fp.isOdd) throw new Error("Field doesn't support isOdd");
			return !Fp.isOdd(y);
		}
		/** Compare one point to another. */
		equals(other) {
			aprjpoint(other);
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const { X: X2, Y: Y2, Z: Z2 } = other;
			const U1 = Fp.eql(Fp.mul(X1, Z2), Fp.mul(X2, Z1));
			const U2 = Fp.eql(Fp.mul(Y1, Z2), Fp.mul(Y2, Z1));
			return U1 && U2;
		}
		/** Flips point to one corresponding to (x, -y) in Affine coordinates. */
		negate() {
			return new Point(this.X, Fp.neg(this.Y), this.Z);
		}
		double() {
			const { X: X1, Y: Y1, Z: Z1 } = this;
			let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO;
			let t0 = Fp.mul(X1, X1);
			let t1 = Fp.mul(Y1, Y1);
			let t2 = Fp.mul(Z1, Z1);
			let t3 = Fp.mul(X1, Y1);
			t3 = Fp.add(t3, t3);
			Z3 = Fp.mul(X1, Z1);
			Z3 = Fp.add(Z3, Z3);
			X3 = mulA(Z3);
			Y3 = Fp.mul(b3, t2);
			Y3 = Fp.add(X3, Y3);
			X3 = Fp.sub(t1, Y3);
			Y3 = Fp.add(t1, Y3);
			Y3 = Fp.mul(X3, Y3);
			X3 = Fp.mul(t3, X3);
			Z3 = Fp.mul(b3, Z3);
			t2 = mulA(t2);
			t3 = Fp.sub(t0, t2);
			t3 = mulA(t3);
			t3 = Fp.add(t3, Z3);
			Z3 = Fp.add(t0, t0);
			t0 = Fp.add(Z3, t0);
			t0 = Fp.add(t0, t2);
			t0 = Fp.mul(t0, t3);
			Y3 = Fp.add(Y3, t0);
			t2 = Fp.mul(Y1, Z1);
			t2 = Fp.add(t2, t2);
			t0 = Fp.mul(t2, t3);
			X3 = Fp.sub(X3, t0);
			Z3 = Fp.mul(t2, t1);
			Z3 = Fp.add(Z3, Z3);
			Z3 = Fp.add(Z3, Z3);
			return new Point(X3, Y3, Z3);
		}
		add(other) {
			aprjpoint(other);
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const { X: X2, Y: Y2, Z: Z2 } = other;
			let X3 = Fp.ZERO, Y3 = Fp.ZERO, Z3 = Fp.ZERO;
			let t0 = Fp.mul(X1, X2);
			let t1 = Fp.mul(Y1, Y2);
			let t2 = Fp.mul(Z1, Z2);
			let t3 = Fp.add(X1, Y1);
			let t4 = Fp.add(X2, Y2);
			t3 = Fp.mul(t3, t4);
			t4 = Fp.add(t0, t1);
			t3 = Fp.sub(t3, t4);
			t4 = Fp.add(X1, Z1);
			let t5 = Fp.add(X2, Z2);
			t4 = Fp.mul(t4, t5);
			t5 = Fp.add(t0, t2);
			t4 = Fp.sub(t4, t5);
			t5 = Fp.add(Y1, Z1);
			X3 = Fp.add(Y2, Z2);
			t5 = Fp.mul(t5, X3);
			X3 = Fp.add(t1, t2);
			t5 = Fp.sub(t5, X3);
			Z3 = mulA(t4);
			X3 = Fp.mul(b3, t2);
			Z3 = Fp.add(X3, Z3);
			X3 = Fp.sub(t1, Z3);
			Z3 = Fp.add(t1, Z3);
			Y3 = Fp.mul(X3, Z3);
			t1 = Fp.add(t0, t0);
			t1 = Fp.add(t1, t0);
			t2 = mulA(t2);
			t4 = Fp.mul(b3, t4);
			t1 = Fp.add(t1, t2);
			t2 = Fp.sub(t0, t2);
			t2 = mulA(t2);
			t4 = Fp.add(t4, t2);
			t0 = Fp.mul(t1, t4);
			Y3 = Fp.add(Y3, t0);
			t0 = Fp.mul(t5, t4);
			X3 = Fp.mul(t3, X3);
			X3 = Fp.sub(X3, t0);
			t0 = Fp.mul(t3, t1);
			Z3 = Fp.mul(t5, Z3);
			Z3 = Fp.add(Z3, t0);
			return new Point(X3, Y3, Z3);
		}
		subtract(other) {
			aprjpoint(other);
			return this.add(other.negate());
		}
		is0() {
			return this.equals(Point.ZERO);
		}
		/**
		* Constant time multiplication.
		* Uses precomputed tables (signed fixed-window wNAF) when available.
		* Uses scalar blinding and avoids endomorphism splitting in the secret-scalar path.
		* @param scalar - by which the point would be multiplied
		* @returns New point
		*/
		multiply(scalar) {
			if (!Fn.isValidNot0(scalar)) throw new RangeError("invalid scalar: out of range");
			const { p, f } = wnaf.mulSecret(this, scalar, cofactor, normalize);
			return normalize([p, f])[0];
		}
		/**
		* Non-constant-time multiplication. Uses width-4 wNAF with GLV endomorphism splitting
		* when available (two half-width scalars sharing one halved doubling chain).
		* It's faster, but should only be used when you don't care about
		* an exposed secret key e.g. sig verification, which works over *public* keys.
		*/
		multiplyUnsafe(scalar) {
			const p = this;
			const sc = scalar;
			if (!Fn.isValid(sc)) throw new RangeError("invalid scalar: out of range");
			if (sc === _0n || p.is0()) return Point.ZERO;
			if (sc === _1n) return p;
			if (wnaf.hasWindowSize(this)) return wnaf.mulUnsafe(p, sc, normalize);
			const points = [];
			const scalars = [];
			pushWnafPair(points, scalars, p, sc);
			return mulAddUnsafe(Point, points, scalars);
		}
		/**
		* Non-constant-time double-scalar multiplication `a⋅this + b⋅other` (Strauss–Shamir).
		* Both walks share one doubling chain via {@link mulAddUnsafe}, and GLV endomorphism
		* (when available) halves the chain again by splitting each scalar into two half-width
		* parts. Used by ECDSA verification and public-key recovery for `R = u1⋅G + u2⋅P`.
		* Only for public scalars.
		*/
		mulAddUnsafe(a, other, b) {
			aprjpoint(other);
			const points = [];
			const scalars = [];
			pushWnafPair(points, scalars, this, a);
			pushWnafPair(points, scalars, other, b);
			return mulAddUnsafe(Point, points, scalars);
		}
		/**
		* Converts Projective point to affine (x, y) coordinates.
		* (X, Y, Z) ∋ (x=X/Z, y=Y/Z).
		* @param invertedZ - Z^-1 (inverted zero) - optional, precomputation is useful for invertBatch
		*/
		toAffine(invertedZ) {
			const p = this;
			let iz = invertedZ;
			if (iz != null && !Fp.isValid(iz)) throw new RangeError("\"invertedZ\" expected valid field element");
			const { X, Y, Z } = p;
			if (Fp.eql(Z, Fp.ONE)) return {
				x: X,
				y: Y
			};
			const is0 = p.is0();
			if (iz == null) iz = is0 ? Fp.ONE : Fp.inv(Z);
			const x = Fp.mul(X, iz);
			const y = Fp.mul(Y, iz);
			const zz = Fp.mul(Z, iz);
			if (is0) return {
				x: Fp.ZERO,
				y: Fp.ZERO
			};
			if (!Fp.eql(zz, Fp.ONE)) throw new Error("invZ was invalid");
			return {
				x,
				y
			};
		}
		/**
		* Checks whether Point is free of torsion elements (is in prime subgroup).
		* Always torsion-free for cofactor=1 curves.
		*/
		isTorsionFree() {
			if (cofactor === _1n) return true;
			if (isTorsionFree) return isTorsionFree(Point, this);
			return wnaf.mulUnsafe(this, CURVE_ORDER).is0();
		}
		clearCofactor() {
			if (cofactor === _1n) return this;
			if (clearCofactor) return clearCofactor(Point, this);
			return this.multiplyUnsafe(cofactor);
		}
		isSmallOrder() {
			if (cofactor === _1n) return this.is0();
			return this.clearCofactor().is0();
		}
		toBytes(isCompressed = true) {
			abool(isCompressed, "isCompressed");
			this.assertValidity();
			return encodePoint(Point, this, isCompressed);
		}
		toHex(isCompressed = true) {
			return bytesToHex(this.toBytes(isCompressed));
		}
		toString() {
			return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
		}
	}
	const normalize = (points) => normalizeZ(Point, points);
	const wnaf = new ScalarMultiplier(Point, randomBytes$2);
	if (wnaf.bits >= 6) Point.BASE.precompute(6);
	Object.freeze(Point.prototype);
	Object.freeze(Point);
	return Point;
}
function pprefix(hasEvenY) {
	return Uint8Array.of(hasEvenY ? 2 : 3);
}
function getWLengths(Fp, Fn) {
	return {
		secretKey: Fn.BYTES,
		publicKey: 1 + Fp.BYTES,
		publicKeyUncompressed: 1 + 2 * Fp.BYTES,
		publicKeyHasPrefix: true,
		signature: 2 * Fn.BYTES
	};
}
/**
* Sometimes users only need getPublicKey, getSharedSecret, and secret key handling.
* This helper ensures no signature functionality is present. Less code, smaller bundle size.
* @param Point - Weierstrass point constructor.
* @param ecdhOpts - Optional randomness helpers:
*   - `randomBytes` (optional): Optional RNG override.
* @returns ECDH helper namespace.
* @example
* Sometimes users only need getPublicKey, getSharedSecret, and secret key handling.
*
* ```ts
* import { ecdh } from '@noble/curves/abstract/weierstrass.js';
* import { p256 } from '@noble/curves/nist.js';
* const dh = ecdh(p256.Point);
* const alice = dh.keygen();
* const shared = dh.getSharedSecret(alice.secretKey, alice.publicKey);
* ```
*/
function ecdh(Point, ecdhOpts = {}) {
	validatePointCons(Point);
	const { Fn } = Point;
	const randomBytes_ = ecdhOpts.randomBytes === void 0 ? randomBytes : ecdhOpts.randomBytes;
	const lengths = Object.assign(getWLengths(Point.Fp, Fn), { seed: Math.max(getMinHashLength(Fn.ORDER), 16) });
	function isValidSecretKey(secretKey) {
		try {
			const num = Fn.fromBytes(secretKey);
			return Fn.isValidNot0(num);
		} catch (error) {
			return false;
		}
	}
	function isValidPublicKey(publicKey, isCompressed) {
		const { publicKey: comp, publicKeyUncompressed } = lengths;
		try {
			const l = publicKey.length;
			if (isCompressed === true && l !== comp) return false;
			if (isCompressed === false && l !== publicKeyUncompressed) return false;
			return !Point.fromBytes(publicKey).is0();
		} catch (error) {
			return false;
		}
	}
	/**
	* Produces cryptographically secure secret key from random of size
	* (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
	*/
	function randomSecretKey(seed) {
		seed = seed === void 0 ? randomBytes_(lengths.seed) : seed;
		return mapHashToField(abytes(seed, lengths.seed, "seed"), Fn.ORDER);
	}
	/**
	* Computes public key for a secret key. Checks for validity of the secret key.
	* @param isCompressed - whether to return compact (default), or full key
	* @returns Public key, full when isCompressed=false; short when isCompressed=true
	*/
	function getPublicKey(secretKey, isCompressed = true) {
		return Point.BASE.multiply(Fn.fromBytes(secretKey)).toBytes(isCompressed);
	}
	/**
	* Quick and dirty check for item being public key. Does not validate hex, or being on-curve.
	*/
	function isProbPub(item) {
		const { secretKey, publicKey, publicKeyUncompressed } = lengths;
		const allowedLengths = Fn._lengths;
		if (!isBytes(item)) return void 0;
		const l = abytes(item, void 0, "key").length;
		const isPub = l === publicKey || l === publicKeyUncompressed;
		const isSec = l === secretKey || !!allowedLengths?.includes(l);
		if (isPub && isSec) return void 0;
		return isPub;
	}
	/**
	* ECDH (Elliptic Curve Diffie Hellman).
	* Computes encoded shared point from secret key A and public key B.
	* Checks: 1) secret key validity 2) shared key is on-curve.
	* Does NOT hash the result or expose the SEC 1 x-coordinate-only `z`.
	* Returns the encoded shared point on purpose: callers that need `x_P`
	* can derive it from the encoded point, but `x_P` alone cannot recover the
	* point/parity back.
	* This helper only exposes the fully validated public-key path, not cofactor DH.
	* @param isCompressed - whether to return compact (default), or full key
	* @returns shared point encoding
	*/
	function getSharedSecret(secretKeyA, publicKeyB, isCompressed = true) {
		if (isProbPub(secretKeyA) === true) throw new Error("first arg must be private key");
		if (isProbPub(publicKeyB) === false) throw new Error("second arg must be public key");
		const s = Fn.fromBytes(secretKeyA);
		const b = Point.fromBytes(publicKeyB);
		if (b.is0()) throw new Error("invalid public key: point at infinity");
		return b.multiply(s).toBytes(isCompressed);
	}
	const utils = {
		isValidSecretKey,
		isValidPublicKey,
		randomSecretKey
	};
	const keygen = createKeygen(randomSecretKey, getPublicKey);
	Object.freeze(utils);
	Object.freeze(lengths);
	return Object.freeze({
		getPublicKey,
		getSharedSecret,
		keygen,
		Point,
		utils,
		lengths
	});
}
/**
* Creates ECDSA signing interface for given elliptic curve `Point` and `hash` function.
*
* @param Point - created using {@link weierstrass} function
* @param hash - used for 1) message prehash-ing 2) k generation in `sign`, using hmac_drbg(hash)
* @param ecdsaOpts - rarely needed, see {@link ECDSAOpts}:
*   - `lowS`: Default low-S policy.
*   - `hmac`: HMAC implementation used by RFC6979 DRBG.
*   - `randomBytes`: Optional RNG override.
*   - `bits2int`: Optional hash-to-int conversion override.
*   - `bits2int_modN`: Optional hash-to-int-mod-n conversion override.
*
* @returns ECDSA helper namespace.
* @example
* Create an ECDSA signer/verifier bundle for one curve implementation.
*
* ```ts
* import { ecdsa } from '@noble/curves/abstract/weierstrass.js';
* import { p256 } from '@noble/curves/nist.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const p256ecdsa = ecdsa(p256.Point, sha256);
* const { secretKey, publicKey } = p256ecdsa.keygen();
* const msg = new TextEncoder().encode('hello noble');
* const sig = p256ecdsa.sign(msg, secretKey);
* const isValid = p256ecdsa.verify(sig, msg, publicKey);
* ```
*/
function ecdsa(Point, hash, ecdsaOpts = {}) {
	validatePointCons(Point);
	const hash_ = hash;
	ahash(hash_);
	validateObject(ecdsaOpts, {}, {
		hmac: "function",
		lowS: "boolean",
		randomBytes: "function",
		bits2int: "function",
		bits2int_modN: "function"
	});
	const opts = Object.assign({}, ecdsaOpts);
	const randomBytes$3 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
	const hmac$1 = opts.hmac === void 0 ? (key, msg) => hmac(hash_, key, msg) : opts.hmac;
	const { Fp, Fn } = Point;
	const { ORDER: CURVE_ORDER, BITS: fnBits } = Fn;
	const blindLength = getMinHashLength(CURVE_ORDER);
	const csprng = probeRandomBytes(randomBytes$3, blindLength);
	const { keygen, getPublicKey, getSharedSecret, utils, lengths } = ecdh(Point, opts);
	const defaultSigOpts = {
		prehash: true,
		lowS: typeof opts.lowS === "boolean" ? opts.lowS : true,
		format: "compact",
		extraEntropy: false
	};
	const hasLargeRecoveryLifts = CURVE_ORDER * _2n + _1n < Fp.ORDER;
	function isBiggerThanHalfOrder(number) {
		return number > CURVE_ORDER >> _1n;
	}
	function validateRS(title, num) {
		if (!Fn.isValidNot0(num)) throw new Error(`invalid signature ${title}: out of range 1..Point.Fn.ORDER`);
		return num;
	}
	function assertFieldSignIsSupported() {
		if (!Fp.isOdd) throw new Error("Field doesn't support isOdd");
	}
	function getRecoveryBit(x, y, r) {
		assertFieldSignIsSupported();
		return (x === r ? 0 : 2) | Number(Fp.isOdd(y));
	}
	function assertRecoverableCurve() {
		if (hasLargeRecoveryLifts) throw new Error("\"recovered\" sig type is not supported for cofactor >2 curves");
	}
	function validateSigLength(bytes, format) {
		validateSigFormat(format);
		const size = lengths.signature;
		return abytes(bytes, format === "compact" ? size : format === "recovered" ? size + 1 : void 0);
	}
	/**
	* ECDSA signature with its (r, s) properties. Supports compact, recovered & DER representations.
	*/
	class Signature {
		r;
		s;
		recovery;
		constructor(r, s, recovery) {
			this.r = validateRS("r", r);
			this.s = validateRS("s", s);
			if (recovery != null) {
				assertRecoverableCurve();
				if (![
					0,
					1,
					2,
					3
				].includes(recovery)) throw new Error("invalid recovery id");
				this.recovery = recovery;
			}
			Object.freeze(this);
		}
		static fromBytes(bytes, format = defaultSigOpts.format) {
			validateSigLength(bytes, format);
			let recid;
			if (format === "der") {
				if (bytes.length > 2 * Fn.BYTES + 16) throw new DER.Err("invalid signature: DER signature too long");
				const { r, s } = DER.toSig(abytes(bytes), Fn.BYTES + 1);
				return new Signature(r, s);
			}
			if (format === "recovered") {
				recid = bytes[0];
				format = "compact";
				bytes = bytes.subarray(1);
			}
			const L = lengths.signature / 2;
			const r = bytes.subarray(0, L);
			const s = bytes.subarray(L, L * 2);
			return new Signature(Fn.fromBytes(r), Fn.fromBytes(s), recid);
		}
		static fromHex(hex, format) {
			return this.fromBytes(hexToBytes(hex), format);
		}
		assertRecovery() {
			const { recovery } = this;
			if (recovery == null) throw new Error("invalid recovery id: must be present");
			return recovery;
		}
		addRecoveryBit(recovery) {
			return new Signature(this.r, this.s, recovery);
		}
		recoverPublicKey(messageHash) {
			const { r, s } = this;
			const recovery = this.assertRecovery();
			const radj = recovery === 2 || recovery === 3 ? r + CURVE_ORDER : r;
			if (!Fp.isValid(radj)) throw new Error("invalid recovery id: sig.r+curve.n != R.x");
			const x = Fp.toBytes(radj);
			const R = Point.fromBytes(concatBytes(pprefix((recovery & 1) === 0), x));
			const ir = Fn.inv(radj);
			const h = bits2int_modN(abytes(messageHash, void 0, "msgHash"));
			const u1 = Fn.create(-h * ir);
			const u2 = Fn.create(s * ir);
			const Q = Point.BASE.mulAddUnsafe(u1, R, u2);
			if (Q.is0()) throw new Error("invalid recovery: point at infinify");
			Q.assertValidity();
			return Q;
		}
		hasHighS() {
			return isBiggerThanHalfOrder(this.s);
		}
		toBytes(format = defaultSigOpts.format) {
			validateSigFormat(format);
			if (format === "der") return hexToBytes(DER.hexFromSig(this));
			const { r, s } = this;
			const rb = Fn.toBytes(r);
			const sb = Fn.toBytes(s);
			if (format === "recovered") {
				assertRecoverableCurve();
				return concatBytes(Uint8Array.of(this.assertRecovery()), rb, sb);
			}
			return concatBytes(rb, sb);
		}
		toHex(format) {
			return bytesToHex(this.toBytes(format));
		}
	}
	Object.freeze(Signature.prototype);
	Object.freeze(Signature);
	const bits2int = opts.bits2int === void 0 ? function bits2int_def(bytes) {
		if (bytes.length > 8192) throw new Error("input is too large");
		const num = bytesToNumberBE(bytes);
		const delta = bytes.length * 8 - fnBits;
		return delta > 0 ? num >> BigInt(delta) : num;
	} : opts.bits2int;
	const bits2int_modN = opts.bits2int_modN === void 0 ? function bits2int_modN_def(bytes) {
		return Fn.create(bits2int(bytes));
	} : opts.bits2int_modN;
	const ORDER_MASK = bitMask(fnBits);
	/** Converts to bytes. Checks if num in `[0..ORDER_MASK-1]` e.g.: `[0..2^256-1]`. */
	function int2octets(num) {
		aInRange("num < 2^" + fnBits, num, _0n, ORDER_MASK);
		return Fn.toBytes(num);
	}
	function validateMsgAndHash(message, prehash) {
		abytes(message, void 0, "message");
		return prehash ? abytes(hash_(message), void 0, "prehashed message") : message;
	}
	/**
	* Steps A, D of RFC6979 3.2.
	* Creates RFC6979 seed; converts msg/privKey to numbers.
	* Used only in sign, not in verify.
	*
	* Warning: we cannot assume here that message has same amount of bytes as curve order,
	* this will be invalid at least for P521. Also it can be bigger for P224 + SHA256.
	*/
	function prepSig(message, secretKey, opts) {
		const { lowS, prehash, extraEntropy } = validateSigOpts(opts, defaultSigOpts);
		message = validateMsgAndHash(message, prehash);
		const h1int = bits2int_modN(message);
		const d = Fn.fromBytes(secretKey);
		if (!Fn.isValidNot0(d)) throw new Error("invalid private key");
		const seedArgs = [int2octets(d), int2octets(h1int)];
		if (extraEntropy != null && extraEntropy !== false) {
			const e = extraEntropy === true ? randomBytes$3(lengths.secretKey) : extraEntropy;
			seedArgs.push(abytes(e, void 0, "extraEntropy"));
		}
		const seed = concatBytes(...seedArgs);
		const m = h1int;
		function k2sig(kBytes) {
			const k = bits2int(kBytes);
			if (!Fn.isValidNot0(k)) return;
			const q = Point.BASE.multiply(k).toAffine();
			const r = Fn.create(q.x);
			if (r === _0n) return;
			let s;
			if (csprng !== void 0) {
				const b = bytesToNumberBE(mapHashToField(csprng(blindLength), CURVE_ORDER));
				const ibk = Fn.inv(Fn.mul(b, k));
				const bm = Fn.mul(b, m);
				const bd = Fn.mul(b, d);
				s = Fn.create(ibk * Fn.create(bm + bd * r));
			} else {
				const ik = invertCt(k, CURVE_ORDER);
				s = Fn.create(ik * Fn.create(m + r * d));
			}
			if (s === _0n) return;
			let recovery = getRecoveryBit(q.x, q.y, r);
			let normS = s;
			if (lowS && isBiggerThanHalfOrder(s)) {
				normS = Fn.neg(s);
				recovery ^= 1;
			}
			return new Signature(r, normS, hasLargeRecoveryLifts ? void 0 : recovery);
		}
		return {
			seed,
			k2sig
		};
	}
	/**
	* Signs a message or message hash with a secret key.
	* With the default `prehash: true`, raw message bytes are hashed internally;
	* only `{ prehash: false }` expects a caller-supplied digest.
	*
	* ```
	* sign(m, d) where
	*   k = rfc6979_hmac_drbg(m, d)
	*   (x, y) = G × k
	*   r = x mod n
	*   s = (m + dr) / k mod n
	* ```
	*/
	function sign(message, secretKey, opts = {}) {
		const { seed, k2sig } = prepSig(message, secretKey, opts);
		return createHmacDrbg(hash_.outputLen, Fn.BYTES, hmac$1)(seed, k2sig).toBytes(opts.format);
	}
	/**
	* Verifies a signature against message and public key.
	* Rejects lowS signatures by default: see {@link ECDSAVerifyOpts}.
	* Implements section 4.1.4 from https://www.secg.org/sec1-v2.pdf:
	*
	* ```
	* verify(r, s, h, P) where
	*   u1 = hs^-1 mod n
	*   u2 = rs^-1 mod n
	*   R = u1⋅G + u2⋅P
	*   mod(R.x, n) == r
	* ```
	*/
	function verify(signature, message, publicKey, opts = {}) {
		const { lowS, prehash, format } = validateSigOpts(opts, defaultSigOpts);
		publicKey = abytes(publicKey, void 0, "publicKey");
		message = validateMsgAndHash(message, prehash);
		if (!isBytes(signature)) {
			const end = signature instanceof Signature ? ", use sig.toBytes()" : "";
			throw new Error("verify expects Uint8Array signature" + end);
		}
		validateSigLength(signature, format);
		try {
			const sig = Signature.fromBytes(signature, format);
			const P = Point.fromBytes(publicKey);
			if (P.is0()) return false;
			if (lowS && sig.hasHighS()) return false;
			const { r, s } = sig;
			const h = bits2int_modN(message);
			const is = Fn.inv(s);
			const u1 = Fn.create(h * is);
			const u2 = Fn.create(r * is);
			const R = Point.BASE.mulAddUnsafe(u1, P, u2);
			if (R.is0()) return false;
			const q = R.toAffine();
			if (Fn.create(q.x) !== r) return false;
			if (format === "recovered" && sig.recovery !== getRecoveryBit(q.x, q.y, r)) return false;
			return true;
		} catch (e) {
			return false;
		}
	}
	function recoverPublicKey(signature, message, opts = {}) {
		const { prehash } = validateSigOpts(opts, defaultSigOpts);
		message = validateMsgAndHash(message, prehash);
		return Signature.fromBytes(signature, "recovered").recoverPublicKey(message).toBytes();
	}
	return Object.freeze({
		keygen,
		getPublicKey,
		getSharedSecret,
		utils,
		lengths,
		Point,
		sign,
		verify,
		recoverPublicKey,
		Signature,
		hash: hash_
	});
}
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
/**
* NIST P256 (aka secp256r1, prime256v1) curve, ECDSA and ECDH methods.
* Hashes inputs with sha256 by default.
*
* @example
* Generate one P-256 keypair, sign a message, and verify it.
*
* ```js
* import { p256 } from '@noble/curves/nist.js';
* const { secretKey, publicKey } = p256.keygen();
* const recovered = p256.getPublicKey(secretKey);
* const peer = p256.keygen();
* const shared = p256.getSharedSecret(secretKey, peer.publicKey);
* const msg = new TextEncoder().encode('hello noble');
* const sig = p256.sign(msg, secretKey, { lowS: true, prehash: true });
* const isValid = p256.verify(sig, msg, publicKey);
* // const sigKeccak = p256.sign(keccak256(msg), secretKey, { prehash: false });
* ```
*/
var p256 = /* @__PURE__ */ ecdsa(/* @__PURE__ */ weierstrass(/* @__PURE__ */ (() => ({
	p: BigInt("0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff"),
	n: BigInt("0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551"),
	h: BigInt(1),
	a: BigInt("0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc"),
	b: BigInt("0x5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b"),
	Gx: BigInt("0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296"),
	Gy: BigInt("0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5")
}))()), sha256);
//#endregion
//#region node_modules/.pnpm/@noble+hashes@2.4.0/node_modules/@noble/hashes/hkdf.js
/**
* HKDF (RFC 5869): extract + expand in one step.
* See {@link https://soatok.blog/2021/11/17/understanding-hkdf/}.
* @module
*/
var HKDF_COUNTER = /* @__PURE__ */ Uint8Array.of(0);
var EMPTY_BUFFER = /* @__PURE__ */ Uint8Array.of();
/**
* HKDF-expand from the spec. The most important part. `HKDF-Expand(PRK, info, L) -> OKM`
* @param hash - hash function that would be used (e.g. sha256)
* @param prk - a pseudorandom key of at least HashLen octets
*   (usually, the output from the extract step)
* @param info - optional context and application specific information (can be a zero-length string)
* @param length - length of output keying material in bytes.
*   RFC 5869 §2.3 allows `0..255*HashLen`, so `0` returns an empty OKM.
* @param _recycled - Internal destroyed extract hashes owned by the combined `hkdf()` call.
* @returns Output keying material with the requested length.
* @throws If the requested output length exceeds the HKDF limit
*   for the selected hash. {@link Error}
* @example
* Run the HKDF expand step.
* ```ts
* import { expand } from '@noble/hashes/hkdf.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* expand(sha256, new Uint8Array(32), new Uint8Array([1, 2, 3]), 16);
* ```
*/
function expand(hash, prk, info, length = 32, _recycled) {
	ahash(hash);
	anumber$1(length, "length");
	abytes$1(prk, void 0, "prk");
	const olen = hash.outputLen;
	if (prk.length < olen) throw new Error("\"prk\" must be at least HashLen octets");
	if (length > 255 * olen) throw new Error("Length must be <= 255*HashLen");
	const blocks = Math.ceil(length / olen);
	if (info === void 0) info = EMPTY_BUFFER;
	else abytes$1(info, void 0, "info");
	if (!blocks) {
		if (_recycled) clean(prk);
		return /* @__PURE__ */ new Uint8Array();
	}
	const okm = _recycled && blocks === 1 ? prk : new Uint8Array(blocks * olen);
	const { iHash, oHash } = hmac.create(hash, prk);
	const T = _recycled ? prk : new Uint8Array(olen);
	const worker = blocks > 1 ? _recycled?.iHash || hash.create() : void 0;
	for (let counter = 0; counter < blocks - 1; counter++) {
		HKDF_COUNTER[0] = counter + 1;
		const iWork = iHash._cloneInto(worker);
		if (counter) iWork.update(T);
		iWork.update(info).update(HKDF_COUNTER).digestInto(T);
		oHash._cloneInto(worker).update(T).digestInto(T);
		okm.set(T, olen * counter);
	}
	HKDF_COUNTER[0] = blocks;
	if (blocks > 1) iHash.update(T);
	iHash.update(info).update(HKDF_COUNTER).digestInto(T);
	oHash.update(T).digestInto(T);
	okm.set(T, olen * (blocks - 1));
	iHash.destroy();
	oHash.destroy();
	worker?.destroy();
	if (T !== okm) clean(T);
	clean(HKDF_COUNTER);
	if (length === okm.length) return okm;
	const res = okm.slice(0, length);
	clean(okm);
	return res;
}
/**
* HKDF (RFC 5869): derive keys from an initial input.
* Combines hkdf_extract + hkdf_expand in one step
* @param hash - hash function that would be used (e.g. sha256)
* @param ikm - input keying material, the initial key
* @param salt - optional salt value (a non-secret random value)
* @param info - optional context and application specific information bytes
* @param length - length of output keying material in bytes.
*   RFC 5869 §2.3 allows `0..255*HashLen`, so `0` returns an empty OKM.
* @returns Output keying material derived from the input key.
* @throws If the requested output length exceeds the HKDF limit
*   for the selected hash. {@link Error}
* @example
* HKDF (RFC 5869): derive keys from an initial input.
* ```ts
* import { hkdf } from '@noble/hashes/hkdf.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* import { randomBytes, utf8ToBytes } from '@noble/hashes/utils.js';
* const inputKey = randomBytes(32);
* const salt = randomBytes(32);
* const info = utf8ToBytes('application-key');
* const okm = hkdf(sha256, inputKey, salt, info, 32);
* ```
*/
var hkdf = (hash, ikm, salt, info, length) => {
	ahash(hash);
	if (salt === void 0) salt = new Uint8Array(hash.outputLen);
	const HMAC = hmac.create(hash, salt).update(ikm);
	return expand(hash, HMAC.digest(), info, length, HMAC);
};
//#endregion
//#region src/background/mbp1/spake2-core.ts
/**
* MBP1 group-generic SPAKE2 core (bridge-pairing-protocol.md §3, §6.3-§6.6).
*
* The group is injected rather than hard-coded so the exact composition here
* — public share derivation, cofactor-cleared shared secret, transcript
* layout, key schedule, confirmation MACs — can be proven against the RFC
* 9382 Appendix B P-256 vectors *before* the edwards25519 instantiation MBP1
* actually uses is trusted (§13). Passing only self-generated MBP1 vectors
* would prove nothing about the composition itself: a wrong-but-self-
* consistent implementation reproduces its own vectors happily.
*
* `Spake2Group` operates entirely on wire-format byte encodings — every
* point argument and return value is a `Uint8Array`, never a curve
* library's own point type. This keeps the boundary narrow enough that the
* underlying curve arithmetic can never leak into the transcript / key
* schedule logic below, which is what makes validating the same code path
* against two unrelated curve libraries' point representations (P-256 here,
* edwards25519 in production) a meaningful test of the *composition* and not
* just of one curve's arithmetic.
*
* Two entry points, one composition. `spake2Run` takes **both** scalars, which
* is the shape §13's vectors (and RFC 9382 Appendix B's) are stated in and the
* only shape in which A's and B's independently-computed secrets can be
* cross-checked. `spake2ClientRun` takes only `x` and the peer's `pB`, which is
* the shape a real client is in — `y` is B's secret and never crosses the wire
* — and is therefore what `pairing-flow.ts` calls. Both derive the transcript
* and key schedule through the same private `keyScheduleFrom`, so the vector
* suite that gates one gates the other; a second copy for the client role would
* put the production path outside everything those vectors prove.
*
* Everything this module touches is secret: `w`, `x`, `y`, `K`, `Ke`, `Ka`,
* `KcA`, `KcB`, the confirmation MACs, the §6.6 traffic keys, and their inputs
* (§11). This module MUST NOT log any of it at any level, and every
* intermediate lives in caller-owned memory only — nothing here is persisted or
* cached.
*/
/**
* Thrown when a received point does not decode as a canonical on-curve
* encoding (§6.3). Wire-level handling MUST map this onto the `pairError`
* code `protocolViolation`.
*/
var Spake2ProtocolViolationError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "Spake2ProtocolViolationError";
	}
};
/**
* Thrown when the computed shared secret `K` is the identity element of the
* group — a failed protocol attempt, never a wire-level abort (§6.3, §7.2).
*/
var Spake2IdentityKError = class extends Error {
	constructor(message) {
		super(message);
		this.name = "Spake2IdentityKError";
	}
};
function buildGroup(Point, order, cofactor, M, N, encodePoint) {
	function decodeOrThrow(bytes) {
		try {
			return Point.fromBytes(bytes);
		} catch {
			throw new Spake2ProtocolViolationError("point is not a canonical encoding of a point on the curve");
		}
	}
	return {
		M,
		N,
		order,
		mulBase(scalar) {
			return encodePoint(Point.BASE.multiply(scalar));
		},
		addPoints(a, b) {
			return encodePoint(decodeOrThrow(a).add(decodeOrThrow(b)));
		},
		negPoint(p) {
			return encodePoint(decodeOrThrow(p).negate());
		},
		mulPoint(p, scalar) {
			return encodePoint(decodeOrThrow(p).multiply(scalar));
		},
		decode(b) {
			return decodeOrThrow(b);
		},
		cofactorClear(p) {
			return encodePoint(decodeOrThrow(p).multiplyUnsafe(cofactor));
		},
		isIdentity(p) {
			return decodeOrThrow(p).is0();
		}
	};
}
/**
* MBP1's actual ciphersuite group: edwards25519 with the RFC 9382 §6 fixed
* points (bridge-pairing-protocol.md §3), cofactor `h = 8`, 32-byte RFC 8032
* compressed point encoding. `ed25519.Point.fromBytes` defaults to strict
* RFC 8032 decoding (`zip215 = false`), matching §6.3's canonical-encoding
* requirement without any extra argument.
*/
var ED25519_GROUP = buildGroup(ed25519.Point, ed25519.Point.Fn.ORDER, 8n, hexToBytes$1("d048032c6ea0b6d697ddc2e86bda85a33adac920f1bf18e1b0c6d166a5cecdaf"), hexToBytes$1("d3bfb518f44f3430f29d0c92af503865a1ed3281dc69b35dd868ba85f886c4ab"), (p) => p.toBytes());
p256.Point, p256.Point.Fn.ORDER, p256.Point.fromBytes(hexToBytes$1("02886e2f97ace46e55ba9dd7242579f2993b64e16ef3dcab95afd497333d8fa12f")).toBytes(false), p256.Point.fromBytes(hexToBytes$1("03d8bbd6c639c62937b04d997f38c3770719c629d7014d49a24b4f98baa1292b49")).toBytes(false);
/** Width of a SPAKE2 scalar draw and of `I2OSP(w, 32)` in the transcript (§6.3, §6.4). */
var SCALAR_BYTES = 32;
/**
* Draws a scalar uniformly from `[1, order)` by rejection sampling (§6.3,
* RFC 9382 §7): draw 32 CSPRNG bytes, interpret them big-endian, and redraw
* while the value is 0 or ≥ `order`. Modular reduction is deliberately never
* used here — it would bias the low end of the range, which is exactly what
* rejection sampling exists to avoid. `rng` defaults to
* `@noble/hashes`'s `randomBytes`, which uses the platform CSPRNG
* (`crypto.getRandomValues` in a browser extension background worker); it is
* overridable for deterministic tests.
*/
function drawScalar(order, rng = randomBytes$1) {
	for (;;) {
		const bytes = rng(SCALAR_BYTES);
		if (bytes.length !== SCALAR_BYTES) throw new Spake2ProtocolViolationError("drawScalar requires exactly 32 bytes of entropy per draw");
		const candidate = os2ip(bytes);
		if (candidate !== 0n && candidate < order) return candidate;
	}
}
/** Big-endian interpretation of a byte string as an integer (§2 `OS2IP`). */
function os2ip(bytes) {
	let n = 0n;
	for (const byte of bytes) n = n << 8n | BigInt(byte);
	return n;
}
/**
* `OS2IP` for callers outside this module — specifically for turning
* `deriveW`'s 32-byte big-endian `w` into the scalar `spake2ClientRun` needs.
*
* Exported rather than duplicated at the call site because a second big-endian
* decoder is a second chance to write a little-endian one, and the resulting
* `w` would be wrong in a way no local test could see: both sides would still
* agree on `pA`, and only key confirmation against the *real* Motrix would
* fail.
*/
function scalarFromBytes(bytes) {
	return os2ip(bytes);
}
/**
* `I2OSP(w, 32)` (§2): big-endian, zero-padded to the transcript's constant
* scalar width (RFC 9382 §3.3, §6.4). A negative or oversized `w` is a
* broken local invariant rather than peer-supplied data — `deriveW` and
* `drawScalar` both guarantee `w` fits — so this throws a plain `Error`
* rather than `Spake2ProtocolViolationError`, which is reserved for
* peer-facing wire failures.
*/
function i2osp32(w) {
	if (w < 0n) throw new Error("i2osp32: w must be non-negative");
	const out = new Uint8Array(SCALAR_BYTES);
	let remaining = w;
	for (let i = 31; i >= 0; i--) {
		out[i] = Number(remaining & 255n);
		remaining >>= 8n;
	}
	if (remaining !== 0n) throw new Error("i2osp32: w does not fit in 32 bytes");
	return out;
}
/** A local, broken invariant on a caller-supplied scalar — never peer data. */
function assertScalarInRange(value, order, label) {
	if (value <= 0n || value >= order) throw new Error(`${label} must lie in [1, order); got out-of-range scalar`);
}
var CONFIRMATION_KEYS_LABEL = utf8("ConfirmationKeys");
/**
* `K = h·(secretScalar·d)` (§6.3) — the SPAKE2 shared-secret computation
* from one party's own secret scalar (`x` for A, `y` for B) and the
* peer-share-minus-mask difference `d` (`pB − w·N` for A, `pA − w·M` for B).
* `spake2Run` calls this for both `kFromA` and `kFromB` below, and it is
* exported specifically so the crafted torsion-guard test in
* `spake2-core.mbp1.test.ts` exercises this exact composition rather than an
* independently-written mirror of it that could drift from what
* `spake2Run` actually does.
*
* DO NOT "simplify" this into a single `g.mulPoint(d, (h·secretScalar) %
* g.order)`, folding the cofactor into the secret scalar before the
* multiply. Cofactor multiplication is not a mod-order operation: `d` may
* carry a low-order torsion component `T`, and multiplying by `h` as a
* literal integer (not reduced mod the prime-subgroup order) kills it
* because `h | h`, whereas `(h·secretScalar) mod order` can lose that exact
* divisibility and leave a residual torsion term. The two forms then
* disagree — but ONLY against a torsion-carrying peer share; every
* published RFC 9382 and MBP1 vector is generated from honest, torsion-free
* shares, so **a green vector suite is not evidence this function is
* correct.** Only the crafted torsion-carrying share in
* `spake2-core.mbp1.test.ts` proves it. `g.cofactor` is deliberately not
* part of the public `Spake2Group` interface at all — the only way to apply
* it is through `g.cofactorClear`, which forces this two-step order.
*/
function sharedSecretFromDifference(g, d, secretScalar) {
	return g.cofactorClear(g.mulPoint(d, secretScalar));
}
/**
* `TT` (§6.4), then `Ke ‖ Ka`, `KcA ‖ KcB`, `cA` and `cB` (§6.5).
*
* The **single** composition of the transcript and key schedule in this
* package. `spake2Run` (both scalars given, which is the shape §13's vectors
* are stated in) and `spake2ClientRun` (only `x` known, which is the shape a
* real client is in) both go through it, so the RFC 9382 P-256 vectors that
* gate `spake2Run` gate the production client path too. Writing a second copy
* for the client role would put the production path outside everything those
* vectors prove.
*/
function keyScheduleFrom(args) {
	const TT = concatBytes$2(enc(args.aId), enc(args.bId), enc(args.pA), enc(args.pB), enc(args.K), enc(i2osp32(args.w)));
	const digest = sha256(TT);
	const Ke = digest.slice(0, 16);
	const Ka = digest.slice(16, 32);
	const confirmationKeys = hkdf(sha256, Ka, /* @__PURE__ */ new Uint8Array(0), concatBytes$2(CONFIRMATION_KEYS_LABEL, args.aad), 32);
	const KcA = confirmationKeys.slice(0, 16);
	const KcB = confirmationKeys.slice(16, 32);
	return {
		TT,
		Ke,
		Ka,
		KcA,
		KcB,
		cA: hmac(sha256, KcA, TT),
		cB: hmac(sha256, KcB, TT)
	};
}
/**
* `pA = w·M + x·P` (§6.3) — A's public share, which is everything the client
* needs to send `pakeA` before `pB` exists.
*
* Split from `spake2ClientRun` rather than returning intermediate state,
* because `pA` is a pure function of `w` and `x`: `spake2ClientRun` recomputes
* it internally, so the value bound into `TT` is identical to the value sent on
* the wire *by construction*, with no caller-held state that could drift. The
* cost is one extra pair of scalar multiplications per run, which is nothing
* next to the scrypt in `deriveW`.
*/
function spake2ClientShare(g, w, x) {
	assertScalarInRange(w, g.order, "w");
	assertScalarInRange(x, g.order, "x");
	return g.addPoints(g.mulPoint(g.M, w), g.mulBase(x));
}
/**
* The client half of one SPAKE2 run (§6.3-§6.5): given the peer's `pB`, derive
* `K = h·x·(pB − w·N)` and everything §6.4/§6.5 hang off it.
*
* This is the shape a real client is in — `y` is B's secret and is never known
* here — so it, not `spake2Run`, is the production entry point `pairing-flow.ts`
* calls. Both share `keyScheduleFrom`, so the two agree by construction and the
* §13 vectors gate both.
*
* Throws `Spake2ProtocolViolationError` when `pB` is not a canonical encoding
* of a point on the curve (§6.3: abort with `protocolViolation`), and
* `Spake2IdentityKError` when the shared secret is the identity element (§6.3,
* §7.2: a failed attempt, and one that must stay indistinguishable from a bad
* confirmation MAC — otherwise it is an oracle for `pB = w·N`, i.e. for `w`).
*/
function spake2ClientRun(g, args) {
	const { aId, bId, w, x, pB, aad } = args;
	const pA = spake2ClientShare(g, w, x);
	const K = sharedSecretFromDifference(g, g.addPoints(pB, g.negPoint(g.mulPoint(g.N, w))), x);
	if (g.isIdentity(K)) throw new Spake2IdentityKError("SPAKE2 shared secret K is the identity element");
	return {
		pA,
		K,
		...keyScheduleFrom({
			aId,
			bId,
			pA,
			pB,
			K,
			w,
			aad
		})
	};
}
var PAIR_TRAFFIC_SALT = utf8("MBP1/pair/v1");
var PAIR_TRAFFIC_INFO_C2S = utf8("MBP1-pair-traffic-c2s");
var PAIR_TRAFFIC_INFO_S2C = utf8("MBP1-pair-traffic-s2c");
var TRAFFIC_KEY_BYTES = 32;
/**
* §6.6 pair-session traffic keys, derived from `Ke` after mutual confirmation:
*
* ```
* kC2S = HKDF-SHA-256(ikm=Ke, salt="MBP1/pair/v1", info="MBP1-pair-traffic-c2s", L=32)
* kS2C = HKDF-SHA-256(ikm=Ke, salt="MBP1/pair/v1", info="MBP1-pair-traffic-s2c", L=32)
* ```
*
* The `info` labels are deliberately distinct from §8's reconnect labels
* (`"MBP1-traffic-c2s"` / `"MBP1-traffic-s2c"`, salt `S ‖ C`) — every HKDF/HMAC
* invocation in MBP1 carries a globally unique label, so key separation never
* rests on incidental differences in IKM or salt alone. Do not unify the two
* families.
*
* Both keys MUST NOT be logged at any level (§11).
*/
function pairTrafficKeys(Ke) {
	return {
		c2s: hkdf(sha256, Ke, PAIR_TRAFFIC_SALT, PAIR_TRAFFIC_INFO_C2S, TRAFFIC_KEY_BYTES),
		s2c: hkdf(sha256, Ke, PAIR_TRAFFIC_SALT, PAIR_TRAFFIC_INFO_S2C, TRAFFIC_KEY_BYTES)
	};
}
//#endregion
//#region src/background/mbp1/ticket-bootstrap.ts
/**
* MBP1 NM attestation bootstrap (bridge-pairing-protocol.md §9.1) and
* ticketProof signing (§6.5).
*
* The extension generates an ephemeral Ed25519 "binding" keypair per
* bootstrap attempt, sends `bindingPub` to the Native Messaging host over NM
* stdio, and later proves possession of `bindingPriv` to the Motrix bridge
* server by signing the domain-tagged SPAKE2 transcript `TT` as
* `confirmA.ticketProof`. This binds a minted ticket to the one handshake
* that holds the corresponding private key, so the ticket cannot be replayed
* onto a different pairing attempt.
*
* Curve operations go through `@noble/curves`, never WebCrypto — WebCrypto's
* Ed25519 support needs Chrome 133 / Firefox 130, above this extension's
* Chrome 120+ / Firefox 121+ floor (§3, Appendix B).
*
* `bindingPriv` MUST NOT be logged at any level (§11); it lives only in this
* bootstrap's in-memory keypair for the lifetime of one pairing attempt.
*
* **Deviation from a minimal `{action, protocolVersion, bindingPub}` request
* shape:** Line A's Native Messaging host — the peer this module must
* interoperate with — only wakes a sleeping Motrix when the bootstrap
* request's `allowLaunch` field is *literally* `true`; a request that omits it
* never triggers the gesture-free wake path (§9.1 step 3: "wakes Motrix if
* needed"). So the field stays on the wire, always present and explicit.
*
* It is a **parameter**, not a constant. An earlier shape typed it as the
* literal `true` and hardcoded it, which would have silently discarded the
* caller's choice the moment the discovery chain wired this up — every
* background liveness probe would have launched the desktop app, which is
* precisely what the flag exists to prevent. The host's "only literal `true`
* wakes" rule is a fact about the host, not a reason to send only `true`.
*/
/** Generates a fresh ephemeral Ed25519 keypair for one bootstrap attempt (§9.1 step 1). */
function generateBindingKeypair() {
	const priv = ed25519.utils.randomSecretKey();
	return {
		priv,
		pub: ed25519.getPublicKey(priv)
	};
}
/**
* Builds the NM stdio request the extension sends to the host (§9.1 step 2).
*
* `allowLaunch` is the caller's decision: `true` only when a user gesture is
* driving the attempt, `false` for any background probe. See the module note
* for why it must not be hardcoded.
*/
function buildBootstrapRequest(pub, allowLaunch) {
	return {
		action: "bootstrap",
		protocolVersion: 1,
		bindingPub: b64uEncode(pub),
		allowLaunch
	};
}
var TICKET_PROOF_LABEL = utf8("MBP1/ticket-proof/v1");
/**
* Signs `"MBP1/ticket-proof/v1" ‖ TT` with `bindingPriv` (§6.5, §9.1 step 4).
* The server verifies this signature in RFC 8032 strict mode
* (`zip215: false` in noble-curves 2.0.1), never the permissive ZIP-215
* default (§9.1) — this module only signs and takes no position on
* verification mode itself.
*/
function signTicketProof(priv, TT) {
	return ed25519.sign(concatBytes$2(TICKET_PROOF_LABEL, TT), priv);
}
//#endregion
//#region src/background/mbp1/transcript.ts
/**
* MBP1 transcript identity strings, PAKE AAD, and NM-ticket digest
* (bridge-pairing-protocol.md §6.4, cross-referenced against §9.2).
*
* `buildAId`/`buildBId` produce the identity byte strings that feed
* `spake2Run`'s `aId`/`bId` parameters (spake2-core.ts already owns the
* `TT = enc(aId) ‖ enc(bId) ‖ ...` transcript *layout*) — this module owns
* only their construction, so transcript assembly has exactly one home and
* is never duplicated between the two files.
*
* `ticketDigest` deliberately hashes the wire `purpose` string rather than
* a fixed domain tag. §9.2's ticket MAC canonical input uses a *different*
* construction that fixes `purpose` to the constant `"mbp1-attestation"`
* instead of the parsed field — the two are intentionally distinct so that
* tampering `purpose` in transit is caught here even though it would not
* change the §9.2 MAC input. See `__tests__/transcript.test.ts` for the
* negative test that proves this module hashes the field, not the tag.
*
* Every value this module touches feeds key confirmation or ticket
* validation and MUST NOT be logged at any level (§11), including the
* identity strings, `ticketBindingKey`, ticket fields, and the digest
* itself.
*/
var EMPTY_BYTES = /* @__PURE__ */ new Uint8Array(0);
/** `A_id = enc("MBP1/A/v1") ‖ enc(browser) ‖ enc(verifiedOrigin) ‖ enc(claimedExtensionId) ‖ enc(clientInstallationId)` (§6.4). */
function buildAId(a) {
	return concatBytes$2(enc("MBP1/A/v1"), enc(a.browser), enc(a.verifiedOrigin), enc(a.claimedExtensionId), enc(a.clientInstallationId));
}
/** `B_id = enc("MBP1/B/v1") ‖ enc("motrix-bridge") ‖ enc(instanceId)` (§6.4). */
function buildBId(instanceId) {
	return concatBytes$2(enc("MBP1/B/v1"), enc("motrix-bridge"), enc(instanceId));
}
/**
* `ticketDigest = SHA-256(encU32BE(v) ‖ enc(purpose) ‖ encU32BE(ticketProtocolVersion) ‖ enc(serverGeneration) ‖ enc(browser) ‖ enc(callerId) ‖ encU64BE(exp) ‖ enc(bindingPub) ‖ enc(mac))` (§6.4).
*
* `bindingPub` and `mac` are hashed as their raw decoded bytes, not the
* base64url wire spelling.
*/
function ticketDigest(t) {
	return sha256(concatBytes$2(encU32BE(t.v), enc(t.purpose), encU32BE(t.protocolVersion), enc(t.serverGeneration), enc(t.browser), enc(t.callerId), encU64BE(t.exp), enc(t.bindingPub), enc(t.mac)));
}
/**
* `AAD = encU32BE(protocolVersion) ‖ enc(pairNonce) ‖ enc(ticketBindingKeyOrEmpty) ‖ enc(ticketDigestOrEmpty)` (§6.4),
* bound into confirmation-key derivation via `spake2Run`'s `aad` parameter.
*
* `ticketBindingKey`/`ticket` are both `null` for a ticketless attempt; each
* then contributes a zero-length `enc()` slot (an 8-byte zero length prefix
* and no payload) rather than being omitted, so the AAD's field count and
* order never depend on whether a ticket was presented.
*/
function buildAad(args) {
	return concatBytes$2(encU32BE(args.protocolVersion), enc(args.pairNonce), enc(args.ticketBindingKey ?? EMPTY_BYTES), enc(args.ticket ? ticketDigest(args.ticket) : EMPTY_BYTES));
}
/** §6.5: the extension's own absolute session deadline, from `pairHello`. */
var SESSION_DEADLINE_MS = 18e4;
/**
* §7.2: the code dies 120 s after it is generated, which is when the dialog is
* queued — i.e. when `pairAccept` arrives.
*
* This is the **inner** bound and the one to design against. `/pair`'s
* pre-authentication table deadline of 150 s is a longer *backstop* that exists
* so the session's own `expired` branch is reachable in production rather than
* being pre-empted by a socket close; budgeting against 150 s would blow the
* real deadline.
*/
var CODE_LIFETIME_MS = 12e4;
/**
* A first-pair failure. The optional detail fields are `null` rather than
* absent so callers can read them without `exactOptionalPropertyTypes` dances,
* and so a `PairingFlowError` is a plain data record the UI can switch on.
*
* `attemptsRemaining`, when present, is the peer's last claim and is **display
* data only** — it never influenced any decision this flow made.
*/
var PairingFlowError = class extends Error {
	reason;
	pairErrorCode;
	retryAtMs;
	attemptsRemaining;
	constructor(reason, message, details = {}) {
		super(message);
		this.name = "PairingFlowError";
		this.reason = reason;
		this.pairErrorCode = details.pairErrorCode ?? null;
		this.retryAtMs = details.retryAtMs ?? null;
		this.attemptsRemaining = details.attemptsRemaining ?? null;
	}
};
var textDecoder = new TextDecoder();
var PairingFlow = class {
	deps;
	now;
	aborted = false;
	constructor(deps) {
		this.deps = {
			...deps,
			creds: resolveCredentialLifecycleStore(deps.creds)
		};
		this.now = deps.now ?? Date.now;
	}
	async run(args) {
		const prepared = this.prepare(args);
		const gate = await this.deps.backoff.check(this.now());
		this.ensureCurrent();
		if (!gate.allowed) throw new PairingFlowError("backoffLocked", "first-pair backoff is active; try again later", gate.retryAtMs === void 0 ? {} : { retryAtMs: gate.retryAtMs });
		const state = {
			reachedPakeA: false,
			confirmed: false
		};
		try {
			return await this.session(args, prepared, state);
		} catch (error) {
			if (state.reachedPakeA && !state.confirmed) try {
				await this.deps.backoff.recordFailure(this.now());
			} catch {}
			this.deps.channel.close();
			throw error instanceof PairingFlowError ? error : this.wrapUnknownError(error);
		}
	}
	/**
	* Discards this run at its next checkpoint. Does **not** zeroize anything —
	* it cannot. The SPAKE2 scalars (`w`, `x`) and every key this run derives
	* are locals inside `runAttempts`/`session`, never promoted to a field of
	* this class specifically so that a method with no access to another call
	* frame's locals is never tempted to overwrite them in place. This just
	* flips a flag `ensureCurrent()` already checks after every await, so the
	* run's next checkpoint throws and that call frame unwinds; the scalars and
	* derived keys become unreachable — and therefore GC-eligible — at that
	* point, on whatever schedule the engine chooses. JavaScript offers no way
	* to erase them sooner, and a `bigint` in particular cannot be erased at
	* all: it is immutable, so overwriting the variable only drops this
	* reference while the original value stays wherever the engine put it.
	*
	* Also closes the channel, so a run currently blocked inside `receiveText`/
	* `receiveBinary` — waiting on a peer that will never answer, for instance
	* — unblocks immediately instead of waiting out the full §6.5/§7.2 deadline
	* first. `FrameChannel.close()` is documented to make a pending receive
	* reject rather than hang, which is what turns the flag flip into an
	* immediate rejection instead of one deferred until the next natural I/O.
	*/
	abort() {
		this.aborted = true;
		this.deps.channel.close();
	}
	prepare(args) {
		const { discovery, principal } = args;
		if (discovery.nonce === void 0 || discovery.nonce.length === 0) throw new PairingFlowError("missingNonce", "/pair requires a §4.2 nonce; call DiscoveryService.ensureNonce first");
		if (principal.browser !== "chromium" && principal.browser !== "firefox") throw new PairingFlowError("unsupportedBrowser", "pairHello.browser must be chromium or firefox");
		const rawTicket = args.nmTicket ?? discovery.nmTicket;
		const bindingKeypair = args.bindingKeypair ?? null;
		if (rawTicket === void 0 || rawTicket === null) return {
			port: discovery.wsPort,
			url: args.remotePairUrl ?? pairUrl(discovery.wsPort, discovery.nonce),
			persistLocalPins: args.remotePairUrl === void 0,
			pairNonce: discovery.nonce,
			browser: principal.browser,
			ticket: null,
			rawTicket: void 0,
			bindingKeypair: null
		};
		if (bindingKeypair === null) throw new PairingFlowError("ticketWithoutBindingKeypair", "an nmTicket was supplied without the §9.1 binding keypair that signs its proof");
		let ticket;
		try {
			ticket = parseNmTicket(rawTicket);
		} catch {
			throw new PairingFlowError("malformedTicket", "the host returned a ticket this client cannot parse into §6.4 digest fields");
		}
		if (!timingSafeEqualBytes(ticket.bindingPub, bindingKeypair.pub)) throw new PairingFlowError("ticketBindingKeyMismatch", "the ticket is bound to a different key than this attempt holds");
		return {
			port: discovery.wsPort,
			url: args.remotePairUrl ?? pairUrl(discovery.wsPort, discovery.nonce),
			persistLocalPins: args.remotePairUrl === void 0,
			pairNonce: discovery.nonce,
			browser: principal.browser,
			ticket,
			rawTicket,
			bindingKeypair
		};
	}
	async session(args, prepared, state) {
		try {
			await this.deps.channel.open(prepared.url);
		} catch {
			throw new PairingFlowError("channelUnavailable", "the pairing channel could not be opened");
		}
		this.ensureCurrent();
		const helloFrame = buildPairHello({
			browser: prepared.browser,
			claimedExtensionId: args.claimedExtensionId,
			clientInstallationId: args.principal.clientInstallationId,
			...prepared.ticket === null ? {} : {
				nmTicket: prepared.rawTicket,
				ticketBindingKey: b64uEncode(prepared.bindingKeypair.pub)
			}
		});
		const sessionDeadline = this.now() + SESSION_DEADLINE_MS;
		await this.deps.channel.sendText(helloFrame);
		this.ensureCurrent();
		const accept = await this.expect("pairAccept", sessionDeadline);
		assertProtocolVersionOrThrow(accept.protocolVersion);
		const codeDeadline = this.now() + CODE_LIFETIME_MS;
		const instanceId = accept.instanceId;
		const aId = buildAId({
			browser: prepared.browser,
			verifiedOrigin: args.principal.verifiedOrigin,
			claimedExtensionId: args.claimedExtensionId,
			clientInstallationId: args.principal.clientInstallationId
		});
		const bId = buildBId(instanceId);
		const aad = buildAad({
			protocolVersion: 1,
			pairNonce: prepared.pairNonce,
			ticketBindingKey: prepared.bindingKeypair?.pub ?? null,
			ticket: prepared.ticket
		});
		const confirmed = await this.runAttempts({
			args,
			prepared,
			state,
			instanceId,
			aId,
			bId,
			aad,
			deadline: Math.min(sessionDeadline, codeDeadline)
		});
		await this.deps.backoff.recordSuccess();
		this.ensureCurrent();
		const traffic = pairTrafficKeys(confirmed.Ke);
		const envelope = await EnvelopeCodec.create(traffic.c2s, traffic.s2c, "client");
		this.ensureCurrent();
		return {
			credentialId: await this.issueCredential({
				envelope,
				principal: args.principal,
				instanceId,
				port: prepared.port,
				persistLocalPins: prepared.persistLocalPins,
				deadline: sessionDeadline
			}),
			envelope,
			instanceId
		};
	}
	/**
	* §6.5/§7.2: up to `MAX_RUNS_PER_SESSION` protocol runs on one socket, each
	* with a **fresh `x`**, retrying only through `codeMismatch`.
	*
	* The ceiling is this side's own and is enforced by the loop bound alone —
	* nothing the peer sends can extend it. `attemptsRemaining` is carried along
	* only to be handed to the code provider for display.
	*/
	async runAttempts(ctx) {
		const { prepared, state, aId, bId, aad, deadline } = ctx;
		let attemptsRemaining = null;
		let cachedCode = null;
		let cachedW = null;
		for (let run = 1; run <= 3; run++) {
			const code = await this.resolveCode(ctx.args.code, {
				instanceId: ctx.instanceId,
				timeoutMs: this.budget(deadline),
				run,
				attemptsRemaining
			});
			this.budget(deadline);
			if (code !== cachedCode) {
				cachedCode = code;
				cachedW = scalarFromBytes(deriveW(code, prepared.pairNonce));
			}
			const w = cachedW;
			const x = drawScalar(ED25519_GROUP.order, this.deps.random);
			const pA = spake2ClientShare(ED25519_GROUP, w, x);
			state.reachedPakeA = true;
			await this.deps.channel.sendText(buildPakeA(b64uEncode(pA)));
			this.ensureCurrent();
			const pakeB = await this.expectOrCodeMismatch("pakeB", deadline);
			if (pakeB === null) {
				attemptsRemaining = this.lastAttemptsRemaining;
				continue;
			}
			let result;
			try {
				result = spake2ClientRun(ED25519_GROUP, {
					aId,
					bId,
					w,
					x,
					pB: b64uDecode(pakeB.pB),
					aad
				});
			} catch (error) {
				if (error instanceof Spake2IdentityKError) throw new PairingFlowError("identityK", "the SPAKE2 shared secret was the identity element");
				throw new PairingFlowError("protocolViolation", "the peer sent a share that is not a canonical curve point");
			}
			const ticketProof = prepared.ticket === null || prepared.bindingKeypair === null ? void 0 : b64uEncode(signTicketProof(prepared.bindingKeypair.priv, result.TT));
			await this.deps.channel.sendText(buildConfirmA(b64uEncode(result.cA), ticketProof));
			this.ensureCurrent();
			const confirmB = await this.expectOrCodeMismatch("confirmB", deadline);
			if (confirmB === null) {
				attemptsRemaining = this.lastAttemptsRemaining;
				continue;
			}
			if (!timingSafeEqualBytes(b64uDecode(confirmB.cB), result.cB)) throw new PairingFlowError("peerNotAuthentic", "the peer accepted confirmA but its confirmB did not verify");
			state.confirmed = true;
			return result;
		}
		throw new PairingFlowError("runsExhausted", `key confirmation failed on all 3 runs of this session`, {
			pairErrorCode: "codeMismatch",
			...attemptsRemaining === null ? {} : { attemptsRemaining }
		});
	}
	/**
	* §6.7 inside the AEAD channel, in the one order that survives a crash at
	* every point:
	*
	* ```
	* credentialOffer -> writeProvisionalUnacked -> markCommitUncertain (durable)
	*   -> credentialAck -> credentialCommitted -> finalizeAndPrune
	*   -> clear each pruned pin -> commit this pin
	* ```
	*
	* The write-ahead before `credentialAck` is mandatory (§6.7 step 2).
	* `finalizeAndPrune`'s deletion callback is mandatory too: §12 requires
	* deleting the other credentials **and their pins** in the same serialized
	* plan/apply transaction.
	*/
	async issueCredential(ctx) {
		const { envelope, principal, instanceId } = ctx;
		const offer = await this.receiveSealed(envelope, ctx.deadline);
		if (offer.type !== "credentialOffer") throw new PairingFlowError("credentialPhaseFailed", "expected credentialOffer inside the channel");
		const credentialId = offer.credentialId;
		this.ensureCurrent();
		try {
			await this.deps.creds.writeProvisionalUnacked(principal, {
				credentialId,
				mutualKey: offer.mutualKey
			}, instanceId);
		} catch (error) {
			if (error instanceof OfferContradictsSlotError) throw new PairingFlowError("protocolViolation", error.message);
			throw error;
		}
		this.ensureCurrent();
		await this.deps.creds.markCommitUncertain(credentialId);
		this.ensureCurrent();
		await this.sendSealed(envelope, buildCredentialAck(credentialId));
		this.ensureCurrent();
		if ((await this.receiveSealed(envelope, ctx.deadline)).type !== "credentialCommitted") throw new PairingFlowError("credentialPhaseFailed", "expected credentialCommitted inside the channel");
		this.ensureCurrent();
		await this.deps.creds.finalizeAndPrune(credentialId, principal, instanceId, async (staleIds) => {
			if (!ctx.persistLocalPins) return;
			for (const staleId of staleIds) await this.deps.pins.clear(staleId);
		});
		this.ensureCurrent();
		if (ctx.persistLocalPins) await this.deps.pins.commit(credentialId, {
			port: ctx.port,
			instanceId: ctx.instanceId
		});
		this.ensureCurrent();
		return credentialId;
	}
	lastAttemptsRemaining = null;
	/**
	* Awaits one text frame and requires it to be `type`.
	*
	* A `pairError` here is terminal: the caller that can retry through
	* `codeMismatch` uses `expectOrCodeMismatch` instead.
	*/
	async expect(type, deadline) {
		const frame = await this.receiveText(deadline);
		if (frame.type === "pairError") throw this.pairErrorToFlowError(frame);
		if (frame.type !== type) throw new PairingFlowError("protocolViolation", `expected ${type} but the peer sent another frame`);
		return frame;
	}
	/**
	* As `expect`, but returns `null` on `pairError {code:"codeMismatch"}` — the
	* one error §6.5 lets a fresh run follow. Every other code is terminal.
	*/
	async expectOrCodeMismatch(type, deadline) {
		const frame = await this.receiveText(deadline);
		if (frame.type === "pairError") {
			if (frame.code !== "codeMismatch") throw this.pairErrorToFlowError(frame);
			this.lastAttemptsRemaining = frame.attemptsRemaining ?? null;
			return null;
		}
		if (frame.type !== type) throw new PairingFlowError("protocolViolation", `expected ${type} but the peer sent another frame`);
		return frame;
	}
	async receiveText(deadline) {
		const raw = await this.deps.channel.receiveText(this.budget(deadline));
		this.ensureCurrent();
		try {
			return parseTextFrame(raw);
		} catch (error) {
			throw toFlowError(error);
		}
	}
	async sendSealed(envelope, frame) {
		const sealed = await envelope.seal(utf8(JSON.stringify(frame)));
		this.ensureCurrent();
		await this.deps.channel.sendBinary(sealed);
	}
	async receiveSealed(envelope, deadline) {
		const raw = await this.deps.channel.receiveBinary(this.budget(deadline));
		this.ensureCurrent();
		let plaintext;
		try {
			plaintext = await envelope.open(raw);
		} catch {
			throw new PairingFlowError("credentialPhaseFailed", "an envelope frame failed to open");
		}
		this.ensureCurrent();
		try {
			return parseTextFrame(textDecoder.decode(plaintext));
		} catch (error) {
			throw toFlowError(error);
		}
	}
	budget(deadline) {
		const remaining = deadline - this.now();
		if (remaining <= 0) throw new PairingFlowError("deadlineExceeded", "the pairing session ran out of time (§6.5 / §7.2)");
		return remaining;
	}
	async resolveCode(source, request) {
		const raw = typeof source === "string" ? source : await source(request);
		this.ensureCurrent();
		const normalized = normalizePairingCode(raw);
		if (normalized === null) throw new PairingFlowError("invalidCode", "the pairing code failed §7.1 local normalization");
		return normalized;
	}
	pairErrorToFlowError(frame) {
		if (frame.code === "unsupportedVersion") return new PairingFlowError("unsupportedVersion", "the peer rejected this protocol version", { pairErrorCode: frame.code });
		return new PairingFlowError(frame.code === "busy" || frame.code === "rateLimited" ? "peerBusy" : "peerRejected", frame.code === "busy" || frame.code === "rateLimited" ? "the peer is rate-limiting pairing; try again later" : "the peer refused the pairing", {
			pairErrorCode: frame.code,
			...frame.attemptsRemaining === void 0 ? {} : { attemptsRemaining: frame.attemptsRemaining }
		});
	}
	ensureCurrent() {
		if (this.aborted) throw new PairingFlowError("aborted", "the run was aborted");
		if (!this.deps.isCurrent()) throw new PairingFlowError("staleAttempt", "a newer connection attempt superseded this one");
	}
	/**
	* Wraps any error this flow did not itself classify — a storage rejection
	* (quota, MV3 service-worker teardown), `CredentialStore` throwing because
	* a concurrent attempt's prune already removed this credential between the
	* orchestrator's read and this write, or anything else unmodelled. A
	* caller switching on `error.reason` seeing `undefined` is a worse outcome
	* than a coarse `internalError`.
	*
	* `abort()` takes priority over everything else here. Closing the channel
	* is what unblocks a receive that was already pending when `abort()` ran,
	* and that unblocking surfaces as a plain rejection from the channel
	* itself (never a `PairingFlowError`) — arriving here, not at
	* `ensureCurrent()`'s own checkpoint, since the channel's rejection is what
	* threw, not the checkpoint that never got a chance to run. Once the
	* caller has aborted, every failure downstream of that is a consequence of
	* the abort, whatever its proximate shape — reporting one as `internalError`
	* would say something actually went wrong when the honest answer is just
	* that the caller gave up.
	*
	* This forwards `error.message` verbatim rather than a fixed generic
	* string, because "which step failed" is the whole diagnosis for exactly
	* the errors that reach here — a durable-write rejection or a corrupted
	* store. That is only safe because of a constraint on this flow's own
	* dependencies, not a property of this function: **nothing this flow
	* depends on may interpolate a value into a thrown message.** The current
	* sources all honour it: `canonical.ts`'s decoders name only a length, a
	* single offending character, or a fixed string, never key material;
	* `credential-store.ts`'s own module doc states its thrown messages never
	* interpolate a `credentialId`; `scrypt-w.ts` has one throw site with a
	* fixed string; `spake2-core.ts`'s throws are fixed strings or interpolate
	* only a scalar's fixed label (`'w'`/`'x'`/`'y'`), never its value; and
	* `ticket-bootstrap.ts` and `first-pair-backoff.ts` throw nothing of their
	* own at all. If a future dependency's error can carry a secret or other
	* sensitive value, this function needs a message allowlist before that
	* dependency is wired in here, not after.
	*/
	wrapUnknownError(error) {
		if (this.aborted) return new PairingFlowError("aborted", "the run was aborted");
		return new PairingFlowError("internalError", error instanceof Error ? error.message : "an unclassified error occurred");
	}
};
/** §11: a version mismatch is `unsupportedVersion`, never a generic violation. */
function assertProtocolVersionOrThrow(protocolVersion) {
	try {
		assertProtocolVersion(protocolVersion);
	} catch (error) {
		throw toFlowError(error);
	}
}
/**
* Maps a `FrameError` onto the §11 code it belongs to, keeping
* `unsupportedVersion` distinct from `protocolViolation` on this side of the
* wire too.
*/
function toFlowError(error) {
	if (!(error instanceof FrameError)) return error;
	if (error.kind === "unsupportedVersion") return new PairingFlowError("unsupportedVersion", error.message);
	return new PairingFlowError("protocolViolation", error.message);
}
//#endregion
//#region src/background/mbp1/pin-store.ts
/**
* MBP1 client pin store (bridge-pairing-protocol.md §12, §4.1).
*
* A pin records where a given credential last authenticated: `{port,
* instanceId}`, keyed by `credentialId`. Its only purpose is to skip the
* candidate-port sweep on the next reconnect.
*
* **A pin is a routing hint and never a trust decision** (§4.1). Neither
* `port` nor `instanceId` is authenticated by anything — `/discovery` is
* unauthenticated and replayable, and any local process can serve a matching
* `instanceId`. So nothing in this module, and nothing that reads it, may
* decide anything on the strength of a pin beyond *which endpoint to try
* first*. A matching pin is a fast path; the reconnect challenge–response
* (§8) is what actually authenticates. A stale, wrong, or forged pin can
* therefore only cost a failed attempt and a sweep.
*
* That is also why nothing here is encrypted or hardened: there is no secret
* in a pin. `browser.storage.local` is sandboxed to the extension and
* protected by OS user isolation, as for other extension settings.
*
* Boundedness is a caller obligation, not a policy this store enforces: §12
* requires the post-authentication prune to delete "all other stored
* credentials **and pins** for that same principal", and
* `CredentialStore.prunePrincipalExcept` returns exactly the ids to pass to
* `clear`. No eviction policy is implemented here because a cap can never be
* needed for safety — it is the caller's loop that keeps the map the size of
* the live credential set.
*/
var STORAGE_KEY$3 = "motrix.mbp1.pins";
/**
* A bound on the persisted `instanceId`, whose only job is to stop a corrupted
* or oversized value from growing `storage.local` without limit. Motrix's own
* value is a UUID.
*/
var MAX_INSTANCE_ID_LENGTH$1 = 128;
/**
* A pinned `instanceId` is plain ASCII, matched by frames.ts's own (private)
* schema-level check for the same field on the wire (`asciiString()`).
* Duplicated here as a cheap boolean predicate rather than imported, because
* `canonical.ts`'s `assertAscii` throws and allocates UTF-8 bytes this check
* has no use for.
*/
function isAsciiString(s) {
	for (let i = 0; i < s.length; i++) if (s.charCodeAt(i) > 127) return false;
	return true;
}
/**
* Validates one persisted pin.
*
* The checks stop at "present, in range, bounded, and ASCII" on purpose.
* `ReconnectFlow` (§8) feeds a pinned `instanceId` straight into `enc()` when
* building the reconnect transcript `RT`, and `enc` throws on non-ASCII
* input. This store's check is a **second layer**, not the only thing
* standing between a corrupted pin and a crash: `ReconnectFlow` independently
* guards the same value (and the other three strings `RT` feeds to `enc()`)
* before it ever reaches `enc()`, so this check narrows *when* a bad value is
* caught rather than being the sole reason it is. Both the wire path that
* writes a pin (`pairAccept.instanceId` is `asciiString()`) and the flow that
* reads one back are already ASCII-safe, so this is defence in depth against
* a corrupted or hand-edited `storage.local` value, not a live bug. Rejecting
* a pin still costs only a candidate sweep (§4.1 makes it a hint), while
* inventing a stricter format beyond ASCII would risk discarding a perfectly
* good hint from a future Motrix.
*/
function readPin(value) {
	if (!value || typeof value !== "object") return null;
	const raw = value;
	if (typeof raw.port !== "number" || !Number.isInteger(raw.port) || raw.port < 1 || raw.port > 65535) return null;
	if (typeof raw.instanceId !== "string" || raw.instanceId.length === 0 || raw.instanceId.length > MAX_INSTANCE_ID_LENGTH$1 || !isAsciiString(raw.instanceId)) return null;
	return {
		port: raw.port,
		instanceId: raw.instanceId
	};
}
/**
* Drops unreadable entries individually rather than discarding the whole map.
* One corrupted pin should cost one extra sweep, not a sweep for every
* credential the user has.
*/
function readStoredPins(value) {
	const empty = {
		version: 1,
		pins: {}
	};
	if (!value || typeof value !== "object") return {
		kind: "known",
		set: empty
	};
	const stored = value;
	if (Object.hasOwn(stored, "version") && stored.version !== 1) return { kind: "future" };
	if (stored.version !== 1) return {
		kind: "known",
		set: empty
	};
	const rawPins = stored.pins;
	if (!rawPins || typeof rawPins !== "object" || Array.isArray(rawPins)) return {
		kind: "known",
		set: empty
	};
	const pins = Object.create(null);
	for (const [credentialId, rawPin] of Object.entries(rawPins)) {
		if (credentialId.length === 0) continue;
		const pin = readPin(rawPin);
		if (pin !== null) pins[credentialId] = pin;
	}
	return {
		kind: "known",
		set: {
			version: 1,
			pins
		}
	};
}
/** Fixed fail-closed error that never includes persisted pin contents. */
var UnsupportedPinStoreVersionError = class extends Error {
	constructor() {
		super("pin store version is unsupported");
	}
};
/** Remote MBP1 routes are fixed and deliberately have no local port pin. */
var RemotePinStoreUnsupportedError = class extends Error {
	constructor() {
		super("remote backend authorities do not use the local pin store");
	}
};
var enqueuePinOperation = createOperationQueue();
var PinStore = class {
	/**
	* Pins are a loopback candidate optimization and therefore local-only.
	* A remote branch must model the absence of this dependency explicitly; it
	* cannot obtain a silent no-op PinStore and cannot contaminate local pins.
	*/
	constructor(authority = LOCAL_BACKEND_AUTHORITY) {
		assertBackendAuthority(authority);
		if (authority.kind !== "local") throw new RemotePinStoreUnsupportedError();
	}
	/** The pin for `credentialId`, or `null` if none is stored or it is unreadable. */
	async get(credentialId) {
		return enqueuePinOperation(async () => {
			const set = await this.read(false);
			if (set === null) return null;
			const { pins } = set;
			return pins[credentialId] ?? null;
		});
	}
	/**
	* Records where `credentialId` authenticated, replacing any previous pin for
	* it.
	*
	* **Post-mutual-authentication only.** §12: "A pin is committed **only
	* after** a mutually-authenticated session on that port — never from
	* `/discovery`." That invariant is enforced by the caller, not by this
	* store: the store cannot observe whether a session authenticated, and a
	* flag saying so would be exactly as trustworthy as the caller passing it.
	* So the rule lives here in the doc comment and in the two call sites — the
	* end of `PairingFlow` and the end of `ReconnectFlow`, both after key
	* confirmation.
	*
	* Committing early is not a privilege escalation — a pin authenticates
	* nothing (§4.1) — but it would defeat the point: the client would pin
	* whatever answered `/discovery` first, so a local impostor could park
	* itself in front of the real Motrix on every subsequent reconnect and turn
	* a one-off failed attempt into a persistent one.
	*/
	async commit(credentialId, pin) {
		return enqueuePinOperation(async () => {
			const set = await this.read(true);
			if (set === null) throw new UnsupportedPinStoreVersionError();
			await this.write({
				version: 1,
				pins: {
					...set.pins,
					[credentialId]: pin
				}
			});
		});
	}
	/**
	* Forgets the pin for `credentialId`.
	*
	* Two callers, and both need this to be a **no-op on an unknown id**:
	*
	* - The §12 post-authentication prune loops over the ids
	*   `CredentialStore.prunePrincipalExcept` returns, most of which never had
	*   a pin at all (a credential only gets one once it has authenticated
	*   somewhere).
	* - §8's "not my Motrix" recovery clears the pin after a `reconnectAccept`
	*   whose MAC does not verify, which can happen on a credential whose pin
	*   was already cleared by an earlier attempt.
	*
	* Throwing in either case would turn "nothing to do" into an error the
	* caller has to swallow, and a swallowed error is how the other ids in the
	* prune loop stop getting cleared.
	*/
	async clear(credentialId) {
		return enqueuePinOperation(async () => {
			const set = await this.read(true);
			if (set === null) throw new UnsupportedPinStoreVersionError();
			if (!(credentialId in set.pins)) return;
			const pins = { ...set.pins };
			delete pins[credentialId];
			await this.write({
				version: 1,
				pins
			});
		});
	}
	async read(forMutation) {
		const stored = readStoredPins((await browser.storage.local.get(STORAGE_KEY$3))[STORAGE_KEY$3]);
		if (stored.kind === "future") {
			if (forMutation) throw new UnsupportedPinStoreVersionError();
			return null;
		}
		return stored.set;
	}
	async write(set) {
		if (Object.keys(set.pins).length === 0) {
			await browser.storage.local.remove(STORAGE_KEY$3);
			return;
		}
		await browser.storage.local.set({ [STORAGE_KEY$3]: set });
	}
};
//#endregion
//#region src/background/mbp1/reconnect-mac.ts
/**
* MBP1 reconnect transcript, confirmation MACs, and traffic key derivation
* (bridge-pairing-protocol.md §8, the challenge-response run on `/v1`).
*
* The MAC labels `"MBP1-R/c"` / `"MBP1-R/s"` are prepended to the HMAC
* message as their raw UTF-8 bytes, deliberately NOT `enc()`-wrapped — every
* other canonical structure in this protocol length-prefixes its fields,
* but §8's vector is authoritative here and only agrees with the raw form.
*
* Every HKDF/HMAC label in MBP1 is globally unique so key separation never
* rests on an incidental difference in IKM or salt alone. In particular,
* these traffic-key labels (`"MBP1-traffic-c2s"` / `"MBP1-traffic-s2c"`) are
* distinct from §6.6's pair-session traffic labels
* (`"MBP1-pair-traffic-c2s"` / `"MBP1-pair-traffic-s2c"`, salt
* `"MBP1/pair/v1"`) even though both key schedules ultimately derive from a
* shared secret — do not unify or reuse either family's labels.
*
* `mutualKey`, both MACs, and both traffic keys feed or gate session
* authentication and MUST NOT be logged at any level (§11).
*/
var MAC_CLIENT_LABEL = utf8("MBP1-R/c");
var MAC_SERVER_LABEL = utf8("MBP1-R/s");
var TRAFFIC_C2S_INFO = utf8("MBP1-traffic-c2s");
var TRAFFIC_S2C_INFO = utf8("MBP1-traffic-s2c");
var TRAFFIC_KEY_LENGTH = 32;
/**
* `RT = enc("MBP1/reconnect/v1") ‖ encU32BE(protocolVersion) ‖ enc(credentialId) ‖ enc(browser) ‖ enc(verifiedOrigin) ‖ enc(instanceId)` (§8).
*
* `browser`/`verifiedOrigin` MUST be the stored credential principal's
* values on the client side and the live connection's values on the server
* side (§8) — a mismatch desynchronizes the MAC by construction.
*/
function reconnectTranscript(a) {
	return concatBytes$2(enc("MBP1/reconnect/v1"), encU32BE(a.protocolVersion), enc(a.credentialId), enc(a.browser), enc(a.verifiedOrigin), enc(a.instanceId));
}
/**
* `client = HMAC-SHA-256(mutualKey, "MBP1-R/c" ‖ S ‖ C ‖ RT)`,
* `server = HMAC-SHA-256(mutualKey, "MBP1-R/s" ‖ S ‖ C ‖ RT)` (§8).
*/
function reconnectMacs(mutualKey, S, C, RT) {
	return {
		client: hmac(sha256, mutualKey, concatBytes$2(MAC_CLIENT_LABEL, S, C, RT)),
		server: hmac(sha256, mutualKey, concatBytes$2(MAC_SERVER_LABEL, S, C, RT))
	};
}
/**
* `c2s = HKDF-SHA-256(ikm=mutualKey, salt=S‖C, info="MBP1-traffic-c2s", L=32)`,
* `s2c` likewise with `"MBP1-traffic-s2c"` (§8).
*/
function reconnectTrafficKeys(mutualKey, S, C) {
	const salt = concatBytes$2(S, C);
	return {
		c2s: hkdf(sha256, mutualKey, salt, TRAFFIC_C2S_INFO, TRAFFIC_KEY_LENGTH),
		s2c: hkdf(sha256, mutualKey, salt, TRAFFIC_S2C_INFO, TRAFFIC_KEY_LENGTH)
	};
}
//#endregion
//#region src/background/mbp1/reconnect-flow.ts
/**
* MBP1 reconnect state machine (bridge-pairing-protocol.md §8, §6.7, §12).
*
* The code path a browser walks on every restart once it already holds a
* committed credential: a short challenge-response on `/v1` that mutually
* authenticates both sides against the stored `mutualKey`, with no code entry
* and no user interaction.
*
* ```
* open /v1 (no query credentials) -> reconnectChallenge { S }
*   -> reconnectResponse { credentialId, C, mac: client } -> reconnectAccept { mac }
*                                                              |
*                     verify mac === server, constant-time, BEFORE anything else
*                                                              |
*                              traffic keys -> EnvelopeCodec (role 'client')
*                                                              |
*                    finalizeAndPrune -> clear pins -> pin
* ```
*
* ## The one rule that makes this endpoint safe against an impostor
*
* §8 requires the client to send **no application data** — not even MDXP
* `motrix/initialize` — until `reconnectAccept.mac` has been verified against
* the locally computed `server` MAC, in constant time. A listener that is not
* the real Motrix (something else bound to the port, or a stale process) would
* otherwise learn whatever the first application frame reveals for free. That
* verification happens before a single byte of §6.7's post-auth transaction is
* touched, and before the caller ever sees the returned `EnvelopeCodec`.
*
* ## Two failure modes that look identical on the wire and need opposite handling
*
* The server answers an unknown `credentialId` and a bad client MAC with the
* **same** `pairError {code:"authFailed"}`, deliberately, so the surface is
* never a credential-ID oracle (§8, §11). That frame proves nothing about the
* endpoint — it is pre-channel and any listener can forge it — so §12 forbids
* deleting the credential on it, and the pin is left alone too: the endpoint
* answered correctly, so it is still worth trying again with a different
* credential.
*
* A `reconnectAccept` whose `mac` fails to verify is ambiguous, not proof of
* an impostor: `RT` binds `credentialId`, `browser`, `verifiedOrigin`, AND
* `instanceId`, and the orchestrator may supply `instanceId` from an
* untrusted `/discovery` hint when no pin exists yet for this credential —
* so a wrong hint against the *genuine* Motrix produces the identical
* mismatch as a real "not my Motrix" impostor. Either way the
* credential was never disproved — only this pin's claim about where it
* lives was — so the credential is kept and only the **pin** is cleared: a
* later attempt sweeps for the real instance instead of reusing an unproven
* one. See `serverMacMismatch`'s own doc comment for why clearing is correct
* under both readings.
*
* `ReconnectFlowError.reason` is how the caller (the connection orchestrator)
* tells these apart; see the doc comment on each `ReconnectFailureReason` for the
* disposition it implies.
*
* ## A third case the server never sends a frame for
*
* §8's per-origin and global reconnect throttle, and the pre-authentication
* table's own capacity limit, are both enforced by rejecting the WebSocket
* *upgrade* itself (or closing immediately after it, before a single frame is
* sent) — there is no `pairError` for either, because no pre-auth session
* object exists yet to send one from. The WebSocket API does not expose
* handshake status codes to script, so this side cannot tell "the upgrade was
* throttled" from "nothing is listening on this port" or "the process is
* gone" — all three look like `channelUnavailable` here. That is why walking
* to the next stored credential on a `channelUnavailable` is actively harmful
* rather than merely useless: every attempt (regardless of which credential it
* carries) counts against the same per-origin counter, so retrying only makes
* a real throttle worse while learning nothing. See the reason's own doc
* comment for the exact caller obligation.
*
* ## Logging
*
* Nothing here logs at any level (§11). `mutualKey`, `S`, `C`, both
* reconnect MACs, and both derived traffic keys are all in scope in this
* module and must never appear in a thrown message — the messages below name
* a step, never a value.
*/
/**
* §8: the challenge-response on `/v1` must complete within 10 s of the
* upgrade. This is the number Line A's spec designs against — the server's
* own session times out on the same 10 s internally, and its 15 s
* pre-authentication backstop exists only so that *server-side* 10 s timeout
* fires first and the peer receives a uniform `pairError{authFailed}` rather
* than a bare socket close. That is a statement about what Line A sends when
* its own budget runs out, not a guarantee about what this client observes:
* `FrameChannel.receiveText` cannot distinguish a timeout from a close (see
* `channelUnavailable`'s doc comment), so a real 10 s stall on this side is
* far more likely to surface as `channelUnavailable`/`channelClosed` than as
* `deadlineExceeded` — see that reason's own doc comment for what it actually
* detects. Budgeting against 15 s would still blow the real deadline, so this
* stays 10 s regardless.
*/
var RECONNECT_DEADLINE_MS = 1e4;
/** §8: the client-generated nonce `C` is 32 CSPRNG bytes. */
var C_BYTES = 32;
/**
* A reconnect failure. Modelled on `PairingFlowError`: `reason` is what the
* caller switches on, and `pairErrorCode` — present only when the failure
* came from an actual `pairError` frame — is carried for display/diagnostics
* only and never drives any decision here.
*/
var ReconnectFlowError = class extends Error {
	reason;
	pairErrorCode;
	constructor(reason, message, details = {}) {
		super(message);
		this.name = "ReconnectFlowError";
		this.reason = reason;
		this.pairErrorCode = details.pairErrorCode ?? null;
	}
};
var ReconnectFlow = class {
	deps;
	now;
	constructor(deps) {
		this.deps = {
			...deps,
			creds: resolveCredentialLifecycleStore(deps.creds)
		};
		this.now = deps.now ?? Date.now;
	}
	async run(args) {
		this.assertAsciiField(args.credential.credentialId, "credentialId");
		this.assertAsciiField(args.principal.browser, "browser");
		this.assertAsciiField(args.principal.verifiedOrigin, "verifiedOrigin");
		this.assertAsciiField(args.instanceId, "instanceId");
		try {
			return await this.session(args);
		} catch (error) {
			this.deps.channel.close();
			throw error instanceof ReconnectFlowError ? error : this.wrapUnknownError(error);
		}
	}
	async session(args) {
		const { credential, discovery, principal, instanceId } = args;
		await this.openChannel(args.remoteV1Url ?? reconnectUrl(discovery.wsPort));
		this.ensureCurrent();
		const deadline = this.now() + RECONNECT_DEADLINE_MS;
		const challenge = await this.receiveChallenge(deadline);
		const S = b64uDecode(challenge.S);
		const C = this.deps.random?.(C_BYTES) ?? randomBytes$1(C_BYTES);
		let mutualKey;
		try {
			mutualKey = b64uDecode(credential.mutualKey);
		} catch {
			throw new ReconnectFlowError("internalError", "stored credential mutualKey is not valid base64url");
		}
		const RT = reconnectTranscript({
			protocolVersion: 1,
			credentialId: credential.credentialId,
			browser: principal.browser,
			verifiedOrigin: principal.verifiedOrigin,
			instanceId
		});
		const macs = reconnectMacs(mutualKey, S, C, RT);
		let responseFrame;
		try {
			responseFrame = buildReconnectResponse({
				credentialId: credential.credentialId,
				C: b64uEncode(C),
				mac: b64uEncode(macs.client)
			});
		} catch (error) {
			throw this.toFlowError(error);
		}
		await this.deps.channel.sendText(responseFrame);
		this.ensureCurrent();
		const accept = await this.receiveAccept(deadline);
		if (!timingSafeEqualBytes(b64uDecode(accept.mac), macs.server)) {
			if (args.remoteV1Url === void 0) await this.deps.pins.clear(credential.credentialId);
			throw new ReconnectFlowError("serverMacMismatch", "reconnectAccept.mac did not verify against the mutual key");
		}
		const traffic = reconnectTrafficKeys(mutualKey, S, C);
		const envelope = await EnvelopeCodec.create(traffic.c2s, traffic.s2c, "client");
		this.ensureCurrent();
		await this.deps.creds.finalizeAndPrune(credential.credentialId, principal, instanceId, async (staleIds) => {
			if (args.remoteV1Url !== void 0) return;
			for (const staleId of staleIds) await this.deps.pins.clear(staleId);
		});
		this.ensureCurrent();
		if (args.remoteV1Url === void 0) await this.deps.pins.commit(credential.credentialId, {
			port: discovery.wsPort,
			instanceId
		});
		this.ensureCurrent();
		return { envelope };
	}
	async openChannel(url) {
		try {
			await this.deps.channel.open(url);
		} catch {
			throw new ReconnectFlowError("channelUnavailable", "the /v1 upgrade did not complete");
		}
	}
	async receiveChallenge(deadline) {
		const frame = await this.receiveFrame(deadline, "channelUnavailable");
		if (frame.type === "pairError") throw this.pairErrorToFlowError(frame);
		if (frame.type !== "reconnectChallenge") throw new ReconnectFlowError("protocolViolation", `expected reconnectChallenge but the peer sent ${frame.type}`);
		this.assertProtocolVersionOrThrow(frame.protocolVersion);
		return frame;
	}
	async receiveAccept(deadline) {
		const frame = await this.receiveFrame(deadline, "channelClosed");
		if (frame.type === "pairError") throw this.pairErrorToFlowError(frame);
		if (frame.type !== "reconnectAccept") throw new ReconnectFlowError("protocolViolation", `expected reconnectAccept but the peer sent ${frame.type}`);
		return frame;
	}
	async receiveFrame(deadline, closeReason) {
		const timeoutMs = this.budget(deadline);
		let raw;
		try {
			raw = await this.deps.channel.receiveText(timeoutMs);
		} catch {
			throw new ReconnectFlowError(closeReason, closeReason === "channelUnavailable" ? "no frame arrived — either the channel closed or the peer never spoke within the budget" : "no further frame arrived after the peer had already sent one — either a close or a stall");
		}
		this.ensureCurrent();
		try {
			return parseTextFrame(raw);
		} catch (error) {
			throw this.toFlowError(error);
		}
	}
	budget(deadline) {
		const remaining = deadline - this.now();
		if (remaining <= 0) throw new ReconnectFlowError("deadlineExceeded", "the §8 challenge-response did not complete within 10 s of the upgrade");
		return remaining;
	}
	pairErrorToFlowError(frame) {
		if (frame.code === "authFailed") return new ReconnectFlowError("authFailed", "the peer rejected this credentialId or client MAC", { pairErrorCode: frame.code });
		if (frame.code === "unsupportedVersion") return new ReconnectFlowError("unsupportedVersion", "the peer rejected this protocol version", { pairErrorCode: frame.code });
		return new ReconnectFlowError("protocolViolation", `the peer refused reconnect with ${frame.code}`, { pairErrorCode: frame.code });
	}
	assertProtocolVersionOrThrow(protocolVersion) {
		try {
			assertProtocolVersion(protocolVersion);
		} catch (error) {
			throw this.toFlowError(error);
		}
	}
	/** §11: keeps `unsupportedVersion` distinct from a generic `protocolViolation`. */
	toFlowError(error) {
		if (!(error instanceof FrameError)) return error;
		if (error.kind === "unsupportedVersion") return new ReconnectFlowError("unsupportedVersion", error.message);
		return new ReconnectFlowError("protocolViolation", error.message);
	}
	assertAsciiField(value, field) {
		try {
			assertAscii(value, field);
		} catch {
			throw new ReconnectFlowError("protocolViolation", `${field} is not ASCII and cannot be fed to enc() for the §8 transcript`);
		}
	}
	/**
	* Wraps any error this flow did not itself classify — a storage rejection
	* (quota, MV3 service-worker teardown), `CredentialStore` throwing because
	* a concurrent attempt's prune already removed this credential between the
	* orchestrator's read and this write, or anything else unmodelled. A
	* caller switching on `error.reason` seeing `undefined` is a worse outcome
	* than a coarse `internalError`.
	*
	* This forwards `error.message` verbatim rather than a fixed generic
	* string, because "which step failed" is the whole diagnosis for exactly
	* the errors that reach here — a durable-write rejection or a corrupted
	* store. That is only safe because of a constraint on this flow's own
	* dependencies, not a property of this function: **nothing this flow
	* depends on may interpolate a value into a thrown message.** The two
	* current sources honour it — `canonical.ts`'s decoders name only a
	* length, a single offending character, or a fixed string, never
	* key material, and `credential-store.ts`'s own module doc states its
	* thrown messages never interpolate a `credentialId`. If a future
	* dependency's error can carry a secret or other sensitive value, this
	* function needs a message allowlist before that dependency is wired in
	* here, not after.
	*/
	wrapUnknownError(error) {
		return new ReconnectFlowError("internalError", error instanceof Error ? error.message : "an unclassified error occurred");
	}
	ensureCurrent() {
		if (!this.deps.isCurrent()) throw new ReconnectFlowError("superseded", "a newer connection attempt superseded this reconnect");
	}
};
//#endregion
//#region src/background/mbp1/remote-discovery-service.ts
var SUPPORTED_DISCOVERY_API_VERSION = 1;
var SUPPORTED_MBP_VERSION = 1;
var SUPPORTED_MDXP_VERSION = "1.0";
var DEFAULT_TIMEOUT_MS$2 = 5e3;
var REMOTE_NONCE_MAX_CAPABILITY_TTL_MS = 6e4;
var MAX_INSTANCE_ID_LENGTH = 128;
var MAX_APP_VERSION_LENGTH = 64;
var MAX_PROTOCOL_NAME_LENGTH = 32;
var MAX_VERSION_LIST_LENGTH = 16;
var MAX_PROTOCOL_VERSION = 65535;
var MAX_JSON_DEPTH = 32;
var MAX_RETRY_AFTER_SECONDS = 86400;
/** MBP1 v1 §4.2 fixes nonce lifetime at exactly 60 seconds. */
var NONCE_TTL_SECONDS = 60;
var ROUTE_VALIDATION_NONCE = "AQIDBAUGBwgJCgsMDQ4PEA";
var DISCOVERY_TOP_LEVEL_KEYS = [
	"app",
	"apiVersion",
	"instanceId",
	"appVersion",
	"runtime",
	"extensionPairing",
	"applicationProtocols"
];
var EXTENSION_PAIRING_KEYS = ["protocol", "versions"];
var APPLICATION_PROTOCOL_KEYS = ["mdxp"];
var NONCE_RESPONSE_KEYS = ["nonce", "ttlSeconds"];
var DANGEROUS_JSON_KEYS = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
var REMOTE_NONCE_CAPABILITY_BRAND = Symbol("motrix.mbp1.remote-nonce-capability");
var remoteNonceCapabilities = /* @__PURE__ */ new WeakMap();
var BodyTooLargeError = class extends Error {};
var MalformedDocumentError = class extends Error {};
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasExactKeys(value, allowed) {
	const keys = Object.keys(value);
	return keys.length === allowed.length && keys.every((key) => allowed.includes(key));
}
function isPrintableAscii$1(value, allowSpace) {
	const minimum = allowSpace ? 32 : 33;
	for (let index = 0; index < value.length; index += 1) {
		const code = value.charCodeAt(index);
		if (code < minimum || code > 126) return false;
	}
	return true;
}
function readNumericVersions(value) {
	if (!Array.isArray(value) || value.length === 0 || value.length > MAX_VERSION_LIST_LENGTH) return null;
	const result = [];
	const seen = /* @__PURE__ */ new Set();
	for (const entry of value) {
		if (typeof entry !== "number" || !Number.isSafeInteger(entry) || entry < 0 || entry > MAX_PROTOCOL_VERSION || seen.has(entry)) return null;
		seen.add(entry);
		result.push(entry);
	}
	return Object.freeze(result);
}
function parseMdxpVersion(value) {
	const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(value);
	if (match === null) return null;
	const major = Number(match[1]);
	const minor = Number(match[2]);
	if (!Number.isSafeInteger(major) || !Number.isSafeInteger(minor) || major > MAX_PROTOCOL_VERSION || minor > MAX_PROTOCOL_VERSION) return null;
	return [major, minor];
}
function readMdxpVersions(value) {
	if (!Array.isArray(value) || value.length === 0 || value.length > MAX_VERSION_LIST_LENGTH) return null;
	const result = [];
	const seen = /* @__PURE__ */ new Set();
	for (const entry of value) {
		if (typeof entry !== "string" || parseMdxpVersion(entry) === null || seen.has(entry)) return null;
		seen.add(entry);
		result.push(entry);
	}
	return Object.freeze(result);
}
/**
* Structural validation is intentionally stricter than `JSON.parse` alone:
* unknown routing/token fields, duplicate capability entries, and data that
* could inject control characters into UI/logs are rejected as malformed.
*/
function readDiscoveryDocument(value) {
	if (!isRecord$1(value) || !hasExactKeys(value, DISCOVERY_TOP_LEVEL_KEYS)) return null;
	if (value.app !== "motrix-bridge") return null;
	if (typeof value.apiVersion !== "number" || !Number.isSafeInteger(value.apiVersion) || value.apiVersion < 0 || value.apiVersion > MAX_PROTOCOL_VERSION) return null;
	if (typeof value.instanceId !== "string" || value.instanceId.length === 0 || value.instanceId.length > MAX_INSTANCE_ID_LENGTH || !isPrintableAscii$1(value.instanceId, false)) return null;
	if (typeof value.appVersion !== "string" || value.appVersion.length === 0 || value.appVersion.length > MAX_APP_VERSION_LENGTH || value.appVersion.trim() !== value.appVersion || !isPrintableAscii$1(value.appVersion, true)) return null;
	if (value.runtime !== "electron" && value.runtime !== "server") return null;
	const pairing = value.extensionPairing;
	if (!isRecord$1(pairing) || !hasExactKeys(pairing, EXTENSION_PAIRING_KEYS)) return null;
	if (typeof pairing.protocol !== "string" || pairing.protocol.length === 0 || pairing.protocol.length > MAX_PROTOCOL_NAME_LENGTH || !isPrintableAscii$1(pairing.protocol, false)) return null;
	const pairingVersions = readNumericVersions(pairing.versions);
	if (pairingVersions === null) return null;
	const protocols = value.applicationProtocols;
	if (!isRecord$1(protocols) || !hasExactKeys(protocols, APPLICATION_PROTOCOL_KEYS)) return null;
	const mdxpVersions = readMdxpVersions(protocols.mdxp);
	if (mdxpVersions === null) return null;
	return Object.freeze({
		app: "motrix-bridge",
		apiVersion: value.apiVersion,
		instanceId: value.instanceId,
		appVersion: value.appVersion,
		runtime: value.runtime,
		extensionPairing: Object.freeze({
			protocol: pairing.protocol,
			versions: pairingVersions
		}),
		applicationProtocols: Object.freeze({ mdxp: mdxpVersions })
	});
}
/**
* `JSON.parse` silently keeps only the last duplicate object member. That is
* unsuitable for a pre-authentication protocol document: a proxy, log parser,
* and this client could otherwise disagree about which version or route was
* advertised. Scan the JSON grammar first and reject duplicate decoded keys.
*/
var JsonObjectKeyScanner = class {
	text;
	offset = 0;
	constructor(text) {
		this.text = text;
	}
	scan() {
		this.skipWhitespace();
		this.scanValue(0);
		this.skipWhitespace();
		if (this.offset !== this.text.length) throw new MalformedDocumentError();
	}
	scanValue(depth) {
		if (depth > MAX_JSON_DEPTH) throw new MalformedDocumentError();
		const char = this.text[this.offset];
		if (char === "{") {
			this.scanObject(depth + 1);
			return;
		}
		if (char === "[") {
			this.scanArray(depth + 1);
			return;
		}
		if (char === "\"") {
			this.scanString();
			return;
		}
		if (char === "t") {
			this.scanLiteral("true");
			return;
		}
		if (char === "f") {
			this.scanLiteral("false");
			return;
		}
		if (char === "n") {
			this.scanLiteral("null");
			return;
		}
		this.scanNumber();
	}
	scanObject(depth) {
		this.offset += 1;
		this.skipWhitespace();
		if (this.consume("}")) return;
		const keys = /* @__PURE__ */ new Set();
		for (;;) {
			if (this.text[this.offset] !== "\"") throw new MalformedDocumentError();
			const key = this.scanString();
			if (keys.has(key) || DANGEROUS_JSON_KEYS.has(key)) throw new MalformedDocumentError();
			keys.add(key);
			this.skipWhitespace();
			if (!this.consume(":")) throw new MalformedDocumentError();
			this.skipWhitespace();
			this.scanValue(depth);
			this.skipWhitespace();
			if (this.consume("}")) return;
			if (!this.consume(",")) throw new MalformedDocumentError();
			this.skipWhitespace();
		}
	}
	scanArray(depth) {
		this.offset += 1;
		this.skipWhitespace();
		if (this.consume("]")) return;
		for (;;) {
			this.scanValue(depth);
			this.skipWhitespace();
			if (this.consume("]")) return;
			if (!this.consume(",")) throw new MalformedDocumentError();
			this.skipWhitespace();
		}
	}
	scanString() {
		const start = this.offset;
		this.offset += 1;
		while (this.offset < this.text.length) {
			const char = this.text[this.offset];
			if (char === "\"") {
				this.offset += 1;
				try {
					return JSON.parse(this.text.slice(start, this.offset));
				} catch {
					throw new MalformedDocumentError();
				}
			}
			if (char === "\\") {
				this.offset += 1;
				const escapeCode = this.text[this.offset];
				if (escapeCode === "u") {
					const hex = this.text.slice(this.offset + 1, this.offset + 5);
					if (!/^[0-9a-fA-F]{4}$/.test(hex)) throw new MalformedDocumentError();
					this.offset += 5;
					continue;
				}
				if (escapeCode !== "\"" && escapeCode !== "\\" && escapeCode !== "/" && escapeCode !== "b" && escapeCode !== "f" && escapeCode !== "n" && escapeCode !== "r" && escapeCode !== "t") throw new MalformedDocumentError();
				this.offset += 1;
				continue;
			}
			if (char === void 0 || char.charCodeAt(0) <= 31) throw new MalformedDocumentError();
			this.offset += 1;
		}
		throw new MalformedDocumentError();
	}
	scanLiteral(literal) {
		if (this.text.slice(this.offset, this.offset + literal.length) !== literal) throw new MalformedDocumentError();
		this.offset += literal.length;
	}
	scanNumber() {
		const start = this.offset;
		if (this.text[this.offset] === "-") this.offset += 1;
		if (this.text[this.offset] === "0") this.offset += 1;
		else {
			if (!this.isDigitOneToNine(this.text[this.offset])) throw new MalformedDocumentError();
			this.offset += 1;
			while (this.isDigit(this.text[this.offset])) this.offset += 1;
		}
		if (this.text[this.offset] === ".") {
			this.offset += 1;
			if (!this.isDigit(this.text[this.offset])) throw new MalformedDocumentError();
			while (this.isDigit(this.text[this.offset])) this.offset += 1;
		}
		if (this.text[this.offset] === "e" || this.text[this.offset] === "E") {
			this.offset += 1;
			if (this.text[this.offset] === "+" || this.text[this.offset] === "-") this.offset += 1;
			if (!this.isDigit(this.text[this.offset])) throw new MalformedDocumentError();
			while (this.isDigit(this.text[this.offset])) this.offset += 1;
		}
		if (this.offset === start) throw new MalformedDocumentError();
	}
	isDigit(value) {
		return value !== void 0 && value >= "0" && value <= "9";
	}
	isDigitOneToNine(value) {
		return value !== void 0 && value >= "1" && value <= "9";
	}
	skipWhitespace() {
		while (this.text[this.offset] === " " || this.text[this.offset] === "\n" || this.text[this.offset] === "\r" || this.text[this.offset] === "	") this.offset += 1;
	}
	consume(expected) {
		if (this.text[this.offset] !== expected) return false;
		this.offset += 1;
		return true;
	}
};
function parseStrictJson(text) {
	new JsonObjectKeyScanner(text).scan();
	try {
		return JSON.parse(text);
	} catch {
		throw new MalformedDocumentError();
	}
}
function compareMdxpVersions(a, b) {
	const left = parseMdxpVersion(a);
	const right = parseMdxpVersion(b);
	if (left === null || right === null) return 0;
	return left[0] === right[0] ? left[1] - right[1] : left[0] - right[0];
}
function classifyDocument(authority, document) {
	if (document.runtime !== "server") return unavailable("unexpectedRuntimeHint");
	const incompatibilities = [];
	const onlyNewer = [];
	if (document.apiVersion !== SUPPORTED_DISCOVERY_API_VERSION) {
		incompatibilities.push("apiVersion");
		onlyNewer.push(document.apiVersion > SUPPORTED_DISCOVERY_API_VERSION);
	}
	const pairing = document.extensionPairing;
	if (pairing.protocol !== "mbp1" || !pairing.versions.includes(SUPPORTED_MBP_VERSION)) {
		incompatibilities.push("extensionPairing");
		onlyNewer.push(pairing.protocol === "mbp1" && pairing.versions.every((version) => version > SUPPORTED_MBP_VERSION));
	}
	const mdxpVersions = document.applicationProtocols.mdxp;
	if (!mdxpVersions.includes(SUPPORTED_MDXP_VERSION)) {
		incompatibilities.push("mdxp");
		onlyNewer.push(mdxpVersions.every((version) => compareMdxpVersions(version, SUPPORTED_MDXP_VERSION) > 0));
	}
	if (incompatibilities.length === 0) return Object.freeze({
		[REMOTE_NONCE_CAPABILITY_BRAND]: true,
		status: "compatible",
		authority,
		untrustedDocument: document
	});
	return Object.freeze({
		status: "incompatible",
		reason: onlyNewer.every(Boolean) ? "extensionUpgradeRequired" : "backendUpgradeRequired",
		incompatibilities: Object.freeze(incompatibilities),
		authority,
		untrustedDocument: document
	});
}
function unavailable(detail, extra = {}) {
	return Object.freeze({
		status: "unavailable",
		reason: "remoteDiscoveryUnavailable",
		detail,
		...extra
	});
}
function nonceUnavailable(detail, extra = {}) {
	return Object.freeze({
		status: "unavailable",
		reason: detail === "rateLimited" ? "pairingRateLimited" : "remotePairingUnavailable",
		detail,
		...extra
	});
}
/**
* The single MBP1 v1 nonce DTO shared with Motrix's NonceService. The Server
* lifetime is exactly 60 seconds. Rejecting any other value prevents a
* superficially similar, non-MBP1 endpoint from being classified as ready.
*/
function readNonceResponse(value) {
	if (!isRecord$1(value) || !hasExactKeys(value, NONCE_RESPONSE_KEYS)) return null;
	if (!isCanonicalMbp1PairNonce(value.nonce)) return null;
	if (typeof value.ttlSeconds !== "number" || !Number.isSafeInteger(value.ttlSeconds) || value.ttlSeconds !== NONCE_TTL_SECONDS) return null;
	return Object.freeze({
		status: "ready",
		nonce: value.nonce,
		ttlSeconds: value.ttlSeconds
	});
}
function readRetryAfterSeconds(value) {
	if (value === null || !/^(0|[1-9]\d{0,5})$/.test(value)) return void 0;
	const seconds = Number(value);
	return seconds <= MAX_RETRY_AFTER_SECONDS ? seconds : void 0;
}
/** Process-local monotonic time keeps a wall-clock adjustment from extending
* a nonce capability. A service-worker restart drops the WeakMap entirely. */
function monotonicNow() {
	return globalThis.performance.now();
}
function createRequestDeadline(timeoutMs, callerSignal) {
	const controller = new AbortController();
	let source = null;
	const abort = (next) => {
		if (controller.signal.aborted) return;
		source = next;
		controller.abort();
	};
	const onCallerAbort = () => abort("caller");
	if (callerSignal?.aborted) abort("caller");
	else callerSignal?.addEventListener("abort", onCallerAbort, { once: true });
	const timeout = controller.signal.aborted ? void 0 : setTimeout(() => abort("timeout"), timeoutMs);
	return {
		signal: controller.signal,
		source: () => source,
		dispose() {
			if (timeout !== void 0) clearTimeout(timeout);
			callerSignal?.removeEventListener("abort", onCallerAbort);
			if (!controller.signal.aborted) controller.abort();
		}
	};
}
async function readWithAbort(promise, signal) {
	if (signal.aborted) throw new DOMException("aborted", "AbortError");
	return new Promise((resolve, reject) => {
		const onAbort = () => reject(new DOMException("aborted", "AbortError"));
		signal.addEventListener("abort", onAbort, { once: true });
		promise.then(resolve, reject).finally(() => {
			signal.removeEventListener("abort", onAbort);
		});
	});
}
/**
* Race the fetch headers promise against our own deadline instead of assuming
* an injected/browser fetch implementation settles when its signal aborts.
* If a non-conforming fetch resolves later, eagerly cancel its body so the
* already-terminal adapter call does not leave an unobserved response alive.
*/
function fetchWithAbort(promise, signal) {
	if (signal.aborted) {
		promise.then(cancelBody, () => void 0);
		return Promise.reject(new DOMException("aborted", "AbortError"));
	}
	return new Promise((resolve, reject) => {
		let terminal = false;
		const onAbort = () => {
			if (terminal) return;
			terminal = true;
			signal.removeEventListener("abort", onAbort);
			reject(new DOMException("aborted", "AbortError"));
		};
		signal.addEventListener("abort", onAbort, { once: true });
		promise.then((response) => {
			signal.removeEventListener("abort", onAbort);
			if (terminal || signal.aborted) {
				cancelBody(response);
				return;
			}
			terminal = true;
			resolve(response);
		}, (error) => {
			signal.removeEventListener("abort", onAbort);
			if (terminal) return;
			terminal = true;
			reject(error);
		});
	});
}
function cancelBody(response) {
	response.body?.cancel().catch(() => void 0);
}
async function readBoundedBody(response, maxBytes, signal) {
	const reader = response.body?.getReader();
	if (reader === void 0) return "";
	const chunks = [];
	let length = 0;
	try {
		for (;;) {
			const { done, value } = await readWithAbort(reader.read(), signal);
			if (done) break;
			length += value.byteLength;
			if (length > maxBytes) throw new BodyTooLargeError();
			chunks.push(value);
		}
	} catch (error) {
		reader.cancel().catch(() => void 0);
		throw error;
	} finally {
		try {
			reader.releaseLock();
		} catch {}
	}
	const bytes = new Uint8Array(length);
	let offset = 0;
	for (const chunk of chunks) {
		bytes.set(chunk, offset);
		offset += chunk.byteLength;
	}
	try {
		return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
	} catch {
		throw new MalformedDocumentError();
	}
}
function isJsonContentType(value) {
	if (value === null) return false;
	return /^application\/json(?:\s*;\s*charset=(?:utf-8|"utf-8"))?$/i.test(value.trim());
}
function validateRoute(route) {
	remotePairUrl(route, ROUTE_VALIDATION_NONCE);
	const canonical = deriveRemoteBridgeRoute(route.authority);
	if (route.discoveryUrl !== canonical.discoveryUrl || route.nonceUrl !== canonical.nonceUrl || route.v1Url !== canonical.v1Url || remotePairUrl(route, ROUTE_VALIDATION_NONCE) !== remotePairUrl(canonical, ROUTE_VALIDATION_NONCE)) throw new Error("BridgeRoute is not canonical for its BackendAuthority");
	return route.authority;
}
/**
* Fetch one configured remote authority exactly once. All transport and parse
* failures are data, while forged capabilities remain programmer errors and
* reject before any network request.
*/
var RemoteDiscoveryService = class {
	fetchImpl;
	timeoutMs;
	maxBodyBytes;
	nonceMaxBodyBytes;
	nonceCapabilityTtlMs;
	nonceIssuer = Object.freeze({});
	constructor(options = {}) {
		const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS$2;
		const maxBodyBytes = options.maxBodyBytes ?? 65536;
		const nonceMaxBodyBytes = options.nonceMaxBodyBytes ?? 4096;
		const nonceCapabilityTtlMs = options.nonceCapabilityTtlMs ?? 3e4;
		if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 1e4) throw new Error("remote discovery timeout is outside the policy bound");
		if (!Number.isInteger(maxBodyBytes) || maxBodyBytes < 1 || maxBodyBytes > 65536) throw new Error("remote discovery body cap is outside the policy bound");
		if (!Number.isInteger(nonceMaxBodyBytes) || nonceMaxBodyBytes < 1 || nonceMaxBodyBytes > 4096) throw new Error("remote nonce body cap is outside the policy bound");
		if (!Number.isInteger(nonceCapabilityTtlMs) || nonceCapabilityTtlMs < 1 || nonceCapabilityTtlMs > REMOTE_NONCE_MAX_CAPABILITY_TTL_MS) throw new Error("remote nonce capability TTL is outside the policy bound");
		this.fetchImpl = options.fetchImpl ?? globalThis.fetch.bind(globalThis);
		this.timeoutMs = timeoutMs;
		this.maxBodyBytes = maxBodyBytes;
		this.nonceMaxBodyBytes = nonceMaxBodyBytes;
		this.nonceCapabilityTtlMs = nonceCapabilityTtlMs;
	}
	async discover(route, options = {}) {
		const authority = validateRoute(route);
		const deadline = createRequestDeadline(this.timeoutMs, options.signal);
		if (deadline.signal.aborted) {
			deadline.dispose();
			return unavailable("requestAborted");
		}
		try {
			let response;
			try {
				response = await fetchWithAbort(this.fetchImpl(route.discoveryUrl, {
					method: "GET",
					credentials: "omit",
					cache: "no-store",
					redirect: "error",
					referrerPolicy: "no-referrer",
					signal: deadline.signal
				}), deadline.signal);
			} catch {
				if (deadline.source() === "caller") return unavailable("requestAborted");
				if (deadline.source() === "timeout") return unavailable("requestTimedOut");
				return unavailable("networkError");
			}
			if (deadline.signal.aborted) {
				cancelBody(response);
				return unavailable(deadline.source() === "timeout" ? "requestTimedOut" : "requestAborted");
			}
			if (response.type === "opaqueredirect" || response.redirected) {
				cancelBody(response);
				return unavailable("redirectRejected");
			}
			if (response.url !== route.discoveryUrl) {
				cancelBody(response);
				return unavailable("unexpectedResponseUrl");
			}
			if (response.status >= 300 && response.status < 400) {
				cancelBody(response);
				return unavailable("redirectRejected", { httpStatus: response.status });
			}
			if (response.status === 429) {
				cancelBody(response);
				const retryAfterSeconds = readRetryAfterSeconds(response.headers.get("retry-after"));
				return unavailable("rateLimited", {
					httpStatus: response.status,
					...retryAfterSeconds === void 0 ? {} : { retryAfterSeconds }
				});
			}
			if (response.status !== 200) {
				cancelBody(response);
				return unavailable("httpStatus", { httpStatus: response.status });
			}
			if (!isJsonContentType(response.headers.get("content-type"))) {
				cancelBody(response);
				return unavailable("invalidContentType");
			}
			let text;
			try {
				text = await readBoundedBody(response, this.maxBodyBytes, deadline.signal);
			} catch (error) {
				if (deadline.source() === "caller") return unavailable("requestAborted");
				if (deadline.source() === "timeout") return unavailable("requestTimedOut");
				if (error instanceof BodyTooLargeError) return unavailable("bodyTooLarge");
				if (error instanceof MalformedDocumentError) return unavailable("malformedDocument");
				return unavailable("responseReadFailed");
			}
			let document;
			try {
				document = readDiscoveryDocument(parseStrictJson(text));
			} catch {
				document = null;
			}
			if (document === null) return unavailable("malformedDocument");
			const result = classifyDocument(authority, document);
			if (result.status === "compatible") remoteNonceCapabilities.set(result, {
				issuer: this.nonceIssuer,
				route,
				expiresAt: monotonicNow() + this.nonceCapabilityTtlMs,
				consumed: false
			});
			return result;
		} finally {
			deadline.dispose();
		}
	}
	/**
	* Consume one compatible discovery result to issue one remote pairing nonce.
	*
	* The result identity is the capability: copies, JSON clones, and
	* incompatible/unavailable results are absent from the process-local
	* registry. A result also carries an opaque issuer identity, so another
	* service instance cannot use it. Issuer mismatch burns the capability, and
	* the valid issuer flips `consumed` synchronously before expiry and the first
	* await, so cross-instance misuse and concurrent calls both burn it without
	* a second POST. Every terminal attempt requires a new discovery.
	*/
	async requestNonce(discovery, options = {}) {
		if (typeof discovery !== "object" || discovery === null) return nonceUnavailable("invalidDiscoveryCapability");
		const capability = remoteNonceCapabilities.get(discovery);
		if (capability === void 0 || discovery[REMOTE_NONCE_CAPABILITY_BRAND] !== true) return nonceUnavailable("invalidDiscoveryCapability");
		if (capability.issuer !== this.nonceIssuer) {
			capability.consumed = true;
			return nonceUnavailable("invalidDiscoveryCapability");
		}
		if (capability.consumed) return nonceUnavailable("discoveryCapabilityConsumed");
		capability.consumed = true;
		if (monotonicNow() >= capability.expiresAt) return nonceUnavailable("discoveryCapabilityExpired");
		const deadline = createRequestDeadline(this.timeoutMs, options.signal);
		if (deadline.signal.aborted) {
			deadline.dispose();
			return nonceUnavailable("requestAborted");
		}
		const { route } = capability;
		try {
			let response;
			try {
				response = await fetchWithAbort(this.fetchImpl(route.nonceUrl, {
					method: "POST",
					headers: { "X-Motrix-Bridge": "1" },
					credentials: "omit",
					cache: "no-store",
					redirect: "error",
					referrerPolicy: "no-referrer",
					signal: deadline.signal
				}), deadline.signal);
			} catch {
				if (deadline.source() === "caller") return nonceUnavailable("requestAborted");
				if (deadline.source() === "timeout") return nonceUnavailable("requestTimedOut");
				return nonceUnavailable("networkError");
			}
			if (deadline.signal.aborted) {
				cancelBody(response);
				return nonceUnavailable(deadline.source() === "timeout" ? "requestTimedOut" : "requestAborted");
			}
			if (response.type === "opaqueredirect" || response.redirected) {
				cancelBody(response);
				return nonceUnavailable("redirectRejected");
			}
			if (response.url !== route.nonceUrl) {
				cancelBody(response);
				return nonceUnavailable("unexpectedResponseUrl");
			}
			if (response.status >= 300 && response.status < 400) {
				cancelBody(response);
				return nonceUnavailable("redirectRejected", { httpStatus: response.status });
			}
			if (response.status === 429) {
				cancelBody(response);
				const retryAfterSeconds = readRetryAfterSeconds(response.headers.get("retry-after"));
				return nonceUnavailable("rateLimited", {
					httpStatus: response.status,
					...retryAfterSeconds === void 0 ? {} : { retryAfterSeconds }
				});
			}
			if (response.status !== 200) {
				cancelBody(response);
				return nonceUnavailable("httpStatus", { httpStatus: response.status });
			}
			if (!isJsonContentType(response.headers.get("content-type"))) {
				cancelBody(response);
				return nonceUnavailable("invalidContentType");
			}
			let text;
			try {
				text = await readBoundedBody(response, this.nonceMaxBodyBytes, deadline.signal);
			} catch (error) {
				if (deadline.source() === "caller") return nonceUnavailable("requestAborted");
				if (deadline.source() === "timeout") return nonceUnavailable("requestTimedOut");
				if (error instanceof BodyTooLargeError) return nonceUnavailable("bodyTooLarge");
				if (error instanceof MalformedDocumentError) return nonceUnavailable("malformedNonceResponse");
				return nonceUnavailable("responseReadFailed");
			}
			let result;
			try {
				result = readNonceResponse(parseStrictJson(text));
			} catch {
				result = null;
			}
			return result ?? nonceUnavailable("malformedNonceResponse");
		} finally {
			deadline.dispose();
		}
	}
};
//#endregion
//#region src/background/mbp1/verified-origin.ts
/**
* MBP1 `verifiedOrigin` (bridge-pairing-protocol.md §6.4, §6.7).
*
* `verifiedOrigin` is a member of `Principal` and one of the four strings
* `buildAId` binds into the SPAKE2 transcript `A_id` (§6.4) — so it must equal,
* **byte for byte**, what the server derives on its side. Line A's
* `parseExtensionOrigin` returns `{browser, extensionId, origin}` where
* `origin` is the raw `Origin` request header, taken verbatim: not
* lowercased, no trailing-slash handling, no re-serialization. A divergence
* here does not fail loudly — `A_id`, `RT`, and every MAC just quietly differ
* from the server's, and both pairing and reconnect fail closed with no
* indication of why.
*
* The trap is one character wide: `browser.runtime.getURL('/')` (equivalently
* `getURL('')`) returns `chrome-extension://<id>/` **with** a trailing slash,
* but a WebSocket upgrade's `Origin` header never carries one — it is a
* scheme+host(+port) tuple by construction (RFC 6454), never a path. This
* derives the tuple directly from the parsed URL's `protocol`/`host` rather
* than reading `.origin`: per the WHATWG URL spec, `origin` for a
* *non-special* scheme (and `chrome-extension:`/`moz-extension:` are not
* special) is an opaque origin, serialized as the literal string `"null"` —
* real Chrome and Firefox both register their extension schemes internally
* and return the real tuple there, but relying on that browser-specific
* behavior means depending on a deviation from the very spec `URL` is
* nominally implementing, with no guard against a spec-conformant `"null"`
* slipping through. Building the tuple from `protocol`/`host` keeps `URL`
* doing the parsing (still rejects a malformed `getURL()` result) without
* that dependency. Do not derive this by string-concatenating a scheme onto
* `browser.runtime.id`, and do not normalize (lowercase, trim) what this
* returns — the server does not.
*
* **Unverified assumption, flagged rather than asserted:** this value is only
* correct if the browser actually sends an `Origin` header on a WebSocket
* opened from an extension background/service-worker context — Line A's
* `parseExtensionOrigin` refuses the upgrade outright when `Origin` is
* missing or unparseable. RFC 6455 §4.1 makes `Origin` a mandatory field of
* the client's opening handshake, which is a wire-protocol requirement browser
* vendors do not treat as extension-context-optional, but that is inference
* from the spec, not an observation made against a real Firefox build — this
* has not been exercised against a live Firefox extension background
* context. Confirming it empirically against a real browser belongs to this
* project's end-to-end test suite, not this unit-level module.
*/
/**
* A wrong `verifiedOrigin` is undiagnosable downstream by construction (see
* the module doc) — it has to fail here or nowhere. This is the shape every
* value this function can legitimately produce matches; anything else (most
* concretely, the literal string `"null"` an opaque-origin serialization
* would produce) means the derivation above is no longer valid for this
* runtime and must not be allowed to silently corrupt every MAC downstream.
*/
var VERIFIED_ORIGIN_SHAPE = /^(chrome|moz)-extension:\/\/[^/]+$/;
function computeVerifiedOrigin() {
	const root = new URL(browser.runtime.getURL("/"));
	const origin = `${root.protocol}//${root.host}`;
	if (!VERIFIED_ORIGIN_SHAPE.test(origin)) throw new Error(`computeVerifiedOrigin: unexpected shape "${origin}"`);
	return origin;
}
//#endregion
//#region src/background/NativeBootstrap.ts
/**
* Native Messaging bootstrap. Connects to the Motrix native host shim,
* which reads endpoint.json (or launches Motrix if needed) and reports
* back the local WebSocket port plus a one-shot pairing nonce. The NM
* channel exists only for this handoff — once we know port + nonce, we
* disconnect and use WebSocket for all subsequent traffic.
*
* Wire shape (local native-host contract), now one of two request shapes the host's
* `parse_host_request` accepts side by side (`packages/native-host/src/lib.rs`):
*
*   { action: 'start', allowLaunch }                                  (v1, legacy)
*   { action: 'bootstrap', protocolVersion: 1, bindingPub, allowLaunch } (§9.1)
*
* Both replies look like:
*   { action: 'requestPair', protocolVersion: <int>, port: <number>,
*     nonce: <string | null>, nmTicket?: <object> }
*
* The host serializes `protocolVersion` on *every* `requestPair` reply
* regardless of which request shape triggered it
* (`ResolveResult::request_pair`/`request_pair_with_ticket` in
* `packages/native-host/src/resolve.rs`), and omits `nmTicket` entirely
* rather than sending it `null` — a ticket is only ever minted for a
* `bootstrap` request whose caller identity and `endpoint.json` inputs are
* all trusted (§9.1/§9.2), so a `start` request never gets one.
*
* `nonce` is null if the host failed to fetch a fresh nonce from
* /nonce. Bootstrap still surfaces the port — the caller (ConnectionManager)
* decides whether to attempt /pair (needs a non-null nonce) or an
* authenticated MBP1 reconnect (uses a stored credential).
*/
/** Raw length of the §9.1 binding public key `bindingPub` must decode to. */
var BINDING_PUB_BYTES = 32;
var NativeBootstrapError = class extends Error {
	code;
	constructor(message, code) {
		super(message);
		this.name = "NativeBootstrapError";
		this.code = code;
	}
};
var DEFAULT_HOST_NAME = "app.motrix.bridge.takeover";
var DEFAULT_TIMEOUT_MS$1 = 2e4;
var MAX_NONCE_LENGTH = 512;
var NativeBootstrap = class {
	opts;
	constructor(opts = {}) {
		this.opts = opts;
	}
	async discover(opts = {}) {
		const hostName = this.opts.hostName ?? DEFAULT_HOST_NAME;
		const timeoutMs = this.opts.timeoutMs ?? DEFAULT_TIMEOUT_MS$1;
		const allowLaunch = opts.allowLaunch === true;
		if (opts.bindingPub !== void 0 && opts.bindingPub.length !== BINDING_PUB_BYTES) throw new NativeBootstrapError(`bindingPub must be exactly ${BINDING_PUB_BYTES} bytes, got ${opts.bindingPub.length}`, "invalid-binding-pub");
		if (!hasNativeMessagingSupport()) throw new NativeBootstrapError("Native Messaging is unavailable on this browser; configure a Motrix Server instead", "unsupported");
		log.info(`[NM] connectNative(${hostName}) allowLaunch=${allowLaunch}`);
		const port = browser.runtime.connectNative(hostName);
		return new Promise((resolve, reject) => {
			let settled = false;
			const settle = (action) => {
				if (settled) return;
				settled = true;
				clearTimeout(timer);
				try {
					port.disconnect();
				} catch {}
				action();
			};
			const timer = setTimeout(() => {
				settle(() => reject(new NativeBootstrapError("NM bootstrap timeout", "timeout")));
			}, timeoutMs);
			port.onMessage.addListener((rawMsg) => {
				const msg = rawMsg;
				log.info(`[NM] recv action=${msg.action ?? "none"} port=${typeof msg.port === "number" ? msg.port : "none"} error=${msg.error !== void 0 ? String(msg.error) : "none"}`);
				if (msg.error !== void 0) {
					settle(() => reject(new NativeBootstrapError(String(msg.error), `host-error:${String(msg.error)}`)));
					return;
				}
				const validPort = typeof msg.port === "number" && Number.isInteger(msg.port) && msg.port >= 1 && msg.port <= 65535;
				const validNonce = msg.nonce === void 0 || msg.nonce === null || typeof msg.nonce === "string" && msg.nonce.length > 0 && msg.nonce.length <= MAX_NONCE_LENGTH;
				const validProtocolVersion = typeof msg.protocolVersion === "number" && Number.isInteger(msg.protocolVersion) && msg.protocolVersion >= 0;
				const validNmTicket = msg.nmTicket === void 0 || msg.nmTicket === null || typeof msg.nmTicket === "object" && !Array.isArray(msg.nmTicket);
				if (msg.action === "requestPair" && validPort && validNonce && validProtocolVersion && validNmTicket) {
					const nonce = typeof msg.nonce === "string" ? msg.nonce : null;
					const nmTicket = msg.nmTicket === void 0 || msg.nmTicket === null ? null : msg.nmTicket;
					settle(() => resolve({
						wsPort: msg.port,
						nonce,
						nmTicket,
						protocolVersion: msg.protocolVersion
					}));
					return;
				}
				settle(() => reject(new NativeBootstrapError("malformed NM response", "malformed")));
			});
			port.onDisconnect.addListener(() => {
				const lastErr = browser.runtime.lastError?.message;
				log.info(`[NM] onDisconnect lastError=${lastErr ?? "none"}`);
				settle(() => reject(new NativeBootstrapError(`NM host disconnected${lastErr ? `: ${lastErr}` : ""}`, "disconnect")));
			});
			const request = opts.bindingPub === void 0 ? {
				action: "start",
				allowLaunch
			} : buildBootstrapRequest(opts.bindingPub, allowLaunch);
			try {
				port.postMessage(request);
			} catch (error) {
				settle(() => reject(new NativeBootstrapError(`NM start failed: ${error.message ?? String(error)}`, "disconnect")));
			}
		});
	}
};
//#endregion
//#region src/background/RemoteBackendPolicyStore.ts
/**
* Durable, authority-scoped consent for a remote Motrix Server.
*
* Pairing authenticates a Server; it does not authorize browser data to leave
* this device. This store keeps that second decision separately and binds it
* to both the opaque remote `BackendAuthority` and the instance identity that
* MBP1 authenticated. A changed URL produces a different authority key, and a
* changed instance id does not match the retained row, so both changes read as
* the all-disabled policy.
*
* Production reads/writes are consumed through `withMutationBoundary()`, whose
* ConnectionManager/endpoint-lifecycle caller revalidates the captured
* `{endpointId, canonicalUrl, revision}` immediately before storage I/O.
* Authority retirement also calls the global cleanup helper. This store cannot
* observe endpoint revisions by itself, so direct mutation remains a test/core
* primitive rather than a production authorization path.
*
* Persisted rows contain only an opaque authority key, an authenticated
* instance id, a consent timestamp, and fixed boolean grants. In particular,
* this store never writes a URL, token, cookie, header, or page payload.
*/
var STORAGE_KEY$2 = "motrix.remoteBackendPolicies";
var MAX_AUTHENTICATED_INSTANCE_ID_LENGTH = 128;
var MAX_AUTHORITY_KEY_LENGTH = 8192;
var leaseBoundRemoteBackendPolicyStoreBrand = Symbol("LeaseBoundRemoteBackendPolicyStore");
var POLICY_KEYS = /* @__PURE__ */ new Set([
	"version",
	"authorityKey",
	"authenticatedInstanceId",
	"remoteDataBoundaryAcceptedAt",
	"allowRequestCredentials",
	"allowCustomHeaders",
	"allowPageContent",
	"allowServerUrlProbe",
	"allowServerUrlResolve",
	"allowAutomaticTakeover"
]);
var REPLACEMENT_KEYS = /* @__PURE__ */ new Set([
	"remoteDataBoundaryAcceptedAt",
	"allowRequestCredentials",
	"allowCustomHeaders",
	"allowPageContent",
	"allowServerUrlProbe",
	"allowServerUrlResolve",
	"allowAutomaticTakeover"
]);
var CONTAINER_KEYS = /* @__PURE__ */ new Set(["version", "policies"]);
var enqueueRemoteBackendPolicyOperation = createOperationQueue();
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function hasExactOwnKeys(value, expected) {
	const keys = Object.keys(value);
	return keys.length === expected.size && keys.every((key) => expected.has(key));
}
function isPrintableAscii(value, maxLength) {
	if (value.length === 0 || value.length > maxLength) return false;
	for (let index = 0; index < value.length; index += 1) {
		const code = value.charCodeAt(index);
		if (code < 32 || code > 126) return false;
	}
	return true;
}
function isAuthenticatedInstanceId(value) {
	return typeof value === "string" && isPrintableAscii(value, MAX_AUTHENTICATED_INSTANCE_ID_LENGTH);
}
function isAttributableAuthorityKey(value) {
	return typeof value === "string" && value.length > 0 && value.length <= MAX_AUTHORITY_KEY_LENGTH && /^[A-Za-z0-9_-]+$/.test(value);
}
function authorityKeyOf(value) {
	if (!isRecord(value) || !Object.hasOwn(value, "authorityKey")) return null;
	return isAttributableAuthorityKey(value.authorityKey) ? value.authorityKey : null;
}
function isConsentTimestamp(value) {
	return value === null || typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
}
function hasSensitiveGrant(policy) {
	return policy.allowRequestCredentials || policy.allowCustomHeaders || policy.allowPageContent || policy.allowServerUrlProbe || policy.allowServerUrlResolve || policy.allowAutomaticTakeover;
}
function readPolicy(value) {
	if (!isRecord(value) || !hasExactOwnKeys(value, POLICY_KEYS)) return null;
	if (value.version !== 1 || !isAttributableAuthorityKey(value.authorityKey) || !isAuthenticatedInstanceId(value.authenticatedInstanceId) || !isConsentTimestamp(value.remoteDataBoundaryAcceptedAt) || typeof value.allowRequestCredentials !== "boolean" || typeof value.allowCustomHeaders !== "boolean" || typeof value.allowPageContent !== "boolean" || typeof value.allowServerUrlProbe !== "boolean" || typeof value.allowServerUrlResolve !== "boolean" || typeof value.allowAutomaticTakeover !== "boolean") return null;
	const policy = {
		version: 1,
		authorityKey: value.authorityKey,
		authenticatedInstanceId: value.authenticatedInstanceId,
		remoteDataBoundaryAcceptedAt: value.remoteDataBoundaryAcceptedAt,
		allowRequestCredentials: value.allowRequestCredentials,
		allowCustomHeaders: value.allowCustomHeaders,
		allowPageContent: value.allowPageContent,
		allowServerUrlProbe: value.allowServerUrlProbe,
		allowServerUrlResolve: value.allowServerUrlResolve,
		allowAutomaticTakeover: value.allowAutomaticTakeover
	};
	if (policy.remoteDataBoundaryAcceptedAt === null && hasSensitiveGrant(policy)) return null;
	return policy;
}
function readStoredSet(value, present) {
	if (!present) return {
		kind: "known",
		set: {
			version: 1,
			policies: []
		}
	};
	if (!isRecord(value)) return { kind: "corrupt" };
	if (!Object.hasOwn(value, "version") || typeof value.version !== "number" || !Number.isSafeInteger(value.version) || value.version < 1) return { kind: "corrupt" };
	if (value.version !== 1) return { kind: "future" };
	if (!hasExactOwnKeys(value, CONTAINER_KEYS) || !Array.isArray(value.policies)) return { kind: "corrupt" };
	if (value.policies.some((policy) => authorityKeyOf(policy) === null)) return { kind: "corrupt" };
	return {
		kind: "known",
		set: {
			version: 1,
			policies: value.policies
		}
	};
}
function validateReplacement(value) {
	if (!isRecord(value) || !hasExactOwnKeys(value, REPLACEMENT_KEYS) || !isConsentTimestamp(value.remoteDataBoundaryAcceptedAt) || typeof value.allowRequestCredentials !== "boolean" || typeof value.allowCustomHeaders !== "boolean" || typeof value.allowPageContent !== "boolean" || typeof value.allowServerUrlProbe !== "boolean" || typeof value.allowServerUrlResolve !== "boolean" || typeof value.allowAutomaticTakeover !== "boolean") throw new InvalidRemoteBackendPolicyError();
	const replacement = {
		remoteDataBoundaryAcceptedAt: value.remoteDataBoundaryAcceptedAt,
		allowRequestCredentials: value.allowRequestCredentials,
		allowCustomHeaders: value.allowCustomHeaders,
		allowPageContent: value.allowPageContent,
		allowServerUrlProbe: value.allowServerUrlProbe,
		allowServerUrlResolve: value.allowServerUrlResolve,
		allowAutomaticTakeover: value.allowAutomaticTakeover
	};
	if (replacement.remoteDataBoundaryAcceptedAt === null && hasSensitiveGrant(replacement)) throw new RemoteDataBoundaryRequiredError();
	return replacement;
}
async function loadStoredSet(forMutation) {
	const object = await browser.storage.local.get(STORAGE_KEY$2);
	const result = readStoredSet(object[STORAGE_KEY$2], Object.hasOwn(object, STORAGE_KEY$2));
	if (forMutation && result.kind === "future") throw new UnsupportedRemoteBackendPolicyVersionError();
	if (forMutation && result.kind === "corrupt") throw new CorruptRemoteBackendPolicyStoreError();
	return result;
}
async function persistPolicies(policies) {
	if (policies.length === 0) {
		await browser.storage.local.remove(STORAGE_KEY$2);
		return;
	}
	await browser.storage.local.set({ [STORAGE_KEY$2]: {
		version: 1,
		policies
	} });
}
/** Fixed errors never include persisted data or caller-controlled identity. */
var RemoteBackendPolicyRequiresRemoteAuthorityError = class extends Error {
	constructor() {
		super("remote backend policy requires a module-issued remote authority");
	}
};
var InvalidAuthenticatedInstanceIdError = class extends Error {
	constructor() {
		super("authenticated instance id is outside the accepted printable form");
	}
};
var InvalidRemoteBackendPolicyError = class extends Error {
	constructor() {
		super("remote backend policy replacement is invalid");
	}
};
var RemoteDataBoundaryRequiredError = class extends Error {
	constructor() {
		super("remote data boundary consent is required before granting access");
	}
};
var UnsupportedRemoteBackendPolicyVersionError = class extends Error {
	constructor() {
		super("remote backend policy store version is unsupported");
	}
};
var CorruptRemoteBackendPolicyStoreError = class extends Error {
	constructor() {
		super("remote backend policy store is corrupt");
	}
};
function authorityKeyFromRemoteAuthority(authority) {
	assertBackendAuthority(authority);
	if (authority.kind !== "remote") throw new RemoteBackendPolicyRequiresRemoteAuthorityError();
	return backendAuthorityKey(authority);
}
async function clearPoliciesForAuthorityKey(authorityKey) {
	return enqueueRemoteBackendPolicyOperation(async () => {
		const result = await loadStoredSet(true);
		if (result.kind !== "known") throw new CorruptRemoteBackendPolicyStoreError();
		const policies = result.set.policies.filter((policy) => authorityKeyOf(policy) !== authorityKey);
		if (policies.length === result.set.policies.length) return;
		await persistPolicies(policies);
	});
}
async function clearRemoteBackendPoliciesForAuthority(authority) {
	await clearPoliciesForAuthorityKey(authorityKeyFromRemoteAuthority(authority));
}
var RemoteBackendPolicyStoreCore = class {
	authorityKey;
	authenticatedInstanceId;
	constructor(authority, authenticatedInstanceId) {
		const authorityKey = authorityKeyFromRemoteAuthority(authority);
		if (!isAuthenticatedInstanceId(authenticatedInstanceId)) throw new InvalidAuthenticatedInstanceIdError();
		this.authorityKey = authorityKey;
		this.authenticatedInstanceId = authenticatedInstanceId;
	}
	/**
	* Return this exact authority/identity policy. Missing, mismatched,
	* malformed, duplicate, future-version, and corrupt state all read as a
	* fresh policy with every permission disabled.
	*/
	async get() {
		return enqueueRemoteBackendPolicyOperation(async () => {
			const result = await loadStoredSet(false);
			const fallback = this.defaultPolicy();
			if (result.kind !== "known") return fallback;
			let matched = null;
			let matches = 0;
			for (const rawPolicy of result.set.policies) {
				if (authorityKeyOf(rawPolicy) !== this.authorityKey) continue;
				matches += 1;
				if (matches > 1) return fallback;
				matched = readPolicy(rawPolicy);
			}
			if (matches !== 1 || matched === null || matched.authenticatedInstanceId !== this.authenticatedInstanceId) return fallback;
			return { ...matched };
		});
	}
	/**
	* Replace every grant for this authority with one complete policy bound to
	* this authenticated instance.
	*
	* Coordinator-only in production: the future lifecycle coordinator must
	* first revalidate its captured `{endpointId, canonicalUrl, revision}`.
	* Calling this primitive directly cannot prevent an old async attempt from
	* writing after endpoint replacement.
	*/
	async replace(value) {
		const replacement = validateReplacement(value);
		return enqueueRemoteBackendPolicyOperation(async () => {
			const result = await loadStoredSet(true);
			if (result.kind !== "known") throw new CorruptRemoteBackendPolicyStoreError();
			const policies = result.set.policies.filter((policy) => authorityKeyOf(policy) !== this.authorityKey);
			policies.push({
				version: 1,
				authorityKey: this.authorityKey,
				authenticatedInstanceId: this.authenticatedInstanceId,
				...replacement
			});
			await persistPolicies(policies);
		});
	}
	/**
	* Remove every retained identity/policy for this authority, leaving all
	* other authorities byte-for-byte untouched.
	*
	* Coordinator-only in production, under the same captured endpoint revision
	* rule as `replace`; this primitive does not make endpoint deletion durable.
	*/
	async clear() {
		await clearPoliciesForAuthorityKey(this.authorityKey);
	}
	/** Remote production consumers use this facade so every read/grant/clear is
	* revalidated against the same endpoint revision immediately before I/O. */
	withMutationBoundary(boundary) {
		return Object.freeze({
			[leaseBoundRemoteBackendPolicyStoreBrand]: true,
			get: () => boundary.run(() => this.get()),
			replace: (value) => boundary.run(() => this.replace(value)),
			clear: () => boundary.run(() => this.clear())
		});
	}
	defaultPolicy() {
		return {
			version: 1,
			authorityKey: this.authorityKey,
			authenticatedInstanceId: this.authenticatedInstanceId,
			remoteDataBoundaryAcceptedAt: null,
			allowRequestCredentials: false,
			allowCustomHeaders: false,
			allowPageContent: false,
			allowServerUrlProbe: false,
			allowServerUrlResolve: false,
			allowAutomaticTakeover: false
		};
	}
};
/** The only production constructor: every operation re-enters the caller's
* nominal endpoint-attempt lease immediately before storage I/O. */
function createLeaseBoundRemoteBackendPolicyStore(authority, authenticatedInstanceId, boundary) {
	assertBackendAttemptMutationCapability(boundary);
	return new RemoteBackendPolicyStoreCore(authority, authenticatedInstanceId).withMutationBoundary(boundary);
}
//#endregion
//#region src/background/remote-submit-policy.ts
var CREDENTIAL_HEADER_NAMES = /* @__PURE__ */ new Set([
	"authorization",
	"cookie",
	"proxy-authorization",
	"set-cookie"
]);
var RemoteDataBoundaryConsentRequiredError = class extends Error {
	reason = "permissionRequired";
	constructor() {
		super("remote download data boundary consent is required");
		this.name = "RemoteDataBoundaryConsentRequiredError";
	}
};
var RemoteAutomaticTakeoverConsentRequiredError = class extends Error {
	reason = "permissionRequired";
	constructor() {
		super("automatic browser-download takeover is not allowed for this Server");
		this.name = "RemoteAutomaticTakeoverConsentRequiredError";
	}
};
function sanitizeResource(resource, policy) {
	const headers = policy.allowCustomHeaders ? Object.fromEntries(Object.entries(resource.headers).filter(([name]) => policy.allowRequestCredentials || !CREDENTIAL_HEADER_NAMES.has(name.toLowerCase()))) : {};
	return {
		...resource,
		headers,
		cookies: policy.allowRequestCredentials ? resource.cookies.map((cookie) => ({ ...cookie })) : []
	};
}
/** Enforce the remote data boundary at the last outbound serialization seam.
* Pairing alone never authorizes a page-derived submission. The returned
* object is detached from caller-owned resources so later mutation cannot add
* credentials after this check. */
function applyRemoteSubmitPolicy(params, policy) {
	if (policy.remoteDataBoundaryAcceptedAt === null) throw new RemoteDataBoundaryConsentRequiredError();
	const selection = params.selection;
	if (selection.kind === "magnet") return {
		...params,
		source: { ...params.source },
		meta: { ...params.meta },
		selection: { ...selection }
	};
	if (selection.kind === "mux") return {
		...params,
		source: { ...params.source },
		meta: { ...params.meta },
		selection: {
			...selection,
			video: sanitizeResource(selection.video, policy),
			audio: sanitizeResource(selection.audio, policy)
		}
	};
	return {
		...params,
		source: { ...params.source },
		meta: { ...params.meta },
		selection: {
			...selection,
			primary: sanitizeResource(selection.primary, policy)
		}
	};
}
//#endregion
//#region src/background/TaskEventStore.ts
/**
* Latest `$/task/progress` per task id + an active-set change observer. The
* popup renders progress from the polled `task/list` (which already carries
* `progress`), so this store is the background's record of in-flight pushes
* — read on completion/error to clean up and to enrich the OS notification.
* `take` removes and returns the entry.
*
* `onChange` fires only when the set of in-flight ids changes membership
* (first sight of an id, or its removal) — not on every progress tick — so
* a badge listener refreshes on start/stop, not on every push.
*/
var TaskEventStore = class {
	latest = /* @__PURE__ */ new Map();
	listeners = [];
	onChange(cb) {
		this.listeners.push(cb);
	}
	fire() {
		for (const cb of this.listeners) cb();
	}
	get size() {
		return this.latest.size;
	}
	recordProgress(p) {
		const had = this.latest.has(p.taskId);
		this.latest.set(p.taskId, p);
		if (!had) this.fire();
	}
	take(taskId) {
		const v = this.latest.get(taskId);
		if (v !== void 0) {
			this.latest.delete(taskId);
			this.fire();
		}
		return v;
	}
	/**
	* Drop all in-flight entries. Call on each fresh connection so a task that
	* completed during a WS blip (and whose `TaskCompleted` push was lost)
	* doesn't leave a stale entry that keeps `hasActiveTasks()` true forever.
	*/
	clear() {
		if (this.latest.size > 0) {
			this.latest.clear();
			this.fire();
		}
	}
};
//#endregion
//#region src/background/BrowserWebSocketStream.ts
/**
* Browser-side WebSocket → vscode-jsonrpc MessageReader/Writer adapter.
* Mirrors Motrix's WebSocketMessageStream but uses the browser
* WebSocket event model (addEventListener + MessageEvent.data) instead
* of Node's ws.WebSocket (EventEmitter + Buffer).
*/
var OPEN_STATE = 1;
var BrowserWebSocketMessageReader = class {
	ws;
	errorEmitter = new import_api.Emitter();
	closeEmitter = new import_api.Emitter();
	partialMessageEmitter = new import_api.Emitter();
	dataCallback = null;
	attached = false;
	messageListener = (ev) => {
		if (!this.dataCallback) return;
		const data = ev.data;
		let text;
		if (typeof data === "string") text = data;
		else if (data instanceof ArrayBuffer) text = new TextDecoder().decode(data);
		else {
			this.errorEmitter.fire(/* @__PURE__ */ new Error("unsupported WS frame type"));
			return;
		}
		let parsed;
		try {
			parsed = JSON.parse(text);
		} catch (e) {
			this.errorEmitter.fire(/* @__PURE__ */ new Error(`failed to parse WS frame: ${e.message}`));
			return;
		}
		this.dataCallback(parsed);
	};
	closeListener = () => {
		this.closeEmitter.fire(void 0);
	};
	errorListener = () => {
		this.errorEmitter.fire(/* @__PURE__ */ new Error("WebSocket error event"));
	};
	constructor(ws) {
		this.ws = ws;
	}
	get onError() {
		return this.errorEmitter.event;
	}
	get onClose() {
		return this.closeEmitter.event;
	}
	get onPartialMessage() {
		return this.partialMessageEmitter.event;
	}
	listen(callback) {
		if (this.attached) throw new Error("BrowserWebSocketMessageReader already listening");
		this.dataCallback = callback;
		this.ws.addEventListener("message", this.messageListener);
		this.ws.addEventListener("close", this.closeListener);
		this.ws.addEventListener("error", this.errorListener);
		this.attached = true;
		return { dispose: () => this.dispose() };
	}
	dispose() {
		if (!this.attached) return;
		this.ws.removeEventListener("message", this.messageListener);
		this.ws.removeEventListener("close", this.closeListener);
		this.ws.removeEventListener("error", this.errorListener);
		this.attached = false;
		this.dataCallback = null;
		this.errorEmitter.dispose();
		this.closeEmitter.dispose();
		this.partialMessageEmitter.dispose();
	}
};
var BrowserWebSocketMessageWriter = class {
	ws;
	errorEmitter = new import_api.Emitter();
	closeEmitter = new import_api.Emitter();
	closeListener = () => {
		this.closeEmitter.fire(void 0);
	};
	attached = false;
	constructor(ws) {
		this.ws = ws;
		this.ws.addEventListener("close", this.closeListener);
		this.attached = true;
	}
	get onError() {
		return this.errorEmitter.event;
	}
	get onClose() {
		return this.closeEmitter.event;
	}
	async write(msg) {
		if (this.ws.readyState !== OPEN_STATE) throw new Error(`WebSocket is closed (readyState=${this.ws.readyState})`);
		try {
			this.ws.send(JSON.stringify(msg));
		} catch (e) {
			this.errorEmitter.fire([
				e,
				msg,
				void 0
			]);
			throw e;
		}
	}
	end() {
		if (this.ws.readyState === OPEN_STATE) this.ws.close();
	}
	dispose() {
		if (!this.attached) return;
		this.ws.removeEventListener("close", this.closeListener);
		this.attached = false;
		this.errorEmitter.dispose();
		this.closeEmitter.dispose();
	}
};
//#endregion
//#region src/background/WebSocketClient.ts
var WS_CLOSED$1 = 3;
var DEFAULT_OPEN_TIMEOUT_MS$1 = 8e3;
/**
* Owns one WebSocket lifecycle. connect() opens the socket and wraps it
* in an MdxpConnection (handlers must be attached + listen() called by
* the caller — we hand off the unlistened connection so ConnectionManager
* can install onRequest/onNotification before incoming traffic flows).
*/
var WebSocketClient = class {
	/** The sole live/pending socket. Callback ownership lives on the session,
	*  never on the client, so a late close from an older socket cannot observe
	*  callbacks registered for its replacement. */
	session = null;
	Ctor;
	openTimeoutMs;
	constructor(opts = {}) {
		this.Ctor = opts.WebSocketCtor ?? globalThis.WebSocket;
		this.openTimeoutMs = opts.openTimeoutMs ?? DEFAULT_OPEN_TIMEOUT_MS$1;
	}
	async connect(url, subprotocol) {
		if (this.session) throw new Error("WebSocketClient already connected");
		const ws = new this.Ctor(url, subprotocol);
		const session = {
			ws,
			conn: null,
			closeCallbacks: [],
			closeHandled: false
		};
		this.session = session;
		await new Promise((resolve, reject) => {
			let timer = null;
			const cleanup = () => {
				if (timer !== null) clearTimeout(timer);
				ws.removeEventListener("open", onOpen);
				ws.removeEventListener("error", onError);
				ws.removeEventListener("close", onCloseBeforeOpen);
			};
			const onOpen = () => {
				cleanup();
				resolve();
			};
			const onError = () => {
				cleanup();
				if (this.session === session) this.session = null;
				if (ws.readyState !== WS_CLOSED$1) ws.close();
				reject(/* @__PURE__ */ new Error("WebSocket failed to open"));
			};
			const onCloseBeforeOpen = () => {
				cleanup();
				if (this.session === session) this.session = null;
				reject(/* @__PURE__ */ new Error("WebSocket closed before opening"));
			};
			ws.addEventListener("open", onOpen);
			ws.addEventListener("error", onError);
			ws.addEventListener("close", onCloseBeforeOpen);
			timer = setTimeout(() => {
				cleanup();
				if (this.session === session) this.session = null;
				if (ws.readyState !== WS_CLOSED$1) ws.close();
				reject(/* @__PURE__ */ new Error(`WebSocket open timed out after ${this.openTimeoutMs}ms`));
			}, this.openTimeoutMs);
		});
		if (this.session !== session) {
			if (ws.readyState !== WS_CLOSED$1) ws.close();
			throw new Error("WebSocket connection superseded");
		}
		ws.addEventListener("close", () => this.handleSocketClose(session));
		const conn = createMdxpConnection(new BrowserWebSocketMessageReader(ws), new BrowserWebSocketMessageWriter(ws));
		session.conn = conn;
		return conn;
	}
	onClose(cb) {
		this.session?.closeCallbacks.push(cb);
	}
	close() {
		const session = this.session;
		if (session === null) return;
		this.session = null;
		if (session.ws.readyState !== WS_CLOSED$1) session.ws.close();
		session.conn?.dispose();
		session.conn = null;
		session.closeCallbacks.length = 0;
	}
	getConnection() {
		return this.session?.conn ?? null;
	}
	handleSocketClose(session) {
		if (session.closeHandled) return;
		session.closeHandled = true;
		const callbacks = session.closeCallbacks.splice(0);
		if (this.session === session) this.session = null;
		session.conn?.dispose();
		session.conn = null;
		for (const cb of callbacks) cb();
	}
};
//#endregion
//#region src/background/WebSocketFrameChannel.ts
/**
* Real `FrameChannel` (bridge-pairing-protocol.md §6.1) over a browser
* `WebSocket`, driving `PairingFlow`/`ReconnectFlow` on `/pair` and `/v1`.
*
* `PairingFlow`/`ReconnectFlow`'s own tests drive a scripted in-memory peer
* against the `FrameChannel` interface instead of a socket; this is the
* adapter that makes the interface real for `ConnectionManager`.
*
* ## The contract this must honour (see `frames.ts`'s `FrameChannel` doc)
*
* - `open` requests the `motrix-bridge.v1` subprotocol; the server 401s the
*   upgrade without it.
* - `receiveText`/`receiveBinary` reject — never hang, never resolve — on a
*   timeout or a socket close with nothing pending. A flow that cannot tell
*   "closed" from "still waiting" cannot honour its own deadlines.
* - Exactly one receive is outstanding at a time; the flows never issue a
*   second one before the first settles. Arriving frames are queued FIFO so a
*   frame that shows up before it is asked for is not lost.
* - A frame of the wrong kind for what was asked (text vs binary) is a §6.1
*   violation, surfaced as a rejection rather than silently coerced.
* - `close` is idempotent and safe on an already-closed or never-opened
*   socket.
*
* ## What happens after a flow succeeds
*
* Neither flow calls `close()` on success — the caller owns the socket from
* there on, since MDXP `motrix/initialize` runs inside the envelope the flow
* just derived. `release()` (not part of `FrameChannel`, so callers must hold
* the concrete class to reach it) detaches this channel's own listeners and
* hands back the live `WebSocket` **and** any frames still sitting in
* `this.queue` — every frame that arrived after the flow's last `receive*()`
* call but before `release()` ran. There is a real window for that: the
* caller does several `storage.local` writes (credential commit, pin
* commit, prune) between a flow returning and `release()` actually being
* called. Dropping a queued frame here would silently desynchronize the
* envelope's strict per-direction sequence counter the moment the caller
* starts reading with the fresh transport layer — the next inbound frame
* would fail `sequenceMismatch` and look like tampering, for a frame the
* peer sent perfectly correctly. The fresh transport layer (the AEAD
* envelope's `MessageReader`) is the one that must process any handed-over
* frames, in order, before it starts listening for new ones.
*/
var WS_OPEN = 1;
var WS_CLOSED = 3;
var DEFAULT_OPEN_TIMEOUT_MS = 8e3;
var WebSocketFrameChannel = class {
	Ctor;
	openTimeoutMs;
	ws = null;
	released = false;
	closed = false;
	closeError = null;
	abortOpening = null;
	queue = [];
	pending = null;
	/** Last URL passed to `open()` — exposed for callers to record (e.g.
	*  `ConnectionManager.lastConnectUrl`), mirroring `ScriptedChannel.openedUrls`
	*  in the flow test suites. */
	openedUrl = null;
	onMessage = (ev) => {
		const data = ev.data;
		if (typeof data === "string") {
			this.enqueue({
				kind: "text",
				data
			});
			return;
		}
		if (data instanceof ArrayBuffer) {
			this.enqueue({
				kind: "binary",
				data: new Uint8Array(data)
			});
			return;
		}
		this.forceClose(/* @__PURE__ */ new Error("unsupported WebSocket frame type"));
	};
	onSocketClose = () => {
		this.forceClose(/* @__PURE__ */ new Error("WebSocket closed"));
	};
	constructor(options = {}) {
		this.Ctor = options.WebSocketCtor ?? globalThis.WebSocket;
		this.openTimeoutMs = options.openTimeoutMs ?? DEFAULT_OPEN_TIMEOUT_MS;
	}
	async open(url) {
		if (this.ws !== null) throw new Error("WebSocketFrameChannel already opened");
		this.openedUrl = url;
		const ws = new this.Ctor(url, MBP1_SUBPROTOCOL);
		this.ws = ws;
		ws.binaryType = "arraybuffer";
		await new Promise((resolve, reject) => {
			let timer = null;
			let settled = false;
			const cleanup = () => {
				if (timer !== null) clearTimeout(timer);
				ws.removeEventListener("open", onOpen);
				ws.removeEventListener("error", onError);
				ws.removeEventListener("close", onCloseBeforeOpen);
				if (this.abortOpening === fail) this.abortOpening = null;
			};
			const fail = (error) => {
				if (settled) return;
				settled = true;
				cleanup();
				this.forceClose(error);
				if (ws.readyState !== WS_CLOSED) ws.close();
				reject(error);
			};
			const onOpen = () => {
				if (settled) return;
				settled = true;
				cleanup();
				resolve();
			};
			const onError = () => {
				fail(/* @__PURE__ */ new Error("WebSocket failed to open"));
			};
			const onCloseBeforeOpen = () => {
				fail(/* @__PURE__ */ new Error("WebSocket closed before opening"));
			};
			this.abortOpening = fail;
			ws.addEventListener("open", onOpen);
			ws.addEventListener("error", onError);
			ws.addEventListener("close", onCloseBeforeOpen);
			timer = setTimeout(() => {
				fail(/* @__PURE__ */ new Error(`WebSocket open timed out after ${this.openTimeoutMs}ms`));
			}, this.openTimeoutMs);
		});
		if (this.closed) throw this.closeError ?? /* @__PURE__ */ new Error("WebSocketFrameChannel closed");
		ws.addEventListener("message", this.onMessage);
		ws.addEventListener("close", this.onSocketClose);
	}
	async sendText(frame) {
		this.send(JSON.stringify(frame));
	}
	async sendBinary(frame) {
		this.send(frame);
	}
	async receiveText(timeoutMs) {
		const frame = await this.receiveFrame(timeoutMs);
		if (frame.kind !== "text") throw new Error("§6.1 violation: expected a text frame, received a binary one");
		return frame.data;
	}
	async receiveBinary(timeoutMs) {
		const frame = await this.receiveFrame(timeoutMs);
		if (frame.kind !== "binary") throw new Error("§6.1 violation: expected a binary frame, received a text one");
		return frame.data;
	}
	close() {
		if (this.released) return;
		if (this.ws === null) return;
		const error = /* @__PURE__ */ new Error("WebSocketFrameChannel closed");
		this.forceClose(error);
		this.abortOpening?.(error);
		if (this.ws !== null) {
			this.ws.removeEventListener("message", this.onMessage);
			this.ws.removeEventListener("close", this.onSocketClose);
			if (this.ws.readyState !== WS_CLOSED) this.ws.close();
		}
	}
	/**
	* Detaches this channel's own listeners and hands back the live socket —
	* plus any frames still queued from before `release()` ran, see the
	* module doc — for a fresh transport layer (the envelope reader/writer)
	* to attach its own listeners and drain in order. Never called by
	* `PairingFlow`/`ReconnectFlow` themselves — they only call `close()`, and
	* only on failure — so this is the caller's own seam for the success
	* path. Idempotent-unsafe by design: calling it twice, or calling it on a
	* channel that never opened, is a caller bug, not a recoverable state, so
	* it throws rather than silently returning a stale reference.
	*
	* A queued **text** frame is a §6.1 violation in its own right at this
	* point — every frame after the channel activates must be binary — so
	* this throws rather than silently discarding it or handing it to a
	* binary-only consumer.
	*/
	release() {
		if (this.ws === null) throw new Error("WebSocketFrameChannel: release() before open()");
		if (this.released) throw new Error("WebSocketFrameChannel: already released");
		if (this.closed || this.ws.readyState !== WS_OPEN) throw new Error("WebSocketFrameChannel: socket is not open");
		const queuedFrames = [];
		for (const frame of this.queue) {
			if (frame.kind === "text") throw new Error("§6.1 violation: a text frame is still queued at release() — every frame past channel activation must be binary");
			queuedFrames.push(frame.data);
		}
		this.released = true;
		this.queue.length = 0;
		this.ws.removeEventListener("message", this.onMessage);
		this.ws.removeEventListener("close", this.onSocketClose);
		return {
			socket: this.ws,
			queuedFrames
		};
	}
	send(data) {
		if (this.ws === null || this.ws.readyState !== WS_OPEN) throw new Error("WebSocketFrameChannel: not open");
		this.ws.send(typeof data === "string" ? data : data);
	}
	enqueue(frame) {
		if (this.pending !== null) {
			const { resolve } = this.pending;
			this.pending = null;
			resolve(frame);
			return;
		}
		this.queue.push(frame);
	}
	forceClose(error) {
		if (this.closed) return;
		this.closed = true;
		this.closeError = error;
		if (this.pending !== null) {
			const { reject } = this.pending;
			this.pending = null;
			reject(error);
		}
	}
	receiveFrame(timeoutMs) {
		if (this.pending !== null) return Promise.reject(/* @__PURE__ */ new Error("WebSocketFrameChannel: a receive is already pending"));
		const queued = this.queue.shift();
		if (queued !== void 0) return Promise.resolve(queued);
		if (this.closed) return Promise.reject(this.closeError ?? /* @__PURE__ */ new Error("WebSocketFrameChannel: closed with no frame pending"));
		return new Promise((resolve, reject) => {
			const timer = setTimeout(() => {
				this.pending = null;
				reject(/* @__PURE__ */ new Error(`receive timed out after ${timeoutMs}ms`));
			}, timeoutMs);
			this.pending = {
				resolve: (frame) => {
					clearTimeout(timer);
					resolve(frame);
				},
				reject: (error) => {
					clearTimeout(timer);
					reject(error);
				}
			};
		});
	}
};
//#endregion
//#region src/background/ConnectionManager.ts
var DEFAULT_REQUEST_TIMEOUT_MS = 15e3;
var DEFAULT_INITIALIZE_TIMEOUT_MS = 9e4;
var BackendCompatibilityError = class extends Error {
	reason;
	constructor(reason, message) {
		super(message);
		this.name = "BackendCompatibilityError";
		this.reason = reason;
	}
};
var RemoteConnectionError = class extends Error {
	reason;
	constructor(reason, message) {
		super(message);
		this.name = "RemoteConnectionError";
		this.reason = reason;
	}
};
function isStrictlyNewerMdxp(version) {
	const match = /^(\d+)\.(\d+)$/.exec(version);
	if (match === null) return false;
	const major = Number(match[1]);
	const minor = Number(match[2]);
	return major > 1 || major === 1 && minor > 0;
}
/**
* Classify an authenticated peer's malformed/incompatible initialize result.
* Discovery is only an unauthenticated hint; this is the authoritative verdict
* after MBP1 has proved which backend we are talking to.
*/
function initializeCompatibilityFailureReason(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return "backendUpgradeRequired";
	const result = value;
	if (typeof result.protocolVersion === "string" && isStrictlyNewerMdxp(result.protocolVersion)) return "extensionUpgradeRequired";
	return "backendUpgradeRequired";
}
/** Internal cancellation signal for async work that belongs to a connection
* attempt superseded by stop() or a newer connect(). */
var StaleConnectionAttemptError = class extends Error {
	constructor() {
		super("connection attempt superseded");
		this.name = "StaleConnectionAttemptError";
	}
};
/**
* `connectLocalMbp1`'s recovery-order walk exhausted every stored credential
* during an attempt nobody asked for (`autostart()`, or the automatic
* post-close probe-reconnect) — never during a user-initiated one. §6.7/§12
* both require fresh code-entry pairing to wait for the user or an explicit
* revocation; falling through here regardless would put an unrequested
* approval dialog on the user's Motrix and count against its §7.3 lockout
* on every unattended wake, escalating a stale-credential situation the
* user has not even seen yet into an hour-long server-side lockout.
*
* Lands the manager in `disconnected` (via `connect()`'s ordinary catch
* path) with `reason` set so a UI can explain why, and touches no
* credential or pin — the retained set is left exactly as `recoverOrder`
* found it, for a later retry (a fresh wake, or the user asking explicitly).
*/
var RecoveryExhaustedUnattendedError = class extends Error {
	reason = "recoveryExhaustedUnattended";
	constructor() {
		super("every stored MBP1 credential failed and this attempt was not user-initiated; not falling back to fresh code-entry pairing");
		this.name = "RecoveryExhaustedUnattendedError";
	}
};
function isSameEndpointIncarnation(left, right) {
	if (left.activeEndpointId !== right.activeEndpointId) return false;
	if (left.endpointConfig.mode !== right.endpointConfig.mode) return false;
	if (left.endpointConfig.mode === "local") return true;
	if (right.endpointConfig.mode === "local") return false;
	return left.endpointConfig.endpointId === right.endpointConfig.endpointId && left.endpointConfig.remoteUrl === right.endpointConfig.remoteUrl && left.endpointConfig.revision === right.endpointConfig.revision;
}
/**
* Orchestrates the full transport stack:
*   MBP1 discovery → authenticated WebSocket → motrix/initialize →
*   ws-close-driven reconnect.
*
* State machine:
*   disconnected ─connect()→ bootstrapping ─ok→ connecting ─ok→ handshaking ─ok→ connected
*                                    (first pair) handshaking ⇄ awaiting-code (code provider pending)
*                         └ err → dormant (disconnected)                           │
*                                              one probe-reconnect ←── ws close ──┘
*   stop() at any state → disconnected (closes WS).
*
* Entry points:
*   autostart()           — SW startup: checks MBP1 credentials.
*   connect({allowLaunch}) — single attempt; true = wake Motrix if needed.
*   clearGateAndStart()   — popup "Connect": clears gate, calls connect(allowLaunch:true).
*/
var ConnectionManager = class {
	state = "disconnected";
	stateListeners = [];
	currentConn = null;
	/** Captured authority/revision for the live authenticated session. Durable
	* policy reads revalidate this snapshot immediately before outbound I/O. */
	currentEndpointScope = null;
	currentAuthenticatedInstanceId = null;
	/**
	* The raw socket behind a *local* (MBP1) `currentConn`, or null for a
	* remote connection. Remote's `currentConn` is a `WebSocketClient`-owned
	* socket, so `this.client.close()` already tears it down; a local
	* connection's socket comes from `channel.release()` instead and
	* `this.client` never learns of it, so `stop()`/`enterDenied()` need this
	* separate handle to close it too — otherwise a denied/torn-down MBP1
	* session leaks an open WebSocket indefinitely.
	*/
	currentMbp1Socket = null;
	/**
	* Channel whose socket is still owned by PairingFlow/ReconnectFlow. Unlike
	* `currentMbp1Socket`, this exists before authentication and may remain open
	* while a user reads/types a pairing code. Keeping it on the manager lets
	* stop() close it synchronously instead of waiting for the protocol TTL.
	*/
	preAuthChannel = null;
	lastErrorMessage = null;
	/**
	* `PairingFlowError`/`ReconnectFlowError`'s own `reason`/`retryAtMs`, kept
	* alongside the plain-string message so a UI can render §7.3's backoff
	* state ("try again later") without parsing English out of an error
	* message. `retryAtMs` here is always the value the client's own
	* `FirstPairBackoff` computed — never anything the server reported — since
	* a fake or relaying peer can claim whatever `attemptsRemaining`/timing it
	* likes.
	*/
	lastErrorReason = null;
	lastErrorRetryAtMs = null;
	/** Owner of the process-local presentation state below. Durable state is
	* scoped by its stores; this snapshot prevents an old selected Server's
	* transient error/prompt/retry verdict from appearing under a newly
	* selected endpoint while its connection attempt is being captured. */
	presentationEndpointIncarnation = null;
	/** Set exactly while the provider wrapper holds `awaiting-code`; read
	*  through `getPendingPairingCode()`, which additionally gates on the
	*  state so a stopped attempt's record is invisible even before the
	*  un-cancellable provider promise is reaped by its own §7.2 timeout. */
	pendingPairingCode = null;
	/** Full local cleanup + persisted denial for an authenticated revocation.
	* A user may click Reconnect as soon as the synchronous `denied` transition
	* renders; that retry must wait until stale credentials are gone. */
	pendingRevocationCleanup = null;
	/** The candidate a caller explicitly picked via `choosePairCandidate`,
	*  consumed (and cleared) by the next first-pair attempt. `null` means
	*  "use whatever `discoverForFirstPair` ranks first", the existing
	*  default. */
	preferredCandidatePort = null;
	bootstrap;
	client;
	endpointConfigStore;
	backendOperationCoordinator;
	endpointLifecycleService;
	gate;
	opts;
	taskEvents;
	notify;
	requestTimeoutMs;
	initializeTimeoutMs;
	closeReconnectDelayMs;
	serverCapabilities = null;
	serverIdentity = null;
	/**
	* Set exactly once per first-pair attempt in this session, at the same
	* point `connectFirstPairMbp1` decides what to pass as `discovery` to
	* `PairingFlow.run`: whether the candidate that answered presented no
	* §9.1 attestation ticket at all (`nmTicket === undefined`) — the host
	* degraded to ticketless. This is **not** the §5 identity tri-state; that
	* is the *server's* verdict about the extension, shown in Motrix's own
	* dialog, and never reaches the client at all.
	*
	* `null` until a first-pair attempt has actually run this session — a
	* plain reconnect (`connectLocalMbp1` succeeding via `recoverOrder`)
	* never re-presents a ticket, so it has no way to answer either way.
	* Reset alongside `serverIdentity` so a stale value from an earlier
	* attempt never survives into a later one.
	*/
	degraded = null;
	/** Last URL passed to client.connect() — exposed for tests / observability. */
	lastConnectUrl = null;
	/** DEBUG: monotonic connectOnce counter. Each increment = one NM
	*  bootstrap spawn (in local mode). TODO(remove-after-rootcause). */
	attemptSeq = 0;
	/** Monotonic ownership token for async connection work. stop() and every
	*  accepted connect() invalidate all earlier continuations and callbacks. */
	generation = 0;
	/** One user-authorized connection lifecycle at a time. Endpoint activation,
	*  the Options Pair button, popup Connect, and an explicit handoff can all
	*  express the same intent before `connectOnce` has advanced the visible
	*  state. Joining that flight is security-relevant: restarting after the
	*  Server queued its prompt records a failed §7.3 attempt and can lock the
	*  replacement out. `stop()` clears the flight so an endpoint/lifecycle
	*  change can start a genuinely new intent. */
	explicitConnectFlight = null;
	credentialStore;
	pinStore;
	discoveryService;
	remoteDiscoveryService;
	firstPairBackoff;
	createFrameChannel;
	createPairingFlow;
	createReconnectFlow;
	createEnvelopeConnection;
	constructor(opts) {
		this.opts = opts;
		this.bootstrap = opts.bootstrap ?? new NativeBootstrap();
		this.client = opts.client ?? new WebSocketClient();
		this.endpointConfigStore = opts.endpointConfigStore ?? new EndpointConfigStore();
		this.backendOperationCoordinator = opts.backendOperationCoordinator ?? new BackendOperationCoordinator();
		this.endpointLifecycleService = opts.endpointLifecycleService ?? new EndpointCatalogService(this.endpointConfigStore, { retire: async () => {
			throw new Error("test-only endpoint lifecycle cannot retire");
		} }, { coordinator: this.backendOperationCoordinator });
		this.gate = opts.gate ?? new ConnectionGate();
		this.taskEvents = opts.taskEvents ?? new TaskEventStore();
		this.requestTimeoutMs = opts.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
		this.initializeTimeoutMs = opts.initializeTimeoutMs ?? DEFAULT_INITIALIZE_TIMEOUT_MS;
		this.closeReconnectDelayMs = opts.closeReconnectDelayMs ?? 250;
		if (!Number.isSafeInteger(this.closeReconnectDelayMs) || this.closeReconnectDelayMs < 0) throw new TypeError("closeReconnectDelayMs must be a non-negative integer");
		this.notify = opts.notify ?? ((n) => {
			if (typeof browser !== "undefined" && typeof browser.notifications !== "undefined") browser.notifications.create({
				type: "basic",
				iconUrl: browser.runtime.getURL("icons/icon-128.png"),
				title: n.title,
				message: n.message
			}).catch(() => {});
		});
		this.credentialStore = opts.credentialStore ?? new CredentialStore();
		this.pinStore = opts.pinStore ?? new PinStore();
		this.firstPairBackoff = opts.firstPairBackoff ?? new FirstPairBackoff();
		this.discoveryService = opts.discoveryService ?? new DiscoveryService({
			pins: this.pinStore,
			nativeBootstrap: { bootstrap: async (o) => {
				const result = await this.bootstrap.discover({
					allowLaunch: o.allowLaunch,
					...o.bindingPub === void 0 ? {} : { bindingPub: o.bindingPub }
				});
				return {
					port: result.wsPort,
					nonce: result.nonce,
					nmTicket: result.nmTicket ?? void 0
				};
			} }
		});
		this.remoteDiscoveryService = opts.remoteDiscoveryService ?? new RemoteDiscoveryService();
		this.createFrameChannel = opts.createFrameChannel ?? (() => new WebSocketFrameChannel());
		this.createPairingFlow = opts.createPairingFlow ?? ((deps) => new PairingFlow(deps));
		this.createReconnectFlow = opts.createReconnectFlow ?? ((deps) => new ReconnectFlow(deps));
		this.createEnvelopeConnection = opts.createEnvelopeConnection ?? ((socket, envelope, queuedFrames) => createMdxpConnection(new EnvelopeMessageReader(socket, envelope, queuedFrames), new EnvelopeMessageWriter(socket, envelope)));
	}
	getState() {
		return this.state;
	}
	/** Message of the most recent connect/reconnect failure; null after
	*  a successful handshake. UI surfaces this in the popup. */
	getLastError() {
		return this.lastErrorMessage;
	}
	/** `PairingFlowError`/`ReconnectFlowError.reason` behind the last failure,
	*  or `null` if the last failure wasn't one of those (or there was none).
	*  `'backoffLocked'` is what a UI checks for to show the §7.3 backoff
	*  state; see `getLastErrorRetryAtMs()` for the retry time to pair with it. */
	getLastErrorReason() {
		return this.lastErrorReason;
	}
	/** The client's own `FirstPairBackoff`-computed retry time for the last
	*  `'backoffLocked'` failure, or `null`. Never derived from anything the
	*  peer reported. */
	getLastErrorRetryAtMs() {
		return this.lastErrorRetryAtMs;
	}
	/**
	* The pairing-code prompt currently awaiting the user, or `null`.
	* Non-null exactly while the state is `awaiting-code` — the read is
	* gated on the state, so a stopped or superseded attempt's prompt
	* vanishes from every polling surface at once even though the provider
	* promise itself cannot be cancelled (§7.2's timeout reaps it later).
	*/
	getPendingPairingCode() {
		const pending = this.pendingPairingCode;
		return this.state === "awaiting-code" && pending !== null && this.presentationEndpointIncarnation !== null && isSameEndpointIncarnation(pending.owner, this.presentationEndpointIncarnation) ? pending : null;
	}
	/**
	* Wraps a function-typed code source so the state machine owns the
	* "awaiting the user's code" phase: entered when the flow invokes the
	* provider, left when it settles. The restore is guarded — it never
	* resurrects a state that `stop()` or supersession already moved on
	* from. String sources (fixed test codes) pass through untouched.
	*/
	wrapPairingCodeSource(source, scope) {
		if (typeof source !== "function") return source;
		const provider = async (request) => {
			this.ensureCurrentAttempt(scope.generation);
			const pending = {
				request,
				deadlineMs: Date.now() + request.timeoutMs,
				owner: scope
			};
			this.pendingPairingCode = pending;
			this.setState("awaiting-code");
			try {
				return await source(request);
			} finally {
				if (this.pendingPairingCode === pending) {
					this.pendingPairingCode = null;
					if (this.isCurrentAttempt(scope.generation) && this.state === "awaiting-code") this.setState("handshaking");
				}
			}
		};
		return provider;
	}
	/** Records an explicit candidate choice (from `bg.chooseCandidate`) for
	*  the next explicit lifecycle intent to use instead of
	*  `discoverForFirstPair`'s own top-ranked result. `connect()` or
	*  `clearGateAndStart()` claims and clears it synchronously, before any
	*  await, so a stopped/superseded discovery cannot leak the choice into a
	*  later pairing session. */
	choosePairCandidate(port) {
		this.preferredCandidatePort = port;
	}
	takePreferredCandidatePort() {
		const port = this.preferredCandidatePort;
		this.preferredCandidatePort = null;
		return port;
	}
	/**
	* Sweeps for live local candidates to pair with, for a picker UI to show
	* before the user commits to one. Read-only — this does not affect any
	* in-flight `connect()` attempt and does not itself start pairing;
	* `choosePairCandidate` + `connect()`/`clearGateAndStart()` does that.
	*/
	async listPairCandidates(opts) {
		return (await this.discoveryService.discoverForFirstPair(opts)).map((r) => ({
			port: r.wsPort,
			instanceId: r.instanceId ?? null,
			appVersion: r.appVersion ?? null
		}));
	}
	/** Capabilities reported by the server during initialize handshake; null
	*  until the first successful handshake. */
	getServerCapabilities() {
		return this.serverCapabilities;
	}
	/** Identity reported by the backend during the latest successful handshake. */
	getServerIdentity() {
		return this.serverIdentity === null ? null : { ...this.serverIdentity };
	}
	/**
	* Whether this session's pairing completed without native-host
	* attestation — no proof of *which* Motrix answered, though the pairing
	* itself was still mutually authenticated by the code. `null` when no
	* first-pair has run this session (see the field doc on `degraded`).
	*/
	getDegraded() {
		return this.degraded;
	}
	/**
	* Issue a typed MDXP request over the live connection. Used by the
	* background control-plane proxy (popup → bg.* → here → WS). Throws if the
	* session is not connected — callers surface that to the popup as an error.
	*/
	async request(method, params) {
		const conn = this.currentConn;
		if (conn === null || this.state !== "connected") throw new Error(`bridge not connected (state: ${this.state})`);
		return await this.withTimeout(conn.sendRequest(method, params), this.requestTimeoutMs, String(method));
	}
	/** Hand a browser-detected download to Motrix (the page-shaped submit path).
	*  The trigger gesture (resolve active tab → build these params) lands with
	*  real adapter extraction; this is the reachable, typed submit capability. */
	async submitDownload(params, options = {}) {
		options.assertCurrent?.();
		let outbound = params;
		const scope = this.currentEndpointScope;
		if (scope?.authority.kind === "remote") {
			const conn = this.currentConn;
			const instanceId = this.currentAuthenticatedInstanceId;
			if (instanceId === null || conn === null) throw new Error("authenticated remote instance is unavailable");
			const policy = await this.remotePolicyFor(scope, instanceId).get();
			this.ensureCurrentConnection(scope.generation, conn);
			if (options.automaticTakeover && !policy.allowAutomaticTakeover) throw new RemoteAutomaticTakeoverConsentRequiredError();
			outbound = applyRemoteSubmitPolicy(params, policy);
		}
		const withKey = outbound.idempotencyKey ? outbound : {
			...outbound,
			idempotencyKey: crypto.randomUUID()
		};
		options.assertCurrent?.();
		return this.request(Methods.DownloadSubmit, withKey);
	}
	/** Current remote authority's consent, bound to the MBP1-authenticated
	* instance. Local or disconnected sessions have no remote policy surface. */
	async getRemoteBackendPolicy() {
		const scope = this.currentEndpointScope;
		const instanceId = this.currentAuthenticatedInstanceId;
		if (scope?.authority.kind !== "remote" || instanceId === null) return null;
		return this.remotePolicyFor(scope, instanceId).get();
	}
	/** Replace the complete remote grant set. Callback/takeover grants remain
	* unavailable in this beta because the remote initialize path deliberately
	* registers none of those handlers. Any change closes the live channel so
	* the next connection renegotiates capabilities from the new policy. */
	async replaceRemoteBackendPolicy(replacement) {
		if (replacement.allowServerUrlProbe || replacement.allowServerUrlResolve || replacement.allowAutomaticTakeover) throw new Error("remote callback and automatic takeover grants unavailable");
		const scope = this.currentEndpointScope;
		const instanceId = this.currentAuthenticatedInstanceId;
		if (scope?.authority.kind !== "remote" || instanceId === null) throw new Error("no authenticated remote Server is active");
		const store = this.remotePolicyFor(scope, instanceId);
		await store.replace(replacement);
		const policy = await store.get();
		this.stop();
		await this.connect({
			allowLaunch: false,
			userInitiated: true
		});
		return policy;
	}
	/** Cancel a previously submitted download by its task id. */
	async cancelDownload(taskId) {
		await this.request(Methods.DownloadCancel, { taskId });
	}
	onStateChange(cb) {
		this.stateListeners.push(cb);
	}
	onActivityChange(cb) {
		this.taskEvents.onChange(cb);
	}
	hasActiveTasks() {
		return this.taskEvents.size > 0;
	}
	setState(s) {
		if (this.state === s) return;
		this.state = s;
		for (const cb of this.stateListeners) cb(s);
	}
	clearPresentationVerdict() {
		this.lastErrorMessage = null;
		this.lastErrorReason = null;
		this.lastErrorRetryAtMs = null;
		this.pendingPairingCode = null;
	}
	adoptPresentationEndpoint(incarnation) {
		if (this.presentationEndpointIncarnation !== null && isSameEndpointIncarnation(this.presentationEndpointIncarnation, incarnation)) return;
		this.clearPresentationVerdict();
		this.presentationEndpointIncarnation = incarnation;
	}
	endpointIncarnationFromAttempt(attempt) {
		if (attempt.authority.kind === "local") return {
			activeEndpointId: LOCAL_ENDPOINT_ID,
			endpointConfig: { mode: "local" },
			authority: LOCAL_BACKEND_AUTHORITY,
			gate: this.gate
		};
		if (attempt.canonicalWsBase === null) throw new StaleConnectionAttemptError();
		const endpointConfig = {
			mode: "remote",
			endpointId: attempt.endpointId,
			remoteUrl: attempt.canonicalWsBase,
			revision: attempt.revision
		};
		return {
			activeEndpointId: attempt.endpointId,
			endpointConfig,
			authority: attempt.authority,
			gate: ConnectionGate.forAuthority(attempt.authority)
		};
	}
	bindAttemptScope(incarnation, generation, lease, mutation) {
		const credentials = this.credentialStore.forAttempt(incarnation.authority, mutation);
		return {
			...incarnation,
			generation,
			lease,
			mutation,
			credentials
		};
	}
	async captureEndpointAttempt(generation, expected = null) {
		this.ensureCurrentAttempt(generation);
		const lease = await this.endpointLifecycleService.issueBackendAttemptLease(expected?.activeEndpointId);
		this.ensureCurrentAttempt(generation);
		return this.endpointLifecycleService.runWithBackendAttemptLease(lease, async (attempt) => {
			this.ensureCurrentAttempt(generation);
			const incarnation = this.endpointIncarnationFromAttempt(attempt);
			if (expected !== null && !isSameEndpointIncarnation(incarnation, expected)) throw new StaleConnectionAttemptError();
			this.adoptPresentationEndpoint(incarnation);
			const mutation = this.endpointLifecycleService.bindBackendAttemptLease(lease, (currentAttempt) => {
				this.ensureCurrentAttempt(generation);
				if (!isSameEndpointIncarnation(this.endpointIncarnationFromAttempt(currentAttempt), incarnation)) throw new StaleConnectionAttemptError();
			});
			return this.bindAttemptScope(incarnation, generation, lease, mutation);
		});
	}
	/**
	* The only path from a live attempt to durable gate/credential mutation.
	* The coordinator is held for one storage operation, never for discovery,
	* network I/O, user code entry, or the MDXP handshake.
	*/
	async runEndpointMutation(scope, operation) {
		return scope.mutation.run(async (attempt) => {
			this.ensureCurrentAttempt(scope.generation);
			if (!isSameEndpointIncarnation(this.endpointIncarnationFromAttempt(attempt), scope)) throw new StaleConnectionAttemptError();
			const result = await operation();
			this.ensureCurrentAttempt(scope.generation);
			return result;
		});
	}
	remotePolicyFor(scope, authenticatedInstanceId) {
		if (scope.authority.kind !== "remote") throw new Error("remote policy requires a remote authority");
		return createLeaseBoundRemoteBackendPolicyStore(scope.authority, authenticatedInstanceId, scope.mutation);
	}
	ownPreAuthChannel(channel, generation) {
		this.ensureCurrentAttempt(generation);
		if (this.preAuthChannel !== null && this.preAuthChannel !== channel) {
			try {
				channel.close();
			} catch {}
			throw new StaleConnectionAttemptError();
		}
		this.preAuthChannel = channel;
	}
	closePreAuthChannel(channel) {
		if (channel !== void 0 && this.preAuthChannel !== channel) {
			try {
				channel.close();
			} catch {}
			return;
		}
		const owned = this.preAuthChannel;
		this.preAuthChannel = null;
		if (owned === null) return;
		try {
			owned.close();
		} catch {}
	}
	releasePreAuthChannel(channel, generation) {
		this.ensureCurrentAttempt(generation);
		if (this.preAuthChannel !== channel) throw new StaleConnectionAttemptError();
		const released = channel.release();
		this.preAuthChannel = null;
		return released;
	}
	/**
	* Unified connect entry. `allowLaunch` and `userInitiated` answer two
	* different questions and MUST NOT be conflated even though every caller
	* today happens to pass the same value for both:
	*
	* - `allowLaunch`: may this attempt wake Motrix via the native host
	*   (`NativeBootstrap`)? Forwarded to the discovery chain.
	* - `userInitiated`: did an actual human ask for this attempt, as opposed
	*   to an automatic background one (SW-startup autostart, or the single
	*   probe-reconnect after a socket closes)? Consulted only by
	*   `connectLocalMbp1`, which refuses to fall through to fresh
	*   code-entry pairing once the recovery order is exhausted unless this
	*   is `true` — see `RecoveryExhaustedUnattendedError`.
	*
	* Single attempt only. On failure: enters denied (if pair denied/revoked)
	* or returns to disconnected (dormant). No backoff loop.
	*
	* Respects the connection gate: if a pair attempt is pending or a denial
	* is recorded, surfaces the prior state without re-attempting.
	*/
	async connect(opts) {
		await this.connectExpected(opts, null, this.takePreferredCandidatePort());
	}
	async connectExpected(opts, expected, preferredCandidatePort = null) {
		if (this.state !== "disconnected" && this.state !== "denied") {
			log.warn("connect called in state", this.state);
			return;
		}
		const generation = ++this.generation;
		if (this.state === "denied") {
			this.lastErrorMessage = null;
			this.lastErrorReason = null;
			this.lastErrorRetryAtMs = null;
			this.setState("disconnected");
		}
		let scope = null;
		try {
			const attemptScope = await this.captureEndpointAttempt(generation, expected);
			scope = attemptScope;
			this.ensureCurrentAttempt(generation);
			const shouldAutoConnect = await this.runEndpointMutation(attemptScope, () => attemptScope.gate.shouldAutoConnect());
			if (!this.isCurrentAttempt(generation)) return;
			if (!shouldAutoConnect) {
				const gateState = await this.runEndpointMutation(attemptScope, () => attemptScope.gate.get());
				if (!this.isCurrentAttempt(generation)) return;
				log.info(`connect gated (reason=${gateState.reason ?? "unknown"}); awaiting explicit reconnect.`);
				this.lastErrorMessage = gateState.lastError;
				this.lastErrorReason = null;
				this.lastErrorRetryAtMs = null;
				this.setState(gateState.reason === "denied" ? "denied" : "disconnected");
				return;
			}
			if (!this.isCurrentAttempt(generation) || this.state !== "disconnected") {
				log.warn(`connect raced past gate; aborting (state: ${this.state})`);
				return;
			}
			this.lastErrorMessage = null;
			this.lastErrorReason = null;
			this.lastErrorRetryAtMs = null;
			await this.connectOnce(opts.allowLaunch, opts.userInitiated, attemptScope, preferredCandidatePort);
		} catch (e) {
			if (!this.isCurrentAttempt(generation)) return;
			this.lastErrorMessage = e.message;
			const detail = e;
			this.lastErrorReason = typeof detail.reason === "string" ? detail.reason : null;
			this.lastErrorRetryAtMs = typeof detail.retryAtMs === "number" ? detail.retryAtMs : null;
			const { level, reason } = classifyConnectError(e);
			if (level === "error") log.error("connect failed", e);
			else log[level](`not connected: ${reason}`);
			if (this.shouldEnterDenied(e)) await this.enterDenied(e, scope, generation);
			else this.stopCurrentAttempt();
		}
	}
	/**
	* SW-startup auto-attach: only if previously paired, and never wakes
	* Motrix (allowLaunch:false = probe-only).
	*
	* Both local and remote endpoints require an authority-scoped committed
	* MBP1 credential before any discovery or socket work. Token-era storage is
	* never a proof of pairing and is never consulted.
	*/
	async autostart() {
		const generation = this.generation;
		const scope = await this.captureEndpointAttempt(generation);
		if (!this.isCurrentAttempt(generation)) return;
		const principal = {
			browser: this.opts.clientInfo.browser,
			verifiedOrigin: computeVerifiedOrigin(),
			clientInstallationId: await getClientInstallationId()
		};
		if (!this.isCurrentAttempt(generation)) return;
		const order = await scope.credentials.recoverOrder(principal);
		if (!this.isCurrentAttempt(generation)) return;
		if (order.length === 0) {
			log.info("autostart: no stored credential → dormant");
			return;
		}
		await this.connectExpected({
			allowLaunch: false,
			userInitiated: false
		}, scope);
	}
	/**
	* Explicit user-triggered reconnect. Clears the gate so the next SW
	* restart can auto-connect again, then connects wake-authorized and
	* user-initiated. This is the only caller that passes `userInitiated:
	* true` — every automatic path (`autostart`, the post-close probe-
	* reconnect) passes `false` for both.
	*
	* Four call sites, all downstream of a real click: `bg.reconnect` (popup
	* "Connect"), `bg.chooseCandidate` (the "Pair" dialog),
	* `EndpointCatalogService.afterConnectionChange`, and
	* `makeOps.connectWithLaunch`. The last two are worth naming explicitly,
	* since "a human asked for *this*" takes some interpreting there:
	* switching the backend selector to the local App while unpaired, and a
	* right-click "Download with Motrix" on an unpaired endpoint, both reach
	* this method — and therefore `/pair` — as a side effect of an action that
	* was not itself "pair". Both are treated as user-initiated on purpose:
	* choosing that backend, or explicitly asking to download via Motrix, is
	* already an expressed intent to use it, and offering to pair is the
	* right response to either. Recorded here so the next reader finds a
	* decision, not an oversight.
	*/
	clearGateAndStart() {
		const active = this.explicitConnectFlight;
		if (active !== null) return active;
		const flight = this.runExplicitConnect();
		this.explicitConnectFlight = flight;
		const release = () => {
			if (this.explicitConnectFlight === flight) this.explicitConnectFlight = null;
		};
		flight.then(release, release);
		return flight;
	}
	async runExplicitConnect() {
		const preferredCandidatePort = this.takePreferredCandidatePort();
		if (this.state === "awaiting-code") return;
		const revocationCleanup = this.pendingRevocationCleanup;
		if (revocationCleanup !== null) await revocationCleanup;
		const intentGeneration = this.generation;
		const intent = await this.captureEndpointAttempt(intentGeneration);
		await this.runEndpointMutation(intent, () => intent.gate.clear());
		if (this.state !== "disconnected" && this.state !== "denied") this.stopCurrentAttempt();
		await this.connectExpected({
			allowLaunch: true,
			userInitiated: true
		}, intent, preferredCandidatePort);
	}
	stop() {
		this.explicitConnectFlight = null;
		this.stopCurrentAttempt();
	}
	stopCurrentAttempt() {
		this.generation += 1;
		this.preferredCandidatePort = null;
		this.pendingPairingCode = null;
		this.closePreAuthChannel();
		try {
			this.client.close();
		} catch {}
		if (this.currentMbp1Socket !== null) {
			try {
				this.currentMbp1Socket.close();
			} catch {}
			this.currentMbp1Socket = null;
		}
		this.currentConn = null;
		this.currentEndpointScope = null;
		this.currentAuthenticatedInstanceId = null;
		this.serverCapabilities = null;
		this.serverIdentity = null;
		this.degraded = null;
		this.taskEvents.clear();
		this.setState("disconnected");
	}
	/** Stop because the selected endpoint is about to change. Unlike a normal
	* transport stop after a failed attempt, this synchronously retires the
	* old endpoint's process-local verdict before listeners render the
	* disconnected transition. Durable gate/error state remains in its own
	* authority namespace and can be shown again only if that endpoint is
	* selected later. */
	stopForEndpointChange() {
		this.clearPresentationVerdict();
		this.presentationEndpointIncarnation = null;
		this.stop();
	}
	async connectOnce(allowLaunch, userInitiated, scope, preferredCandidatePort) {
		const { generation, endpointConfig } = scope;
		this.ensureCurrentAttempt(generation);
		const seq = ++this.attemptSeq;
		this.serverIdentity = null;
		this.degraded = null;
		this.setState("bootstrapping");
		log.info(`[connect#${seq}] connectOnce start; mode=${endpointConfig.mode} allowLaunch=${allowLaunch} userInitiated=${userInitiated}`);
		if (endpointConfig.mode === "local") {
			await this.connectLocalMbp1(seq, allowLaunch, userInitiated, scope, preferredCandidatePort);
			return;
		}
		await this.connectRemoteMbp1(seq, userInitiated, scope);
	}
	async connectRemoteMbp1(seq, userInitiated, scope) {
		const { generation, authority } = scope;
		if (authority.kind !== "remote") throw new StaleConnectionAttemptError();
		const principal = {
			browser: this.opts.clientInfo.browser,
			verifiedOrigin: computeVerifiedOrigin(),
			clientInstallationId: await getClientInstallationId()
		};
		this.ensureCurrentAttempt(generation);
		const now = Date.now();
		await scope.credentials.ageOutUnacked(now);
		await scope.credentials.cleanupFirstPairOrphans(principal, now);
		const order = await scope.credentials.recoverOrder(principal);
		this.ensureCurrentAttempt(generation);
		const route = deriveRemoteBridgeRoute(authority);
		const discovery = await this.remoteDiscoveryService.discover(route);
		this.ensureCurrentAttempt(generation);
		if (discovery.status === "incompatible") throw new BackendCompatibilityError(discovery.reason, discovery.reason === "extensionUpgradeRequired" ? "the configured Server requires a newer extension" : "the configured Server requires a newer Motrix version");
		if (discovery.status !== "compatible") throw new RemoteConnectionError("remoteDiscoveryUnavailable", `remote Motrix Server discovery is unavailable (${discovery.detail})`);
		this.setState("connecting");
		for (const credential of order) {
			const instanceId = credential.authenticatedInstanceId;
			if (instanceId === null || instanceId === void 0) continue;
			const channel = this.createFrameChannel();
			this.ownPreAuthChannel(channel, generation);
			try {
				this.lastConnectUrl = route.v1Url;
				const result = await this.createReconnectFlow({
					channel,
					creds: scope.credentials,
					pins: this.pinStore,
					isCurrent: () => this.isCurrentAttempt(generation)
				}).run({
					credential,
					discovery: {
						transport: "probe",
						wsPort: 0,
						instanceId: discovery.untrustedDocument.instanceId,
						appVersion: discovery.untrustedDocument.appVersion,
						compatibility: "compatible"
					},
					principal,
					instanceId,
					remoteV1Url: route.v1Url
				});
				this.ensureCurrentAttempt(generation);
				await this.finishMbp1Connection(channel, result.envelope, scope, seq, false, instanceId);
				return;
			} catch (error) {
				this.closePreAuthChannel(channel);
				this.ensureCurrentAttempt(generation);
				if (error instanceof ReconnectFlowError) {
					if (error.reason === "channelUnavailable" || error.reason === "internalError") {
						if (error.reason === "channelUnavailable") throw new RemoteConnectionError("remoteTransportUnavailable", "the remote Motrix WebSocket could not be opened");
						throw error;
					}
					continue;
				}
				throw error;
			}
		}
		if (!userInitiated) throw new RecoveryExhaustedUnattendedError();
		if (this.opts.pairingCodeSource === void 0) throw new Error("first-pair requires a pairing code source; none configured");
		const nonce = await this.remoteDiscoveryService.requestNonce(discovery);
		this.ensureCurrentAttempt(generation);
		if (nonce.status !== "ready") throw new RemoteConnectionError("remotePairingUnavailable", "remote Motrix Server pairing nonce is unavailable");
		const codeSource = this.wrapPairingCodeSource(this.opts.pairingCodeSource, scope);
		const channel = this.createFrameChannel();
		this.ownPreAuthChannel(channel, generation);
		try {
			const pairUrl = remotePairUrl(route, nonce.nonce);
			this.lastConnectUrl = pairUrl;
			const result = await this.createPairingFlow({
				channel,
				creds: scope.credentials,
				pins: this.pinStore,
				backoff: this.firstPairBackoff,
				isCurrent: () => this.isCurrentAttempt(generation)
			}).run({
				code: codeSource,
				discovery: {
					transport: "probe",
					wsPort: 0,
					nonce: nonce.nonce,
					instanceId: discovery.untrustedDocument.instanceId,
					appVersion: discovery.untrustedDocument.appVersion,
					compatibility: "compatible"
				},
				principal,
				claimedExtensionId: this.opts.clientInfo.extensionId,
				remotePairUrl: pairUrl
			});
			this.degraded = true;
			this.ensureCurrentAttempt(generation);
			await this.finishMbp1Connection(channel, result.envelope, scope, seq, true, result.instanceId);
		} catch (error) {
			this.closePreAuthChannel(channel);
			if (error instanceof PairingFlowError && error.reason === "channelUnavailable") throw new RemoteConnectionError("remoteTransportUnavailable", "the remote Motrix pairing WebSocket could not be opened");
			throw error;
		}
	}
	/**
	* The local-endpoint half of `connectOnce`: MBP1 (§6/§8) end to end,
	* entirely replacing the retired NM-discover + token path for this
	* mode. Owns its own state transitions and its own call into
	* `doInitialize` — `connectOnce` does not fall through to the remote-only
	* code after this returns.
	*
	* The `Principal` computed here (verifiedOrigin, clientInstallationId,
	* browser) is what every MBP1 module downstream consumes but nothing
	* before this task constructed — see `verified-origin.ts`'s doc for why
	* `verifiedOrigin` in particular must be exact.
	*/
	async connectLocalMbp1(seq, allowLaunch, userInitiated, scope, preferredCandidatePort) {
		const { generation } = scope;
		const principal = {
			browser: this.opts.clientInfo.browser,
			verifiedOrigin: computeVerifiedOrigin(),
			clientInstallationId: await getClientInstallationId()
		};
		this.ensureCurrentAttempt(generation);
		const now = Date.now();
		await scope.credentials.ageOutUnacked(now);
		this.ensureCurrentAttempt(generation);
		await scope.credentials.cleanupFirstPairOrphans(principal, now);
		this.ensureCurrentAttempt(generation);
		const order = await scope.credentials.recoverOrder(principal);
		this.ensureCurrentAttempt(generation);
		this.setState("connecting");
		for (const credential of order) {
			const discovered = await this.discoveryService.discoverForReconnect(credential.credentialId);
			this.ensureCurrentAttempt(generation);
			if (discovered === null) continue;
			const pin = await this.pinStore.get(credential.credentialId);
			this.ensureCurrentAttempt(generation);
			const instanceId = pin?.instanceId ?? discovered.instanceId;
			if (instanceId === void 0) continue;
			const url = reconnectUrl(discovered.wsPort);
			this.lastConnectUrl = url;
			log.info(`[connect#${seq}] MBP1 reconnect attempt port=${discovered.wsPort}`);
			const channel = this.createFrameChannel();
			this.ownPreAuthChannel(channel, generation);
			let result;
			try {
				result = await this.createReconnectFlow({
					channel,
					creds: scope.credentials,
					pins: this.pinStore,
					isCurrent: () => this.isCurrentAttempt(generation)
				}).run({
					credential,
					discovery: discovered,
					principal,
					instanceId
				});
			} catch (error) {
				this.closePreAuthChannel(channel);
				this.ensureCurrentAttempt(generation);
				if (error instanceof ReconnectFlowError) {
					if (error.reason === "channelUnavailable" || error.reason === "internalError") throw error;
					log.info(`[connect#${seq}] MBP1 reconnect candidate failed (${error.reason}); trying next stored credential`);
					continue;
				}
				throw error;
			}
			try {
				this.ensureCurrentAttempt(generation);
				await this.finishMbp1Connection(channel, result.envelope, scope, seq, false);
			} catch (error) {
				this.closePreAuthChannel(channel);
				throw error;
			}
			return;
		}
		if (!userInitiated) throw new RecoveryExhaustedUnattendedError();
		await this.connectFirstPairMbp1(seq, allowLaunch, scope, principal, preferredCandidatePort);
	}
	/**
	* §6: fresh code-entry pairing. Reached only when `connectLocalMbp1`'s
	* caller was `userInitiated` AND `recoverOrder`'s list is exhausted (or
	* was empty to begin with) — never on the first reconnect failure, and
	* never for an unattended attempt (see `RecoveryExhaustedUnattendedError`).
	*/
	async connectFirstPairMbp1(seq, allowLaunch, scope, principal, preferredCandidatePort) {
		const { generation } = scope;
		if (this.opts.pairingCodeSource === void 0) throw new Error("first-pair requires a pairing code source; none configured");
		const codeSource = this.wrapPairingCodeSource(this.opts.pairingCodeSource, scope);
		const bindingKeypair = generateBindingKeypair();
		const candidates = await this.discoveryService.discoverForFirstPair({
			allowLaunch,
			bindingPub: bindingKeypair.pub
		});
		this.ensureCurrentAttempt(generation);
		const candidate = preferredCandidatePort === null ? candidates[0] : candidates.find((c) => c.wsPort === preferredCandidatePort) ?? candidates[0];
		if (candidate === void 0) throw new Error("no Motrix instance found to pair with");
		const preflighted = await this.discoveryService.preflightCompatibility(candidate);
		this.ensureCurrentAttempt(generation);
		this.assertBackendCompatibility(preflighted);
		const withNonce = await this.discoveryService.ensureNonce(preflighted);
		this.ensureCurrentAttempt(generation);
		if (withNonce === null || withNonce.nonce === void 0) throw new Error("could not obtain a §4.2 pairing nonce");
		this.degraded = withNonce.nmTicket === void 0;
		const url = pairUrl(withNonce.wsPort, withNonce.nonce);
		this.lastConnectUrl = url;
		log.info(`[connect#${seq}] MBP1 first-pair attempt port=${withNonce.wsPort}`);
		const channel = this.createFrameChannel();
		this.ownPreAuthChannel(channel, generation);
		try {
			const result = await this.createPairingFlow({
				channel,
				creds: scope.credentials,
				pins: this.pinStore,
				backoff: this.firstPairBackoff,
				isCurrent: () => this.isCurrentAttempt(generation)
			}).run({
				code: codeSource,
				discovery: withNonce,
				principal,
				claimedExtensionId: this.opts.clientInfo.extensionId,
				...withNonce.nmTicket === void 0 ? {} : { bindingKeypair }
			});
			this.ensureCurrentAttempt(generation);
			await this.finishMbp1Connection(channel, result.envelope, scope, seq, true);
		} catch (error) {
			this.closePreAuthChannel(channel);
			throw error;
		}
	}
	/**
	* Shared tail for both MBP1 branches: hand the live socket from the
	* pre-auth channel to a fresh envelope-wrapped transport layer, then run
	* the same `doInitialize` the remote path uses. This ordering matters:
	* MBP1 authenticates *below* MDXP, so `motrix/initialize` must be the
	* first application message and it must travel inside the envelope,
	* never before it.
	*/
	async finishMbp1Connection(channel, envelope, scope, seq, isFirstPair, authenticatedInstanceId = null) {
		const { generation } = scope;
		const { socket, queuedFrames } = this.releasePreAuthChannel(channel, generation);
		let conn;
		try {
			conn = this.createEnvelopeConnection(socket, envelope, queuedFrames);
		} catch (error) {
			try {
				socket.close();
			} catch {}
			throw error;
		}
		if (!this.isCurrentAttempt(generation)) {
			try {
				conn.dispose();
			} catch {}
			try {
				socket.close();
			} catch {}
			throw new StaleConnectionAttemptError();
		}
		this.currentConn = conn;
		this.currentMbp1Socket = socket;
		socket.addEventListener("close", () => this.handleClose(generation, conn));
		this.ensureCurrentConnection(generation, conn);
		this.setState("handshaking");
		if (isFirstPair) {
			this.ensureCurrentConnection(generation, conn);
			await this.runEndpointMutation(scope, () => scope.gate.pausePending());
			this.ensureCurrentConnection(generation, conn);
		}
		log.info(`[connect#${seq}] MBP1 handshake starting (firstPair=${isFirstPair})`);
		await this.doInitialize(conn, scope, generation, authenticatedInstanceId);
		this.ensureCurrentConnection(generation, conn);
		this.ensureCurrentConnection(generation, conn);
		await this.runEndpointMutation(scope, () => scope.gate.clear());
		this.ensureCurrentConnection(generation, conn);
		this.taskEvents.clear();
		this.currentEndpointScope = scope;
		this.currentAuthenticatedInstanceId = authenticatedInstanceId;
		this.setState("connected");
		this.lastErrorMessage = null;
		this.lastErrorReason = null;
		this.lastErrorRetryAtMs = null;
	}
	async doInitialize(conn, scope, generation, authenticatedInstanceId) {
		const allowBrowserData = scope.endpointConfig.mode === "local";
		const remotePolicy = scope.authority.kind === "remote" && authenticatedInstanceId !== null ? await this.remotePolicyFor(scope, authenticatedInstanceId).get() : null;
		this.ensureCurrentConnection(generation, conn);
		const allowRemoteSubmit = remotePolicy !== null && remotePolicy.remoteDataBoundaryAcceptedAt !== null;
		const adapters = allowBrowserData ? this.opts.adapterRegistry?.list() ?? [] : [];
		const canResolve = allowBrowserData && this.opts.resolutionDispatcher !== void 0 && adapters.length > 0;
		if (adapters.length > 0 && this.opts.adapterRegistry) {
			const registry = this.opts.adapterRegistry;
			conn.onRequest(Methods.UrlProbe, async (params) => {
				if (!this.isCurrentConnection(generation, conn)) return { handled: false };
				const found = registry.findFor(params.url);
				return found ? {
					handled: true,
					adapterId: found.id,
					confidence: "high"
				} : { handled: false };
			});
		}
		if (canResolve && this.opts.resolutionDispatcher) {
			const dispatcher = this.opts.resolutionDispatcher;
			conn.onRequest(Methods.UrlResolve, async (params) => {
				this.ensureCurrentConnection(generation, conn);
				return await dispatcher.resolve(params.url, params.preferences);
			});
		}
		conn.onNotification(Notifications.TaskProgress, (p) => {
			if (!this.isCurrentConnection(generation, conn)) return;
			this.taskEvents.recordProgress(p);
		});
		conn.onNotification(Notifications.TaskCompleted, (p) => {
			if (!this.isCurrentConnection(generation, conn)) return;
			this.taskEvents.take(p.taskId);
			const name = p.filePath.split("/").pop() ?? p.filePath;
			this.notify({
				title: instance.t("notify.downloadComplete"),
				message: name,
				severity: "confirm"
			});
		});
		conn.onNotification(Notifications.TaskError, (p) => {
			if (!this.isCurrentConnection(generation, conn)) return;
			this.taskEvents.take(p.taskId);
			this.notify({
				title: instance.t("notify.downloadFailed"),
				message: p.message,
				severity: "error"
			});
		});
		conn.onNotification(Notifications.PairRevoked, (params) => {
			if (!this.isCurrentConnection(generation, conn)) return;
			this.handlePairRevoked(params.reason, scope, generation, conn);
		});
		this.ensureCurrentConnection(generation, conn);
		conn.listen();
		const rawResult = await this.withTimeout(conn.sendRequest(Methods.MotrixInitialize, {
			protocolVersion: "1.0",
			client: this.opts.clientInfo,
			capabilities: {
				submitDownload: allowBrowserData || allowRemoteSubmit,
				resolveUrl: canResolve,
				probeUrl: adapters.length > 0,
				cancellation: true,
				progress: true
			},
			adapters
		}), this.initializeTimeoutMs, Methods.MotrixInitialize);
		this.ensureCurrentConnection(generation, conn);
		const parsedResult = InitializeResultSchema.safeParse(rawResult);
		if (!parsedResult.success) {
			const reason = initializeCompatibilityFailureReason(rawResult);
			throw new BackendCompatibilityError(reason, reason === "extensionUpgradeRequired" ? "the authenticated Motrix backend requires a newer extension protocol version" : reason === "unsupportedRemote" ? "the authenticated Motrix runtime does not support browser-extension pairing" : "the authenticated Motrix backend returned an incompatible motrix/initialize result; update Motrix");
		}
		const result = parsedResult.data;
		const expectedRuntime = scope.endpointConfig.mode === "local" ? "electron" : "server";
		if (result.server.runtime !== expectedRuntime) throw new BackendCompatibilityError("unsupportedRemote", `the authenticated Motrix runtime is not the configured ${expectedRuntime} backend`);
		this.ensureCurrentConnection(generation, conn);
		this.serverIdentity = {
			...result.server,
			...authenticatedInstanceId === null ? {} : { instanceId: authenticatedInstanceId }
		};
		this.captureCapabilities(result.capabilities);
		conn.sendNotification(Notifications.MotrixInitialized, void 0);
	}
	async withTimeout(operation, timeoutMs, label) {
		let timer = null;
		try {
			const timeout = new Promise((_resolve, reject) => {
				timer = setTimeout(() => reject(/* @__PURE__ */ new Error(`${label} timed out after ${timeoutMs}ms`)), timeoutMs);
			});
			return await Promise.race([operation, timeout]);
		} finally {
			if (timer !== null) clearTimeout(timer);
		}
	}
	handleClose(generation, conn) {
		if (!this.isCurrentConnection(generation, conn)) return;
		if (this.state === "disconnected" || this.state === "denied") return;
		log.info("WS closed; one probe-reconnect (allowLaunch:false)");
		this.stop();
		const reconnectGeneration = this.generation;
		setTimeout(() => {
			if (!this.isCurrentAttempt(reconnectGeneration) || this.state !== "disconnected") return;
			this.connect({
				allowLaunch: false,
				userInitiated: false
			});
		}, this.closeReconnectDelayMs);
	}
	/**
	* Handle the server's `$/pair/revoked` notification. Clears credentials,
	* pauses the gate (so SW restart doesn't re-pair) and enters 'denied'.
	* Reuses enterDenied so the ws-close that Motrix sends ~50ms
	* later is a no-op (handleClose bails on 'denied').
	*/
	async handlePairRevoked(reason, scope, generation, conn) {
		if (!this.isCurrentConnection(generation, conn)) return;
		log.info(`pairing revoked by Motrix (${reason})`);
		this.lastErrorMessage = `Pairing revoked by Motrix: ${reason}`;
		this.lastErrorReason = null;
		this.lastErrorRetryAtMs = null;
		this.notify({
			title: instance.t("notify.pairRevokedTitle"),
			message: instance.t("notify.pairRevokedBody"),
			severity: "reminder"
		});
		await this.enterDenied({
			code: ErrorCodes.PairRevoked,
			message: `Pairing revoked by Motrix: ${reason}`
		}, scope, generation, conn);
	}
	/**
	* Explicit pair-denial errors (user clicked Deny, or a credential was
	* revoked) MUST NOT trigger automatic reconnect — otherwise the ext loops
	* the NM bootstrap which keeps re-focusing Motrix's window and piling up
	* stale pair toasts. Session abort/expiry is intentionally not terminal:
	* neither proves an operator refusal. Terminate only the explicit cases and
	* surface lastError so the popup can offer an explicit retry.
	*/
	shouldEnterDenied(e) {
		const detail = e;
		if (detail?.pairErrorCode === "denied") return true;
		const code = detail?.code;
		return code === ErrorCodes.PermissionDenied || code === ErrorCodes.PairRevoked;
	}
	async enterDenied(e, sourceScope, generation, conn) {
		if (!this.isCurrentAttempt(generation)) return;
		if (conn !== void 0 && this.currentConn !== conn) return;
		const deniedGeneration = ++this.generation;
		const terminalScope = sourceScope === null ? null : this.bindAttemptScope(sourceScope, deniedGeneration, sourceScope.lease, this.endpointLifecycleService.bindBackendAttemptLease(sourceScope.lease, (attempt) => {
			this.ensureCurrentAttempt(deniedGeneration);
			if (!isSameEndpointIncarnation(this.endpointIncarnationFromAttempt(attempt), sourceScope)) throw new StaleConnectionAttemptError();
		}));
		this.closePreAuthChannel();
		const revocationCleanup = e?.code === ErrorCodes.PairRevoked ? Promise.resolve().then(async () => {
			await this.clearRevokedState(terminalScope);
			if (!this.isCurrentAttempt(deniedGeneration)) return;
			if (terminalScope === null) return;
			try {
				await this.runEndpointMutation(terminalScope, () => terminalScope.gate.pauseDenied(e.message ?? "pair denied"));
			} catch {}
		}) : null;
		if (revocationCleanup !== null) this.pendingRevocationCleanup = revocationCleanup;
		this.currentConn = null;
		this.currentEndpointScope = null;
		this.currentAuthenticatedInstanceId = null;
		this.serverCapabilities = null;
		this.serverIdentity = null;
		this.degraded = null;
		this.taskEvents.clear();
		this.setState("denied");
		try {
			this.client.close();
		} catch {}
		if (this.currentMbp1Socket !== null) {
			try {
				this.currentMbp1Socket.close();
			} catch {}
			this.currentMbp1Socket = null;
		}
		if (revocationCleanup !== null) {
			try {
				await revocationCleanup;
			} finally {
				if (this.pendingRevocationCleanup === revocationCleanup) this.pendingRevocationCleanup = null;
			}
			return;
		}
		if (!this.isCurrentAttempt(deniedGeneration)) return;
		if (terminalScope === null) return;
		try {
			await this.runEndpointMutation(terminalScope, () => terminalScope.gate.pauseDenied(e.message ?? "pair denied"));
		} catch {}
		if (!this.isCurrentAttempt(deniedGeneration)) return;
	}
	/**
	* Authenticated revocation invalidates every credential for the current
	* local principal. Pins are cleared first through CredentialStore's
	* transaction callback; an individual pin failure is non-authoritative and
	* must never preserve a credential key.
	*/
	async clearRevokedState(scope) {
		if (scope === null) return;
		try {
			const principal = {
				browser: this.opts.clientInfo.browser,
				verifiedOrigin: computeVerifiedOrigin(),
				clientInstallationId: await getClientInstallationId()
			};
			await scope.credentials.revokeAll(principal, scope.endpointConfig.mode === "local" ? async (revokedIds) => {
				for (const credentialId of revokedIds) try {
					await this.pinStore.clear(credentialId);
				} catch {}
			} : void 0);
		} catch {}
	}
	isCurrentAttempt(generation) {
		return this.generation === generation;
	}
	ensureCurrentAttempt(generation) {
		if (!this.isCurrentAttempt(generation)) throw new StaleConnectionAttemptError();
	}
	isCurrentConnection(generation, conn) {
		return this.isCurrentAttempt(generation) && this.currentConn === conn;
	}
	ensureCurrentConnection(generation, conn) {
		if (!this.isCurrentConnection(generation, conn)) throw new StaleConnectionAttemptError();
	}
	assertBackendCompatibility(result) {
		switch (result.compatibility) {
			case "compatible": return;
			case void 0:
			case "backendUpgradeRequired": throw new BackendCompatibilityError("backendUpgradeRequired", "this Motrix backend does not advertise compatible MBP1/MDXP capabilities; update Motrix");
			case "extensionUpgradeRequired": throw new BackendCompatibilityError(result.compatibility, "this Motrix backend requires a newer extension protocol version");
			case "unsupportedRemote": throw new BackendCompatibilityError(result.compatibility, "this Motrix runtime does not support browser-extension pairing");
		}
	}
	captureCapabilities(caps) {
		this.serverCapabilities = {
			ffmpegAvailable: caps.ffmpegAvailable,
			selectionKinds: [...caps.selectionKinds],
			taskReveal: caps.taskReveal === true
		};
	}
};
/**
* Classify a failed connect attempt into a log level so benign, expected
* states don't masquerade as errors:
*  - info : Motrix simply isn't running, or its native host isn't installed
*           yet (the normal state on SW wake before the user opens Motrix).
*  - warn : pairing not authorized, slow/aborted handshake — actionable but
*           not a crash.
*  - error: malformed protocol response or any unexpected fault — a real bug.
*/
function classifyConnectError(e) {
	const mdxpCode = e?.code;
	if (mdxpCode === ErrorCodes.PairRevoked || mdxpCode === ErrorCodes.PermissionDenied) return {
		level: "warn",
		reason: "pairing not authorized (denied or revoked)"
	};
	if (e instanceof RecoveryExhaustedUnattendedError) return {
		level: "info",
		reason: e.message
	};
	if (e instanceof NativeBootstrapError) {
		if (e.code === "unsupported") return {
			level: "info",
			reason: e.message
		};
		if (e.code === "host-error:motrix-not-running") return {
			level: "info",
			reason: "Motrix is not running"
		};
		if (e.code === "disconnect" && /not found|no such|forbidden|not installed/i.test(e.message)) return {
			level: "info",
			reason: "Motrix native host not installed"
		};
		if (e.code === "timeout" || e.code === "disconnect") return {
			level: "warn",
			reason: e.message
		};
		return {
			level: "error",
			reason: e.message
		};
	}
	return {
		level: "error",
		reason: e?.message ?? String(e)
	};
}
//#endregion
//#region src/background/capture/buildMediaSubmitParams.ts
function buildMediaSubmitParams(media, cookies, headers, audioCredentials = {
	cookies: [],
	headers: {}
}) {
	const primary = {
		url: media.url,
		headers,
		cookies,
		refererPolicy: "strict-origin-when-cross-origin"
	};
	const source = {
		pageUrl: media.pageUrl,
		pageTitle: media.pageTitle,
		detectedAt: media.detectedAt
	};
	const estimatedBytes = normalizeSize(media.sizeBytes);
	const meta = estimatedBytes === void 0 ? {
		suggestedFilename: deriveName(media),
		qualityLabel: "auto"
	} : {
		suggestedFilename: deriveName(media),
		qualityLabel: "auto",
		estimatedBytes
	};
	const buildMuxSelection = () => {
		const audioUrl = media.audioUrl ?? "";
		return {
			kind: "mux",
			video: {
				url: media.url,
				headers,
				cookies,
				refererPolicy: "strict-origin-when-cross-origin"
			},
			audio: {
				url: audioUrl,
				headers: audioCredentials.headers,
				cookies: audioCredentials.cookies,
				refererPolicy: "strict-origin-when-cross-origin"
			},
			container: "mp4"
		};
	};
	return {
		source,
		selection: media.kind === "direct" ? {
			kind: "direct",
			primary
		} : media.kind === "hls" ? {
			kind: "hls",
			primary,
			container: "mp4"
		} : media.kind === "dash" ? {
			kind: "dash",
			primary,
			container: "mp4"
		} : buildMuxSelection(),
		meta
	};
}
function deriveName(media) {
	const fallback = media.kind === "direct" ? "download" : "video";
	const candidate = firstNonEmpty(media.suggestedFilename, filenameFromUrl$1(media.url), media.alt, media.pageTitle) ?? fallback;
	if (media.kind !== "direct") return sanitizeFilenameWithExtension(candidate, "mp4", fallback);
	const inferredMime = inferMediaMimeType(media.url, media.mimeType);
	const extension = extensionForMediaMimeType(inferredMime ?? media.mimeType);
	const candidateMime = inferMediaMimeType(candidate);
	if (inferredMime && candidateMime && bareMimeType(candidateMime) === bareMimeType(inferredMime)) return sanitizeFilename(candidate, fallback);
	return extension ? sanitizeFilenameWithExtension(candidate, extension, fallback) : sanitizeFilename(candidate, fallback);
}
function bareMimeType(value) {
	return value.split(";", 1)[0]?.trim().toLowerCase() ?? "";
}
function firstNonEmpty(...values) {
	for (const value of values) if (typeof value === "string" && value.trim().length > 0) return value;
	return null;
}
function filenameFromUrl$1(url) {
	try {
		const segment = new URL(url).pathname.split("/").filter(Boolean).at(-1);
		if (!segment) return void 0;
		try {
			return decodeURIComponent(segment);
		} catch {
			return segment;
		}
	} catch {
		return;
	}
}
function normalizeSize(sizeBytes) {
	return typeof sizeBytes === "number" && Number.isFinite(sizeBytes) && sizeBytes > 0 ? Math.round(sizeBytes) : void 0;
}
//#endregion
//#region src/background/capture/MediaCredentialStore.ts
var MEDIA_CREDENTIAL_TTL_MS = 3e5;
var PRIVATE_REQUEST_HEADERS = /* @__PURE__ */ new Map([
	["accept", "Accept"],
	["accept-language", "Accept-Language"],
	["cookie", "Cookie"],
	["origin", "Origin"],
	["referer", "Referer"],
	["user-agent", "User-Agent"],
	["x-requested-with", "X-Requested-With"]
]);
var MAX_PRIVATE_HEADER_VALUE_LENGTH = 16384;
function httpUrl$1(value) {
	try {
		const url = new URL(value);
		return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
	} catch {
		return null;
	}
}
function observationKey(tabId, pageUrl, url) {
	return `${tabId}\u0000${pageUrl}\u0000${url}`;
}
function privateHeaders(input) {
	const result = {};
	for (const [rawName, rawValue] of Object.entries(input)) {
		const name = PRIVATE_REQUEST_HEADERS.get(rawName.trim().toLowerCase());
		const value = rawValue.trim();
		if (!name || !value || value.length > MAX_PRIVATE_HEADER_VALUE_LENGTH || /[\r\n]/.test(value)) continue;
		result[name] = value;
	}
	return result;
}
var MediaCredentialStore = class {
	now;
	observations = /* @__PURE__ */ new Map();
	constructor(now = Date.now) {
		this.now = now;
	}
	remember(observation) {
		const pageUrl = httpUrl$1(observation.pageUrl);
		const url = httpUrl$1(observation.url);
		if (observation.tabId < 0 || !pageUrl || !url) return;
		this.prune();
		const key = observationKey(observation.tabId, pageUrl, url);
		this.observations.delete(key);
		this.observations.set(key, {
			tabId: observation.tabId,
			pageUrl,
			url,
			observedAt: observation.observedAt,
			requestHeaders: privateHeaders(observation.requestHeaders)
		});
		while (this.observations.size > 512) {
			const oldest = this.observations.keys().next().value;
			if (typeof oldest !== "string") break;
			this.observations.delete(oldest);
		}
	}
	get(tabId, pageUrlValue, urlValue) {
		this.prune();
		const pageUrl = httpUrl$1(pageUrlValue);
		const url = httpUrl$1(urlValue);
		if (!pageUrl || !url) return void 0;
		const observation = this.observations.get(observationKey(tabId, pageUrl, url));
		return observation ? {
			...observation,
			requestHeaders: { ...observation.requestHeaders }
		} : void 0;
	}
	retainPage(tabId, pageUrlValue) {
		const pageUrl = httpUrl$1(pageUrlValue);
		for (const [key, observation] of this.observations) if (observation.tabId === tabId && (!pageUrl || observation.pageUrl !== pageUrl)) this.observations.delete(key);
	}
	clear(tabId) {
		for (const [key, observation] of this.observations) if (observation.tabId === tabId) this.observations.delete(key);
	}
	clearAll() {
		this.observations.clear();
	}
	prune() {
		const oldestAllowed = this.now() - MEDIA_CREDENTIAL_TTL_MS;
		for (const [key, observation] of this.observations) if (observation.observedAt < oldestAllowed) this.observations.delete(key);
	}
};
//#endregion
//#region src/background/capture/mediaCredentials.ts
var FORWARDED_HEADERS = /* @__PURE__ */ new Map([
	["accept", "Accept"],
	["accept-language", "Accept-Language"],
	["origin", "Origin"],
	["referer", "Referer"],
	["user-agent", "User-Agent"],
	["x-requested-with", "X-Requested-With"]
]);
var MAX_HEADER_VALUE_LENGTH = 8192;
/**
* Defense in depth for records already present in session storage. Secret or
* malformed headers are never forwarded, even if an older extension build
* persisted them before the current capture policy was installed.
*/
function safeMediaRequestHeaders(input) {
	const result = {};
	for (const [rawName, rawValue] of Object.entries(input ?? {})) {
		const name = FORWARDED_HEADERS.get(rawName.trim().toLowerCase());
		const value = rawValue.trim();
		if (!name || !value || value.length > MAX_HEADER_VALUE_LENGTH || /[\r\n]/.test(value)) continue;
		result[name] = value;
	}
	return result;
}
function requestHeader(headers, name) {
	return Object.entries(headers).find(([candidate]) => candidate.trim().toLowerCase() === name.toLowerCase())?.[1];
}
function originOnly(value) {
	if (!value) return void 0;
	try {
		const url = new URL(value);
		return url.protocol === "http:" || url.protocol === "https:" ? `${url.origin}/` : void 0;
	} catch {
		return;
	}
}
function observedCookies(value, resourceUrl) {
	let url;
	try {
		url = new URL(resourceUrl);
	} catch {
		return [];
	}
	const cookies = [];
	for (const item of value?.split(";") ?? []) {
		const separator = item.indexOf("=");
		if (separator <= 0) continue;
		const name = item.slice(0, separator).trim();
		const cookieValue = item.slice(separator + 1).trim();
		if (!name || /[\r\n\u0000]/.test(name + cookieValue)) continue;
		cookies.push({
			name,
			value: cookieValue,
			domain: url.hostname,
			path: "/",
			secure: url.protocol === "https:",
			httpOnly: false,
			sameSite: "unspecified"
		});
	}
	return cookies;
}
async function buildResourceCredentials(options) {
	if (!options.observation) return {
		cookies: [],
		headers: {}
	};
	const captured = safeMediaRequestHeaders(options.observation.requestHeaders);
	const headers = { ...captured };
	const referer = originOnly(captured.Referer);
	const origin = originOnly(captured.Origin);
	if (referer) headers.Referer = referer;
	else delete headers.Referer;
	if (origin) headers.Origin = origin.slice(0, -1);
	else delete headers.Origin;
	headers["User-Agent"] = captured["User-Agent"] ?? options.userAgent;
	return {
		cookies: observedCookies(requestHeader(options.observation.requestHeaders, "cookie"), options.url),
		headers
	};
}
//#endregion
//#region src/background/capture/cookies.ts
function mapSameSite(s) {
	switch (s) {
		case "strict": return "strict";
		case "lax": return "lax";
		case "no_restriction": return "none";
		default: return "unspecified";
	}
}
function mapCookies(src) {
	return src.map((c) => {
		const base = {
			name: c.name,
			value: c.value,
			domain: c.domain,
			path: c.path,
			secure: c.secure,
			httpOnly: c.httpOnly,
			sameSite: mapSameSite(c.sameSite)
		};
		return typeof c.expirationDate === "number" ? {
			...base,
			expiresAt: Math.round(c.expirationDate * 1e3)
		} : base;
	});
}
//#endregion
//#region src/background/capture/pageCookies.ts
function cookieIdentity(cookie) {
	return [
		cookie.name,
		cookie.value,
		cookie.domain,
		cookie.path,
		cookie.secure,
		cookie.httpOnly,
		cookie.sameSite,
		cookie.expirationDate ?? ""
	].join("\0");
}
/**
* Capture cookies for the explicit page-level resolver. Firefox queries both
* unpartitioned/FPI and the active top-level partition; any unsupported query
* degrades to the other result (or no cookies) instead of disabling resolve.
*/
async function capturePageCookies(options) {
	let pageUrl;
	try {
		pageUrl = new URL(options.url);
	} catch {
		return [];
	}
	if (pageUrl.protocol !== "http:" && pageUrl.protocol !== "https:") return [];
	const base = {
		url: pageUrl.toString(),
		...options.storeId ? { storeId: options.storeId } : {}
	};
	const queries = options.browser === "firefox" ? [{
		...base,
		firstPartyDomain: null
	}, {
		...base,
		firstPartyDomain: null,
		partitionKey: {
			topLevelSite: pageUrl.origin,
			hasCrossSiteAncestor: false
		}
	}] : [base];
	const settled = await Promise.allSettled(queries.map((query) => options.api.getAll(query)));
	const unique = /* @__PURE__ */ new Map();
	for (const result of settled) {
		if (result.status !== "fulfilled") continue;
		for (const cookie of result.value) unique.set(cookieIdentity(cookie), cookie);
	}
	return mapCookies([...unique.values()]);
}
//#endregion
//#region src/background/capture/normalizeTarget.ts
function basename(s) {
	const parts = (s.split(/[?#]/)[0] ?? s).split(/[\\/]/).filter(Boolean);
	return parts[parts.length - 1] ?? "";
}
function nonEmpty(s) {
	return typeof s === "string" && s.length > 0;
}
function normalizeTarget(raw) {
	const url = nonEmpty(raw.finalUrl) ? raw.finalUrl : raw.url;
	const pageUrl = nonEmpty(raw.referrer) ? raw.referrer : url;
	const suggestedFilename = basename(nonEmpty(raw.suggestedFilename) ? raw.suggestedFilename : basename(url)).slice(0, 255);
	const pageTitle = (nonEmpty(raw.tabTitle) ? raw.tabTitle : suggestedFilename).slice(0, 500);
	const sizeBytes = typeof raw.sizeBytes === "number" && raw.sizeBytes > 0 ? raw.sizeBytes : null;
	return {
		url,
		pageUrl,
		pageTitle,
		suggestedFilename,
		mime: raw.mime ?? "",
		sizeBytes,
		siteHint: hostOf(pageUrl),
		origin: raw.origin
	};
}
//#endregion
//#region src/background/contextMenu/register.ts
var MENU_ID = "motrix.takeover.download";
function contextMenuTitle(paired, t) {
	return t(paired ? "contextMenu.downloadWithMotrix" : "contextMenu.pairThenDownload");
}
function updateContextMenuTitle(paired) {
	browser.contextMenus.update(MENU_ID, { title: contextMenuTitle(paired, instance.t) }).catch(() => {});
}
function isHttp(url) {
	return typeof url === "string" && (url.startsWith("http://") || url.startsWith("https://"));
}
/** Start the equivalent native browser download for a right-click HTTP(S) URL. */
async function downloadHttpInBrowser(url, download = (options) => browser.downloads.download(options)) {
	if (!isHttp(url)) throw new Error("Browser download fallback only supports HTTP(S) URLs");
	await download({ url });
}
async function handleMenuClick(info, tab, deps) {
	const url = info.linkUrl ?? info.srcUrl;
	const referrer = typeof info.pageUrl === "string" ? { referrer: info.pageUrl } : {};
	const tabTitle = typeof tab?.title === "string" ? { tabTitle: tab.title } : {};
	if (isHttp(url)) {
		await deps.run(normalizeTarget({
			url,
			...referrer,
			...tabTitle,
			origin: "context-menu"
		}));
		return;
	}
	if (isMagnetUrl(url)) {
		const dn = magnetDisplayName(url);
		await deps.run(normalizeTarget({
			url,
			...referrer,
			...tabTitle,
			...dn ? { suggestedFilename: dn } : {},
			origin: "context-menu"
		}));
		return;
	}
	log.debug("[contextMenu] ignored unsupported click target", typeof url === "string" ? describeUrlForLog(url) : "<missing-url>");
}
/** Event listeners cannot return this promise to the browser. Contain every
* startup/handoff failure here so a failed lifecycle barrier never becomes an
* unhandled rejection, and do not log the target URL or raw error. */
async function handleMenuClickSafely(info, tab, deps) {
	try {
		await handleMenuClick(info, tab, deps);
	} catch {
		log.debug("[contextMenu] handoff unavailable");
	}
}
function registerContextMenu(deps) {
	browser.contextMenus.removeAll().then(() => {
		browser.contextMenus.create({
			id: MENU_ID,
			title: contextMenuTitle(false, instance.t),
			contexts: [
				"link",
				"image",
				"video",
				"audio"
			]
		});
	});
	browser.contextMenus.onClicked.addListener((info, tab) => {
		if (info.menuItemId !== "motrix.takeover.download") return;
		handleMenuClickSafely(info, tab, deps);
	});
}
//#endregion
//#region src/background/handoff/guard.ts
var HandoffEndpointChangedError = class extends Error {
	constructor() {
		super("the selected backend changed during download handoff");
		this.name = "HandoffEndpointChangedError";
	}
};
/** Owns only the lifetime of a download's selected backend. Normal reconnects
* retain the guard; catalog activation/edit invalidates it synchronously. */
var HandoffEndpointTracker = class {
	store;
	coordinator;
	generation = 0;
	constructor(store, coordinator) {
		this.store = store;
		this.coordinator = coordinator;
	}
	invalidate() {
		this.generation += 1;
	}
	capture(origin) {
		return this.coordinator.run(async () => {
			const config = await this.store.getForLifecycleMutation();
			if (origin === "auto" && !supportsAutomaticTakeover(config)) return null;
			const generation = this.generation;
			return {
				origin,
				assertCurrent: () => {
					if (generation !== this.generation) throw new HandoffEndpointChangedError();
				}
			};
		});
	}
};
//#endregion
//#region src/background/capture/sensitiveDomains.ts
/** Seed list of sensitive host suffixes (financial / government / medical). User-extendable. */
var SENSITIVE_SUFFIXES = [
	"gov",
	"mil",
	"gov.uk",
	"gov.cn",
	"bank",
	"paypal.com",
	"nhs.uk"
];
function isSensitiveDomain(host) {
	const h = host.toLowerCase();
	return SENSITIVE_SUFFIXES.some((suffix) => hostSuffixMatch(h, suffix));
}
//#endregion
//#region src/background/handoff/makeOps.ts
async function waitForConnected(manager, deadlineMs) {
	const start = Date.now();
	while (Date.now() - start < deadlineMs) {
		if (manager.getState() === "connected") return true;
		if (manager.getState() === "denied" || manager.getState() === "disconnected") {}
		await new Promise((r) => setTimeout(r, 150));
	}
	return manager.getState() === "connected";
}
function makeOps(deps) {
	const { manager, gate, nudge } = deps;
	return {
		assertCurrent: deps.guard.assertCurrent,
		getState: () => manager.getState(),
		connectWithLaunch: async () => {
			deps.guard.assertCurrent();
			log.debug("[takeover] connectWithLaunch (clearGateAndStart); state=", manager.getState());
			await manager.clearGateAndStart();
		},
		waitForConnected: async (ms) => {
			const ok = await waitForConnected(manager, ms);
			log.debug("[takeover] waitForConnected ->", ok, "finalState=", manager.getState(), "lastErr=", manager.getLastError());
			return ok;
		},
		isPaired: async () => {
			const paired = await deps.isPaired();
			log.debug("[takeover] isPaired=", paired);
			return paired;
		},
		canAutoConnect: async () => {
			const can = await gate.shouldAutoConnect();
			log.debug("[takeover] canAutoConnect=", can);
			return can;
		},
		isSensitive: (host) => isSensitiveDomain(host),
		confirmSensitive: deps.confirmSensitive,
		cancelNative: async () => {
			deps.guard.assertCurrent();
			log.debug("[takeover] cancelNative");
			await deps.cancelNative();
		},
		fallbackToBrowser: async () => {
			log.warn("[takeover] fallbackToBrowser (Motrix handoff unavailable)");
			await deps.fallbackToBrowser();
		},
		captureCookies: async (url) => {
			deps.guard.assertCurrent();
			const raw = await browser.cookies.getAll({ url });
			log.debug("[takeover] captureCookies count=", raw.length, "for", describeUrlForLog(url));
			return mapCookies(raw);
		},
		buildHeaders: (t) => ({
			Referer: t.pageUrl,
			"User-Agent": navigator.userAgent
		}),
		submit: async (params) => {
			const primaryUrl = params.selection.kind === "direct" ? describeUrlForLog(params.selection.primary.url) : "(non-direct)";
			log.debug("[takeover] submit attempt; state=", manager.getState(), "url=", primaryUrl, "pageUrl=", describeUrlForLog(params.source.pageUrl), "title.len=", params.source.pageTitle.length, "cookies=", params.selection.kind === "direct" ? params.selection.primary.cookies.length : -1);
			try {
				const r = await manager.submitDownload(params, {
					automaticTakeover: deps.guard.origin === "auto",
					assertCurrent: deps.guard.assertCurrent
				});
				log.debug("[takeover] submit OK taskId=", r.taskId);
				return r;
			} catch (e) {
				const err = e;
				log.error("[takeover] submit FAILED reason=", err?.reason ?? err?.code ?? "unknown", "message=", err?.message);
				throw e;
			}
		},
		notify: deps.notify,
		nudgePair: () => nudge.maybeNudge()
	};
}
//#endregion
//#region src/background/capture/buildSubmitParams.ts
function buildSubmitParams(t, cookies, headers) {
	const meta = t.sizeBytes !== null ? {
		suggestedFilename: t.suggestedFilename,
		qualityLabel: QUALITY_SENTINEL,
		estimatedBytes: t.sizeBytes
	} : {
		suggestedFilename: t.suggestedFilename,
		qualityLabel: QUALITY_SENTINEL
	};
	const source = t.siteHint.length > 0 ? {
		pageUrl: t.pageUrl,
		pageTitle: t.pageTitle,
		detectedAt: Date.now(),
		siteHint: t.siteHint
	} : {
		pageUrl: t.pageUrl,
		pageTitle: t.pageTitle,
		detectedAt: Date.now()
	};
	if (isMagnetUrl(t.url)) return {
		source,
		selection: {
			kind: "magnet",
			uri: t.url
		},
		meta
	};
	return {
		source,
		selection: {
			kind: "direct",
			primary: {
				url: t.url,
				headers,
				cookies,
				refererPolicy: "strict-origin-when-cross-origin"
			}
		},
		meta
	};
}
//#endregion
//#region src/background/handoff/delivery.ts
var CONNECT_DEADLINE_MS = 8e3;
function notifySafely(ops, input) {
	try {
		ops.notify(input);
	} catch {}
}
async function submitOrFallback(params, ops) {
	try {
		await submitWithRetry(params, ops);
	} catch {
		let fellBack = false;
		try {
			if (params.selection.kind === "direct") {
				await ops.fallbackToBrowser();
				fellBack = true;
			}
		} finally {
			notifySafely(ops, {
				title: instance.t("notify.submitFailedTitle"),
				message: instance.t(fellBack ? "notify.submitFailedBody" : "notify.notReachableBody"),
				severity: "error"
			});
		}
		return;
	}
	notifySafely(ops, {
		title: instance.t("notify.handedToMotrix"),
		message: params.meta.suggestedFilename,
		severity: "confirm"
	});
}
async function submitWithRetry(params, ops) {
	try {
		await ops.submit(params);
	} catch (error) {
		if (error instanceof HandoffEndpointChangedError || error instanceof RemoteDataBoundaryConsentRequiredError || error instanceof RemoteAutomaticTakeoverConsentRequiredError) throw error;
		if (ops.getState() !== "connected") try {
			await ops.waitForConnected(CONNECT_DEADLINE_MS);
		} catch {}
		await ops.submit(params);
	}
}
function withIdempotencyKey(params) {
	return params.idempotencyKey ? params : {
		...params,
		idempotencyKey: crypto.randomUUID()
	};
}
async function commitHandoff(params, ops) {
	const keyedParams = withIdempotencyKey(params);
	await ops.cancelNative();
	await submitOrFallback(keyedParams, ops);
}
//#endregion
//#region src/background/handoff/runHandoff.ts
function canFallbackExplicitly(target) {
	return target.origin === "context-menu" && (target.url.startsWith("http://") || target.url.startsWith("https://"));
}
async function fallbackExplicitly(target, ops) {
	if (!canFallbackExplicitly(target)) return false;
	await ops.fallbackToBrowser();
	return true;
}
function notifyBrowserFallback(ops) {
	notifySafely(ops, {
		title: instance.t("notify.browserFallbackTitle"),
		message: instance.t("notify.browserFallbackBody"),
		severity: "reminder"
	});
}
async function prepareHandoff(target, ops) {
	if (ops.isSensitive(hostOf(target.url))) {
		if (!await ops.confirmSensitive(target)) return { kind: "sensitive-skipped" };
		return {
			kind: "submit",
			params: buildSubmitParams(target, [], ops.buildHeaders(target))
		};
	}
	const magnet = isMagnetUrl(target.url);
	return {
		kind: "submit",
		params: buildSubmitParams(target, magnet ? [] : await ops.captureCookies(target.url), magnet ? {} : ops.buildHeaders(target))
	};
}
async function runHandoff(target, ops) {
	try {
		await runCurrentHandoff(target, ops);
	} catch (error) {
		if (!(error instanceof HandoffEndpointChangedError)) throw error;
	}
}
async function runCurrentHandoff(target, ops) {
	ops.assertCurrent();
	if (ops.getState() !== "connected") {
		if (!(target.origin === "context-menu") && (!await ops.isPaired() || !await ops.canAutoConnect())) {
			await ops.nudgePair();
			ops.notify({
				title: instance.t("notify.notConnectedTitle"),
				message: instance.t("notify.notConnectedBody"),
				severity: "reminder"
			});
			return;
		}
		let connected = false;
		try {
			await ops.connectWithLaunch();
			connected = await ops.waitForConnected(CONNECT_DEADLINE_MS);
		} catch (error) {
			if (error instanceof HandoffEndpointChangedError) throw error;
		}
		if (!connected) {
			if (await fallbackExplicitly(target, ops)) {
				notifyBrowserFallback(ops);
				return;
			}
			notifySafely(ops, {
				title: instance.t("notify.notReachableTitle"),
				message: instance.t("notify.notReachableBody"),
				severity: "error"
			});
			return;
		}
	}
	let prepared;
	try {
		ops.assertCurrent();
		prepared = await prepareHandoff(target, ops);
	} catch (error) {
		if (error instanceof HandoffEndpointChangedError) throw error;
		if (await fallbackExplicitly(target, ops)) {
			notifyBrowserFallback(ops);
			return;
		}
		throw error;
	}
	if (prepared.kind === "sensitive-skipped") {
		if (await fallbackExplicitly(target, ops)) {
			notifySafely(ops, {
				title: instance.t("notify.sensitiveSkippedTitle"),
				message: instance.t("notify.sensitiveSkippedBody"),
				severity: "reminder"
			});
			return;
		}
		notifySafely(ops, {
			title: instance.t("notify.sensitiveSkippedTitle"),
			message: instance.t("notify.sensitiveSkippedBody"),
			severity: "reminder"
		});
		return;
	}
	ops.assertCurrent();
	await commitHandoff(prepared.params, ops);
}
//#endregion
//#region src/background/capture/probeSize.ts
function parseLen(value) {
	if (value === null) return null;
	const n = Number(value);
	return Number.isFinite(n) && n > 0 ? n : null;
}
async function probeSize(url, deps) {
	const timeout = deps.timeoutMs ?? 3e3;
	try {
		const head = await deps.fetch(url, {
			method: "HEAD",
			credentials: "include",
			signal: AbortSignal.timeout(timeout)
		});
		if (head.ok) {
			const len = parseLen(head.headers.get("content-length"));
			if (len !== null) return len;
		}
	} catch {
		return null;
	}
	try {
		const ranged = await deps.fetch(url, {
			method: "GET",
			credentials: "include",
			headers: { Range: "bytes=0-0" },
			signal: AbortSignal.timeout(timeout)
		});
		if (!ranged.ok && ranged.status !== 206) return null;
		const total = ranged.headers.get("content-range")?.split("/")[1];
		return parseLen(total ?? null);
	} catch {
		return null;
	}
}
//#endregion
//#region src/background/interception/eligibility.ts
/** The URL a takeover should act on: post-redirect finalUrl when present. */
function pickDownloadUrl(item) {
	return item.finalUrl && item.finalUrl.length > 0 ? item.finalUrl : item.url;
}
function isEligibleDownload(item, selfExtensionId) {
	if (item.byExtensionId === selfExtensionId) return false;
	const url = pickDownloadUrl(item);
	return url.startsWith("http://") || url.startsWith("https://");
}
//#endregion
//#region src/background/policy/decideTakeover.ts
function ruleMatches(match, target) {
	if (match.domains && match.domains.length > 0) {
		const host = hostOf(target.url);
		if (!match.domains.some((d) => hostSuffixMatch(host, d))) return false;
	}
	if (typeof match.minSizeMB === "number") {
		if (target.sizeBytes === null) return false;
		if (target.sizeBytes >= match.minSizeMB * 1048576) return false;
	}
	if (match.mimePatterns && match.mimePatterns.length > 0) {
		if (!match.mimePatterns.some((p) => target.mime.includes(p))) return false;
	}
	return true;
}
function decideTakeover(config, target) {
	if (target.origin === "context-menu") return "motrix";
	if (!config.enabled) return "chrome";
	for (const rule of config.rules) if (ruleMatches(rule.match, target)) return rule.action === "motrix" ? "motrix" : "chrome";
	return config.defaultAction;
}
//#endregion
//#region src/background/interception/firefox.ts
function configHasThreshold(cfg) {
	return cfg.rules.some((r) => typeof r.match.minSizeMB === "number");
}
async function cancelFirefoxDownload(id) {
	await browser.downloads.cancel(id);
	try {
		await browser.downloads.erase({ id });
	} catch (error) {
		log.debug("[takeover] Firefox download history cleanup failed", error);
	}
}
function registerFirefoxInterception(deps) {
	browser.downloads.onCreated.addListener((item) => {
		if (!isEligibleDownload(item, deps.selfExtensionId)) return;
		handleFirefoxDownloadSafely(item, deps);
	});
}
/** Firefox's downloads event ignores returned promises. Keep a rejected
* startup barrier or handoff contained without logging URL-bearing errors. */
async function handleFirefoxDownloadSafely(item, deps) {
	try {
		await handle(item, deps);
	} catch {
		log.debug("[takeover] Firefox handoff unavailable");
	}
}
async function handle(item, deps) {
	const cfg = await deps.getConfig();
	if (!cfg.enabled) return;
	const guard = await deps.captureGuard();
	if (guard === null) return;
	const finalUrl = item.finalUrl;
	const url = finalUrl && finalUrl.length > 0 ? finalUrl : item.url;
	let sizeBytes = typeof item.totalBytes === "number" && item.totalBytes > 0 ? item.totalBytes : null;
	if (sizeBytes === null && configHasThreshold(cfg)) sizeBytes = await probeSize(url, { fetch: globalThis.fetch });
	const target = normalizeTarget({
		url,
		...typeof item.referrer === "string" && item.referrer.length > 0 ? { referrer: item.referrer } : {},
		...typeof item.filename === "string" ? { suggestedFilename: item.filename } : {},
		...typeof item.mime === "string" ? { mime: item.mime } : {},
		sizeBytes,
		origin: "auto"
	});
	if (decideTakeover(cfg, target) !== "motrix") return;
	await runHandoff(target, makeOps({
		manager: deps.manager,
		guard,
		isPaired: deps.isPaired,
		gate: deps.gate,
		nudge: deps.nudge,
		cancelNative: () => cancelFirefoxDownload(item.id),
		fallbackToBrowser: async () => {
			await browser.downloads.download({ url });
		},
		confirmSensitive: async () => false,
		notify: deps.notify
	}));
}
//#endregion
//#region src/background/localeSync.ts
/**
* Returns a storage.onChanged listener that re-applies the i18n locale
* whenever `motrix.locale` changes in local storage, then calls `onApplied`.
*
* Extract this logic so it can be unit-tested in isolation without importing
* the service-worker bootstrap (background/service-worker.ts has side effects).
*/
function makeLocaleChangeHandler(onApplied) {
	return (changes, area) => {
		if (area !== "local" || !changes["motrix.locale"]) return;
		initI18n().then(() => onApplied());
	};
}
//#endregion
//#region src/background/logLevelSync.ts
/**
* Returns a `browser.storage.onChanged` listener that applies a persisted
* log-level change to the running service worker's cached level. Mirrors
* `localeSync.ts`.
*/
function makeLogLevelChangeHandler() {
	return (changes, area) => {
		if (area !== "local") return;
		const change = changes[LOG_LEVEL_KEY];
		if (!change) return;
		log.setLevel(parseLogLevel(change.newValue) ?? "info");
	};
}
//#endregion
//#region src/background/MediaReportLimiter.ts
var MEDIA_REPORT_WINDOW_MS = 1e3;
var TEXT_FIELDS = [
	"kind",
	"url",
	"audioUrl",
	"pageUrl",
	"pageTitle",
	"mimeType",
	"category",
	"suggestedFilename",
	"alt"
];
var encoder = new TextEncoder();
function reportCost(payload) {
	if (typeof payload !== "object" || payload === null) return {
		items: 0,
		bytes: 0
	};
	const report = payload;
	if (!Array.isArray(report.items)) return {
		items: 0,
		bytes: 0
	};
	const items = report.items.length;
	let bytes = 128 + (typeof report.tabUrl === "string" ? encoder.encode(report.tabUrl).byteLength : 0);
	for (const raw of report.items.slice(0, 101)) {
		bytes += 128;
		if (typeof raw !== "object" || raw === null) continue;
		const item = raw;
		for (const field of TEXT_FIELDS) {
			const value = item[field];
			if (typeof value === "string") bytes += encoder.encode(value).byteLength;
		}
		if (Array.isArray(item.evidence)) {
			for (const evidence of item.evidence.slice(0, 9)) if (typeof evidence === "string") bytes += encoder.encode(evidence).byteLength;
		}
		if (bytes > 262144) break;
	}
	return {
		items,
		bytes
	};
}
/** Aggregate all-frame reports by tab before normalization/storage work. */
var MediaReportLimiter = class {
	now;
	windows = /* @__PURE__ */ new Map();
	constructor(now = Date.now) {
		this.now = now;
	}
	allow(tabId, payload) {
		if (tabId < 0) return false;
		const now = this.now();
		const cost = reportCost(payload);
		if (cost.items > 100 || cost.bytes > 262144) return false;
		let window = this.windows.get(tabId);
		if (!window || now - window.startedAt >= 1e3) {
			window = {
				startedAt: now,
				messages: 0,
				items: 0,
				bytes: 0,
				blockedUntil: 0
			};
			this.windows.delete(tabId);
			this.windows.set(tabId, window);
			this.prune(now);
		}
		if (now < window.blockedUntil) return false;
		if (window.messages + 1 > 30 || window.items + cost.items > 300 || window.bytes + cost.bytes > 524288) {
			window.blockedUntil = window.startedAt + MEDIA_REPORT_WINDOW_MS;
			return false;
		}
		window.messages += 1;
		window.items += cost.items;
		window.bytes += cost.bytes;
		return true;
	}
	clear(tabId) {
		this.windows.delete(tabId);
	}
	prune(now) {
		for (const [tabId, window] of this.windows) if (now - window.startedAt >= 2e3) this.windows.delete(tabId);
	}
};
var KIND_PRIORITY = {
	direct: 0,
	dash: 1,
	hls: 1,
	mux: 2
};
function isMeaningful(value) {
	if (value === void 0 || value === null) return false;
	if (typeof value === "string") return value.trim().length > 0;
	if (Array.isArray(value)) return value.length > 0;
	if (typeof value === "object") return Object.keys(value).length > 0;
	return true;
}
function canonicalJson(value) {
	if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
	if (value && typeof value === "object") return `{${Object.entries(value).sort(([left], [right]) => left.localeCompare(right)).map(([key, item]) => `${JSON.stringify(key)}:${canonicalJson(item)}`).join(",")}}`;
	return JSON.stringify(value) ?? "";
}
function observationRichness(media) {
	return Object.values(media).reduce((score, value) => {
		if (!isMeaningful(value)) return score;
		if (Array.isArray(value)) return score + value.length;
		if (typeof value === "object") return score + Object.keys(value).length;
		return score + 1;
	}, 0);
}
function prefersIncoming(existing, incoming) {
	if (incoming.detectedAt !== existing.detectedAt) return incoming.detectedAt > existing.detectedAt;
	const richnessDifference = observationRichness(incoming) - observationRichness(existing);
	if (richnessDifference !== 0) return richnessDifference > 0;
	return canonicalJson(incoming) > canonicalJson(existing);
}
function meaningfulFields(media) {
	return Object.fromEntries(Object.entries(media).filter(([, value]) => isMeaningful(value)));
}
/** Request context is credential material and belongs only in the in-memory
* MediaCredentialStore. Strip legacy/new fields at the storage boundary so a
* Popup scan or storage.onChanged event can never receive them. */
function publicMediaRecord(media) {
	const { requestHeaders: _privateRequestHeaders, ...record } = media;
	return record;
}
function positiveMaximum(left, right) {
	const candidates = [left, right].filter((value) => Number.isFinite(value) && (value ?? 0) > 0);
	return candidates.length > 0 ? Math.max(...candidates) : void 0;
}
function evidenceBackedText(existing, incoming, field, evidence, preferred, fallback) {
	const existingValue = existing[field]?.trim();
	const incomingValue = incoming[field]?.trim();
	const existingBacked = Boolean(existingValue) && existing.evidence?.includes(evidence) === true;
	if (existingBacked !== (Boolean(incomingValue) && incoming.evidence?.includes(evidence) === true)) return existingBacked ? existingValue : incomingValue;
	return preferred[field]?.trim() || fallback[field]?.trim() || void 0;
}
/**
* Combine observations without allowing a sparse refresh to erase metadata
* learned from another capture source. Conflicts prefer the newest observation;
* equal timestamps use richness and a canonical value as stable tie-breakers.
*/
function mergeMedia(existing, incoming) {
	const incomingPreferred = prefersIncoming(existing, incoming);
	const preferred = incomingPreferred ? incoming : existing;
	const fallback = incomingPreferred ? existing : incoming;
	const merged = {
		...meaningfulFields(fallback),
		...meaningfulFields(preferred),
		url: existing.url,
		detectedAt: Math.max(existing.detectedAt, incoming.detectedAt)
	};
	merged.kind = KIND_PRIORITY[existing.kind] > KIND_PRIORITY[incoming.kind] ? existing.kind : KIND_PRIORITY[incoming.kind] > KIND_PRIORITY[existing.kind] ? incoming.kind : preferred.kind;
	if (merged.kind !== "direct") merged.category = "video";
	const evidence = [.../* @__PURE__ */ new Set([...existing.evidence ?? [], ...incoming.evidence ?? []])].filter((item) => item.trim().length > 0).sort();
	if (evidence.length > 0) merged.evidence = evidence;
	const suggestedFilename = evidenceBackedText(existing, incoming, "suggestedFilename", "content-disposition", preferred, fallback);
	const mimeType = evidenceBackedText(existing, incoming, "mimeType", "content-type", preferred, fallback);
	if (suggestedFilename) merged.suggestedFilename = suggestedFilename;
	else delete merged.suggestedFilename;
	if (mimeType) merged.mimeType = mimeType;
	else delete merged.mimeType;
	const sizeBytes = positiveMaximum(existing.sizeBytes, incoming.sizeBytes);
	const width = positiveMaximum(existing.width, incoming.width);
	const height = positiveMaximum(existing.height, incoming.height);
	if (sizeBytes !== void 0) merged.sizeBytes = sizeBytes;
	else delete merged.sizeBytes;
	if (width !== void 0) merged.width = width;
	else delete merged.width;
	if (height !== void 0) merged.height = height;
	else delete merged.height;
	if (existing.previewable === false || incoming.previewable === false) merged.previewable = false;
	else if (existing.previewable === true || incoming.previewable === true) merged.previewable = true;
	return merged;
}
function detectedAtValue(media) {
	return Number.isFinite(media.detectedAt) ? media.detectedAt : 0;
}
function imageRetentionScore(media) {
	const width = positiveMaximum(media.width, void 0) ?? 0;
	const height = positiveMaximum(media.height, void 0) ?? 0;
	const sizeBytes = positiveMaximum(media.sizeBytes, void 0) ?? 0;
	let score = Math.log2(width * height + 1) * 10;
	score += Math.log2(sizeBytes + 1) * 2;
	for (const rawEvidence of new Set(media.evidence ?? [])) {
		const evidence = rawEvidence.toLowerCase();
		if (evidence.includes("current-src") || evidence.includes("currentsrc")) score += 80;
		else if (evidence === "poster" || evidence === "meta") score += 35;
		else if (evidence === "picture" || evidence === "srcset") score += 25;
		else if (evidence === "img" || evidence === "link" || evidence === "input-image") score += 12;
		else if (evidence === "network") score += 4;
		else score += 2;
	}
	if (media.previewable === true) score += 4;
	if (media.suggestedFilename) score += 2;
	if (media.alt) score += 2;
	return score;
}
function oldestMediaKey(items, matches) {
	let oldestKey;
	let oldestDetectedAt = Number.POSITIVE_INFINITY;
	for (const [key, media] of items) {
		if (!matches(media)) continue;
		const detectedAt = detectedAtValue(media);
		if (oldestKey === void 0 || detectedAt < oldestDetectedAt) {
			oldestKey = key;
			oldestDetectedAt = detectedAt;
		}
	}
	return oldestKey;
}
function leastValuableImageKey(items) {
	let selectedKey;
	let selectedScore = Number.POSITIVE_INFINITY;
	let selectedDetectedAt = Number.POSITIVE_INFINITY;
	for (const [key, media] of items) {
		if (mediaCategory(media) !== "image") continue;
		const score = imageRetentionScore(media);
		const detectedAt = detectedAtValue(media);
		if (selectedKey === void 0 || score < selectedScore || score === selectedScore && detectedAt < selectedDetectedAt) {
			selectedKey = key;
			selectedScore = score;
			selectedDetectedAt = detectedAt;
		}
	}
	return selectedKey;
}
function serializedMediaBytes(items) {
	return new TextEncoder().encode(JSON.stringify([...items])).byteLength;
}
function isStorageQuotaError(error) {
	return /quota|quota_bytes/i.test(error instanceof Error ? error.message : String(error));
}
function resolveSessionStorage() {
	const globals = globalThis;
	const storage = globals.browser?.storage?.session ?? globals.chrome?.storage?.session;
	if (!storage) throw new Error("session storage is unavailable");
	return storage;
}
var MediaStore = class {
	operationTails = /* @__PURE__ */ new Map();
	currentPageByTab = /* @__PURE__ */ new Map();
	storage = resolveSessionStorage();
	async add(tabId, items) {
		return this.enqueue(tabId, async () => {
			const existing = await this.read(tabId);
			await this.writeMerged(tabId, existing, items);
		});
	}
	/**
	* Atomically discard findings from prior navigations and add findings for
	* the current page. Keeping both steps in one per-tab queue operation avoids
	* a late network response being inserted between retainPage() and add().
	*/
	async addForPage(tabId, pageUrl, items) {
		return this.enqueue(tabId, async () => {
			if (this.currentPageByTab.has(tabId) && this.currentPageByTab.get(tabId) !== pageUrl) return;
			const existing = (await this.read(tabId)).filter((media) => media.pageUrl === pageUrl);
			const currentItems = items.filter((media) => media.pageUrl === pageUrl);
			await this.writeMerged(tabId, existing, currentItems);
		});
	}
	async get(tabId) {
		return this.enqueue(tabId, () => this.read(tabId));
	}
	async clear(tabId) {
		this.currentPageByTab.set(tabId, null);
		return this.enqueue(tabId, async () => {
			await this.storage.remove(mediaTabStorageKey(tabId));
		});
	}
	/**
	* Keep same-page results so a repeat scan can return the already-installed
	* sniffer's findings, while dropping media left behind by tab navigation.
	*/
	async retainPage(tabId, pageUrl) {
		this.currentPageByTab.set(tabId, pageUrl);
		return this.enqueue(tabId, async () => {
			const current = await this.read(tabId);
			const retained = current.filter((media) => media.pageUrl === pageUrl);
			if (retained.length === current.length) return;
			if (retained.length === 0) {
				await this.storage.remove(mediaTabStorageKey(tabId));
				return;
			}
			await this.storage.set({ [mediaTabStorageKey(tabId)]: retained });
		});
	}
	async read(tabId) {
		const key = mediaTabStorageKey(tabId);
		return ((await this.storage.get(key))[key] ?? []).map(publicMediaRecord);
	}
	async writeMerged(tabId, existing, items) {
		const byKey = new Map(existing.map((media) => {
			const record = publicMediaRecord(media);
			return [mediaStorageKey(record), record];
		}));
		for (const rawMedia of items) {
			const media = publicMediaRecord(rawMedia);
			const key = mediaStorageKey(media);
			const previous = byKey.get(key);
			byKey.delete(key);
			byKey.set(key, previous ? mergeMedia(previous, media) : media);
		}
		let imageCount = [...byKey.values()].filter((media) => mediaCategory(media) === "image").length;
		while (imageCount > 120) {
			const imageKey = leastValuableImageKey(byKey);
			if (imageKey === void 0) break;
			byKey.delete(imageKey);
			imageCount -= 1;
		}
		while (byKey.size > 200) {
			const oldestKey = leastValuableImageKey(byKey) ?? oldestMediaKey(byKey, () => true);
			if (oldestKey === void 0) break;
			byKey.delete(oldestKey);
		}
		while (byKey.size > 0 && serializedMediaBytes(byKey.values()) > 262144) {
			const evictionKey = leastValuableImageKey(byKey) ?? oldestMediaKey(byKey, () => true);
			if (evictionKey === void 0) break;
			byKey.delete(evictionKey);
		}
		if (byKey.size === 0) {
			await this.storage.remove(mediaTabStorageKey(tabId));
			return;
		}
		const key = mediaTabStorageKey(tabId);
		try {
			await this.storage.set({ [key]: [...byKey.values()] });
		} catch (error) {
			if (!isStorageQuotaError(error)) throw error;
			await this.storage.remove(key);
			while (byKey.size > 0 && serializedMediaBytes(byKey.values()) > 131072) {
				const evictionKey = leastValuableImageKey(byKey) ?? oldestMediaKey(byKey, () => true);
				if (evictionKey === void 0) break;
				byKey.delete(evictionKey);
			}
			if (byKey.size === 0) return;
			try {
				await this.storage.set({ [key]: [...byKey.values()] });
			} catch (retryError) {
				if (!isStorageQuotaError(retryError)) throw retryError;
			}
		}
	}
	enqueue(tabId, operation) {
		const result = (this.operationTails.get(tabId) ?? Promise.resolve()).then(operation);
		const next = result.then(() => void 0, () => void 0);
		this.operationTails.set(tabId, next);
		next.then(() => {
			if (this.operationTails.get(tabId) === next) this.operationTails.delete(tabId);
		});
		return result;
	}
};
//#endregion
//#region src/background/mediaTrust.ts
var MAX_REPORT_ITEMS = 100;
var MAX_URL_LENGTH = 32768;
var MAX_TITLE_LENGTH = 512;
var MAX_MIME_LENGTH = 256;
var MAX_ALT_LENGTH = 512;
var MAX_FILENAME_LENGTH = 255;
var MAX_DIMENSION = 1e5;
var MAX_EVIDENCE_ITEMS = 8;
var MAX_REPORT_TEXT_UNITS = 131072;
var MEDIA_KINDS = /* @__PURE__ */ new Set([
	"hls",
	"dash",
	"direct",
	"mux"
]);
var MEDIA_EVIDENCE = /* @__PURE__ */ new Set([
	"img",
	"picture",
	"source",
	"video",
	"audio",
	"poster",
	"srcset",
	"current-src",
	"lazy",
	"css-background",
	"css-pseudo",
	"meta",
	"link",
	"input-image",
	"performance",
	"fetch",
	"xhr",
	"body-hls",
	"body-dash",
	"body-json"
]);
function httpUrl(value) {
	if (typeof value !== "string" || value.length === 0 || value.length > MAX_URL_LENGTH) return null;
	try {
		const parsed = new URL(value);
		return parsed.protocol === "http:" || parsed.protocol === "https:" ? parsed.toString() : null;
	} catch {
		return null;
	}
}
function documentUrlKey(value) {
	const normalized = httpUrl(value);
	if (!normalized) return null;
	const parsed = new URL(normalized);
	parsed.hash = "";
	return parsed.toString();
}
function hostMatches(hostname, domain) {
	return hostname === domain || hostname.endsWith(`.${domain}`);
}
/** Generic page messages cannot mint arbitrary hidden secondary requests.
* The only page-world mux producer today is the dedicated YouTube resolver;
* constrain that seam to the expected page and media origins. */
function isTrustedPageMux(pageUrlValue, videoUrlValue, audioUrlValue) {
	try {
		const pageUrl = new URL(pageUrlValue);
		const videoUrl = new URL(videoUrlValue);
		const audioUrl = new URL(audioUrlValue);
		return (hostMatches(pageUrl.hostname, "youtube.com") || hostMatches(pageUrl.hostname, "youtube-nocookie.com") || pageUrl.hostname === "youtu.be") && videoUrl.protocol === "https:" && audioUrl.protocol === "https:" && hostMatches(videoUrl.hostname, "googlevideo.com") && hostMatches(audioUrl.hostname, "googlevideo.com");
	} catch {
		return false;
	}
}
function boundedText(value, maxLength) {
	if (typeof value !== "string") return void 0;
	const normalized = value.replace(/[\u0000-\u001f\u007f]/g, " ").trim();
	return normalized ? normalized.slice(0, maxLength) : void 0;
}
function positiveInteger(value, maximum) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0 && value <= maximum ? value : void 0;
}
function suggestedFilename(value) {
	const text = boundedText(value, MAX_FILENAME_LENGTH);
	if (!text) return void 0;
	return text.split(/[\\/]/).at(-1)?.trim() || void 0;
}
function normalizedEvidence(value) {
	if (!Array.isArray(value)) return void 0;
	const result = [...new Set(value.filter((entry) => typeof entry === "string" && MEDIA_EVIDENCE.has(entry)))].slice(0, MAX_EVIDENCE_ITEMS);
	return result.length > 0 ? result : void 0;
}
function reportItemTextUnits(item) {
	let units = 0;
	for (const field of [
		"kind",
		"url",
		"audioUrl",
		"pageUrl",
		"pageTitle",
		"mimeType",
		"category",
		"suggestedFilename",
		"alt"
	]) {
		const value = item[field];
		if (typeof value === "string") units += value.length;
	}
	if (Array.isArray(item.evidence)) {
		for (const value of item.evidence.slice(0, MAX_EVIDENCE_ITEMS)) if (typeof value === "string") units += value.length;
	}
	return units;
}
/**
* Treat MAIN-world reports as page-controlled input. Only accept bounded,
* HTTP(S) records that belong to the browser-authenticated sender tab.
*/
function normalizeMediaReport(payload, senderTabUrl, detectedAt = Date.now()) {
	const trustedPageUrl = httpUrl(senderTabUrl);
	const trustedDocumentKey = documentUrlKey(senderTabUrl);
	if (!trustedPageUrl || typeof payload !== "object" || payload === null) return [];
	const report = payload;
	if (documentUrlKey(report.tabUrl) !== trustedDocumentKey || !Array.isArray(report.items)) return [];
	const normalized = [];
	let reportTextUnits = 0;
	for (const raw of report.items.slice(0, MAX_REPORT_ITEMS)) {
		if (typeof raw !== "object" || raw === null) continue;
		const item = raw;
		reportTextUnits += reportItemTextUnits(item);
		if (reportTextUnits > MAX_REPORT_TEXT_UNITS) break;
		const kind = item.kind;
		const url = httpUrl(item.url);
		if (typeof kind !== "string" || !MEDIA_KINDS.has(kind) || !url || documentUrlKey(item.pageUrl) !== trustedDocumentKey || typeof item.pageTitle !== "string") continue;
		const mediaKind = kind;
		const audioUrl = mediaKind === "mux" ? httpUrl(item.audioUrl) : null;
		if (mediaKind === "mux" && !audioUrl) continue;
		if (mediaKind === "mux" && audioUrl && !isTrustedPageMux(trustedPageUrl, url, audioUrl)) continue;
		const mimeType = boundedText(item.mimeType, MAX_MIME_LENGTH);
		const inferredMimeType = inferMediaMimeType(url, mimeType) ?? void 0;
		const category = mediaCategory({
			kind: mediaKind,
			url,
			...inferredMimeType ? { mimeType: inferredMimeType } : {}
		});
		const width = positiveInteger(item.width, MAX_DIMENSION);
		const height = positiveInteger(item.height, MAX_DIMENSION);
		const sizeBytes = positiveInteger(item.sizeBytes, Number.MAX_SAFE_INTEGER);
		const alt = boundedText(item.alt, MAX_ALT_LENGTH);
		const filename = suggestedFilename(item.suggestedFilename);
		const evidence = normalizedEvidence(item.evidence);
		const previewable = category === "image" ? inferredMimeType?.split(";", 1)[0]?.trim().toLowerCase() !== "image/svg+xml" && !/\.svgz?(?:$|[?#])/i.test(url) : void 0;
		normalized.push({
			kind: mediaKind,
			url,
			pageUrl: trustedPageUrl,
			pageTitle: boundedText(item.pageTitle, MAX_TITLE_LENGTH) ?? trustedPageUrl,
			detectedAt,
			category,
			...inferredMimeType ? { mimeType: inferredMimeType } : {},
			...audioUrl ? { audioUrl } : {},
			...filename ? { suggestedFilename: filename } : {},
			...sizeBytes ? { sizeBytes } : {},
			...width ? { width } : {},
			...height ? { height } : {},
			...alt ? { alt } : {},
			...previewable !== void 0 ? { previewable } : {},
			...evidence ? { evidence } : {}
		});
	}
	return normalized;
}
/** Resolve a popup selection back to the canonical record held by background. */
async function resolveStoredMedia(requestedKey, queryActiveTab, store) {
	if (typeof requestedKey !== "string" || requestedKey.length === 0 || requestedKey.length > 7e4) throw new Error("Invalid media key");
	const tab = await queryActiveTab();
	if (typeof tab?.id !== "number" || !tab.url) throw new Error("No active tab");
	const trustedPageUrl = httpUrl(tab.url);
	if (!trustedPageUrl) throw new Error("Unsupported active tab");
	const media = (await store.get(tab.id)).find((item) => mediaStorageKey(item) === requestedKey && item.pageUrl === trustedPageUrl);
	if (!media) throw new Error("Media is no longer available on the active tab");
	return media;
}
//#endregion
//#region src/background/MediaThumbnailBroker.ts
var THUMBNAIL_EDGE = 72;
var DEFAULT_TIMEOUT_MS = 1e3;
var CACHE_TTL_MS = 6e4;
var MAX_CACHE_ITEMS = 64;
var MAX_CACHE_BYTES = 524288;
var MAX_DATA_URL_BYTES = 49152;
var MAX_CANDIDATE_FRAMES = 16;
var NO_THUMBNAIL = { dataUrl: null };
function activeTabQuery() {
	return {
		active: true,
		currentWindow: true
	};
}
function isSafeRasterImage(media) {
	if (mediaCategory(media) !== "image" || media.previewable === false) return false;
	if (media.mimeType?.split(";", 1)[0]?.trim().toLowerCase() === "image/svg+xml") return false;
	try {
		return !/\.svgz?$/i.test(new URL(media.url).pathname);
	} catch {
		return false;
	}
}
/**
* Accept only the compact raster data URLs produced by the content-side
* thumbnail renderer. Keeping the response envelope tiny and strict prevents
* a compromised page relay from turning the service worker into blob storage.
*/
function validatedDataUrl(response) {
	if (!response || typeof response !== "object" || !Object.hasOwn(response, "dataUrl")) return null;
	const dataUrl = response.dataUrl;
	if (typeof dataUrl !== "string" || dataUrl.length === 0 || dataUrl.length > MAX_DATA_URL_BYTES) return null;
	return /^data:image\/(?:webp|png|jpeg);base64,((?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?)$/.exec(dataUrl)?.[1] ? dataUrl : null;
}
function cacheKey(tabId, pageUrl, mediaKey) {
	return JSON.stringify([
		tabId,
		pageUrl,
		mediaKey
	]);
}
/**
* Trusted bridge between Popup selections and a page-frame thumbnail renderer.
* The broker never accepts a raw resource URL from Popup: it resolves a stable
* key through MediaStore, authenticates the active tab, and returns only a
* small validated raster data URL.
*/
var MediaThumbnailBroker = class {
	store;
	tabs;
	webNavigation;
	timeoutMs;
	now;
	cache = /* @__PURE__ */ new Map();
	inFlight = /* @__PURE__ */ new Map();
	generationByTab = /* @__PURE__ */ new Map();
	pendingByTab = /* @__PURE__ */ new Map();
	cacheBytes = 0;
	constructor(options) {
		this.store = options.store;
		this.tabs = options.tabs ?? browser.tabs;
		this.webNavigation = options.webNavigation ?? browser.webNavigation;
		this.timeoutMs = Math.max(1, options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
		this.now = options.now ?? Date.now;
	}
	async get(mediaKey) {
		try {
			const [initialTab] = await this.tabs.query(activeTabQuery());
			if (typeof initialTab?.id !== "number" || !initialTab.url) return NO_THUMBNAIL;
			const media = await resolveStoredMedia(mediaKey, async () => initialTab, this.store);
			if (!isSafeRasterImage(media)) return NO_THUMBNAIL;
			const tabId = initialTab.id;
			const pageUrl = initialTab.url;
			if (!await this.contextIsCurrent(tabId, pageUrl)) return NO_THUMBNAIL;
			const key = cacheKey(tabId, pageUrl, mediaStorageKey(media));
			const cached = this.readCache(key);
			if (cached) return { dataUrl: cached };
			const pending = this.inFlight.get(key);
			if (pending) return await pending.promise;
			const generation = this.generationByTab.get(tabId) ?? 0;
			this.pendingByTab.set(tabId, (this.pendingByTab.get(tabId) ?? 0) + 1);
			const promise = this.loadThumbnail(tabId, pageUrl, media, key, generation);
			this.inFlight.set(key, {
				tabId,
				promise
			});
			try {
				return await promise;
			} finally {
				if (this.inFlight.get(key)?.promise === promise) this.inFlight.delete(key);
				const pending = (this.pendingByTab.get(tabId) ?? 1) - 1;
				if (pending > 0) this.pendingByTab.set(tabId, pending);
				else {
					this.pendingByTab.delete(tabId);
					this.generationByTab.delete(tabId);
				}
			}
		} catch {
			return NO_THUMBNAIL;
		}
	}
	clear(tabId) {
		this.generationByTab.set(tabId, (this.generationByTab.get(tabId) ?? 0) + 1);
		for (const [key, entry] of this.cache) if (entry.tabId === tabId) this.deleteCacheEntry(key, entry);
		for (const [key, entry] of this.inFlight) if (entry.tabId === tabId) this.inFlight.delete(key);
		if (!this.pendingByTab.has(tabId)) this.generationByTab.delete(tabId);
	}
	async loadThumbnail(tabId, pageUrl, media, key, generation) {
		const frameIds = await this.candidateFrames(tabId, media.frameUrl);
		if (frameIds.length === 0) return NO_THUMBNAIL;
		const deadline = this.now() + this.timeoutMs;
		for (const frameId of frameIds) {
			const remainingMs = Math.max(0, deadline - this.now());
			if (remainingMs === 0) break;
			const dataUrl = validatedDataUrl(await this.sendWithTimeout(tabId, frameId, media.url, remainingMs));
			if (!dataUrl) continue;
			if ((this.generationByTab.get(tabId) ?? 0) !== generation || !await this.contextIsCurrent(tabId, pageUrl)) return NO_THUMBNAIL;
			this.writeCache(key, tabId, dataUrl);
			return { dataUrl };
		}
		return NO_THUMBNAIL;
	}
	async candidateFrames(tabId, frameUrl) {
		if (!frameUrl) return [0];
		let frames;
		try {
			frames = await this.webNavigation.getAllFrames({ tabId });
		} catch {
			return [];
		}
		const seen = /* @__PURE__ */ new Set();
		const matches = [];
		for (const frame of frames ?? []) {
			if (frame.url !== frameUrl || !Number.isSafeInteger(frame.frameId) || frame.frameId < 0 || seen.has(frame.frameId)) continue;
			seen.add(frame.frameId);
			matches.push(frame.frameId);
			if (matches.length >= MAX_CANDIDATE_FRAMES) break;
		}
		return matches.sort((left, right) => left - right);
	}
	async sendWithTimeout(tabId, frameId, url, timeoutMs) {
		let timer;
		const timeout = new Promise((resolve) => {
			timer = setTimeout(() => resolve(null), timeoutMs);
		});
		try {
			return await Promise.race([Promise.resolve().then(() => this.tabs.sendMessage(tabId, {
				kind: "content.imageThumbnail",
				payload: {
					url,
					maxEdge: THUMBNAIL_EDGE
				}
			}, { frameId })), timeout]);
		} catch {
			return null;
		} finally {
			if (timer !== void 0) clearTimeout(timer);
		}
	}
	async contextIsCurrent(tabId, pageUrl) {
		try {
			const [activeTabs, currentTab] = await Promise.all([this.tabs.query(activeTabQuery()), this.tabs.get(tabId)]);
			const activeTab = activeTabs[0];
			return activeTab?.id === tabId && activeTab.url === pageUrl && currentTab.id === tabId && currentTab.url === pageUrl && currentTab.active !== false;
		} catch {
			return false;
		}
	}
	readCache(key) {
		const entry = this.cache.get(key);
		if (!entry) return null;
		if (entry.expiresAt <= this.now()) {
			this.deleteCacheEntry(key, entry);
			return null;
		}
		this.cache.delete(key);
		this.cache.set(key, entry);
		return entry.dataUrl;
	}
	writeCache(key, tabId, dataUrl) {
		const previous = this.cache.get(key);
		if (previous) this.deleteCacheEntry(key, previous);
		const entry = {
			tabId,
			dataUrl,
			bytes: dataUrl.length,
			expiresAt: this.now() + CACHE_TTL_MS
		};
		this.cache.set(key, entry);
		this.cacheBytes += entry.bytes;
		this.pruneCache();
	}
	pruneCache() {
		const now = this.now();
		for (const [key, entry] of this.cache) if (entry.expiresAt <= now) this.deleteCacheEntry(key, entry);
		while (this.cache.size > MAX_CACHE_ITEMS || this.cacheBytes > MAX_CACHE_BYTES) {
			const oldest = this.cache.entries().next().value;
			if (!oldest) break;
			this.deleteCacheEntry(oldest[0], oldest[1]);
		}
	}
	deleteCacheEntry(key, entry) {
		if (this.cache.get(key) !== entry) return;
		this.cache.delete(key);
		this.cacheBytes = Math.max(0, this.cacheBytes - entry.bytes);
	}
};
//#endregion
//#region src/background/manualTask.ts
var MANUAL_TASK_ERROR = {
	forbidden: "manual-task.forbidden",
	invalidRequest: "manual-task.invalid-request",
	submitFailed: "manual-task.submit-failed"
};
var MIN_IDEMPOTENCY_KEY_LENGTH$1 = 8;
var MAX_IDEMPOTENCY_KEY_LENGTH$1 = 128;
function isExtensionPageSender(sender, extensionId, extensionBaseUrl) {
	return sender.id === extensionId && sender.tab == null && typeof sender.url === "string" && sender.url.startsWith(extensionBaseUrl);
}
function buildManualTaskSubmitParams(parsed, idempotencyKey, detectedAt) {
	const source = {
		pageUrl: parsed.kind === "direct" ? parsed.url : parsed.uri,
		pageTitle: parsed.suggestedFilename,
		detectedAt
	};
	const meta = {
		suggestedFilename: parsed.suggestedFilename,
		qualityLabel: "file"
	};
	const selection = parsed.kind === "direct" ? {
		kind: "direct",
		primary: {
			url: parsed.url,
			headers: {},
			cookies: [],
			refererPolicy: "strict-origin-when-cross-origin"
		}
	} : {
		kind: "magnet",
		uri: parsed.uri
	};
	const result = DownloadSubmitParamsSchema.safeParse({
		source,
		selection,
		meta,
		idempotencyKey
	});
	if (!result.success) throw new Error(MANUAL_TASK_ERROR.invalidRequest);
	return result.data;
}
function createManualTaskHandler(deps) {
	return async (request, sender) => {
		if (!isExtensionPageSender(sender, deps.extensionId, deps.extensionBaseUrl)) throw new Error(MANUAL_TASK_ERROR.forbidden);
		if (!isValidRequest(request)) throw new Error(MANUAL_TASK_ERROR.invalidRequest);
		const parsed = parseManualTaskInput(request.input);
		if (!parsed.ok) throw new Error(MANUAL_TASK_ERROR.invalidRequest);
		const params = buildManualTaskSubmitParams(parsed.value, request.idempotencyKey, (deps.now ?? Date.now)());
		try {
			return await deps.submitDownload(params);
		} catch {
			throw new Error(MANUAL_TASK_ERROR.submitFailed);
		}
	};
}
function isValidRequest(value) {
	if (typeof value !== "object" || value === null) return false;
	const request = value;
	return typeof request.input === "string" && typeof request.idempotencyKey === "string" && request.idempotencyKey.length >= MIN_IDEMPOTENCY_KEY_LENGTH$1 && request.idempotencyKey.length <= MAX_IDEMPOTENCY_KEY_LENGTH$1;
}
//#endregion
//#region src/background/mediaSubmission.ts
var MIN_IDEMPOTENCY_KEY_LENGTH = 8;
var MAX_IDEMPOTENCY_KEY_LENGTH = 128;
/**
* Completes a trusted media submission with the caller's logical-operation
* key. Parsing the complete object keeps the background as the protocol
* boundary and guarantees the key reaches Motrix unchanged.
*/
function applyCallerIdempotencyKey(params, request) {
	const idempotencyKey = typeof request === "object" && request !== null ? request.idempotencyKey : void 0;
	if (typeof idempotencyKey !== "string" || idempotencyKey.length < MIN_IDEMPOTENCY_KEY_LENGTH || idempotencyKey.length > MAX_IDEMPOTENCY_KEY_LENGTH) throw new Error(MEDIA_SUBMIT_ERROR.invalidRequest);
	const parsed = DownloadSubmitParamsSchema.safeParse({
		...params,
		idempotencyKey
	});
	if (!parsed.success) throw new Error(MEDIA_SUBMIT_ERROR.invalidRequest);
	return parsed.data;
}
/** Prevent active URLs, cookies, native paths and transport details leaking. */
function toSafeMediaSubmitError(error) {
	return error?.message === MEDIA_SUBMIT_ERROR.invalidRequest ? error : new Error(MEDIA_SUBMIT_ERROR.submitFailed);
}
//#endregion
//#region src/background/NotificationsConfigStore.ts
var STORAGE_KEY$1 = "motrix.notificationsConfig";
var NotificationsConfigStore = class {
	async get() {
		const v = (await browser.storage.local.get(STORAGE_KEY$1))[STORAGE_KEY$1];
		if (!v || typeof v !== "object") return NOTIFICATIONS_DEFAULT;
		const c = v;
		if (typeof c.master !== "boolean" || typeof c.confirm !== "boolean" || typeof c.error !== "boolean" || typeof c.reminder !== "boolean") return NOTIFICATIONS_DEFAULT;
		return {
			master: c.master,
			confirm: c.confirm,
			error: c.error,
			reminder: c.reminder
		};
	}
	async set(config) {
		await browser.storage.local.set({ [STORAGE_KEY$1]: config });
	}
};
//#endregion
//#region src/background/networkMediaCapture.ts
var NETWORK_MEDIA_REQUEST_TYPES = [
	"media",
	"image",
	"xmlhttprequest",
	"object",
	"other",
	"sub_frame"
];
/** Short-lived request/response correlation cache. */
var REQUEST_HEADERS_TTL_MS = 3e4;
var CAPTURED_REQUEST_HEADERS = /* @__PURE__ */ new Map([
	["cookie", "Cookie"],
	["origin", "Origin"],
	["referer", "Referer"],
	["accept", "Accept"],
	["accept-language", "Accept-Language"],
	["user-agent", "User-Agent"],
	["x-requested-with", "X-Requested-With"]
]);
var MAX_CAPTURED_HEADER_VALUE_LENGTH = 8192;
function headerValue(headers, name) {
	return (headers?.find((header) => header.name.toLowerCase() === name.toLowerCase())?.value)?.trim() || void 0;
}
function contentTypeFrom(headers) {
	return headerValue(headers, "content-type");
}
function requestKey(tabId, requestId) {
	return `${tabId}\u0000${requestId}`;
}
function prunePendingRequestHeaders(context) {
	const oldestAllowed = context.now() - REQUEST_HEADERS_TTL_MS;
	for (const [key, pending] of context.pendingRequestHeaders) {
		if (pending.capturedAt >= oldestAllowed) continue;
		context.pendingRequestHeaders.delete(key);
	}
}
function capturedHeadersFrom(headers) {
	const captured = {};
	for (const header of headers ?? []) {
		const outputName = CAPTURED_REQUEST_HEADERS.get(header.name.toLowerCase());
		const value = header.value?.trim();
		if (!outputName || !value || value.length > MAX_CAPTURED_HEADER_VALUE_LENGTH || /[\r\n]/.test(value)) continue;
		captured[outputName] = value;
	}
	return captured;
}
function rememberRequestHeaders(details, context) {
	if (details.tabId < 0 || !details.requestId) return;
	const url = parseHttpUrl(details.url)?.toString();
	if (!url) return;
	prunePendingRequestHeaders(context);
	const key = requestKey(details.tabId, details.requestId);
	context.pendingRequestHeaders.delete(key);
	context.pendingRequestHeaders.set(key, {
		tabId: details.tabId,
		requestId: details.requestId,
		url,
		...typeof details.frameId === "number" ? { frameId: details.frameId } : {},
		...details.documentId ? { documentId: details.documentId } : {},
		capturedAt: context.now(),
		headers: capturedHeadersFrom(details.requestHeaders)
	});
	while (context.pendingRequestHeaders.size > 512) {
		const oldest = context.pendingRequestHeaders.keys().next().value;
		if (typeof oldest !== "string") break;
		context.pendingRequestHeaders.delete(oldest);
	}
}
function takeRequestHeaders(details, context) {
	if (!details.requestId) return void 0;
	const key = requestKey(details.tabId, details.requestId);
	const pending = context.pendingRequestHeaders.get(key);
	context.pendingRequestHeaders.delete(key);
	if (!pending) return void 0;
	if (context.now() - pending.capturedAt > 3e4) return;
	const responseUrl = parseHttpUrl(details.url)?.toString();
	if (!responseUrl || responseUrl !== pending.url) return void 0;
	if (typeof details.frameId === "number" && typeof pending.frameId === "number" && details.frameId !== pending.frameId) return;
	if (details.documentId && pending.documentId && details.documentId !== pending.documentId) return;
	return Object.keys(pending.headers).length > 0 ? pending.headers : void 0;
}
function clearPendingForTab(tabId, context) {
	for (const [key, pending] of context.pendingRequestHeaders) if (pending.tabId === tabId) context.pendingRequestHeaders.delete(key);
}
function finitePositiveInteger(value) {
	if (!value || !/^\d+$/.test(value.trim())) return void 0;
	const parsed = Number(value);
	return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : void 0;
}
function responseSizeBytes(headers) {
	const contentRange = headerValue(headers, "content-range");
	const total = contentRange ? finitePositiveInteger(/\/\s*(\d+)\s*$/.exec(contentRange)?.[1]) : void 0;
	if (total) return {
		sizeBytes: total,
		evidence: "content-range"
	};
	const contentLength = finitePositiveInteger(headerValue(headers, "content-length"));
	return contentLength ? {
		sizeBytes: contentLength,
		evidence: "content-length"
	} : {};
}
function decodeExtendedFilename(value) {
	const encoded = /^[^']*'[^']*'(.*)$/.exec(value)?.[1] ?? value;
	try {
		return decodeURIComponent(encoded);
	} catch {
		return encoded.replace(/%([\da-f]{2})/gi, (_match, hex) => String.fromCharCode(Number.parseInt(hex, 16)));
	}
}
function cleanSuggestedFilename(value) {
	if (!value) return void 0;
	const leaf = value.replace(/\\(["\\])/g, "$1").split(/[\\/]/).at(-1);
	return leaf ? sanitizeFilename(leaf, "download") : void 0;
}
function contentDispositionFilename(headers) {
	const disposition = headerValue(headers, "content-disposition");
	if (!disposition) return void 0;
	const extended = /(?:^|;)\s*filename\*\s*=\s*(?:"((?:\\.|[^"])*)"|([^;]*))/i.exec(disposition);
	if (extended) {
		const cleaned = cleanSuggestedFilename(decodeExtendedFilename((extended[1] ?? extended[2] ?? "").trim()));
		if (cleaned) return cleaned;
	}
	const basic = /(?:^|;)\s*filename\s*=\s*(?:"((?:\\.|[^"])*)"|([^;]*))/i.exec(disposition);
	return cleanSuggestedFilename((basic?.[1] ?? basic?.[2])?.trim());
}
function filenameFromUrl(url) {
	const rawLeaf = url.pathname.split("/").at(-1);
	if (!rawLeaf) return void 0;
	try {
		return cleanSuggestedFilename(decodeURIComponent(rawLeaf));
	} catch {
		return cleanSuggestedFilename(rawLeaf);
	}
}
function appendMimeExtension(filename, kind, mimeType) {
	const extension = extensionForMediaMimeType(mimeType ?? void 0) ?? (kind === "hls" ? "m3u8" : kind === "dash" ? "mpd" : null);
	const fallback = kind === "direct" ? "download" : "video";
	const filenameMime = normalizeMimeType(inferMediaMimeType(filename));
	if (mimeType && filenameMime === normalizeMimeType(mimeType)) return sanitizeFilename(filename, fallback);
	return extension ? sanitizeFilenameWithExtension(filename, extension, fallback) : sanitizeFilename(filename, fallback);
}
function normalizeMimeType(value) {
	return value?.split(";", 1)[0]?.trim().toLowerCase() || null;
}
function parseHttpUrl(value) {
	if (value.length === 0 || value.length > 32768) return null;
	try {
		const url = new URL(value);
		return url.protocol === "http:" || url.protocol === "https:" ? url : null;
	} catch {
		return null;
	}
}
function pageKey(value) {
	const url = parseHttpUrl(value);
	if (!url) return null;
	url.hash = "";
	return url.toString();
}
function isNoisySegment(url) {
	return /\.(?:ts|m4s)$/i.test(url.pathname);
}
async function getTab(tabs, tabId) {
	try {
		return await tabs.get(tabId);
	} catch {
		return null;
	}
}
async function getAllFrames(webNavigation, tabId) {
	if (!webNavigation?.getAllFrames) return [];
	try {
		return await webNavigation.getAllFrames({ tabId }) ?? [];
	} catch {
		return [];
	}
}
function buildNavigationState(topPageUrl, frames, generation) {
	const topPageKey = pageKey(topPageUrl);
	if (!topPageKey) return null;
	const topFrame = frames.find((frame) => frame.frameId === 0);
	if (topFrame && pageKey(topFrame.url) !== topPageKey) return null;
	const owners = /* @__PURE__ */ new Map();
	for (const frame of frames) {
		const frameUrlKey = pageKey(frame.url);
		if (!frameUrlKey) continue;
		owners.set(frame.frameId, {
			frameId: frame.frameId,
			parentFrameId: frame.parentFrameId,
			frameUrlKey,
			...frame.documentId ? { documentId: frame.documentId } : {},
			topPageUrl,
			generation
		});
	}
	if (!owners.has(0)) owners.set(0, {
		frameId: 0,
		parentFrameId: -1,
		frameUrlKey: topPageKey,
		topPageUrl,
		generation
	});
	return {
		generation,
		topPageUrl,
		topPageKey,
		frames: owners
	};
}
async function refreshNavigationState(tabId, context) {
	const stateAtStart = context.navigationByTab.get(tabId);
	const [tab, frames] = await Promise.all([getTab(context.tabs, tabId), getAllFrames(context.webNavigation, tabId)]);
	const newerState = context.navigationByTab.get(tabId);
	if (newerState && newerState !== stateAtStart) return newerState;
	if (!tab?.url) return null;
	const state = buildNavigationState(tab.url, frames, stateAtStart?.generation ?? 0);
	if (state) context.navigationByTab.set(tabId, state);
	return state;
}
function isDescendantOf(frameId, ancestorId, frames) {
	let current = frames.get(frameId);
	const seen = /* @__PURE__ */ new Set();
	while (current && current.parentFrameId >= 0 && !seen.has(current.frameId)) {
		if (current.parentFrameId === ancestorId) return true;
		seen.add(current.frameId);
		current = frames.get(current.parentFrameId);
	}
	return false;
}
function commitNavigation(details, context, newDocument) {
	const frameUrlKey = pageKey(details.url);
	if (!frameUrlKey || details.tabId < 0) return;
	const current = context.navigationByTab.get(details.tabId);
	const pageChanged = details.frameId === 0 && current?.topPageUrl !== details.url;
	if (newDocument || pageChanged) for (const [key, pending] of context.pendingRequestHeaders) {
		if (pending.tabId !== details.tabId) continue;
		if (details.frameId === 0 || pending.frameId === details.frameId || typeof pending.frameId === "number" && current && isDescendantOf(pending.frameId, details.frameId, current.frames)) context.pendingRequestHeaders.delete(key);
	}
	if (details.frameId === 0) {
		const generation = current === void 0 ? 0 : current.generation + (newDocument || current.topPageUrl !== details.url ? 1 : 0);
		const frames = newDocument ? /* @__PURE__ */ new Map() : new Map(current?.frames);
		for (const [frameId, owner] of frames) frames.set(frameId, {
			...owner,
			topPageUrl: details.url,
			generation
		});
		frames.set(0, {
			frameId: 0,
			parentFrameId: -1,
			frameUrlKey,
			...details.documentId ? { documentId: details.documentId } : {},
			topPageUrl: details.url,
			generation
		});
		context.navigationByTab.set(details.tabId, {
			generation,
			topPageUrl: details.url,
			topPageKey: frameUrlKey,
			frames
		});
		context.credentialStore?.retainPage(details.tabId, details.url);
		context.store.retainPage(details.tabId, details.url).catch(() => {});
		return;
	}
	if (!current) return;
	const frames = new Map(current.frames);
	if (newDocument) {
		for (const frameId of frames.keys()) if (frameId === details.frameId || isDescendantOf(frameId, details.frameId, frames)) frames.delete(frameId);
	}
	frames.set(details.frameId, {
		frameId: details.frameId,
		parentFrameId: details.parentFrameId,
		frameUrlKey,
		...details.documentId ? { documentId: details.documentId } : {},
		topPageUrl: current.topPageUrl,
		generation: current.generation
	});
	context.navigationByTab.set(details.tabId, {
		...current,
		frames
	});
}
async function resolveFrameOwner(details, context) {
	let state = context.navigationByTab.get(details.tabId);
	let refreshed = false;
	if (!state) {
		const restoredState = await refreshNavigationState(details.tabId, context);
		if (!restoredState) return null;
		state = restoredState;
		refreshed = true;
	}
	let frameId = details.frameId;
	if (typeof frameId !== "number") {
		if ((details.documentUrl ? pageKey(details.documentUrl) : null) !== state.topPageKey) return null;
		frameId = 0;
	}
	const documentUrlKey = details.documentUrl ? pageKey(details.documentUrl) : null;
	let owner = state.frames.get(frameId);
	if ((!owner || Boolean(details.documentId && !owner.documentId && !documentUrlKey)) && !refreshed) {
		state = await refreshNavigationState(details.tabId, context) ?? state;
		owner = state.frames.get(frameId);
	}
	if (!owner || owner.generation !== state.generation) return null;
	if (details.documentId && owner.documentId && details.documentId !== owner.documentId) return null;
	if (documentUrlKey && documentUrlKey !== owner.frameUrlKey) return null;
	if (!details.documentId && !documentUrlKey) return null;
	if (details.documentId && !owner.documentId && !documentUrlKey) return null;
	return {
		owner,
		state
	};
}
/**
* Persist one response observed by webRequest. This path deliberately has no
* Backend/ConnectionManager dependency: discovery remains useful while Motrix
* is offline and submission is gated later by the Popup.
*/
async function captureNetworkMediaResponse(details, context, requestHeaders) {
	if (details.tabId < 0) return;
	if (typeof details.statusCode === "number" && details.statusCode >= 300 && details.statusCode < 400) return;
	const resourceUrl = parseHttpUrl(details.url);
	if (!resourceUrl || isNoisySegment(resourceUrl)) return;
	if (shouldExcludeHost(resourceUrl.hostname, context.webStore)) return;
	const contentType = contentTypeFrom(details.responseHeaders);
	const kind = classifyMediaUrl(resourceUrl.toString(), contentType);
	if (!kind) return;
	const resolved = await resolveFrameOwner(details, context);
	if (!resolved) return;
	const { owner, state } = resolved;
	const currentTab = await getTab(context.tabs, details.tabId);
	const currentPageUrl = currentTab?.url ? parseHttpUrl(currentTab.url) : null;
	const currentPageKey = currentPageUrl ? pageKey(currentPageUrl.toString()) : null;
	const latestState = context.navigationByTab.get(details.tabId);
	if (!currentTab?.url || !currentPageUrl || shouldExcludeHost(currentPageUrl.hostname, context.webStore) || currentPageKey !== state.topPageKey || latestState !== state || owner.generation !== state.generation) return;
	const inferredMime = normalizeMimeType(inferMediaMimeType(resourceUrl.toString(), contentType));
	const dispositionFilename = contentDispositionFilename(details.responseHeaders);
	const suggestedFilename = appendMimeExtension(dispositionFilename ?? filenameFromUrl(resourceUrl) ?? cleanSuggestedFilename(currentTab.title) ?? "media", kind, inferredMime);
	const { sizeBytes, evidence: sizeEvidence } = responseSizeBytes(details.responseHeaders);
	const acceptsRanges = /^bytes$/i.test(headerValue(details.responseHeaders, "accept-ranges") ?? "");
	const evidence = /* @__PURE__ */ new Set(["network"]);
	if (contentType) evidence.add("content-type");
	if (dispositionFilename) evidence.add("content-disposition");
	if (sizeEvidence) evidence.add(sizeEvidence);
	if (acceptsRanges) evidence.add("accept-ranges");
	const category = mediaCategory({
		kind,
		url: resourceUrl.toString(),
		...inferredMime ? { mimeType: inferredMime } : {}
	});
	const isSvg = inferredMime === "image/svg+xml" || /\.svgz?$/i.test(resourceUrl.pathname);
	const media = {
		kind,
		url: resourceUrl.toString(),
		pageUrl: currentTab.url,
		pageTitle: currentTab.title?.trim().slice(0, 512) || currentTab.url,
		detectedAt: typeof details.timeStamp === "number" && Number.isFinite(details.timeStamp) ? details.timeStamp : context.now(),
		...inferredMime ? { mimeType: inferredMime } : {},
		category,
		suggestedFilename,
		...sizeBytes ? { sizeBytes } : {},
		frameUrl: details.documentUrl || owner.frameUrlKey,
		evidence: [...evidence],
		...category === "image" ? { previewable: !isSvg } : {}
	};
	const credentialObservation = {
		tabId: details.tabId,
		pageUrl: media.pageUrl,
		url: media.url,
		observedAt: context.now(),
		requestHeaders: requestHeaders ?? {}
	};
	context.credentialStore?.remember(credentialObservation);
	await context.store.addForPage(details.tabId, media.pageUrl, [media]);
}
function resolveGlobalApis() {
	const globals = globalThis;
	return {
		webRequest: globals.browser?.webRequest ?? globals.chrome?.webRequest,
		webNavigation: globals.browser?.webNavigation ?? globals.chrome?.webNavigation,
		tabs: globals.browser?.tabs ?? globals.chrome?.tabs
	};
}
/** Register synchronously during service-worker evaluation. */
function registerNetworkMediaCapture(options) {
	const globals = resolveGlobalApis();
	const webRequest = options.webRequest ?? globals.webRequest;
	const webNavigation = options.webNavigation ?? globals.webNavigation;
	const tabs = options.tabs ?? globals.tabs;
	if (!webRequest?.onHeadersReceived || !tabs?.get) return () => void 0;
	const context = {
		store: options.store,
		...options.credentialStore ? { credentialStore: options.credentialStore } : {},
		tabs,
		...webNavigation ? { webNavigation } : {},
		webStore: options.webStore ?? isWebStoreBuild(),
		now: options.now ?? Date.now,
		navigationByTab: /* @__PURE__ */ new Map(),
		pendingRequestHeaders: /* @__PURE__ */ new Map()
	};
	const onSendHeaders = (details) => {
		if (context.webStore) {
			const topPageUrl = context.navigationByTab.get(details.tabId)?.topPageUrl;
			if (!topPageUrl) return;
			const candidateUrls = [
				topPageUrl,
				details.documentUrl,
				details.initiator,
				details.url
			];
			try {
				for (const candidate of candidateUrls) if (candidate && shouldExcludeHost(new URL(candidate).hostname, true)) return;
			} catch {
				return;
			}
		}
		rememberRequestHeaders(details, context);
	};
	const onHeadersReceived = (details) => {
		const requestHeaders = takeRequestHeaders(details, context);
		captureNetworkMediaResponse(details, context, requestHeaders).catch(() => {});
	};
	const onCommitted = (details) => {
		commitNavigation(details, context, true);
	};
	const onHistoryStateUpdated = (details) => {
		commitNavigation(details, context, false);
	};
	const onTabUpdated = (tabId, changeInfo, tab) => {
		const pageUrl = changeInfo.url ?? tab.url;
		if (!changeInfo.url || !pageUrl) return;
		if (context.navigationByTab.get(tabId)?.topPageUrl === pageUrl) return;
		commitNavigation({
			tabId,
			frameId: 0,
			parentFrameId: -1,
			url: pageUrl
		}, context, true);
	};
	const onTabRemoved = (tabId) => {
		context.navigationByTab.delete(tabId);
		clearPendingForTab(tabId, context);
		context.credentialStore?.clear(tabId);
		options.store.clear(tabId).catch(() => {});
	};
	const cleanups = [];
	const cleanup = () => {
		for (const remove of cleanups.splice(0).reverse()) try {
			remove();
		} catch {}
		context.pendingRequestHeaders.clear();
		context.credentialStore?.clearAll();
	};
	try {
		if (webRequest.onSendHeaders) {
			const requestFilter = {
				urls: ["http://*/*", "https://*/*"],
				types: [...NETWORK_MEDIA_REQUEST_TYPES]
			};
			let requestListenerRegistered = false;
			if (options.includeExtraHeaders) try {
				webRequest.onSendHeaders.addListener(onSendHeaders, requestFilter, ["requestHeaders", "extraHeaders"]);
				requestListenerRegistered = true;
			} catch {}
			if (!requestListenerRegistered) webRequest.onSendHeaders.addListener(onSendHeaders, requestFilter, ["requestHeaders"]);
			cleanups.push(() => {
				webRequest.onSendHeaders?.removeListener?.(onSendHeaders);
			});
		}
		webRequest.onHeadersReceived.addListener(onHeadersReceived, {
			urls: ["http://*/*", "https://*/*"],
			types: [...NETWORK_MEDIA_REQUEST_TYPES]
		}, ["responseHeaders"]);
		cleanups.push(() => {
			webRequest.onHeadersReceived.removeListener?.(onHeadersReceived);
		});
		if (webNavigation?.onCommitted) {
			webNavigation.onCommitted.addListener(onCommitted);
			cleanups.push(() => {
				webNavigation.onCommitted?.removeListener?.(onCommitted);
			});
		}
		if (webNavigation?.onHistoryStateUpdated) {
			webNavigation.onHistoryStateUpdated.addListener(onHistoryStateUpdated);
			cleanups.push(() => {
				webNavigation.onHistoryStateUpdated?.removeListener?.(onHistoryStateUpdated);
			});
		}
		if (tabs.onUpdated) {
			tabs.onUpdated.addListener(onTabUpdated);
			cleanups.push(() => {
				tabs.onUpdated?.removeListener?.(onTabUpdated);
			});
		}
		if (tabs.onRemoved) {
			tabs.onRemoved.addListener(onTabRemoved);
			cleanups.push(() => {
				tabs.onRemoved?.removeListener?.(onTabRemoved);
			});
		}
	} catch {
		cleanup();
		return () => void 0;
	}
	return cleanup;
}
//#endregion
//#region src/background/notify.ts
function createNotify(store) {
	return (n) => {
		(async () => {
			const cfg = await store.get();
			if (!isSeverityEnabled(cfg, n.severity)) return;
			await browser.notifications?.create({
				type: "basic",
				iconUrl: browser.runtime.getURL("icons/icon-128.png"),
				title: n.title,
				message: n.message
			}).catch(() => {});
		})();
	};
}
//#endregion
//#region src/background/PairingEndpointService.ts
/** Convert a resolved catalogue snapshot into its credential authority. */
function pairingAuthorityForEndpoint(endpoint) {
	if (endpoint.mode === "local") return LOCAL_BACKEND_AUTHORITY;
	if (typeof endpoint.endpointId !== "string" || endpoint.endpointId.length === 0) throw new Error("remote endpoint is missing its stable id");
	return createRemoteBackendAuthority({
		endpointId: endpoint.endpointId,
		wsBase: endpoint.remoteUrl
	});
}
/**
* Endpoint-explicit pairing operations used by runtime message handlers.
* Resolving the id and mutating credentials happen against one immutable
* snapshot, preventing an active-endpoint switch from redirecting an
* operation to another backend while an Options request is in flight.
*/
var PairingEndpointService = class {
	endpointConfigStore;
	local;
	coordinator;
	onActiveUnpair;
	constructor(endpointConfigStore, local, options = {}) {
		this.endpointConfigStore = endpointConfigStore;
		this.local = local;
		this.coordinator = options.coordinator ?? new BackendOperationCoordinator();
		this.onActiveUnpair = options.onActiveUnpair ?? (() => void 0);
	}
	/**
	* Pairing status is an authority-scoped MBP1 credential predicate for both
	* the App and configured Servers. A remote snapshot without its stable
	* catalogue id cannot define a credential authority and is rejected.
	*/
	async getStatus(endpointId) {
		return this.coordinator.run(async () => {
			const { endpoint } = await this.resolve(endpointId);
			return { paired: await this.paired(endpoint) };
		});
	}
	/**
	* Answers "is the currently active endpoint paired" — the same predicate
	* as `getStatus`, resolved against `activeEndpointId` instead of a
	* caller-supplied one. This is the one place outside the options UI that
	* needs `paired`: the auto-takeover gate (`makeOps.isPaired`) and the
	* context-menu label both call this rather than re-deriving the check.
	*/
	async isActivePaired() {
		return this.coordinator.run(async () => {
			const config = await this.endpointConfigStore.get();
			return this.paired(resolveActiveEndpoint(config));
		});
	}
	async paired(endpoint) {
		const authority = pairingAuthorityForEndpoint(endpoint);
		return this.local.credentialStore.hasCommittedCredentialForAuthority(authority, await this.localPrincipal());
	}
	/**
	* §12: "Expired or revoked credentials always require a fresh code-entry
	* pairing — never silent re-trust." Delete the current principal's MBP1
	* credentials within the endpoint authority. Local routing pins are hints
	* and are removed before the authoritative credential write; remote
	* authorities have no local-port pins.
	*/
	async unpair(endpointId) {
		return this.coordinator.run(async () => {
			const { endpoint, active } = await this.resolve(endpointId, true);
			const authority = pairingAuthorityForEndpoint(endpoint);
			const principal = await this.localPrincipal();
			if (endpoint.mode === "local") await this.local.credentialStore.revokePrincipalForAuthority(authority, principal, async (ids) => {
				for (const id of ids) try {
					await this.local.pinStore.clear(id);
				} catch {}
			});
			else await this.local.credentialStore.revokePrincipalForAuthority(authority, principal);
			if (active) await this.onActiveUnpair(authority, endpointId);
			return { active };
		});
	}
	async localPrincipal() {
		return {
			browser: this.local.browser,
			verifiedOrigin: computeVerifiedOrigin(),
			clientInstallationId: await getClientInstallationId()
		};
	}
	async resolve(endpointId, forLifecycleMutation = false) {
		const config = forLifecycleMutation ? await this.endpointConfigStore.getForLifecycleMutation() : await this.endpointConfigStore.get();
		const endpoint = resolveEndpointById(config, endpointId);
		if (endpoint === null) throw new Error(`unknown endpoint: ${endpointId}`);
		return {
			endpoint,
			active: config.activeEndpointId === endpointId
		};
	}
};
//#endregion
//#region src/background/pairing-code-source.ts
/**
* `PairingCodeProvider`'s contract requires it to settle within
* `request.timeoutMs` on its own: `PairingFlow` has no way to cancel a
* pending call, so a provider that simply waits for the popup to respond
* would hold the session open past every deadline §6.5/§7.2 set the moment
* the user walked away without answering. The `setTimeout` below is what
* actually enforces that; `submit` answering before it fires is just the
* happy path.
*
* Extracted out of `service-worker.ts` so this guarantee has a test —
* a deadline enforced only inline in a file with no test coverage is a
* guarantee nobody will notice losing to a future "simplify, the UI already
* has a timer" edit.
*/
function createPairingCodeSource(deps = {}) {
	const now = deps.now ?? Date.now;
	const scheduleTimeout = deps.setTimeout ?? ((callback, ms) => setTimeout(callback, ms));
	const cancelTimeout = deps.clearTimeout ?? ((handle) => clearTimeout(handle));
	let pending = null;
	const provider = (request) => new Promise((resolve, reject) => {
		let timer;
		const entry = {
			request,
			deadlineMs: now() + request.timeoutMs,
			resolve: (code) => {
				if (pending !== entry) return;
				cancelTimeout(timer);
				pending = null;
				resolve(code);
			}
		};
		pending = entry;
		timer = scheduleTimeout(() => {
			if (pending === entry) pending = null;
			reject(/* @__PURE__ */ new Error(`pairing code entry timed out after ${request.timeoutMs}ms`));
		}, request.timeoutMs);
	});
	return {
		provider,
		submit: (code) => {
			if (pending === null) return false;
			pending.resolve(code);
			return true;
		},
		getPending: () => pending === null ? null : {
			request: pending.request,
			deadlineMs: pending.deadlineMs
		}
	};
}
//#endregion
//#region src/background/pairNudge.ts
var KEY = "motrix.takeover.lastPairNudgeAt";
var WINDOW_MS = 864e5;
var PairNudge = class {
	notify;
	now;
	constructor(deps) {
		this.notify = deps.notify;
		this.now = deps.now ?? (() => Date.now());
	}
	async maybeNudge() {
		const last = (await browser.storage.local.get(KEY))[KEY];
		const lastAt = typeof last === "number" && last > 0 ? last : 0;
		const t = this.now();
		if (lastAt > 0 && t - lastAt < WINDOW_MS) return;
		await browser.storage.local.set({ [KEY]: t });
		this.notify({
			title: instance.t("notify.pairNudgeTitle"),
			message: instance.t("notify.pairNudgeBody"),
			severity: "reminder"
		});
	}
};
//#endregion
//#region src/background/storage-migrations.ts
/** Retired credential namespaces that must never be reused. */
var RETIRED_PAIR_TOKEN_STORAGE_KEYS = ["motrix.pairTokens", "motrix.pairToken"];
/**
* Permanently remove the token-era pairing stores.
*
* Values are deliberately neither read nor parsed: no token shape, including
* an unknown future version, is a valid input to MBP1 credential migration.
* Repeating the exact remove on every service-worker start is the tombstone;
* a marker could be left behind while a rolled-back build writes a token back.
*
* Service-worker startup invokes this on every wake before endpoint
* autostart. It is intentionally not a data migration: retired secrets are
* only deleted, never decoded or copied into MBP1 state.
*/
async function purgeRetiredPairTokenStorage(storage = browser.storage.local) {
	await storage.remove([...RETIRED_PAIR_TOKEN_STORAGE_KEYS]);
}
/** Testable startup barrier: autostart is unreachable until both the blind
* token tombstone and interrupted authority cleanup have completed. */
async function recoverStorageBeforeEndpointAutostart(deps, storage = browser.storage.local) {
	await purgeRetiredPairTokenStorage(storage);
	await deps.recoverPendingEndpointCleanup();
	await deps.autostart();
}
//#endregion
//#region src/background/TakeoverConfigStore.ts
var STORAGE_KEY = "motrix.takeoverConfig";
function isRule(v) {
	if (!v || typeof v !== "object") return false;
	const r = v;
	return typeof r.id === "string" && typeof r.match === "object" && r.match !== null && (r.action === "motrix" || r.action === "chrome" || r.action === "ask");
}
var TakeoverConfigStore = class {
	async get() {
		const v = (await browser.storage.local.get(STORAGE_KEY))[STORAGE_KEY];
		if (!v || typeof v !== "object") return TAKEOVER_DEFAULT;
		const c = v;
		if (typeof c.enabled !== "boolean" || typeof c.consentAckVersion !== "number") return TAKEOVER_DEFAULT;
		if (c.defaultAction !== "motrix" && c.defaultAction !== "chrome") return TAKEOVER_DEFAULT;
		if (!Array.isArray(c.rules) || !c.rules.every(isRule)) return TAKEOVER_DEFAULT;
		return {
			enabled: c.enabled,
			consentAckVersion: c.consentAckVersion,
			defaultAction: c.defaultAction,
			rules: c.rules
		};
	}
	async set(config) {
		await browser.storage.local.set({ [STORAGE_KEY]: config });
	}
};
//#endregion
//#region src/background/taskReveal.ts
/**
* Forward a user-initiated reveal only while the authenticated backend still
* advertises the desktop-shell capability. Reading the capability at call
* time prevents an endpoint switch or disconnect from reusing stale support.
*/
async function requestTaskReveal(manager, params) {
	if (manager.getServerCapabilities()?.taskReveal !== true) throw new Error("connected Motrix does not support task/reveal");
	return manager.request(Methods.TaskReveal, params);
}
//#endregion
//#region src/background/UrlResolutionDispatcher.ts
var UrlResolutionError = class extends Error {
	code;
	constructor(message, code) {
		super(message);
		this.name = "UrlResolutionError";
		this.code = code;
	}
};
/**
* On url/resolve, find a tab whose URL matches an adapter pattern and
* forward the request via tabs.sendMessage. The cross-process round-trip
* is the race-y bit (Plan 03b risk #2): we cap with a timeout and surface
* specific error codes so the upstream MDXP caller can react.
*/
var UrlResolutionDispatcher = class {
	registry;
	tabs;
	timeoutMs;
	constructor(opts = {}) {
		this.registry = opts.registry ?? new BgAdapterRegistry();
		this.tabs = opts.tabs ?? browser.tabs;
		this.timeoutMs = opts.timeoutMs ?? 3e4;
	}
	async resolve(url, preferences) {
		const adapter = this.registry.findFor(url);
		if (!adapter) throw new UrlResolutionError(`no adapter for ${url}`, "no-tab");
		const targetTab = (await this.tabs.query({ url: adapter.urlPatterns })).find((t) => typeof t.id === "number");
		if (!targetTab || targetTab.id === void 0) throw new UrlResolutionError(`no open ${adapter.id} tab to resolve ${url}`, "no-tab");
		const envelope = {
			kind: "content.resolve",
			payload: preferences === void 0 ? { url } : {
				url,
				preferences
			}
		};
		return await this.sendWithTimeout(targetTab.id, envelope);
	}
	async sendWithTimeout(tabId, envelope) {
		let timer = null;
		try {
			const sendPromise = this.tabs.sendMessage(tabId, envelope);
			const timeoutPromise = new Promise((_resolve, reject) => {
				timer = setTimeout(() => {
					reject(new UrlResolutionError(`content script did not respond within ${this.timeoutMs}ms`, "timeout"));
				}, this.timeoutMs);
			});
			const raw = await Promise.race([sendPromise, timeoutPromise]);
			if (raw && typeof raw === "object" && "error" in raw) throw new UrlResolutionError(String(raw.error), "tab-error");
			return raw;
		} catch (e) {
			if (e instanceof UrlResolutionError) throw e;
			log.warn("tabs.sendMessage failed", e);
			throw new UrlResolutionError(e.message ?? "tab dispatch failed", "tab-error");
		} finally {
			if (timer !== null) clearTimeout(timer);
		}
	}
};
//#endregion
//#region src/content/sniffer-entry.ts?scriptId=QPw5G
var sniffer_entry_default = "src/content/sniffer-entry.js";
//#endregion
//#region src/content/sniffer-relay.ts?scriptId=mAouJ
var sniffer_relay_default = "src/content/sniffer-relay.js";
//#endregion
//#region src/background/service-worker.ts
var manifest = browser.runtime.getManifest();
var extensionId = browser.runtime.id;
var mediaStore = new MediaStore();
var mediaCredentialStore = new MediaCredentialStore();
var mediaReportLimiter = new MediaReportLimiter();
var mediaThumbnailBroker = new MediaThumbnailBroker({ store: mediaStore });
registerNetworkMediaCapture({
	store: mediaStore,
	credentialStore: mediaCredentialStore,
	webStore: isWebStoreBuild(),
	includeExtraHeaders: false
});
browser.tabs.onRemoved.addListener((tabId) => {
	mediaReportLimiter.clear(tabId);
	mediaThumbnailBroker.clear(tabId);
});
browser.tabs.onUpdated.addListener((tabId, changeInfo) => {
	if (changeInfo.url) {
		mediaReportLimiter.clear(tabId);
		mediaThumbnailBroker.clear(tabId);
	}
});
var endpointConfigStore = new EndpointConfigStore();
var backendOperationCoordinator = new BackendOperationCoordinator();
var handoffEndpoints = new HandoffEndpointTracker(endpointConfigStore, backendOperationCoordinator);
var takeoverConfigStore = new TakeoverConfigStore();
var notificationsConfigStore = new NotificationsConfigStore();
var badgeErrorStore = new BadgeErrorStore();
var gate = new ConnectionGate();
var adapterRegistry = new BgAdapterRegistry();
var resolutionDispatcher = new UrlResolutionDispatcher({ registry: adapterRegistry });
var credentialStore = new CredentialStore();
var pinStore = new PinStore();
var manager;
var endpointCatalogService = new EndpointCatalogService(endpointConfigStore, { retire: async (authority) => {
	await credentialStore.revokeAuthority(authority);
	await ConnectionGate.forAuthority(authority).clear();
	await clearRemoteBackendPoliciesForAuthority(authority);
} }, {
	coordinator: backendOperationCoordinator,
	beforeConnectionChange: () => {
		handoffEndpoints.invalidate();
		manager.stopForEndpointChange();
	},
	afterConnectionChange: () => {
		manager.clearGateAndStart().catch(() => {
			log.warn("backend connection restart failed after endpoint change");
		});
	}
});
var badge = new BadgeController({
	getState: () => manager.getState(),
	hasActiveTasks: () => manager.hasActiveTasks(),
	errorStore: badgeErrorStore
});
var notify = makeBadgeNotify(createNotify(notificationsConfigStore), badge);
var pairingCode = createPairingCodeSource();
manager = new ConnectionManager({
	endpointConfigStore,
	backendOperationCoordinator,
	endpointLifecycleService: endpointCatalogService,
	gate,
	adapterRegistry,
	resolutionDispatcher,
	notify,
	pairingCodeSource: pairingCode.provider,
	credentialStore,
	pinStore,
	clientInfo: {
		kind: "extension",
		name: "motrix-extension",
		version: manifest.version,
		extensionId,
		browser: "firefox",
		browserVersion: navigator.userAgent,
		locale: browser.i18n?.getUILanguage?.() ?? "en"
	}
});
var pairingEndpointService = new PairingEndpointService(endpointConfigStore, {
	credentialStore,
	pinStore,
	browser: "firefox"
}, {
	coordinator: backendOperationCoordinator,
	onActiveUnpair: async (authority) => {
		manager.stop();
		await ConnectionGate.forAuthority(authority).clear();
	}
});
var endpointLifecycleReady = recoverStorageBeforeEndpointAutostart({
	recoverPendingEndpointCleanup: () => endpointCatalogService.recoverPendingCleanup(),
	autostart: () => manager.autostart()
}).catch(() => {
	log.warn("pre-autostart storage recovery failed; autostart suppressed");
	throw new Error("background startup unavailable");
});
endpointLifecycleReady.catch(() => void 0);
manager.onStateChange((s) => {
	log.info("connection state →", s);
});
manager.onStateChange(() => void badge.refresh());
manager.onActivityChange(() => {
	badge.refresh();
	const event = { kind: CONTROL_PANEL_ACTIVITY_EVENT };
	browser.runtime.sendMessage(event).catch(() => void 0);
});
badge.refresh();
var bus = new MessageBus({ beforeDispatch: () => endpointLifecycleReady });
bus.on("bg.getState", async () => {
	const lastError = manager.getLastError();
	const server = manager.getServerIdentity();
	const errorReason = manager.getLastErrorReason();
	const retryAtMs = manager.getLastErrorRetryAtMs();
	const pending = manager.getPendingPairingCode();
	const capabilities = manager.getServerCapabilities();
	const recoveryExhaustedUnattended = errorReason === "recoveryExhaustedUnattended";
	return {
		state: manager.getState(),
		...lastError === null || recoveryExhaustedUnattended ? {} : {
			lastError,
			...errorReason === null ? {} : { lastErrorReason: errorReason }
		},
		...server === null ? {} : { server },
		...pending === null ? {} : { pairingCode: {
			run: pending.request.run,
			maxRuns: 3,
			attemptsRemaining: pending.request.attemptsRemaining,
			deadlineMs: pending.deadlineMs
		} },
		...errorReason === "backoffLocked" && retryAtMs !== null ? { backoff: { retryAtMs } } : {},
		...manager.getDegraded() === true ? { degraded: true } : {},
		capabilities: { taskReveal: capabilities?.taskReveal === true },
		...recoveryExhaustedUnattended ? { recoveryExhaustedUnattended: true } : {}
	};
});
bus.on("bg.reconnect", async () => {
	await manager.clearGateAndStart();
	return { ok: true };
});
bus.on("bg.clearBadgeError", async () => {
	await badge.clearError();
	return { ok: true };
});
bus.on("bg.getEndpointConfig", async () => endpointConfigStore.get());
bus.on("bg.activateEndpoint", async ({ endpointId }) => {
	const { config } = await endpointCatalogService.activate(endpointId);
	return { config };
});
bus.on("bg.addServer", async (input) => {
	return endpointCatalogService.addServer(input);
});
bus.on("bg.updateServer", async ({ endpointId, expected, changes }) => {
	return await endpointCatalogService.updateServer(endpointId, expected, changes);
});
bus.on("bg.removeServer", async ({ endpointId, expected }) => {
	return endpointCatalogService.removeServer(endpointId, expected);
});
bus.on("bg.getPairingStatus", async ({ endpointId }) => {
	return pairingEndpointService.getStatus(endpointId);
});
bus.on("bg.getRemoteBackendPolicy", async () => ({ policy: await manager.getRemoteBackendPolicy() }));
bus.on("bg.replaceRemoteBackendPolicy", async (replacement) => ({ policy: await manager.replaceRemoteBackendPolicy(replacement) }));
bus.on("bg.getTakeoverConfig", async () => takeoverConfigStore.get());
bus.on("bg.setTakeoverConfig", async (payload) => {
	await takeoverConfigStore.set(payload);
	return { ok: true };
});
bus.on("bg.getNotificationsConfig", async () => notificationsConfigStore.get());
bus.on("bg.setNotificationsConfig", async (payload) => {
	await notificationsConfigStore.set(payload);
	return { ok: true };
});
bus.on("bg.unpair", async ({ endpointId }) => {
	const { active } = await pairingEndpointService.unpair(endpointId);
	if (active) refreshMenuTitle();
	return { ok: true };
});
bus.on("bg.pairHeartbeat", async () => ({ ok: true }));
bus.on("bg.listPairCandidates", async () => {
	return { candidates: await manager.listPairCandidates({ allowLaunch: true }) };
});
bus.on("bg.chooseCandidate", async ({ port }) => {
	manager.choosePairCandidate(port);
	manager.clearGateAndStart();
	return { ok: true };
});
bus.on("bg.submitPairingCode", async ({ code }) => {
	if (manager.getState() !== "awaiting-code" || !pairingCode.submit(code)) return { ok: false };
	return { ok: true };
});
bus.on("bg.listAdapters", async () => ({ adapters: adapterRegistry.list().map((a) => ({
	id: a.id,
	version: a.version,
	urlPatterns: a.urlPatterns
})) }));
bus.on("bg.taskList", async (params) => manager.request(Methods.TaskList, params));
bus.on("bg.taskGet", async (params) => manager.request(Methods.TaskGet, params));
bus.on("bg.taskPause", async (params) => manager.request(Methods.TaskPause, params));
bus.on("bg.taskResume", async (params) => manager.request(Methods.TaskResume, params));
bus.on("bg.taskReveal", async (params) => requestTaskReveal(manager, params));
bus.on("bg.taskRemove", async (params) => manager.request(Methods.TaskRemove, params));
bus.on("bg.statsGet", async (params) => manager.request(Methods.StatsGet, params));
bus.on("bg.engineStatus", async (params) => manager.request(Methods.EngineStatus, params));
bus.on("bg.submitDownload", async (params) => manager.submitDownload(params));
bus.on("bg.createManualTask", createManualTaskHandler({
	extensionId,
	extensionBaseUrl: browser.runtime.getURL(""),
	submitDownload: (params) => manager.submitDownload(params)
}));
bus.on("bg.cancelDownload", async (params) => {
	await manager.cancelDownload(params.taskId);
	return { ok: true };
});
function senderDocumentKey(value) {
	if (!value) return null;
	try {
		const url = new URL(value);
		if (url.protocol !== "http:" && url.protocol !== "https:") return null;
		url.hash = "";
		return url.toString();
	} catch {
		return null;
	}
}
bus.on("bg.mediaDetected", async (payload, sender) => {
	const messageSender = sender;
	const senderTab = messageSender.tab;
	const tabId = senderTab?.id;
	const senderTopUrl = senderTab?.url;
	if (typeof tabId === "number" && typeof senderTopUrl === "string") {
		if (!mediaReportLimiter.allow(tabId, payload)) return { ok: true };
		let currentTab;
		try {
			currentTab = await browser.tabs.get(tabId);
			if (!currentTab.url || senderDocumentKey(currentTab.url) !== senderDocumentKey(senderTopUrl) || shouldExcludeHost(new URL(currentTab.url).hostname, isWebStoreBuild())) return { ok: true };
		} catch {
			return { ok: true };
		}
		let frameUrl = messageSender.url ?? senderTopUrl;
		const frameId = messageSender.frameId ?? 0;
		const senderDocumentId = messageSender.documentId;
		try {
			const currentFrame = await browser.webNavigation.getFrame({
				tabId,
				frameId
			});
			const currentDocumentId = currentFrame?.documentId;
			if (!currentFrame?.url || senderDocumentKey(currentFrame.url) !== senderDocumentKey(frameUrl) || senderDocumentId && currentDocumentId && senderDocumentId !== currentDocumentId) return { ok: true };
			frameUrl = currentFrame.url;
		} catch {
			if (!senderDocumentKey(frameUrl)) return { ok: true };
		}
		const currentItems = normalizeMediaReport(payload, frameUrl).filter((item) => {
			try {
				return !shouldExcludeHost(new URL(item.url).hostname, isWebStoreBuild());
			} catch {
				return false;
			}
		}).map((item) => ({
			...item,
			pageUrl: currentTab.url,
			pageTitle: currentTab.title?.trim() || item.pageTitle || currentTab.url,
			...frameUrl !== currentTab.url ? { frameUrl } : {}
		}));
		if (currentItems.length === 0) return { ok: true };
		let latestTab;
		try {
			latestTab = await browser.tabs.get(tabId);
		} catch {
			return { ok: true };
		}
		if (!latestTab.url || senderDocumentKey(latestTab.url) !== senderDocumentKey(currentTab.url)) return { ok: true };
		mediaCredentialStore.retainPage(tabId, currentTab.url);
		await mediaStore.retainPage(tabId, currentTab.url);
		await mediaStore.addForPage(tabId, currentTab.url, currentItems);
	}
	return { ok: true };
});
bus.on("bg.scanActiveTab", async () => {
	const [tab] = await browser.tabs.query({
		active: true,
		currentWindow: true
	});
	const tabId = tab?.id;
	const selectionKinds = manager.getServerCapabilities()?.selectionKinds ?? ["direct"];
	if (typeof tabId !== "number") return {
		media: [],
		selectionKinds
	};
	if (tab?.url) await mediaStore.retainPage(tabId, tab.url);
	else await mediaStore.clear(tabId);
	try {
		await browser.scripting.executeScript({
			target: {
				tabId,
				allFrames: true
			},
			files: [sniffer_relay_default]
		});
		if (!isWebStoreBuild() && false);
		else await browser.scripting.executeScript({
			target: {
				tabId,
				allFrames: true
			},
			world: "MAIN",
			files: [sniffer_entry_default]
		});
		await new Promise((resolve) => setTimeout(resolve, 75));
	} catch {}
	return {
		media: await mediaStore.get(tabId),
		selectionKinds
	};
});
bus.on("bg.getMediaThumbnail", async (request) => mediaThumbnailBroker.get(typeof request === "object" && request !== null ? request.mediaKey : void 0));
bus.on("bg.submitMedia", async (request) => {
	if (typeof request !== "object" || request === null || typeof request.mediaKey !== "string") throw new Error(MEDIA_SUBMIT_ERROR.invalidRequest);
	try {
		const [activeTab] = await browser.tabs.query({
			active: true,
			currentWindow: true
		});
		const media = await resolveStoredMedia(request.mediaKey, async () => activeTab, mediaStore);
		if (!(manager.getServerCapabilities()?.selectionKinds ?? ["direct"]).includes(media.kind)) throw new Error("unsupported media selection");
		if (typeof activeTab?.id !== "number") throw new Error("no active tab");
		const primaryObservation = mediaCredentialStore.get(activeTab.id, media.pageUrl, media.url);
		const primaryCredentials = await buildResourceCredentials({
			url: media.url,
			...primaryObservation ? { observation: primaryObservation } : {},
			userAgent: navigator.userAgent
		});
		const audioObservation = media.audioUrl ? mediaCredentialStore.get(activeTab.id, media.pageUrl, media.audioUrl) : void 0;
		const audioCredentials = media.audioUrl ? await buildResourceCredentials({
			url: media.audioUrl,
			...audioObservation ? { observation: audioObservation } : {},
			userAgent: navigator.userAgent
		}) : {
			cookies: [],
			headers: {}
		};
		const [currentTab] = await browser.tabs.query({
			active: true,
			currentWindow: true
		});
		if (currentTab?.id !== activeTab.id || !currentTab.url || new URL(currentTab.url).toString() !== media.pageUrl) throw new Error("active tab changed");
		const params = applyCallerIdempotencyKey(buildMediaSubmitParams(media, primaryCredentials.cookies, primaryCredentials.headers, audioCredentials), request);
		return await manager.submitDownload(params);
	} catch (error) {
		throw toSafeMediaSubmitError(error);
	}
});
bus.on("bg.resolvePageDownload", async (request) => {
	try {
		const [tab] = await browser.tabs.query({
			active: true,
			currentWindow: true
		});
		if (!tab?.url) throw new Error("no active tab");
		if (!isResolvableVideoPage(tab.url, isWebStoreBuild()).resolvable) throw new Error("page not resolvable");
		const cookies = await capturePageCookies({
			url: tab.url,
			...tab.cookieStoreId ? { storeId: tab.cookieStoreId } : {},
			browser: "firefox",
			api: browser.cookies
		});
		const [currentTab] = await browser.tabs.query({
			active: true,
			currentWindow: true
		});
		if (!currentTab || currentTab.id !== tab.id || !currentTab.url || new URL(currentTab.url).toString() !== new URL(tab.url).toString()) throw new Error("active tab changed");
		const headers = {
			Referer: `${new URL(tab.url).origin}/`,
			"User-Agent": navigator.userAgent
		};
		const params = applyCallerIdempotencyKey(buildMediaSubmitParams({
			kind: "direct",
			url: tab.url,
			pageUrl: tab.url,
			pageTitle: tab.title ?? tab.url,
			detectedAt: Date.now()
		}, cookies, headers), request);
		return await manager.submitDownload(params);
	} catch (error) {
		throw toSafeMediaSubmitError(error);
	}
});
bus.attach();
var pairNudge = new PairNudge({ notify });
var refreshMenuTitle = async () => {
	try {
		await endpointLifecycleReady;
	} catch {
		return;
	}
	updateContextMenuTitle(await pairingEndpointService.isActivePaired());
};
registerContextMenu({
	getConfig: async () => {
		await endpointLifecycleReady;
		return takeoverConfigStore.get();
	},
	run: async (target) => {
		await endpointLifecycleReady;
		if (decideTakeover(await takeoverConfigStore.get(), target) !== "motrix") return;
		const guard = await handoffEndpoints.capture(target.origin);
		if (guard === null) return;
		await runHandoff(target, makeOps({
			manager,
			guard,
			isPaired: () => pairingEndpointService.isActivePaired(),
			gate,
			nudge: pairNudge,
			cancelNative: async () => {},
			fallbackToBrowser: () => downloadHttpInBrowser(target.url),
			confirmSensitive: async () => false,
			notify
		}));
	}
});
refreshMenuTitle();
manager.onStateChange(() => {
	refreshMenuTitle();
});
browser.storage.onChanged.addListener(makeLocaleChangeHandler(() => {
	refreshMenuTitle();
	badge.refresh();
}));
browser.storage.onChanged.addListener(makeLogLevelChangeHandler());
initI18n().then(() => {
	refreshMenuTitle();
	badge.refresh();
});
initLogLevel();
registerFirefoxInterception({
	captureGuard: () => handoffEndpoints.capture("auto"),
	getConfig: async () => {
		await endpointLifecycleReady;
		return takeoverConfigStore.get();
	},
	manager,
	isPaired: () => pairingEndpointService.isActivePaired(),
	gate,
	nudge: pairNudge,
	notify,
	selfExtensionId: extensionId
});
if (typeof browser.alarms !== "undefined") {
	const KEEPALIVE = "motrix.keepalive";
	const syncKeepalive = (s) => {
		if (s === "connected") browser.alarms.create(KEEPALIVE, { periodInMinutes: .5 });
		else browser.alarms.clear(KEEPALIVE);
	};
	manager.onStateChange(syncKeepalive);
	syncKeepalive(manager.getState());
	browser.alarms.onAlarm.addListener((alarm) => {
		if (alarm.name === KEEPALIVE) log.info("keepalive tick; state:", manager.getState());
	});
}
//#endregion

//# sourceMappingURL=service-worker.ts-BWy_qGr7.js.map